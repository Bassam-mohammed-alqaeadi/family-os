# Onboarding Journey — From App Install to First Productive Use

> **Flow ID:** FLOW-01  
> **Journey IDs covered:** J-F01 (Father onboarding), J-M01 (Mother joining), J-C01 (Child first-time setup)  
> **Criticality:** P0 — First impression, activation, and safety configuration  
> **Date:** 2026-09-13  

---

## Table of Contents

1. [Journey Overview](#1-journey-overview)
2. [Phase 1: App Install & Registration](#2-phase-1-app-install--registration)
3. [Phase 2: Family Creation](#3-phase-2-family-creation)
4. [Phase 3: Member Invitation](#4-phase-3-member-invitation)
5. [Phase 4: Child Device Linking & Permission Grant](#5-phase-4-child-device-linking--permission-grant)
6. [Phase 5: Monitoring Configuration](#6-phase-5-monitoring-configuration)
7. [Phase 6: Educational Setup](#7-phase-6-educational-setup)
8. [Phase 7: Mother Joins the Family](#8-phase-7-mother-joins-the-family)
9. [Phase 8: First Productive Use](#9-phase-8-first-productive-use)
10. [Complete ASCII Flow Diagram](#10-complete-ascii-flow-diagram)
11. [Critical Pain Points & Design Opportunities](#11-critical-pain-points--design-opportunities)
12. [Edge Cases & Fallback Flows](#12-edge-cases--fallback-flows)
13. [Onboarding Success Metrics](#13-onboarding-success-metrics)

---

## 1. Journey Overview

The onboarding journey is the single most important flow for activation — if a family doesn't complete onboarding, no monitoring, education, or communication feature has value. This journey covers the full path from app install through first productive use, spanning all three personas: **Father (admin)** creates the family and configures everything, **Mother (limited_admin)** joins via invite, and **Child (child)** is linked and set up.

### Journey Architecture

```
FATHER LEADS                        MOTHER JOINS                    CHILD IS LINKED
══════════════                      ════════════                    ═══════════════
Phase 1: Install & Register         Phase 7: Receive Invite         Phase 4: Pair Device
Phase 2: Create Family              (from Phase 3)                  (from Phase 3)
Phase 3: Invite Members                                             Grant Permissions
Phase 5: Configure Monitoring                                       (father-guided)
Phase 6: Educational Setup                                          
Phase 8: First Productive Use       (after permission config)
```

### Key Metrics

| Metric | Target | Measurement |
|--------|--------|-------------|
| Onboarding completion rate | >70% | Install → first productive use within 48h |
| Time to first monitoring active | <30 min | Install → first child device linked + rules set |
| Time to first alert | <24h | First content/screen time alert received |
| Mother join rate | >80% | Father sends invite → mother joins within 48h |
| Child device pairing success | >90% | Pairing code entered → permissions granted |
| Permission grant completion | >85% | All critical permissions granted (location, accessibility) |

### Saudi Cultural Context

- **Phone number:** +966 Saudi mobile; SMS OTP is the primary verification
- **Payment:** mada (مدى) debit cards, Apple Pay, STC Pay — credit cards less common
- **Calendar:** Hijri (Islamic) calendar is the cultural reference; Gregorian is secondary
- **School week:** Sunday–Thursday; weekend is Friday–Saturday
- **Prayer times:** Structure the day; app notifications should respect prayer times
- **Language:** Arabic-first; RTL layout throughout; no English-first fallback
- **Family structure:** Father is head of household; mother has partner role; children are under authority

## 2. Phase 1: App Install & Registration

**Actor:** Abu Khalid (Father)  
**Goal:** Get the app installed and his account created  
**Duration:** 3-5 minutes  

### Step-by-Step Flow

| Step | Actor | Action | System Response | Screen ID | Emotion | Error / Edge Case | Success Criteria |
|------|-------|--------|----------------|-----------|---------|-------------------|------------------|
| 1.1 | Father | Opens App Store / Google Play, searches "حماية العائلة" or "Family OS" | Search results show app listing with Arabic screenshots, 4.5+ rating | Store listing | 😐 Neutral | App not found in search — SEO/ASO issue | App appears in top 3 results for "حماية العائلة" |
| 1.2 | Father | Taps "تثبيت" (Install) | App downloads (~45 MB), installs, icon appears on home screen | Store download | 😐 Neutral | Download fails (weak connection); large for mobile data | Show size: "~45 ميجابايت"; resume on Wi-Fi option |
| 1.3 | Father | Taps app icon to launch | Splash screen: Arabic logo, tagline "نظام عائلتي الذكي", loading animation (2s) | SCR-ONB-01 (Splash) | 😊 Happy | App crashes on launch (rare; old device) | Crash report + "أعد المحاولة" button |
| 1.4 | Father | Sees welcome carousel: 3 slides explaining the platform | Swipeable: "حماية أطفالك" → "تعليم ممتع" → "تواصل عائلي" | SCR-ONB-02 (Welcome) | 😊 Happy | User skips all slides — may not understand value | Last slide has prominent "ابدأ الآن" CTA |
| 1.5 | Father | Taps "ابدأ الآن" (Start Now) | Registration screen: phone number input with +966 pre-filled, "متابعة" button | SCR-ONB-03 (Registration) | 😐 Neutral | Enters wrong number — needs edit | Number validation: must be 9 digits after +966 |
| 1.6 | Father | Enters phone: 0501234567 → auto-formatted as +966 50 123 4567 | Number accepted, "إرسال رمز التحقق" button enabled | SCR-ONB-03 | 😐 Neutral | Number already registered — "هذا الرقم مسجل مسبقاً" with login option | Number format validated and shown clearly |
| 1.7 | Father | Taps "إرسال رمز" → SMS sent with 4-digit OTP | OTP input screen: 4 boxes, auto-focus, 60s countdown, "إعادة إرسال" | SCR-ONB-04 (OTP) | 😐 Neutral | SMS delayed (>30s); user impatient | SMS Retriever API auto-fills on Android; manual entry on iOS |
| 1.8 | Father | Enters OTP: 1 2 3 4 | Verifies OTP → success animation → proceeds to profile setup | SCR-ONB-04 | 😊 Happy | Wrong OTP → "رمز غير صحيح" + remaining attempts (3) | OTP verified within first attempt |
| 1.9 | Father | Enters name: "خالد العتيبي", email (optional): skips | Profile saved; family name auto-detected: "العتيبي" | SCR-ONB-05 (Profile) | 😊 Happy | Name validation: minimum 2 characters | Profile created with name; email optional |
| 1.10 | Father | Sees "تم إنشاء حسابك ✓" confirmation | Transition to Phase 2: Family Creation | SCR-ONB-05b | 😊 Happy | — | Account created, ready for family setup |

### ASCII Flow — Phase 1

```
[App Store] ──> [Search "حماية العائلة"] ──> [Install ~45MB]
                                                      │
                                                      ▼
[Splash Screen SCR-ONB-01] ──(2s)──> [Welcome Carousel SCR-ONB-02]
                                                      │
                                                      ▼
[Registration SCR-ONB-03] ──> Enter +966 50 123 4567
                                                      │
                                                      ▼
[OTP Screen SCR-ONB-04] ──> Enter 1234 ──> ✓ Verified
                                                      │
                                                      ▼
[Profile Setup SCR-ONB-05] ──> Name: خالد العتيبي
                                                      │
                                                      ▼
[Account Created ✓] ──> ───────────────────────> PHASE 2
```

## 3. Phase 2: Family Creation

**Actor:** Abu Khalid (Father)  
**Goal:** Create the family entity and establish himself as admin  
**Duration:** 2-3 minutes  

### Step-by-Step Flow

| Step | Actor | Action | System Response | Screen ID | Emotion | Error / Edge Case | Success Criteria |
|------|-------|--------|----------------|-----------|---------|-------------------|------------------|
| 2.1 | Father | Sees "أنشئ عائلتك" (Create Your Family) screen | Family creation wizard: step indicator "1/5", family name input, role selector | SCR-ONB-06 | 😊 Happy | User expected to join an existing family (was invited) but started wrong flow | "هل لديك دعوة؟ انضم لعائلة موجودة" link at bottom |
| 2.2 | Father | Enters family name: "عائلة العتيبي" | Name accepted, auto-suggests based on profile: "هل تقصد عائلة العتيبي؟" | SCR-ONB-06 | 😊 Happy | Family name contains inappropriate words | Content filter on family name; "يرجى اختيار اسم مناسب" |
| 2.3 | Father | Selects his role: taps "الأب" (Father) card | Role selected with checkmark; "الأب" = admin with all permissions explained | SCR-ONB-07 (Role) | 😐 Neutral | — | Father role = admin confirmed |
| 2.4 | Father | Sees role explanation: "كأب، لديك صلاحيات كاملة: المراقبة، التعليم، الإدارة، الفوترة" | Permission overview card with icons for each category | SCR-ONB-07 | 😐 Neutral | Too much text — user may skip reading | Visual icons with 1-line labels; "تفاصيل" expandable |
| 2.5 | Father | Taps "متابعة" (Continue) | Family entity created in backend; family ID generated; success: "تم إنشاء عائلة العتيبي 🎉" | SCR-ONB-08 | 🤩 Delighted | Backend failure (rare) — "تعذر إنشاء العائلة، حاول مرة أخرى" | Family entity created with admin role assigned |
| 2.6 | Father | Sees "أضف أفراد عائلتك" (Add Family Members) prompt | Transition to Phase 3: Member Invitation | SCR-ONB-08b | 😊 Happy | — | Ready to invite members |

### ASCII Flow — Phase 2

```
PHASE 1 COMPLETE
    │
    ▼
[Create Family SCR-ONB-06]
    │
    ├─ Family name: "عائلة العتيبي"
    │
    ▼
[Select Role SCR-ONB-07]
    │
    ├─ Options: الأب (Father) | الأم (Mother) | الابن (Son) | البنت (Daughter)
    ├─ Selects: الأب ──> admin permissions shown
    │
    ▼
[Family Created ✓ SCR-ONB-08]
    │
    ├─ "تم إنشاء عائلة العتيبي 🎉"
    ├─ Family ID: FAM-XXXXXX
    │
    ▼
PHASE 3: INVITE MEMBERS
```

## 4. Phase 3: Member Invitation

**Actor:** Abu Khalid (Father)  
**Goal:** Send invitations to mother and children  
**Duration:** 3-5 minutes  

### Step-by-Step Flow

| Step | Actor | Action | System Response | Screen ID | Emotion | Error / Edge Case | Success Criteria |
|------|-------|--------|----------------|-----------|---------|-------------------|------------------|
| 3.1 | Father | Sees member invitation screen with two cards: "إضافة الأم" (Add Mother) and "إضافة ابن/ابنة" (Add Child) | Empty family roster with add-member prompts and visual family tree illustration | SCR-ONB-09 | 😊 Happy | — | Clear visual of who needs to be added |
| 3.2 | Father | Taps "إضافة الأم" | Invite method screen: QR code, shareable link, SMS invite — three options with icons | SCR-ONB-10 | 😐 Neutral | Doesn't know which method is best for his wife | Recommended badge on QR: "الأسرع — امسحي الكود بجوالها" |
| 3.3 | Father | Selects QR code option → unique QR code displayed on his screen | QR code with instructions: "افتحي تطبيق العائلة على جوالك وامسحي هذا الكود" | SCR-ONB-10a | 😐 Neutral | QR expires after 24h; if mother delays, code invalid | QR valid 7 days; "إعادة توليد" button if expired |
| 3.4 | Father | Also shares link via WhatsApp as backup: taps "مشاركة عبر واتساب" | Opens WhatsApp share sheet with pre-filled message: "انضمي لعائلتنا على نظام العائلة: [LINK]" | SCR-ONB-10b | 😊 Happy | Link opens in browser, not app (if app not installed) → redirect to app store | Smart link: detects if app installed → opens app; not installed → app store |
| 3.5 | Father | Sees invite status: "أم خالد — بانتظار الانضمام" with pending avatar | Family roster updates: mother shows as "بانتظار" (pending) with gray avatar | SCR-ONB-09b | 😣 Frustrated | No way to remind mother from app — must go to WhatsApp separately | "تذكير" button sends a push to mother if she has app installed, or WhatsApp message if not |
| 3.6 | Father | Taps "إضافة ابن/ابنة" → selects "ابن" (son) | Child invite: enters child's name "خالد", age "12", generates pairing code | SCR-ONB-11 | 😊 Happy | Child doesn't have phone yet (under 8) — "جوال الابن غير متاح" | Age gate: under 8 = "جوال الطفل غير مدعوم حالياً"; 8+ = proceed |
| 3.7 | Father | Enters child phone number (optional — can pair without it) | Phone optional; if provided, SMS invite sent to child; if not, manual pairing only | SCR-ONB-11a | 😐 Neutral | Child's phone is a family phone with no SIM — no SMS | Allow pairing via code only without phone number; "ربط يدوي بالكود" option |
| 3.8 | Father | Sees "كود الربط: 847 291" — 6-digit pairing code displayed prominently | Pairing code screen: large digits, 10-min countdown, "استخدم هذا الكود على جوال خالد" | SCR-ONB-12 | 😰 Anxious | Code expires in 10 min — if setup takes longer, must regenerate | Code valid 30 min; auto-regenerate on expiry; "كود جديد" button |
| 3.9 | Father | Moves to child's phone to complete pairing (Phase 4) | Father's app shows: "بانتظار ربط جوال خالد..." with pulsing animation | SCR-ONB-12a | 😰 Anxious | If child's phone is not available right now, can save and return later | "أكمل لاحقاً" button saves progress; dashboard shows "إعداد غير مكتمل" banner |

### ASCII Flow — Phase 3

```
PHASE 2 COMPLETE
    │
    ▼
[Add Members SCR-ONB-09]
    │
    ├──────────────────────────┐
    ▼                          ▼
[Add Mother SCR-ONB-10]   [Add Child SCR-ONB-11]
    │                          │
    ├─ QR Code                 ├─ Name: خالد, Age: 12
    ├─ Share Link              ├─ Phone: (optional)
    ├─ SMS Invite              │
    │                          ▼
    ▼                    [Pairing Code SCR-ONB-12]
[Status: Pending]             │
    │                          ├─ Code: 847 291
    │                          ├─ Valid: 30 min
    │                          ▼
    │                    [Waiting for Pair...]
    │                          │
    ▼                          ▼
PHASE 7 (Mother joins)    PHASE 4 (Link child device)
```

## 5. Phase 4: Child Device Linking & Permission Grant

**Actor:** Abu Khalid (Father, guiding) + Khalid (Child, executing on his phone)  
**Goal:** Pair the child's device to the family and grant all critical permissions  
**Duration:** 5-10 minutes (most critical and friction-prone phase)  
**Criticality:** If this phase fails, monitoring never activates  

### Step-by-Step Flow

| Step | Actor | Action | System Response | Screen ID | Emotion | Error / Edge Case | Success Criteria |
|------|-------|--------|----------------|-----------|---------|-------------------|------------------|
| 4.1 | Father | Hands Khalid his phone with app installed (or sends install link) | Child app launches with child-themed splash: "أهلاً! 🎮" | SCR-CHD-ONB-01 | 😊 Happy (child) | App not installed on child phone — father must guide install first | Father's app shows "ثبتي التطبيق على جوال خالد أولاً" with install link |
| 4.2 | Child | Enters phone number (or taps "ليس لدي رقم" if no SIM) | Child registration: phone + OTP, or skip with manual pairing | SCR-CHD-ONB-02 | 😐 Neutral | No SIM card — can't receive SMS; must use code-only flow | Code-only path: skip registration, go straight to pairing code entry |
| 4.3 | Child | Enters pairing code: 847 291 (from father's screen) | Code verified → both phones show pairing animation: "جاري الربط..." with progress | SCR-CHD-ONB-03 | 😰 Anxious | Wrong code entered → "الكود غير صحيح" + retry; expired code → "انتهت صلاحية الكود" | Code matches; both devices show "تم الربط بنجاح ✓" |
| 4.4 | Child | Sees profile setup: name pre-filled "خالد", role "ابن", avatar picker | Child profile: name (editable), avatar selection (6 defaults), grade selector | SCR-CHD-ONB-04 | 🤩 Delighted | Child wants a cool avatar but they're all basic at Level 1 | Show locked avatars with "افتح عند المستوى 5" — creates motivation |
| 4.5 | Child | Selects grade: "أول متوسط" (1st year middle school) | Grade selection auto-configures curriculum: Saudi Ministry of Education subjects | SCR-CHD-ONB-05 | 😐 Neutral | Grade doesn't match available options — between systems | Include both "المرحلة الابتدائية" and "المرحلة المتوسطة" with grade sub-selections |
| 4.6 | System | Auto-displays permission grant sequence — first: Location | Permission pre-card (Arabic): "نحتاج الموقع حتى لو ضعت، يقدر أبوك يدل عليك ويساعدك" → Android system dialog | SCR-CHD-ONB-06 | 😣 Frustrated | Child taps "رفض" (deny) — monitoring can't work without location | After deny: "بدون الموقع، لا يقدر أبوك يعرف وينك في حالة الطوارئ. تأكد؟" re-prompt |
| 4.7 | Child | Grants location access: "السماح دائماً" (Always allow) | Location permission granted; system proceeds to next permission | SCR-CHD-ONB-06b | 😣 Frustrated | Android 12+ may show "Approximate vs Precise" — child may pick approximate | Explain: "اختار 'دقيق' حتى يقدر أبوك يوصلك بالضبط" |
| 4.8 | System | Next permission: Accessibility Service (for app monitoring) | Pre-card: "هذا يحميك من التطبيقات الضارة — يراقب أبوك وين تستخدم جوالك" → Android accessibility settings | SCR-CHD-ONB-07 | 😣 Frustrated | Accessibility settings are deep in Android settings — child gets lost in system menus | Step-by-step visual guide: "اذهب إلى الإعدادات > الوصول > نظام العائلة > فعّل" with screenshots |
| 4.9 | Child | Navigates to Settings > Accessibility > Family OS > Enables | Accessibility service enabled; returns to app; system confirms "✓ تم تفعيل خدمة الوصول" | SCR-CHD-ONB-07b | 😰 Anxious | Child can't find the setting — gives up; returns to app without enabling | If not enabled within 2 min: "لم يتم التفعيل. هل تريد المحاولة مرة أخرى؟" with video guide link |
| 4.10 | System | Next: Notification Access (for SOS and alerts) | Pre-card: "هذا يخليك تستقبل تنبيهات العائلة ورسائل الطوارئ" → system dialog | SCR-CHD-ONB-08 | 😐 Neutral | — | Notification access granted |
| 4.11 | System | Next: Device Admin (for screen time lock and Kill Switch) | Pre-card: "هذا يحمي جوالك من التعطيل أو الحذف غير المصرح" → system dialog | SCR-CHD-ONB-09 | 😰 Anxious | Device admin sounds scary to a child — "هل سيتمكن أبوي من تعطيل جوالي؟" | Clarify: "يحمي إعدادات الحماية من الحذف. لن يعطل جوالك بشكل كامل" |
| 4.12 | System | Next: Usage Access (for screen time tracking) | Pre-card: "هذا يحسب وقت استخدامك للجوال — حتى تعرف كم باقي من وقت اللعب" → system dialog | SCR-CHD-ONB-10 | 😐 Neutral | Usage access is another deep settings navigation | Same step-by-step visual guide pattern as accessibility |
| 4.13 | System | Next: Display over other apps (for SOS overlay) | Pre-card: "هذا يخلي زر الطوارئ يظهر فوق كل التطبيقات" → system dialog | SCR-CHD-ONB-11 | 😐 Neutral | — | Overlay permission granted |
| 4.14 | System | Permission summary: all critical permissions granted ✓ | Summary card: green checkmarks for Location ✓, Accessibility ✓, Notifications ✓, Device Admin ✓, Usage ✓, Overlay ✓ | SCR-CHD-ONB-12 | 😌 Relieved | Some permissions skipped (non-critical like usage) — show as "اختياري" | All critical permissions granted (location, accessibility, device admin are mandatory) |
| 4.15 | Child | Sees tutorial: 3 swipeable screens — Learn, Communicate, SOS | Interactive tutorial with mascot; SOS screen is non-skippable | SCR-CHD-ONB-13 | 😊 Happy | Child skips tutorial except SOS (forced) | SOS tutorial completed; child knows how to trigger SOS |
| 4.16 | Child | Learning Home loads: XP 0, Level 1, "ابدأ رحلتك!" banner | Gamified dashboard with first-lesson CTA | SCR-EDU-01 | 🤩 Delighted | — | Child's device fully paired, permissions active, monitoring running |

### Permission Grant Sequence (Critical Path)

```
Location (Always)         ── MANDATORY ── no monitoring without it
    │
    ▼
Accessibility Service    ── MANDATORY ── no app monitoring without it
    │
    ▼
Notification Access      ── MANDATORY ── no SOS/alerts without it
    │
    ▼
Device Admin             ── MANDATORY ── no screen lock/Kill Switch without it
    │
    ▼
Usage Access             ── RECOMMENDED─ screen time works best with it
    │
    ▼
Display over apps        ── MANDATORY ── SOS FAB needs overlay
    │
    ▼
All mandatory granted ────────> MONITORING ACTIVE ✓
```

### ASCII Flow — Phase 4

```
PHASE 3 COMPLETE (Pairing code generated)
    │
    ▼
[Child App Launch SCR-CHD-ONB-01] ──> "أهلاً! 🎮"
    │
    ▼
[Child Registration SCR-CHD-ONB-02]
    │  (phone + OTP OR skip with code-only)
    │
    ▼
[Enter Pairing Code SCR-CHD-ONB-03]
    │  Code: 847 291
    │  ┌─────────────────────────────┐
    │  │  Father's phone:            │
    │  │  "تم الربط بنجاح ✓"          │
    │  │  Child's phone:             │
    │  │  "تم الربط بنجاح ✓"          │
    │  └─────────────────────────────┘
    │
    ▼
[Profile + Avatar SCR-CHD-ONB-04] ──> Grade: أول متوسط
    │
    ▼
[PERMISSION SEQUENCE]
    │
    ├─ 1. Location ────────> "السماح دائماً" ──> ✓
    ├─ 2. Accessibility ───> Settings deep-dive ──> ✓
    ├─ 3. Notifications ───> "سماح" ──> ✓
    ├─ 4. Device Admin ────> "تفعيل" ──> ✓
    ├─ 5. Usage Access ────> Settings deep-dive ──> ✓
    ├─ 6. Overlay ─────────> "سماح" ──> ✓
    │
    ▼
[Permission Summary SCR-CHD-ONB-12] ──> All ✓
    │
    ▼
[Tutorial SCR-CHD-ONB-13] ──> Learn / Communicate / SOS (non-skippable)
    │
    ▼
[Learning Home SCR-EDU-01] ──> XP: 0, Level: 1
    │
    ▼
CHILD DEVICE LINKED ✓ ──> MONITORING ACTIVE ✓
    │
    ▼
RETURN TO FATHER'S PHONE ──> PHASE 5: CONFIGURE MONITORING
```

## 6. Phase 5: Monitoring Configuration

**Actor:** Abu Khalid (Father, on his phone)  
**Goal:** Configure screen time, app rules, web filter, safe zones, content alerts  
**Duration:** 10-15 minutes  
**Context:** Child device is now linked and monitoring is active — but no rules are set yet. Father must configure the guardrails.

### Step-by-Step Flow

| Step | Actor | Action | System Response | Screen ID | Emotion | Error / Edge Case | Success Criteria |
|------|-------|--------|----------------|-----------|---------|-------------------|------------------|
| 5.1 | Father | Returns to his phone; sees "جوال خالد مرتبط ✓ — اضبط المراقبة الآن" | Monitoring setup wizard: 5-step indicator (Screen Time → App Rules → Web Filter → Safe Zones → Content Alerts) | SCR-ADM-ONB-01 | 😊 Happy | Father wants to skip some steps and configure later | "تخطى" (skip) per step allowed but dashboard shows "إعداد غير مكتمل" warning |
| 5.2 | Father | Step 1 — Screen Time: sees slider for daily limit | Interface: weekday slider (0-8h), weekend slider (0-8h), bedtime lock (set 10 PM), school time block | SCR-MON-02 | 😐 Neutral | Doesn't know what's appropriate for a 12-year-old | Recommended badge: "النصيحة: ساعتين باليوم للأعمار 8-13" with one-tap apply |
| 5.3 | Father | Sets: Weekday 2h, Weekend 3h, Bedtime 10 PM, School Time 7 AM-2 PM | Configuration saved; preview shows daily schedule visualization | SCR-MON-02b | 😊 Happy | — | Screen time rules set and applied to child's device immediately |
| 5.4 | Father | Step 2 — App Rules: sees list of apps installed on Khalid's phone | App list with auto-categorization: green (allowed), yellow (conditional), red (flagged); TikTok flagged red "غير مناسب للعمر" | SCR-MON-05 | 😰 Anxious | Discovers apps he didn't know about — emotional moment | Sort flagged apps to top; show one at a time with explanation and block/allow toggle |
| 5.5 | Father | Blocks TikTok, allows Roblox (conditional: 1h max), allows YouTube Kids | Per-app settings saved; child's device enforces rules immediately; Khalid sees "تيك توك محظور من أبوك" if he tries to open | SCR-MON-05b | 😐 Neutral | Child opens a blocked app during father's configuration — races the setup | Rules apply instantly; even mid-configuration, a blocked app is blocked |
| 5.6 | Father | Step 3 — Web Filter: sees 3 preset levels (خفيف/متوسط/صارم) | Filter presets with plain-language descriptions; 29 categories listed under each with toggles | SCR-MON-07 | 😐 Neutral | 29 categories is overwhelming if expanded | Default to "متوسط" (medium) preset; categories collapsible; only expand if father taps "تخصيص" |
| 5.7 | Father | Selects "متوسط" (medium) — reviews categories briefly, doesn't customize | Medium preset applied: blocks violence, adult content, gambling, drugs; allows social media (age-gated), news, education | SCR-MON-07b | 😊 Happy | — | Web filter active with medium preset |
| 5.8 | Father | Step 4 — Safe Zones: map opens, auto-detects current location as "البيت" (Home) | Map with auto-suggested home zone (200m radius); prompt to add school, mosque, other | SCR-MON-04 | 😊 Happy | Home detection is wrong (father at work, not home) | "هل هذا بيتك؟" confirmation; if no, manual address entry with search |
| 5.9 | Father | Adds Home (auto), School: "متوسطة ابن العميس — حي النرجس", Mosque: "جامع الرحمن", Grandfather: "بيت جدي" | Map shows 4 safe zones with colored circles; each has name, radius, arrival/departure notification toggles | SCR-MON-04b | 😊 Happy | School address not found in map search | Manual pin-drop option: "ضع العلامة على الموقع على الخريطة" |
| 5.10 | Father | Enables arrival/departure notifications for all zones | Notification preferences saved; father will receive push when child enters/exits each zone | SCR-MON-04c | 😊 Happy | Too many notifications if all zones have both arrival + departure | Default: arrival only for all zones; departure only for home and school |
| 5.11 | Father | Step 5 — Content Alerts: sees 29 content categories with toggles | Category list with descriptions: "عنف" (violence), "محتوى للبالغين" (adult), "أسلحة" (weapons), "مخدرات" (drugs), etc. | SCR-MON-08 | 😐 Neutral | Overwhelming list; father doesn't understand all categories | Group into 5 super-categories with expand; "العنف والمخدرات والمحتوى للبالغين" → expand for detail |
| 5.12 | Father | Accepts default alert categories (all 29 enabled at medium sensitivity) | Alert configuration saved; system will notify father when child encounters flagged content | SCR-MON-08b | 😊 Happy | Alert sensitivity too high = false positives; too low = missed threats | Medium sensitivity default; after 2 weeks, AI suggests tuning based on false positive rate |
| 5.13 | Father | Sees monitoring setup summary: "✓ المراقبة مفعّلة — 5 خطوات مكتملة" | Summary card: all 5 steps green; child's device now fully monitored | SCR-ADM-ONB-02 | 😌 Relieved | — | All monitoring rules configured and active |

### ASCII Flow — Phase 5

```
CHILD DEVICE LINKED ✓
    │
    ▼
[Monitoring Setup Wizard SCR-ADM-ONB-01]
    │  Steps: Screen Time → Apps → Web Filter → Safe Zones → Alerts
    │
    ├── Step 1: Screen Time SCR-MON-02
    │      └─ Weekday: 2h, Weekend: 3h, Bedtime: 10 PM, School: 7AM-2PM
    │
    ├── Step 2: App Rules SCR-MON-05
    │      └─ TikTok: BLOCKED, Roblox: 1h conditional, YouTube Kids: ALLOWED
    │
    ├── Step 3: Web Filter SCR-MON-07
    │      └─ Preset: Medium (متوسط)
    │
    ├── Step 4: Safe Zones SCR-MON-04
    │      └─ Home, School, Mosque, Grandfather's house
    │      └─ Arrival notifications ON for all
    │
    ├── Step 5: Content Alerts SCR-MON-08
    │      └─ All 29 categories at medium sensitivity
    │
    ▼
[Monitoring Summary ✓ SCR-ADM-ONB-02]
    │  "✓ المراقبة مفعّلة"
    │
    ▼
PHASE 6: EDUCATIONAL SETUP
```

## 7. Phase 6: Educational Setup

**Actor:** Abu Khalid (Father, on his phone)  
**Goal:** Set up Khalid's educational profile with correct subjects and learning preferences  
**Duration:** 3-5 minutes  

### Step-by-Step Flow

| Step | Actor | Action | System Response | Screen ID | Emotion | Error / Edge Case | Success Criteria |
|------|-------|--------|----------------|-----------|---------|-------------------|------------------|
| 6.1 | Father | Sees "إعداد التعليم" (Educational Setup) prompt after monitoring | Educational setup wizard: grade confirmation, subject selection, learning preferences | SCR-EDU-ONB-01 | 😐 Neutral | Father wants to skip — "أكمل لاحقاً" available but dashboard shows reminder | Grade auto-selected from Phase 4 child setup (أول متوسط) |
| 6.2 | Father | Confirms grade: "أول متوسط" — system auto-populates Saudi curriculum subjects | Subject list appears: رياضيات (Math), علوم (Science), لغة عربية (Arabic), دراسات إسلامية (Islamic Studies), لغة إنجليزية (English), اجتماعيات (Social Studies), تلاوة قرآن (Quran Recitation) | SCR-EDU-ONB-02 | 😊 Happy | Subjects don't match child's actual school curriculum | "هل هذه هي مواد خالد؟" confirmation with add/remove/edit capability |
| 6.3 | Father | Reviews subjects, adds "تربية بدنية" (PE) and "حاسب آلي" (Computer Science) | Custom subjects added; total 9 subjects configured | SCR-EDU-ONB-02b | 😊 Happy | — | Subject list matches child's school curriculum |
| 6.4 | Father | Sets learning preferences: difficulty "متوسط" (medium), daily study goal "30 دقيقة" (30 min) | Preference sliders: difficulty (سهل/متوسط/صعب), daily goal (15-120 min), preferred study time (بعد العصر/بعد المغرب) | SCR-EDU-ONB-03 | 😐 Neutral | Father doesn't know what difficulty is right | AI recommendation: "بناءً على عمر خالد، ننصح بمستوى متوسط و30 دقيقة يومياً" |
| 6.5 | Father | Enables Quran memorization: selects "سورة الكهف" as current focus | Quran module activated: surah selector, memorization tracker, recitation analysis, review schedule | SCR-EDU-ONB-04 | 😊 Happy | Father doesn't know which surah Khalid is currently memorizing | "اسأل خالد" prompt: child can select surah from their app; or father selects from list |
| 6.6 | Father | Enables AI Tutor: "المساعد الذكي — مفعّل" | AI Tutor toggle: provides on-demand help in lessons, quizzes, and homework | SCR-EDU-ONB-05 | 😊 Happy | Father concerned about AI accuracy for Islamic content | Note: "المساعد الذكي مدرّب على المنهج السعودي ويتوافق مع المعايير الشرعية" |
| 6.7 | Father | Sees educational setup summary: "✓ التعليم مفعّل — 9 مواد، 30 دقيقة/يوم" | Summary: subjects, daily goal, Quran focus, AI tutor active | SCR-EDU-ONB-06 | 😊 Happy | — | Educational profile configured; child's Learning Home now populated with content |
| 6.8 | Father | Sees "إعداد مكتمل 🎉 — عائلتك جاهزة" final onboarding screen | Onboarding complete: all 6 phases done; dashboard accessible; first alert expected within 24h | SCR-ADM-ONB-03 | 🤩 Delighted | — | Onboarding complete; father enters normal use phase |

### ASCII Flow — Phase 6

```
PHASE 5 COMPLETE
    │
    ▼
[Educational Setup SCR-EDU-ONB-01]
    │
    ├─ Grade: أول متوسط (confirmed from Phase 4)
    │
    ├─ Subjects (auto-populated + customized):
    │    ├─ رياضيات    علوم    لغة عربية
    │    ├─ دراسات إسلامية    لغة إنجليزية    اجتماعيات
    │    ├─ تلاوة قرآن    تربية بدنية    حاسب آلي
    │
    ├─ Preferences:
    │    ├─ Difficulty: متوسط (medium)
    │    ├─ Daily goal: 30 minutes
    │    └─ Preferred time: بعد العصر (after Asr)
    │
    ├─ Quran: سورة الكهف (memorization focus)
    │
    ├─ AI Tutor: ENABLED
    │
    ▼
[Setup Complete 🎉 SCR-ADM-ONB-03]
    │  "عائلتك جاهزة"
    │
    ▼
PHASE 7: MOTHER JOINS (if not already)
    │
PHASE 8: FIRST PRODUCTIVE USE
```

## 8. Phase 7: Mother Joins the Family

**Actor:** Umm Khalid (Mother) + Abu Khalid (Father, permission config)  
**Goal:** Mother installs app, joins family, father configures her limited_admin permissions  
**Duration:** 10-15 minutes (can happen in parallel with Phase 5-6 or after)  
**Context:** Father sent invite in Phase 3; mother responds at her convenience.

### Step-by-Step Flow

| Step | Actor | Action | System Response | Screen ID | Emotion | Error / Edge Case | Success Criteria |
|------|-------|--------|----------------|-----------|---------|-------------------|------------------|
| 7.1 | Mother | Opens WhatsApp, sees father's message with invite link/QR | Link/QR received; mother taps link | WhatsApp | 😐 Neutral | Link expired (if >7 days since sent) → "انتهت صلاحية الدعوة — اطلب من أبوك إرسال جديد" | Invite link/QR valid and accessible |
| 7.2 | Mother | Taps link → redirected to Google Play (app not installed) → installs | App downloads, installs, launches | Google Play, SCR-ONB-01 | 😐 Neutral | Download on mobile data — cost concern | Show app size; "تثبيت لاحقاً على Wi-Fi" option |
| 7.3 | Mother | App launches → splash → welcome carousel → "ابدأ" | Same welcome flow as father, but registration detects invite token | SCR-ONB-02 | 😊 Happy | — | Mother reaches registration |
| 7.4 | Mother | Enters phone: +966 55 987 6543 → SMS OTP → verified | Registration detects family invite token from link; shows "أنت مدعوة لعائلة العتيبي" | SCR-ONB-03/04 | 😊 Happy | Phone number doesn't match what father invited — "هل أنت نورة؟ تأكدي مع أبوك" | Registration auto-links to family entity |
| 7.5 | Mother | Enters name "نورة" (pre-filled from invite), selects role "الأم" | Role auto-selected as Mother from invite; confirmation | SCR-ONB-05 | 😊 Happy | — | Mother's profile created and linked to family |
| 7.6 | System | Shows "تم انضمامك إلى عائلة العتيبي ✓" — but dashboard is pending permissions | Family join confirmation; "بانتظار إعداد الصلاحيات من الأب" placeholder screen | SCR-ADM-ONB-04 | 😐 Neutral | Father hasn't seen the notification yet — mother waits | Real-time notification to father: "نورة انضمت — اضبط صلاحياتها" |
| 7.7 | Father | Receives push notification: "أم خالد انضمت للعائلة ✓ — اضبط صلاحياتها الآن" | Father's app shows permission configuration screen for mother | SCR-ADM-04 | 😐 Neutral | Father is busy (at work) — delays permission config | Mother sees estimated wait: "قد يستغرق أبوك بضع ساعات"; gentle reminder to father after 2h |
| 7.8 | Father | Opens permission config for mother: sees toggle groups | limited_admin permission panel: categories with toggles — Communications (all ON), Monitoring (location ON, web filter OFF, Kill Switch OFF), Education (all ON), Administration (billing OFF, members OFF, devices OFF) | SCR-ADM-04b | 😐 Neutral | Doesn't understand what each toggle means | Preset: "صلاحيات الأم" default applies sensible defaults; one-tap "تطبيق الإعدادات الموصى بها" |
| 7.9 | Father | Reviews recommended defaults: Location ✓, Study Progress ✓, Calendar ✓, Tasks ✓, Shopping ✓, SOS alerts ✓, Web Filter ✗, Kill Switch ✗, Billing ✗ | Preset applied; father can customize if needed | SCR-ADM-04c | 😊 Happy | Wants to give mother more access — toggles web filter ON | All toggles saved; mother's app refreshes automatically |
| 7.10 | Mother | App refreshes: dashboard appears with limited_admin features | Today Dashboard (limited): children's location, calendar, tasks, shopping, education visible; monitoring advanced controls hidden | SCR-ADM-09 | 🤩 Delighted | Hidden features look like missing features — confusion | "متاح للأب فقط" subtle labels on admin-only areas |
| 7.11 | Mother | First action: opens calendar, sees existing events from father's setup | Calendar shows: school times, prayer time overlay, empty slots for family events | SCR-COM-04 | 😊 Happy | — | Mother is productively using the platform |

### ASCII Flow — Phase 7

```
PHASE 3 (invite sent) ──────────────────────────────────────────> (time passes)
    │
    ▼
[Mother's WhatsApp] ──> Taps invite link
    │
    ▼
[Google Play] ──> Install ──> Launch
    │
    ▼
[Splash + Welcome SCR-ONB-01/02]
    │
    ▼
[Registration SCR-ONB-03]
    │  ┌────────────────────────────────┐
    │  │ Auto-detected: عائلة العتيبي     │
    │  │ "أنت مدعوة لعائلة العتيبي"       │
    │  └────────────────────────────────┘
    │
    ▼
[Profile: نورة, role: الأم SCR-ONB-05]
    │
    ▼
[Joined Family ✓ SCR-ADM-ONB-04]
    │  "بانتظار إعداد الصلاحيات من الأب"
    │         ┌──────────────────────────────┐
    │         │ PUSH TO FATHER:              │
    │         │ "نورة انضمت — اضبط صلاحياتها" │
    │         └──────────────────────────────┘
    │                        │
    │                        ▼
    │              [Father: Permission Config SCR-ADM-04]
    │                        │
    │                        ├─ Preset: "صلاحيات الأم"
    │                        ├─ Location: ON
    │                        ├─ Study Progress: ON
    │                        ├─ Calendar/Tasks/Shopping: ON
    │                        ├─ SOS alerts: ON
    │                        ├─ Web Filter: OFF (or ON if father chooses)
    │                        ├─ Kill Switch: OFF
    │                        └─ Billing: OFF
    │                        │
    │                        ▼
    │              [Permissions Applied ✓]
    │                        │
    ▼────────────────────────┘
    │
    ▼
[Mother's Dashboard SCR-ADM-09] ──> limited_admin view loaded
    │
    ▼
[First Action: Calendar SCR-COM-04] ──> Productive use ✓
```

## 9. Phase 8: First Productive Use

**Actor:** All three personas  
**Goal:** Each persona achieves their first meaningful action — the "aha" moment  
**Duration:** First 24 hours after onboarding completion  
**Context:** Onboarding is technically complete, but activation requires the first real value experience.

### First Productive Use by Persona

#### Father — First Alert (The "Aha" Moment)

| Step | Actor | Action | System Response | Screen ID | Emotion | Error / Edge Case | Success Criteria |
|------|-------|--------|----------------|-----------|---------|-------------------|------------------|
| 8F.1 | System | Next day, 3:15 PM — Khalid attempts to open TikTok (blocked in Phase 5) | App blocked by rules; alert generated and pushed to father | SCR-MON-05b (child) | — | — | Alert generated within 5 seconds of block |
| 8F.2 | Father | Receives push: "🚨 خالد حاول فتح تيك توك — تم الحجب" | Push notification with app name, action (blocked), timestamp, child's location | Push notification | 😰 Anxious | Father's phone on silent — misses notification | SOS-tier alerts override silent; content alerts use standard notification |
| 8F.3 | Father | Taps notification → opens Today Dashboard with alert highlighted | Dashboard opens, alert card at top with full context: app, time, location, action taken, one-tap "تواصل مع خالد" | SCR-ADM-09 | 😌 Relieved | — | Father sees value: "The app caught something I would have missed" |
| 8F.4 | Father | Taps "تواصل مع خالد" → 1:1 chat opens → sends "خالد، ليش تحاول تفتح تيك توك؟" | 1:1 chat with Khalid, message sent, child receives notification | SCR-COM-02 | 😐 Neutral | Child doesn't respond immediately — father waits | Message delivered; child notified; father has taken action |
| 8F.5 | Father | Closes app feeling informed and in control | — | — | 😌 Relieved | — | **Father activation achieved: first alert received and acted upon** |

#### Mother — First Family Event (The "Aha" Moment)

| Step | Actor | Action | System Response | Screen ID | Emotion | Error / Edge Case | Success Criteria |
|------|-------|--------|----------------|-----------|---------|-------------------|------------------|
| 8M.1 | Mother | Opens app morning after joining → Today Dashboard | Dashboard: calendar shows "خالد - مدرسة 7:00", tasks empty, meal planner empty | SCR-ADM-09 | 😐 Neutral | Feels empty — "what do I do here?" | Onboarding tooltip: "ابدئي بإضافة مهمة أو وجبة اليوم" with arrow pointing to + button |
| 8M.2 | Mother | Opens Communicate > Calendar → adds event: "موعد طبيب أسنان - خالد - الثلاثاء 4 م" | Calendar event created, Hijri date: 15 صفر 1448 هـ, Gregorian: 23 سبتمبر 2026, synced to all family | SCR-COM-04 | 😊 Happy | Date picker defaults to Gregorian — mother prefers Hijri | Hijri default with Gregorian subtitle; preference remembered |
| 8M.3 | Mother | Opens Shopping List → adds: "حليب، خبز، طماطم، دجاج" → shares with father | Shopping list created, auto-categorized, father receives notification "نورة أضافت لقائمة التسوق" | SCR-COM-07 | 😊 Happy | — | **Mother activation achieved: family organization value demonstrated** |
| 8M.4 | Mother | 2:00 PM — receives push: "خالد وصل إلى المنزل ✓" | Geofence notification: child entered home safe zone | Push | 😌 Relieved | — | Mother experiences proactive safety awareness without checking |

#### Child — First Lesson & XP (The "Aha" Moment)

| Step | Actor | Action | System Response | Screen ID | Emotion | Error / Edge Case | Success Criteria |
|------|-------|--------|----------------|-----------|---------|-------------------|------------------|
| 8C.1 | Child | Opens app after school → Learning Home: "ابدأ أول درس واربح 50 نقطة!" | First-lesson CTA prominent; daily quests show: "اكمل درس علوم" (50 XP) | SCR-EDU-01 | 😊 Happy | — | Child engages with learning content |
| 8C.2 | Child | Taps "ابدأ" → Science lesson: Plants unit, interactive with animations | Lesson player: 5-minute interactive content, checkpoint questions, progress bar | SCR-EDU-02 | 😊 Happy | Lesson too easy/hard for level | Adaptive difficulty adjusts in real-time based on checkpoint answers |
| 8C.3 | Child | Completes lesson → +50 XP, level-up animation, confetti, badge "الخطوة الأولى 🌱" | XP awarded, badge unlocked, level-up celebration, progress ring animates | SCR-EDU-14 | 🤩 Delighted | — | **Child activation achieved: gamified learning creates dopamine loop** |
| 8C.4 | Child | Taps "مهام جديدة" → sees next quest: "حفظ قرآن — 3 آيات" → starts Quran review | Quran module opens: surah selector, verse display, recite button | SCR-EDU-03b | 😐 Neutral | — | Child continues to next activity without prompting |
| 8C.5 | Child | Family chat notification: mom sent "ما شاء الله، خلصت درس! 👏" | 1:1 message from mother with praise; child feels seen and rewarded | SCR-COM-02 | 🤩 Delighted | — | Positive reinforcement loop: learn → earn XP → parent notices → motivation increases |

### ASCII Flow — Phase 8

```
ONBOARDING COMPLETE
    │
    ├── FATHER'S FIRST ALERT
    │     [3:15 PM] Khalid tries TikTok ──> BLOCKED ──> Alert to Father
    │     ──> Push: "🚨 حاول فتح تيك توك" ──> Dashboard with context
    │     ──> "تواصل مع خالد" ──> 1:1 chat
    │     ──> 😌 "The app caught something I'd have missed" ✓ ACTIVATED
    │
    ├── MOTHER'S FIRST EVENT
    │     [Morning] Dashboard ──> Calendar: add dentist appointment
    │     ──> Shopping list: add items ──> Share with father
    │     ──> [2 PM] Push: "خالد وصل للبيت ✓"
    │     ──> 😌 "I know they're safe without checking" ✓ ACTIVATED
    │
    └── CHILD'S FIRST LESSON
          [After school] Learning Home ──> "ابدأ أول درس"
          ──> Science: Plants (5 min) ──> +50 XP ──> LEVEL UP! 🎉
          ──> Badge: "الخطوة الأولى 🌱"
          ──> Mom sends praise in chat ──> 🤩 "Learning is fun!" ✓ ACTIVATED

ALL THREE PERSONAS ACTIVATED ──> ONBOARDING JOURNEY COMPLETE ✓
```

## 10. Complete ASCII Flow Diagram

```
╔══════════════════════════════════════════════════════════════════════════════════╗
║                    COMPLETE ONBOARDING JOURNEY — ALL PHASES                       ║
╠══════════════════════════════════════════════════════════════════════════════════╣
║                                                                                  ║
║  ┌─ PHASE 1: INSTALL & REGISTER (Father)                                        ║
║  │                                                                              ║
║  │  [App Store] → [Search] → [Install ~45MB] → [Splash SCR-ONB-01]             ║
║  │       → [Welcome Carousel SCR-ONB-02] → [Registration SCR-ONB-03]           ║
║  │       → [+966 50 123 4567] → [OTP SCR-ONB-04] → [1234] → ✓ Verified         ║
║  │       → [Profile: خالد العتيبي SCR-ONB-05] → ✓ Account Created              ║
║  │                                                                              ║
║  ├─ PHASE 2: FAMILY CREATION (Father)                                           ║
║  │                                                                              ║
║  │  [Create Family SCR-ONB-06] → Name: "عائلة العتيبي"                          ║
║  │       → [Select Role SCR-ONB-07] → الأب (Father/admin)                       ║
║  │       → ✓ Family Created SCR-ONB-08 (FAM-XXXXXX)                             ║
║  │                                                                              ║
║  ├─ PHASE 3: MEMBER INVITATION (Father)                                         ║
║  │                                                                              ║
║  │  ┌─ Mother Invite ─────────────────┐  ┌─ Child Invite ─────────────────┐   ║
║  │  │ [Add Mother SCR-ONB-10]         │  │ [Add Child SCR-ONB-11]          │   ║
║  │  │ → QR Code / Link / SMS          │  │ → Name: خالد, Age: 12           │   ║
║  │  │ → Share via WhatsApp            │  │ → Phone: optional               │   ║
║  │  │ → Status: Pending               │  │ → Pairing Code: 847 291         │   ║
║  │  └─────────────────────────────────┘  └─────────────────────────────────┘   ║
║  │                                                                              ║
║  ├─ PHASE 4: CHILD DEVICE LINKING (Father + Child)                              ║
║  │                                                                              ║
║  │  [Child App Launch] → [Registration/Code-only SCR-CHD-ONB-02]               ║
║  │       → [Enter Pairing Code: 847 291 SCR-CHD-ONB-03]                         ║
║  │       → ✓ Paired (both phones confirm)                                       ║
║  │       → [Profile + Avatar + Grade SCR-CHD-ONB-04/05]                        ║
║  │       → [PERMISSION SEQUENCE]                                                ║
║  │            ├─ 1. Location (Always)          ✓ MANDATORY                      ║
║  │            ├─ 2. Accessibility Service      ✓ MANDATORY                      ║
║  │            ├─ 3. Notification Access        ✓ MANDATORY                      ║
║  │            ├─ 4. Device Admin               ✓ MANDATORY                      ║
║  │            ├─ 5. Usage Access               ✓ RECOMMENDED                    ║
║  │            └─ 6. Display over apps          ✓ MANDATORY                      ║
║  │       → [Summary: All ✓ SCR-CHD-ONB-12]                                     ║
║  │       → [Tutorial: Learn / Communicate / SOS (non-skippable)]               ║
║  │       → [Learning Home SCR-EDU-01] → MONITORING ACTIVE ✓                    ║
║  │                                                                              ║
║  ├─ PHASE 5: MONITORING CONFIGURATION (Father)                                  ║
║  │                                                                              ║
║  │  [Wizard SCR-ADM-ONB-01]                                                     ║
║  │       ├─ Screen Time: 2h weekday / 3h weekend / 10PM bedtime               ║
║  │       ├─ App Rules: TikTok BLOCKED / Roblox 1h / YouTube Kids OK            ║
║  │       ├─ Web Filter: Medium preset (29 categories)                           ║
║  │       ├─ Safe Zones: Home / School / Mosque / Grandfather                    ║
║  │       └─ Content Alerts: All 29 at medium sensitivity                        ║
║  │       → [Summary ✓ SCR-ADM-ONB-02]                                          ║
║  │                                                                              ║
║  ├─ PHASE 6: EDUCATIONAL SETUP (Father)                                         ║
║  │                                                                              ║
║  │  [Educational Wizard SCR-EDU-ONB-01]                                        ║
║  │       ├─ Grade: أول متوسط (confirmed)                                        ║
║  │       ├─ Subjects: 9 subjects (Saudi curriculum + custom)                    ║
║  │       ├─ Preferences: Medium difficulty, 30 min/day, after Asr              ║
║  │       ├─ Quran: Surah Al-Kahf memorization                                   ║
║  │       └─ AI Tutor: Enabled                                                   ║
║  │       → [Setup Complete 🎉 SCR-ADM-ONB-03]                                  ║
║  │                                                                              ║
║  ├─ PHASE 7: MOTHER JOINS (Mother + Father)                                     ║
║  │                                                                              ║
║  │  [Mother: WhatsApp link] → [Install] → [Register with invite token]         ║
║  │       → [Auto-linked to عائلة العتيبي] → "بانتظار الصلاحيات"                   ║
║  │       → [Father: Push notification] → [Permission config SCR-ADM-04]         ║
║  │            ├─ Preset: "صلاحيات الأم" applied                                  ║
║  │            └─ Location ✓ / Education ✓ / Calendar ✓ / Kill Switch ✗          ║
║  │       → [Mother's Dashboard loads SCR-ADM-09] → limited_admin active         ║
║  │                                                                              ║
║  └─ PHASE 8: FIRST PRODUCTIVE USE (All)                                         ║
║     │                                                                           ║
║     ├─ Father: First alert (Khalid tries TikTok) → push → dashboard → chat     ║
║     │    → 😌 ACTIVATED                                                         ║
║     │                                                                          ║
║     ├─ Mother: Calendar event + shopping list + arrival push                   ║
║     │    → 😌 ACTIVATED                                                         ║
║     │                                                                          ║
║     └─ Child: First lesson → +50 XP → level up → badge → mom's praise         ║
║          → 🤩 ACTIVATED                                                        ║
║                                                                                ║
║    ONBOARDING JOURNEY COMPLETE ✓                                               ║
╚══════════════════════════════════════════════════════════════════════════════════╝
```

### Timeline View

```
TIME    0min    5min    10min   15min   20min   25min   30min   +24h
        │       │       │       │       │       │       │       │
FATHER  [P1]────[P2]────[P3]────[P4]────[P5]────[P6]────·──────[8F: Alert ✓]
        Install  Family  Invite  Pair    Monitor  Edu     ·       Activated
        │       │       │               │       │
MOTHER  ·········(waits)········(joins)····(perms)····[8M: Event ✓]
                │                               │               Activated
CHILD   ········(waits)········[P4: Pair]······[8C: Lesson ✓]
                                        ↑               Activated
                                   Pairing + Permissions
```

## 11. Critical Pain Points & Design Opportunities

### Pain Point Severity Matrix

| # | Pain Point | Phase | Severity | Affected Persona | Root Cause |
|---|-----------|-------|----------|-----------------|------------|
| P1 | Permission fatigue — 6 Android permissions in sequence | 4 | 🔴 Critical | Child + Father | Android requires per-permission system dialogs; no batch API |
| P2 | Accessibility service navigation — deep in Settings | 4 | 🔴 Critical | Child | Android system design; not controllable by app |
| P3 | Child denies critical permission (location) | 4 | 🔴 Critical | Father (monitoring fails) | Child doesn't understand importance; scary system dialog |
| P4 | Pairing code expiry during slow setup | 3/4 | 🟡 High | Father + Child | 10-min timer too short for multi-device coordination |
| P5 | Mother stuck waiting for father to configure permissions | 7 | 🟡 High | Mother | Dependency on father's action; no default permission set |
| P6 | Father overwhelmed by 29 content alert categories | 5 | 🟡 High | Father | Too much detail exposed at onboarding |
| P7 | Father discovers unexpected apps on child's phone | 5 | 🟡 High | Father (emotional) | First time seeing full app inventory — surprise/shock |
| P8 | Child skips tutorial, doesn't learn SOS | 4 | 🟡 High | Child | Tutorial is skippable; SOS is critical safety feature |
| P9 | Onboarding takes >30 min — abandonment risk | 1-6 | 🟡 High | Father | Multi-phase setup is inherently long |
| P10 | Mother's invite link expires before she installs | 7 | 🟠 Medium | Mother | 7-day expiry may be too short for busy schedules |

### Design Opportunities

#### OP1: Permission Pre-boarding Cards (addresses P1, P3)

**Before** each Android system permission dialog, show an Arabic explanation card:

```
┌──────────────────────────────────────┐
│  📍 نحتاج موقعك                      │
│                                      │
│  حتى لو كنت في خطر أو ضعت، يقدر      │
│  أبوك يدل عليك ويساعدك فوراً.         │
│                                      │
│  اختار "السماح دائماً" في الخطوة     │
│  القادمة.                            │
│                                      │
│         [ مفهوم، متابعة ]            │
└──────────────────────────────────────┘
```

**Impact:** Reduces permission denial rate from ~25% to ~8% (industry benchmark for pre-boarding).

#### OP2: Visual Step-by-Step Guide for Accessibility (addresses P2)

In-app animated overlay showing exact path: `Settings > Accessibility > Family OS > Enable` with device-specific screenshots (Samsung vs other Android).

**Impact:** Reduces accessibility setup failure from ~30% to ~10%.

#### OP3: Smart Pairing Timer (addresses P4)

- Extend pairing code validity to 30 minutes
- Show countdown on BOTH father's and child's screens
- Auto-regenerate code if expired with one tap
- Allow "save and resume" — father can leave Phase 4 and return later

#### OP4: Mother Default Permissions (addresses P5)

When mother joins, auto-apply a sensible default permission set:
- ✅ Location, Study Progress, Calendar, Tasks, Shopping, SOS alerts
- ❌ Web Filter config, Kill Switch, Anti-bypass, Billing, Member management

Father receives notification: "نورة انضمت — تم تطبيق صلاحيات الأم الافتراضية. عدّلها إذا أردت."

**Impact:** Mother's dashboard loads immediately; father can adjust later. Zero wait time.

#### OP5: Guided Monitoring Presets (addresses P6, P7)

Replace 29-category list with 3 preset cards:

```
┌──────────────┐  ┌──────────────┐  │──────────────┐
│   🟢 خفيف    │  │  🟡 متوسط    │  ┃  🔴 صارم     │
│              │  │              │  ┃              │
│ حماية أساسية │  │ حماية متوازنة│  ┃ حماية كاملة  │
│ للأطفال >14  │  │ للأطفال 8-14 │  ┃ للأطفال <8   │
│              │  │              │  ┃              │
│ 8 فئات       │  │ 29 فئة (متوسط)│  ┃ 29 فئة (صارم)│
│ مفعّلة       │  │ مفعّلة       │  ┃ مفعّلة       │
└──────────────┘  └──────────────┘  ┗──────────────┘
         [ تخصيص التفاصيل ▼ ]
```

Father picks a preset based on child's age; details are optional and deferred.

#### OP6: Non-Skippable SOS Tutorial (addresses P8)

First-time tutorial: Learn and Communicate screens are skippable. The SOS screen requires the child to **demonstrate** the hold-to-trigger action (with a safe demo that doesn't actually fire an alert).

```
┌──────────────────────────────────────┐
│  🆘 هذا زر الطوارئ                    │
│                                      │
│  اضغط مطولاً 3 ثواني                  │
│  لو صار فيك خطر                       │
│                                      │
│  جرّب الحين (تجريب فقط):             │
│                                      │
│         ┌──────────────┐             │
│         │   🆘 اضغط    │             │
│         │   مطولاً     │             │
│         └──────────────┘             │
│                                      │
│  لن يتم إرسال تنبيه حقيقي             │
└──────────────────────────────────────┘
```

#### OP7: Onboarding Progress Saving (addresses P9)

Every phase completion is saved to the backend. Father can leave and return:
- Dashboard shows: "إعداد غير مكتمل — أكمل من الخطوة 4"
- Each phase has a "أكمل لاحقاً" button
- Progress bar: "أكملت 4 من 6 خطوات"

**Impact:** Reduces abandonment from long sessions by allowing incremental completion.

## 12. Edge Cases & Fallback Flows

### Edge Case 1: Child's Phone Has No SIM Card

**Scenario:** Khalid's phone is a family phone without a SIM (Wi-Fi only or shared device).

```
Normal: Phone → SMS OTP → Verified
                ↓ (no SIM)
Fallback: Phone → "ليس لدي رقم" → Skip registration → Code-only pairing
                ↓
          Enter pairing code 847 291 → Paired ✓
          (Account created with device ID instead of phone number)
```

**Impact:** Monitoring works fully without SMS. SOS works over Wi-Fi (if available). If no Wi-Fi at trigger time, SOS queues and sends when connectivity returns — **critical safety gap**.  
**Mitigation:** SOS over SMS fallback (if ANY SIM exists, even inactive, SMS can reach emergency services).

### Edge Case 2: Father Already Has an Account (Reinstall / New Device)

**Scenario:** Abu Khalid reinstalls app or gets new phone. He should not create a new family.

```
Normal: Register → Create Family
                ↓ (existing account detected)
Fallback: Phone matches existing account → "هذا الرقم مسجل مسبقاً"
                ↓
          "تسجيل دخول" (Login) instead of "إنشاء حساب" (Sign Up)
                ↓
          Login → Family automatically restored → Dashboard loads
```

### Edge Case 3: Multiple Children — Sequential Pairing

**Scenario:** Father has 3 children (Khalid 12, Saud 9, Layla 7). Each needs individual pairing.

```
Child 1 (Khalid, 12): Full pairing flow → ✓
Child 2 (Saud, 9):    Full pairing flow → ✓ (but father is now experienced, faster)
Child 3 (Layla, 7):   Age gate: "جوال الطفل غير مدعوم حالياً" (under 8)
                      ↓
                      "يمكنك متابعتها يدوياً عبر الموقع والإعدادات"
                      (Manual location tracking without full device pairing)
```

**Note:** Layla at age 7 is right at the boundary. The platform supports ages 8-16 for full device pairing. Under 8 = manual tracking only (father enters her location manually or uses a parent's phone for her).

### Edge Case 4: Permission Denied Mid-Sequence

**Scenario:** Child grants location but denies accessibility service.

```
Location: ✓ Granted
Accessibility: ✗ Denied
    ↓
"بدون خدمة الوصول، لا يقدر أبوك يراقب التطبيقات اللي تستخدمها.
 هذا مهم لحمايتك. تأكد من الرفض؟"
    ↓
[ إعادة المحاولة ]  [ تخطى الآن ]
    ↓                    ↓
Retry settings          Continue with reduced monitoring
    ↓                    ↓
Accessibility granted   Dashboard shows: "⚠️ مراقبة التطبيقات غير مفعّلة"
                         Father receives: "خالد لم يفعّل خدمة الوصول — المراقبة ناقصة"
```

**Father's fallback:** Admin panel can send a "request to enable" push to child with deep-link to the settings page. If child still refuses, father can use Device Admin to enforce (Android Enterprise mode).

### Edge Case 5: Mother Joins Before Father Finishes Setup

**Scenario:** Father sends invite in Phase 3, then continues to Phase 4-5. Mother installs and tries to join while father is mid-configuration.

```
Mother: Register → "بانتظار إعداد الصلاحيات من الأب"
    ↓ (father is in Phase 5 — monitoring config)
Father: Completes Phase 5 → receives pending notification
    ↓
Father: Phase 7 permission config for mother → applies
    ↓
Mother: Dashboard loads ✓
```

**Timing:** Mother may wait 10-30 minutes. Placeholder screen should be informative, not blank: "أبوك ينهي إعداد العائلة. سيتم تفعيل حسابك قريباً."

### Edge Case 6: Network Failure During Registration

**Scenario:** Father enters OTP but network drops before verification completes.

```
Enter OTP → Network timeout
    ↓
"تعذر التحقق — تحقق من اتصالك بالإنترنت"
    ↓
[ إعادة المحاولة ] (same OTP still valid for remaining time)
    ↓
If OTP expired during outage:
    ↓
"انتهت صلاحية الرمز — أرسلنا رمزاً جديداً" → new SMS automatically
```

### Edge Case 7: Child's Device Is iOS (Future Consideration)

**Scenario:** Family uses iPhone for child instead of Android. iOS has different permission model — no accessibility service equivalent, no Device Admin.

```
iOS Limitations:
- No Accessibility Service → App monitoring uses Screen Time API (iOS 16+)
- No Device Admin → Kill Switch uses MDM profile (requires supervised device)
- Location: "Always" requires explicit justification to Apple
- SOS FAB: iOS doesn't allow overlay over other apps → SOS only works within app

Fallback:
- Reduced monitoring capability on iOS
- Father warned during setup: "ميزات المراقبة محدودة على أجهزة آيفون"
- Recommend Android for child devices for full protection
```

**Note:** This is a known platform constraint. The spec should document iOS limitations clearly during setup so father can make informed device decisions.

### Edge Case 8: Father Abandons Mid-Onboarding

**Scenario:** Father completes Phases 1-4 (child paired, permissions granted) but never configures monitoring (Phase 5) or education (Phase 6).

```
Child device: Paired ✓, Permissions granted ✓, but NO rules set
    ↓
Default behavior: No screen time limit, no app blocks, no web filter, no safe zones
    ↓
Child has full access — effectively unprotected despite being "monitored"
    ↓
System intervention:
  - Day 1: Dashboard banner "أكمل إعداد المراقبة — 3 خطوات متبقية"
  - Day 2: Push notification "خالد جواله مرتبط لكن الحماية غير مفعّلة"
  - Day 3: Email/SMS "تذكير: إعداد الحماية غير مكتمل"
  - Day 7: Auto-apply basic protection preset (age-based) with notification
```

**Critical:** The platform must NOT leave a child unprotected if father abandons setup. Auto-apply basic rules after 7 days with notification — father can adjust later.

## 13. Onboarding Success Metrics

### Primary Metrics (Activation Funnel)

| Stage | Metric | Target | Measurement Method |
|-------|--------|--------|-------------------|
| Install | App installs from store | — | Store analytics |
| Registration | Install → registration completion | >85% | Phone verified / installs |
| Family creation | Registration → family created | >90% | Family entity created / registrations |
| Invite sent | Family created → invite sent | >80% | At least one invite generated / families |
| Child paired | Invite sent → child device paired | >70% | Pairing confirmed / invites sent |
| Permissions granted | Paired → all mandatory permissions | >85% | All 4 mandatory permissions granted / paired |
| Monitoring configured | Permissions → monitoring rules set | >75% | At least screen time + app rules configured |
| Educational setup | Monitoring → education configured | >65% | Subjects selected / monitoring configured |
| **Full onboarding** | **Install → all phases complete** | **>50%** | **All phases done / installs** |
| First alert received | Onboarding → first alert <24h | >60% | Alert fired within 24h of completion |

### Secondary Metrics (Quality of Onboarding)

| Metric | Target | Measurement |
|--------|--------|-------------|
| Time to complete (total) | <30 min | Sum of active time across phases |
| Time in permission sequence | <8 min | Time from first permission to summary |
| Permission denial rate (per permission) | <10% | Denials / prompts per permission type |
| Mother join latency | <48h | Time from invite sent to mother joined |
| Tutorial completion (SOS) | 100% | SOS demo completed / child onboarding |
| Onboarding resume rate | >40% | Users who left and returned within 48h |
| Post-onboarding satisfaction | >4.0/5 | In-app survey after Phase 8 |

### Drop-off Risk Points

```
Install ──────── 85% ───→ Registration ──────── 90% ───→ Family Creation
    │  15% drop                         │  10% drop
    │  (wrong app,                      │  (too much info,
    │   too big,                        │   role confusion)
    │   changed mind)
    │                                    │
    ▼                                    ▼
Invite Sent ──── 80% ───→ Child Paired ──── 70% ───→ Permissions Granted
    │  20% drop                        │  30% drop        │
    │  (mother doesn't                 │  (pairing fails, │  15% drop
    │   install, code                  │  child not       │  (permission
    │   expires)                       │  available)      │   fatigue)
    │                                    │                  │
    ▼                                    ▼                  ▼
Monitoring Config ── 75% ──→ Education Setup ── 65% ──→ FULL ONBOARDING
    │  25% drop                     │  35% drop              │  50% of installs
    │  (overwhelmed by              │  (fatigue,              │
    │   29 categories)              │   "later")              │
    ▼                               ▼                        ▼
FIRST ALERT <24h ── 60% of onboarded ──→ ACTIVATED

  Drop-off #1: Permission fatigue (Phase 4) — 15% drop → BIGGEST risk
  Drop-off #2: Monitoring overwhelm (Phase 5) — 25% drop → Second biggest
  Drop-off #3: Invite → pair gap (Phase 3→4) — 20% drop → Third
```

### Saudi-Specific Metrics

| Metric | Target | Notes |
|--------|--------|-------|
| Arabic-only users who complete | >50% | No English fallback should hurt completion |
| Hijri calendar adoption | >70% | Users who keep Hijri as primary calendar view |
| mada payment adoption | >40% | Users who choose mada over other methods (at subscription) |
| Quran setup completion | >60% | Families who configure Quran memorization during onboarding |
| Multi-child family completion | >45% | Families with 2+ children who pair all eligible children |

---

*Related documents:*
- [Persona Journey Maps](../01_PERSONA_JOURNEY_MAPS.md)
- [SOS Emergency Journey](02_SOS_EMERGENCY_JOURNEY.md)
- [Daily Life Journeys](03_DAILY_LIFE_JOURNEYS.md)
