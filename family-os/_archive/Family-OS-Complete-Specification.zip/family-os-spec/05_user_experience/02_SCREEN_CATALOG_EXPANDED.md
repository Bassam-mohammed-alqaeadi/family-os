---
title: "Screen Catalog — Expanded (Derived from 91 P0 Requirements)"
tags: [screens, catalog, expanded, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification
supersedes: "02_SCREEN_CATALOG.md (62-screen frozen pass)"
status: derived-from-requirements
---

# Screen Catalog — Expanded

> Derived screen-by-screen from the 91 P0 services. The screen count is NOT frozen — it is the sum of every primary screen, sub-screen, dialog, sheet, state variant, onboarding step, settings sub-page, error/recovery flow, permission grant, and cross-system integration screen the requirements actually produce. The prior 62-screen catalog collapsed dozens of services into single rows; this pass decomposes them.

---

## 1. Methodology

Each of the 91 P0 services was passed through a seven-question discovery filter:

1. **Own screen vs. feature-in-screen?** — Does the service need a dedicated navigable surface, or is it inline UI within an existing screen (reply context bar, read-receipt checkmarks, quick-reaction picker)?
2. **Sub-screens?** — What creation/detail/edit/preview/list surfaces does it generate? (e.g., *create assignment* → creation form → question builder → preview → detail → submission → grading results.)
3. **Configuration/settings screens?** — Per-service settings, toggles, schedules, thresholds.
4. **State variants?** — Every screen carries the mandatory eight states: **empty · loading (shimmer) · success · error · denied-permission · locked (child) · trial-expired · paywall**. Shared design templates (SHR-055 → SHR-061) document these once; each screen's row lists which apply and any screen-specific behavior. State variants that are meaningfully distinct navigable surfaces (call states, SOS states, trial-expired, paywall, permission-denied for critical flows) get their own row.
5. **Cross-system integration screens?** — Events that cascade across systems (geofence breach → alert center → chat system message → Today Dashboard card → notification) produce integration surfaces: alert center, alert detail, Today cards, system messages.
6. **Onboarding/permission screens?** — First-launch permission grants (notifications, location-always, accessibility, VPN, usage-access, overlay, camera/mic, storage), device pairing, child setup.
7. **Recovery/error screens?** — Crash recovery, force update, account recovery, offline mode, sync conflict.

### Conventions

- **ID scheme:** `SHR-###` (Shared/Meta) · `COM-###` (Communications) · `PAR-###` (Monitoring) · `EDU-###` (Education) · `AIE-###` (AI) · `ADM-###` (Administration).
- **Screen type:** `primary` (tab-level / top-level navigable) · `sub-screen` (drilled into from a primary) · `dialog` (modal, dismissible) · `sheet` (bottom sheet / action sheet) · `state-variant` (distinct navigable state of another screen) · `onboarding` (first-launch flow step) · `component-screen` (reusable full-screen overlay) · `template` (shared design spec referenced by many screens).
- **Parent screen:** the screen the user was on when this surface opened; `—` for top-level / launch.
- **Key UI states:** which of the eight mandatory states apply, plus screen-specific states. "All 8" = the standard set applies; deviations are noted.
- **Roles:** 🟢 Father (admin) · 🟡 Mother (limited_admin, configurable) · 🔵 Child (restricted). `All` = all three roles encounter the screen (with role-gated content).
- **Cross-reference:** services that appear in multiple systems (AI services overlapping Education) are listed in their owning system with a `↔` cross-ref note.

---

## 2. Shared / Meta Screens (SHR)

### 2.1 Onboarding & First-Launch

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| SHR-001 | شاشة البدء / Splash & Launch | All | — | primary | — | loading → app-ready; cold-start shimmer |
| SHR-002 | اختيار اللغة / Language Selection (AR/EN) | All | S-ADM-027 | onboarding | SHR-001 | first-launch; AR default highlighted; toggle persists |
| SHR-003 | مقدمة التطبيق / Welcome Carousel | All | — | onboarding | SHR-002 | 4–5 value-prop slides; skip; next; final → role select |
| SHR-004 | المصادقة / Account Authentication (phone/email) | All | S-ADM-001 | onboarding | SHR-003 | input; error (invalid); loading (verifying) |
| SHR-005 | التحقق OTP / OTP Verification | All | S-ADM-001 | onboarding | SHR-004 | 6-digit entry; resend countdown; error (wrong code); auto-fill |
| SHR-006 | اختيار الدور / Role Selection (Father/Mother/Child) | All | S-ADM-003 | onboarding | SHR-005 | 3 cards; child route → join flow; father route → create family |
| SHR-007 | إنشاء العائلة / Family Creation | 🟢 Father | S-ADM-002/006 | onboarding | SHR-006 | family name; member-limit preview (6/4/1); create button |
| SHR-008 | الانضمام للعائلة / Family Join (Invite) | 🟡🔵 | S-ADM-004 | onboarding | SHR-006 / SHR-048 | invite-link landing; role-confirm; family-preview; accept/reject |
| SHR-009 | إعداد الملف الشخصي / Profile Setup | All | S-ADM-026 | onboarding | SHR-007/008 | name; avatar; phone-confirm; save |
| SHR-010 | إعداد ملف الطفل / Child Profile Setup | 🟢 | S-ADM-002/009 | onboarding | SHR-009 | name; age; grade; avatar; device-link prompt |
| SHR-011 | إذن: الإشعارات / Permission — Notifications | All | S-ADM-020 | onboarding | SHR-009 | rationale card → system prompt; denied → soft-bypass with retry |
| SHR-012 | إذن: الموقع / Permission — Location (Always) | All | S-PAR-011/014 | onboarding | SHR-011 | rationale; "always" emphasis; denied → restricted monitoring banner |
| SHR-013 | إذن: خدمات الوصول / Permission — Accessibility | 🟢🔵 | S-PAR-038 | onboarding | SHR-012 | rationale (anti-bypass); system settings deep-link; verify |
| SHR-014 | إذن: VPN / Permission — VPN Configuration | 🟢🔵 | S-PAR-038/041 | onboarding | SHR-013 | rationale (kill switch); system consent dialog; verify |
| SHR-015 | إذن: الوصول للاستخدام / Permission — Usage Access | 🟢🔵 | S-PAR-001/015 | onboarding | SHR-014 | rationale (screen time / app rules); settings deep-link; verify |
| SHR-016 | إذن: عرض فوق التطبيقات / Permission — Display Overlay | 🟢🔵 | S-PAR-005/039 | onboarding | SHR-015 | rationale (instant lock / SOS overlay); verify |
| SHR-017 | إذن: الكاميرا والمايك / Permission — Camera & Mic | All | S-COM-006/029 | onboarding | SHR-016 | rationale (calls/voice msgs); system prompt; denied retry |
| SHR-018 | إذن: التخزين / Permission — Storage / Files | All | S-COM-010/025 | onboarding | SHR-017 | rationale (media/files); system prompt; denied retry |
| SHR-019 | ربط الجهاز: مسح QR / Device Pairing — QR Scan | 🟢🔵 | S-ADM-009 | onboarding | SHR-010/018 | camera viewfinder; scan-success; scan-fail retry |
| SHR-020 | ربط الجهاز: رمز يدوي / Device Pairing — Manual Code | 🟢🔵 | S-ADM-009 | onboarding | SHR-019 | code entry; error (invalid/expired); retry |
| SHR-021 | ربط الجهاز: نجاح / Device Pairing — Success | 🟢🔵 | S-ADM-009 | onboarding | SHR-019/020 | confirmation; device nickname; child-name confirm; done |
| SHR-022 | اكتمال الإعداد / Onboarding Complete — Family Ready | All | — | onboarding | SHR-021 | summary card; "enter app" → role-app home |

### 2.2 Returning Login & Account Recovery

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| SHR-023 | تسجيل الدخول / Login (returning) | All | S-ADM-001 | primary | SHR-001 | saved-session skip; phone/email + OTP; error; loading |
| SHR-024 | استرجاع الحساب: المعرف / Account Recovery — Identifier | All | S-ADM-001 | sub-screen | SHR-023 | phone/email entry; error (not found); next |
| SHR-025 | استرجاع الحساب: OTP / Account Recovery — OTP | All | S-ADM-001 | sub-screen | SHR-024 | 6-digit; resend; error; success → reset |
| SHR-026 | استرجاع الحساب: إعادة تعيين / Account Recovery — Reset | All | S-ADM-001 | sub-screen | SHR-025 | new credential; confirm; success → login |
| SHR-027 | تأكيد تسجيل الخروج / Logout Confirmation | All | S-ADM-026 | dialog | any | warning; confirm/cancel; data-sync note |

### 2.3 Navigation Containers

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| SHR-028 | شريط التنقل (الأب/الأم) / Parent Bottom Nav (Today·Communicate·Monitor·Learn·More) | 🟢🟡 | S-ADM-033 | primary | — | 5 tabs; badge counts; active highlight; role-gated Monitor access |
| SHR-029 | شريط التنقل (الطفل) / Child Bottom Nav (Learn·Communicate·My Time·AI·More) | 🔵 | S-EDU-001 | primary | — | 5 tabs; AI tab; restricted nav; lock-state overlay |

### 2.4 Profile

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| SHR-030 | ملفي الشخصي / My Profile | All | S-ADM-026 | sub-screen | More menu | avatar; stats; edit; logout; all 8 states |
| SHR-031 | تعديل الملف / Edit Profile | All | S-ADM-026 | sub-screen | SHR-030 | name/avatar/phone; save; validation errors |
| SHR-032 | ملف عضو العائلة / Family Member Profile | 🟢🟡 | S-ADM-003 | sub-screen | ADM-012/013 | role; devices; permissions; activity summary |

### 2.5 Notifications

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| SHR-033 | مركز الإشعارات / Notification Center | All | S-ADM-020/022 | primary | bell icon | grouped by category; unread badges; empty; clear-all; all 8 |
| SHR-034 | تفاصيل إشعار / Notification Detail | All | S-ADM-022 | sub-screen | SHR-033 | full alert; deep-link action; dismiss; mark-read |

### 2.6 Search

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| SHR-035 | البحث العام / Global Search | All | — | primary | search icon | scope chips (chats/events/tasks/lessons/contacts); empty; recent |
| SHR-036 | نتائج البحث / Search Results | All | — | sub-screen | SHR-035 | grouped results; no-results; loading |

### 2.7 Reusable Component-Screens

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| SHR-037 | منتقي التاريخ (هجري/ميلادي) / Hijri-Gregorian Date Picker | All | S-COM-030, S-EDU-009, S-PAR-052, S-ADM-035 | component-screen | any | dual-cal toggle; Hijri default; range select; disabled dates |
| SHR-038 | عارض الصور / Image Viewer (fullscreen) | All | S-COM-010 | component-screen | any | zoom; swipe gallery; save/share; loading; error |
| SHR-039 | مشغل الفيديو / Video Player | All | S-COM-010 | component-screen | any | play/pause/scrub; fullscreen; loading; error |
| SHR-040 | عارض الملفات / File / Document Preview | All | S-COM-025 | component-screen | any | PDF/doc/image; download; loading; unsupported-type error |
| SHR-041 | منتقي الصور / Photo & Avatar Picker | All | S-ADM-026 | component-screen | any | camera/gallery; crop; permission-denied; empty-gallery |
| SHR-042 | حوار التأكيد / Confirmation Dialog (template) | All | — | dialog | any | title/message/confirm/cancel; destructive style variant |
| SHR-043 | ورقة العمل / Action Sheet / Bottom Sheet (template) | All | — | sheet | any | option list; cancel; scroll; title |

### 2.8 System / Error / Recovery

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| SHR-044 | وضع عدم الاتصال / Offline Mode Banner & State | All | — | state-variant | any | banner; cached-content; retry-on-reconnect; queue indicator |
| SHR-045 | حالة المزامنة / Sync Status | All | — | state-variant | any | syncing; last-synced; conflict; manual-sync trigger |
| SHR-046 | استرداد الأعطال / Crash & Error Recovery | All | — | state-variant | any | "something went wrong"; reload; report; stack hidden |
| SHR-047 | تحديث متاح / Update Available (soft) | All | — | state-variant | any | "update available"; later / update; non-blocking |
| SHR-048 | تحديث إجباري / Force Update (hard) | All | — | state-variant | SHR-001 | blocking; "update required"; store deep-link |
| SHR-049 | معالجة الروابط / Deep Link Landing (invite handler) | 🟡🔵 | S-ADM-004 | state-variant | SHR-001 | invite parse; expired-link error; family-preview → SHR-008 |

### 2.9 Help / Legal

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| SHR-050 | حول ومساعدة / About & Help | All | — | sub-screen | More menu | version; links; contact; all 8 |
| SHR-051 | الدعم والتواصل / Support & Contact | All | — | sub-screen | SHR-050 | form / email; attachments; sent confirmation |
| SHR-052 | الأسئلة الشائعة / FAQ | All | — | sub-screen | SHR-050 | searchable; category sections; expand answers |
| SHR-053 | شروط الخدمة / Terms of Service | All | — | sub-screen | SHR-050 | legal text; accept (onboarding variant); RTL |
| SHR-054 | سياسة الخصوصية / Privacy Policy | All | S-ADM-029 | sub-screen | SHR-050 | PDPL/GDPR text; accept; RTL |

### 2.10 Mandatory State-Variant Templates (referenced by every screen)

| ID | Template (AR / EN) | Roles | Applies To | Type | Key Behavior |
|----|--------------------|-------|------------|------|--------------|
| SHR-055 | حالة فارغة / Empty State Template | All | all list/grid screens | template | illustration + AR headline + CTA; per-system variants |
| SHR-056 | حالة التحميل / Loading (Shimmer) Template | All | all async screens | template | skeleton shimmer matching layout; no spinner-only |
| SHR-057 | حالة الخطأ / Error State Template | All | all screens | template | error illustration + retry + contact-support |
| SHR-058 | إذن مرفوض / Permission Denied Template | All | permission-gated screens | template | rationale + "open settings" deep-link + degraded-mode note |
| SHR-059 | قفل الطفل / Locked (Child) Template | 🔵 | parent-feature screens child tries to access | template | jade lock illustration + "ask parent" CTA |
| SHR-060 | انتهاء التجربة / Trial Expired Template | All | premium-gated screens | template | trial-ended + upgrade CTA → ADM-022 |
| SHR-061 | جدار الاشتراك / Paywall Template | All | premium-only features | template | feature preview + 49 SAR plan → ADM-023 |

## 3. Communications Screens (COM)

### 3.1 Chat List & Conversations

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| COM-001 | قائمة المحادثات / Chat List | All | S-COM-001/002/003 | primary | Communicate tab | empty (no chats); loading; pinned; unread badges; search → SHR-035 |
| COM-002 | محادثة العائلة الجماعية / Family Group Chat | All | S-COM-001/004/010/011/025/029/048 | primary | COM-001 | sending; sent; delivered; read receipts; typing; media-loading; all 8 |
| COM-003 | محادثة فردية / 1:1 Private Chat | All | S-COM-002/004/010/011/025/029/048 | primary | COM-001 | same states as COM-002; online indicator; encrypted note |
| COM-004 | محادثة مجموعة فرعية / Sub-group Chat | All | S-COM-003/004/010/011 | sub-screen | COM-001 | member avatars in header; father-created badge |
| COM-005 | إنشاء مجموعة فرعية / Create Sub-group | 🟢 | S-COM-003 | sub-screen | COM-001 | name; member-picker; preview; create; limit-enforcement |
| COM-006 | إدارة أعضاء المجموعة / Sub-group Members Mgmt | 🟢 | S-COM-003 | sub-screen | COM-004 | add/remove; role; leave-group |
| COM-007 | معلومات المحادثة / Conversation Info & Settings | All | S-COM-001/052 | sub-screen | COM-002/003/004 | members; media gallery link; mute; translation toggle; lock toggle |
| COM-008 | معرض الوسائط المشتركة / Shared Media Gallery | All | S-COM-010/025 | sub-screen | COM-007 | tabs: photos/videos/files; grid; empty; loading |

### 3.2 Voice Calls (LiveKit)

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| COM-009 | مكالمة صوت: اتصال / Voice Call — Outgoing (ringing) | All | S-COM-006 | state-variant | COM-002/003 | ringing; cancel; recipient avatar; connecting shimmer |
| COM-010 | مكالمة صوت: وارد / Voice Call — Incoming | All | S-COM-006 | state-variant | system notif | accept/decline; caller id; ringtone; full-screen overlay |
| COM-011 | مكالمة صوت: نشطة / Voice Call — In-Call (active) | All | S-COM-006/044 | primary | COM-009/010 | timer; mute; speaker; end; live-translation toggle; Hold-to-talk |
| COM-012 | مكالمة صوت: انتهت / Voice Call — Ended / Summary | All | S-COM-006 | state-variant | COM-011 | duration; call-quality; redial; back-to-chat |
| COM-013 | مكالمة فائتة / Missed Call Notice | All | S-COM-006 | state-variant | COM-001 | missed-call row; tap-to-callback; notification |

### 3.3 Media, Files & Audio Messages

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| COM-014 | منتقي الوسائط / Media Picker (image/video/file) | All | S-COM-010/025 | sheet | COM-002/003 | gallery/camera/files tabs; multi-select; caption; size-limit warn |
| COM-015 | تسجيل رسالة صوتية / Voice Message Recorder & Review | All | S-COM-029/041 | sheet | COM-002/003 | hold-to-record; waveform; play-back; re-record; send; duration |
| COM-016 | تشغيل رسالة صوتية + تفريغ / Voice Message Player + Transcription | All | S-COM-041 | sub-screen | COM-002/003 | play/scrub; transcription toggle; Whisper text; loading-transcription |
| COM-017 | إرسال ملف / File Send Preview | All | S-COM-025 | sub-screen | COM-014 | file card; size; send; unsupported error |

### 3.4 Reactions, Receipts, Quick Actions

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| COM-018 | منتقي الردود السريعة / Quick Reactions Picker | All | S-COM-048 | sheet | COM-002/003 | emoji/tapback row; multi-reaction; animate on send |
| COM-019 | تفاصيل القراءة / Read Receipts — Seen-by Detail | All | S-COM-011 | sheet | COM-002/003 | per-recipient read/unread list; timestamps |
| COM-020 | سياق الرد / Reply Context Bar (inline state) | All | S-COM-004 | state-variant | COM-002/003 | quoted-message bar above composer; cancel; (inline UI, not navigable) |

### 3.5 Family Calendar (Hijri mandatory)

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| COM-021 | التقويم العائلي: شهري / Family Calendar — Month | 🟢🟡 | S-COM-030/031 | primary | Communicate tab | Hijri/Gregorian toggle; event dots; today highlight; empty-day |
| COM-022 | التقويم: أسبوعي / Family Calendar — Week | 🟢🟡 | S-COM-030/031 | sub-screen | COM-021 | time-grid; event blocks; all-day row |
| COM-023 | التقويم: جدول اليوم / Family Calendar — Agenda / Day | 🟢🟡 | S-COM-030/031 | sub-screen | COM-021 | chronological list; overdue; empty; swipe-complete |
| COM-024 | إنشاء حدث / Calendar Event — Creation | 🟢🟡 | S-COM-030 | sub-screen | COM-021 | title; Hijri date picker (SHR-037); time; reminders; attendees; repeat |
| COM-025 | تفاصيل الحدث / Calendar Event — Detail | All | S-COM-030/031 | sub-screen | COM-021 | full info; attendees; edit/delete (role-gated); join-meeting |
| COM-026 | تعديل حدث / Calendar Event — Edit | 🟢🟡 | S-COM-031 | sub-screen | COM-025 | prefilled form; save; conflict-warn; recurrence-edit prompt |
| COM-027 | حذف حدث / Event Delete Confirmation | 🟢🟡 | S-COM-031 | dialog | COM-025 | confirm; series-vs-single (if recurring); cancel |

### 3.6 Tasks & Reminders

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| COM-028 | قائمة المهام والتذكيرات / Tasks & Reminders List | All | S-COM-032 | primary | Communicate tab | by-due-date; filter (mine/family); complete toggle; empty; all 8 |
| COM-029 | إنشاء مهمة / Task — Creation | All | S-COM-032 | sub-screen | COM-028 | title; assignee; Hijri due; reminder time; repeat |
| COM-030 | تفاصيل/تعديل مهمة / Task — Detail / Edit | All | S-COM-032 | sub-screen | COM-028 | history; comments; complete; snooze (sheet) |
| COM-031 | إنجاز/تأجيل مهمة / Task Complete / Snooze | All | S-COM-032 | sheet | COM-028/030 | complete-confirm; snooze-duration picker |

### 3.7 Shared Shopping List

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| COM-032 | قائمة التسوق المشتركة / Shared Shopping List | All | S-COM-033 | primary | Communicate tab | check-off items; assigned-to; categories; empty; all 8 |
| COM-033 | إضافة عنصر / Shopping — Add Item | All | S-COM-033 | sheet | COM-032 | name; qty; category; assignee; quick-add suggestions |
| COM-034 | تفاصيل/تعديل عنصر / Shopping Item Detail / Edit | All | S-COM-033 | sub-screen | COM-032 | edit; delete; mark-bought; history |

### 3.8 Live Location & Polls

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| COM-035 | بث الموقع اللحظي / Live Location — Broadcast Map | All | S-COM-035/S-PAR-011 | sub-screen | COM-002/003 | my-broadcast toggle; duration; map; recipients; stop |
| COM-036 | مشاركة الموقع: إعدادات / Live Location — Share Settings | All | S-COM-035 | sheet | COM-035 | duration (15m/1h/until-off); recipients; permission prompt |
| COM-037 | عرض موقع عضو / Live Location — Recipient View | All | S-COM-035/S-PAR-011 | sub-screen | COM-002/003 | member pin; ETA; refresh; expired-share state |
| COM-038 | إنشاء استطلاع / Poll — Creation | All | S-COM-036 | sub-screen | COM-002/003 | question; options add/remove; multi-select toggle; duration |
| COM-039 | استطلاع: تصويت / Poll — Voting Card | All | S-COM-036 | state-variant | COM-002/003 | inline card; select; vote; voted-check |
| COM-040 | استطلاع: النتائج / Poll — Results | All | S-COM-036 | state-variant | COM-002/003 | bar chart; vote counts; leader; closed-state |

### 3.9 SOS & Crash Detection

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| COM-041 | SOS: تشغيل / SOS — Trigger (countdown/hold) | 🔵 | S-COM-039 | state-variant | overlay / widget | 5-s countdown; cancel; hold-to-confirm; haptic |
| COM-042 | SOS: نشط / SOS — Active Broadcasting | 🔵 | S-COM-039 | state-variant | COM-041 | broadcasting; location attached; "help is coming"; cancel-SOS |
| COM-043 | SOS: تنبيه وارد / SOS — Alert Received (parent) | 🟢🟡 | S-COM-039/S-PAR-032 | state-variant | system notif | full-screen alarm; child name; location; acknowledge |
| COM-044 | SOS: تفاصيل ورد / SOS — Alert Detail / Respond | 🟢🟡 | S-COM-039 | sub-screen | COM-043 | live location; call child; mark-resolved; log |
| COM-045 | كشف الحوادث: تنبيه / Crash Detection Alert | 🟢🟡 | S-COM-039 | state-variant | system notif | auto-triggered; severity; location; call / dismiss-false |
| COM-046 | SOS: الإعدادات / SOS Settings (contacts, trigger) | 🟢 | S-COM-039 | sub-screen | COM-007 | emergency contacts; trigger method; auto-crash toggle |

### 3.10 Real-time Translation & Chat Lock

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| COM-047 | الترجمة اللحظية: تفعيل / Translation — Toggle & Lang Pair | All | S-COM-044 | sheet | COM-002/003 | on/off; source↔target pair; Gemini status; translating-indicator |
| COM-048 | إعدادات الترجمة / Translation Settings (global) | All | S-COM-044 | sub-screen | More / COM-007 | default pairs; auto-translate contacts; always-translate family group |
| COM-049 | قفل المحادثة: إعداد / Chat Lock — Setup (father) | 🟢 | S-COM-052 | sub-screen | COM-007 | PIN set; biometric toggle; select conversations to lock |
| COM-050 | قفل المحادثة: فتح / Chat Lock — Unlock | All | S-COM-052 | state-variant | COM-001 | biometric prompt / PIN entry; wrong-PIN error; locked-illustration |
| COM-051 | قفل المحادثة: إدارة / Chat Lock — Manage Locked Chats | 🟢 | S-COM-052 | sub-screen | COM-049 | list locked chats; unlock; re-lock |
| COM-052 | قفل محادثة: تبديل / Chat Lock — Per-Conversation Toggle | 🟢 | S-COM-052 | sheet | COM-007 | lock/unlock; PIN confirm |

## 4. Monitoring / Parental Screens (PAR)

### 4.1 Monitoring Hub & Screen Time

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| PAR-001 | مركز المراقبة / Monitoring Hub | 🟢🟡 | S-PAR-034/045 | primary | Monitor tab | child-cards; alert-feed; quick-actions; empty (no linked devices); all 8 |
| PAR-002 | وقت الشاشة: لوحة / Screen Time Dashboard (per child) | 🟢🟡🔵 | S-PAR-001/034 | sub-screen | PAR-001 | used/remaining ring; today; per-app bars; Focus badge |
| PAR-003 | وقت الشاشة: تحديد الحد / Set Daily Limit | 🟢 | S-PAR-001 | sub-screen | PAR-002 | slider/picker; per-weekday override; save |
| PAR-004 | وقت الشاشة: تفصيل التطبيقات / App Usage Breakdown | 🟢🟡 | S-PAR-002 | sub-screen | PAR-002 | per-app time; category grouping; trend chart |
| PAR-005 | تقارير الاستخدام / Usage Reports (day/week/month) | 🟢🟡 | S-PAR-002 | sub-screen | PAR-002 | period selector; charts; export; empty; loading |
| PAR-006 | تقرير الاستخدام: تفصيل / Usage Report — Detail | 🟢🟡 | S-PAR-002 | sub-screen | PAR-005 | trend lines; comparisons; insights cards |

### 4.2 Schedules, Lock & Bedtime

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| PAR-007 | الجداول الذكية: قائمة / Smart Schedules List | 🟢🟡 | S-PAR-003 | sub-screen | PAR-001 | list; active badge; empty; all 8 |
| PAR-008 | جدول ذكي: إنشاء / Smart Schedule — Creation | 🟢 | S-PAR-003 | sub-screen | PAR-007 | name; time-blocks; weekday/Hijri-day picker; app-rules attach |
| PAR-009 | جدول ذكي: تفصيل/تعديل / Smart Schedule — Detail / Edit | 🟢🟡 | S-PAR-003 | sub-screen | PAR-007 | timeline; toggle; delete; conflict-warn |
| PAR-010 | قفل فوري للجهاز / Instant Device Lock — Trigger | 🟢 | S-PAR-005 | sheet | PAR-001/ADM-018 | child select; duration / until-manual; confirm |
| PAR-011 | حالة الجهاز المقفل / Device Locked State | 🔵 | S-PAR-005 | state-variant | child device | lock-screen overlay; "device locked by parent"; countdown; emergency-unlock |
| PAR-012 | جدول وقت النوم: إعدادات / Bedtime Schedule — Settings | 🟢 | S-PAR-006 | sub-screen | PAR-007 | bedtime/wake time; weekdays; enforce-lock toggle |
| PAR-013 | جدول وقت النوم: إنشاء/تعديل / Bedtime Schedule — Create/Edit | 🟢 | S-PAR-006 | sub-screen | PAR-012 | per-day; Hijri alignment; grace-period |

### 4.3 Extra Time Requests

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| PAR-014 | طلب وقت إضافي: طلب / Extra Time — Child Request | 🔵 | S-PAR-009 | sub-screen | My Time tab | reason; minutes; send; pending-status; denied-status |
| PAR-015 | طلب وقت إضافي: حالة / Extra Time — Child Status | 🔵 | S-PAR-009 | state-variant | PAR-014 | pending; approved (time added); denied (reason) |
| PAR-016 | طلب وقت إضافي: موافقة/رفض / Extra Time — Parent Approve/Deny | 🟢🟡 | S-PAR-009 | state-variant | alert / PAR-001 | child; requested-min; approve / deny + reason; grant-amount slider |

### 4.4 Location, GPS & Geofencing

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| PAR-017 | الخريطة وتتبع GPS / Live GPS Map | 🟢🟡 | S-PAR-011 | sub-screen | PAR-001 | all-children pins; last-update; refresh; no-location state |
| PAR-018 | موقع الطفل: تفصيل / Child Location Detail | 🟢🟡 | S-PAR-011 | sub-screen | PAR-017 | pin; accuracy; battery; address; directions; history link |
| PAR-019 | سجل المواقع: خط زمني / Location History — Map Timeline | 🟢🟡 | S-PAR-012 | sub-screen | PAR-018 | date scrubber; path polyline; stops; empty; loading |
| PAR-020 | سجل المواقع: قائمة / Location History — List | 🟢🟡 | S-PAR-012 | sub-screen | PAR-019 | chronological; duration-at-place; export |
| PAR-021 | المناطق الآمنة: خريطة وقائمة / Safe Zones — Map & List | 🟢 | S-PAR-014 | sub-screen | PAR-001 | zones on map; list; active-status; empty |
| PAR-022 | منطقة آمنة: إنشاء / Safe Zone — Creation | 🟢 | S-PAR-014 | sub-screen | PAR-021 | name; drag pin; radius slider; alert-type pick |
| PAR-023 | منطقة آمنة: تفصيل/تعديل / Safe Zone — Detail / Edit | 🟢 | S-PAR-014 | sub-screen | PAR-021 | radius; members; alerts; delete |
| PAR-024 | تنبيهات وصول/مغادرة / Arrival-Exit Alert Settings | 🟢 | S-PAR-032 | sub-screen | PAR-023 | per-zone enter/exit toggles; per-child; quiet-hours |
| PAR-025 | سجل تنبيهات الموقع / Arrival-Exit Alert History | 🟢🟡 | S-PAR-032 | sub-screen | PAR-021 | log; event type; time; map-link; empty |

### 4.5 App & Web Rules

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| PAR-026 | قواعد التطبيقات: قائمة / App Rules — App List | 🟢 | S-PAR-015 | sub-screen | PAR-001 | installed apps; status badges; search; empty (no apps) |
| PAR-027 | قواعد التطبيقات: تفصيل / App Rules — App Detail | 🟢 | S-PAR-015 | sub-screen | PAR-026 | block/allow; daily-limit; schedule; usage stat |
| PAR-028 | قواعد فئات التطبيقات: قائمة / App Category Rules — List | 🟢 | S-PAR-016 | sub-screen | PAR-001 | categories (games/social/education…); per-category status |
| PAR-029 | قاعدة فئة: إعدادات / App Category Rule — Settings | 🟢 | S-PAR-016 | sub-screen | PAR-028 | allow/block; time-cap; schedule; whitelist apps within |
| PAR-030 | فلترة الويب: الفئات / Web Filtering — Category Toggles | 🟢 | S-PAR-017 | sub-screen | PAR-001 | category list (news/social/gambling…); toggle; search |
| PAR-031 | فلترة الويب: تفصيل / Web Filtering — Detail / Blocked List | 🟢 | S-PAR-017 | sub-screen | PAR-030 | blocked count; recent-blocks; safe-search toggle |
| PAR-032 | استثناءات الويب: قائمة / Web Exceptions — List | 🟢 | S-PAR-018 | sub-screen | PAR-030 | allow/block exceptions; empty; all 8 |
| PAR-033 | استثناءات الويب: إضافة / Web Exceptions — Add | 🟢 | S-PAR-018 | sub-screen | PAR-032 | URL/domain; allow-or-block; apply-to-child |

### 4.6 Content Alerts (29 categories) & Suspicious Keywords

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| PAR-034 | كلمات مريبة: فئات / Suspicious Keywords — 29 Categories | 🟢 | S-PAR-021/045 | sub-screen | PAR-001 | category cards; enabled count; severity; search |
| PAR-035 | كلمات مريبة: تفصيل فئة / Suspicious Keywords — Category Detail | 🟢 | S-PAR-021 | sub-screen | PAR-034 | term list; add custom; severity; toggle category |
| PAR-036 | مراجعة تنبيه كلمة / Suspicious Keyword — Alert Review | 🟢🟡 | S-PAR-021/045 + AI-002 | sub-screen | PAR-045 | flagged context; severity; dismiss / escalate / block |
| PAR-037 | مركز التنبيهات: الكل / Alerts Center — All Categories | 🟢🟡 | S-PAR-045 | primary | Monitor tab | consolidated feed; 29 categories; priority sort; unread; empty; all 8 |
| PAR-038 | تنبيه: تفصيل / Alert — Detail | 🟢🟡 | S-PAR-045 | sub-screen | PAR-037 | evidence; timestamp; child; severity; actions; linked chat msg |
| PAR-039 | تنبيهات: تصفية الفئة / Alert — Category Filter | 🟢🟡 | S-PAR-045 | sheet | PAR-037 | multi-select categories; date-range; severity |

### 4.7 Focus, Anti-Bypass, Kill Switch, School Time

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| PAR-040 | Focus Mode: عرض الطفل / Focus Mode — Child Status Display | 🟢🟡 | S-PAR-034/S-EDU-034 | sub-screen | PAR-002 | active timer; subject; distractions-blocked; ↔ EDU-036 |
| PAR-041 | Focus Mode: مراقبة الأهل / Focus Mode — Parent Monitor View | 🟢🟡 | S-PAR-034 | sub-screen | PAR-001 | active sessions per child; compliance; interruptions log |
| PAR-042 | Anti-Bypass: الإعدادات / Anti-Bypass Settings | 🟢 | S-PAR-038 | sub-screen | PAR-001 | VPN monitor; accessibility monitor; uninstall-guard; toggles |
| PAR-043 | Anti-Bypass: تنبيه تلاعب / Anti-Bypass — Tamper Alert | 🟢🟡 | S-PAR-038 | state-variant | alert / PAR-037 | tamper type; child; time; evidence; remediate |
| PAR-044 | Anti-Bypass: مراجعة/حل / Anti-Bypass — Alert Review / Resolve | 🟢 | S-PAR-038 | sub-screen | PAR-043 | re-lock device; notify child; log; dismiss-false |
| PAR-045 | Kill Switch: تفعيل / Kill Switch — Toggle & Active | 🟢 | S-PAR-041 | sub-screen | PAR-001 | pause/resume internet; per-device; active banner; timer |
| PAR-046 | Kill Switch: تأكيد الإيقاف / Kill Switch — Paused Confirmation | 🟢 | S-PAR-041 | state-variant | PAR-045 | "internet paused" on parent + child; resume; auto-resume countdown |
| PAR-047 | وقت المدرسة: جدول / School Time — Schedule View | 🟢🟡 | S-PAR-052/S-ADM-035 | sub-screen | PAR-001 | Hijri week grid; blocks; active-status; ↔ ADM-041 |
| PAR-048 | وقت المدرسة: إنشاء/تعديل / School Time — Schedule Create/Edit | 🟢 | S-PAR-052 | sub-screen | PAR-047 | time-blocks; Hijri-day; allowed-apps; enforcement toggle |
| PAR-049 | وقت المدرسة: حالة نشطة / School Time — Active State (child device) | 🔵 | S-PAR-052 | state-variant | child device | restricted-mode banner; allowed-apps only; end-time countdown |

## 5. Education Screens (EDU)

### 5.1 Learning Home & Subjects

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| EDU-001 | الرئيسية التعليمية / Learning Home (Child) | 🔵 | S-EDU-002 | primary | Learn tab | continue-card; today's tasks; XP streak; recommendations; empty; all 8 |
| EDU-002 | المواد: قائمة / Subjects List | All | S-EDU-002 | sub-screen | EDU-001 / Learn tab | cards w/ progress; search; empty; all 8 |
| EDU-003 | مادة: تفصيل / Subject Detail | All | S-EDU-002 | sub-screen | EDU-002 | lessons; assignments; progress; tutor-entry |
| EDU-004 | مادة: إضافة / Subject — Creation | 🟢🟡 | S-EDU-001 | sub-screen | EDU-002 | name; color/icon; grade; save |
| EDU-005 | مادة: تعديل / Subject — Edit | 🟢🟡 | S-EDU-001 | sub-screen | EDU-003 | prefilled; archive; delete |

### 5.2 Lessons

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| EDU-006 | الدروس: قائمة / Lessons List (within subject) | All | S-EDU-004 | sub-screen | EDU-003 | ordered; completion check; locked-next; empty |
| EDU-007 | درس: عرض / Lesson — Viewer | All | S-EDU-004 | sub-screen | EDU-006 | content render; media; mark-complete; prev/next |
| EDU-008 | درس: إنشاء / Lesson — Creation | 🟢🟡 | S-EDU-003 | sub-screen | EDU-006 | title; subject; summary; → content editor |
| EDU-009 | درس: محرر المحتوى / Lesson — Content Editor | 🟢🟡 | S-EDU-003 | sub-screen | EDU-008 | rich text; embed image/video/audio; RTL; save-draft |
| EDU-010 | درس: تعديل / Lesson — Edit | 🟢🟡 | S-EDU-003 | sub-screen | EDU-007 | → content editor prefilled; reorder |

### 5.3 Assignments

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| EDU-011 | الواجبات: قائمة / Assignments List (by status) | All | S-EDU-014 | sub-screen | EDU-001/003 | tabs: pending/submitted/graded; counts; empty; all 8 |
| EDU-012 | واجب: إنشاء / Assignment — Creation | 🟢🟡 | S-EDU-009 | sub-screen | EDU-011 | title; subject; Hijri due (SHR-037); → question builder |
| EDU-013 | واجب: منشئ الأسئلة / Assignment — Question Builder | 🟢🟡 | S-EDU-009 | sub-screen | EDU-012 | add MCQ/short-answer/file; points; reorder; delete |
| EDU-014 | واجب: معاينة / Assignment — Preview | 🟢🟡 | S-EDU-009 | sub-screen | EDU-012 | student-view; publish / save-draft |
| EDU-015 | واجب: عرض / Assignment — Detail (student) | 🔵 | S-EDU-010 | sub-screen | EDU-011 | questions; due countdown; submit-entry; attached files |
| EDU-016 | واجب: إرسال / Assignment — Submission | 🔵 | S-EDU-011 | sub-screen | EDU-015 | answer entry; photo/file upload; save-progress; submit |
| EDU-017 | واجب: تأكيد الإرسال / Assignment — Submission Confirmation | 🔵 | S-EDU-011 | state-variant | EDU-016 | success; timestamp; awaiting-grading status |
| EDU-018 | واجب: تصحيح AI / Assignment — AI Grading Results | All | S-EDU-013 + AI-004 | sub-screen | EDU-011 | per-question score; AI feedback; ↔ AIE-008 |
| EDU-019 | واجب: مراجعة التصحيح / Assignment — Grading Review (override) | 🟢🟡 | S-EDU-013 | sub-screen | EDU-018 | adjust score; add note; final-publish |
| EDU-020 | واجب: متتبع الحالة / Assignment — Status Tracker | All | S-EDU-014 | sub-screen | EDU-011 | timeline: assigned→submitted→graded; per-student (parent) |

### 5.4 Quizzes

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| EDU-021 | اختبار: إنشاء / Quiz — Creation | 🟢🟡 | S-EDU-017 | sub-screen | EDU-003 | title; subject; → question builder; → settings |
| EDU-022 | اختبار: منشئ الأسئلة / Quiz — Question Builder | 🟢🟡 | S-EDU-017 | sub-screen | EDU-021 | MCQ/true-false/short; correct-answer; points; reorder |
| EDU-023 | اختبار: إعدادات / Quiz — Settings | 🟢🟡 | S-EDU-017 | sub-screen | EDU-021 | time-limit; attempts; shuffle; passing-score; publish |
| EDU-024 | اختبار: أداء / Quiz — Taking | 🔵 | S-EDU-019 | primary | EDU-011 | question view; progress; timer; auto-save; nav-grid; submit |
| EDU-025 | اختبار: إرسال/حفظ تلقائي / Quiz — Submit / Auto-save | 🔵 | S-EDU-019 | state-variant | EDU-024 | confirm-submit; unanswered warn; saving; saved |
| EDU-026 | اختبار: النتائج / Quiz — Results | All | S-EDU-020 | sub-screen | EDU-024 | score; pass/fail; XP earned; retry; → answer review |
| EDU-027 | اختبار: مراجعة الإجابات / Quiz — Answer Review | 🔵 | S-EDU-020 | sub-screen | EDU-026 | per-question; correct/incorrect; explanation; AI feedback |

### 5.5 Gamification — Points, Badges, Redemption, XP

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| EDU-028 | النقاط: لوحة / Points Dashboard | All | S-EDU-024 | sub-screen | EDU-001 / My Time | balance; streak; recent-awards; empty (new user) |
| EDU-029 | النقاط: السجل / Points History / Transactions | All | S-EDU-024 | sub-screen | EDU-028 | chronological; +/−; source; filter; empty |
| EDU-030 | الشارات: المجموعة / Badges — Collection Gallery | All | S-EDU-028 | sub-screen | EDU-001 | earned/locked grid; progress-to-next; empty |
| EDU-031 | شارة: تفصيل / Badge Detail | All | S-EDU-028 | sub-screen | EDU-030 | artwork; criteria; date-earned; share |
| EDU-032 | متجر الاستبدال: تصفح / Redemption Store — Browse | 🔵 | S-EDU-029 | sub-screen | EDU-028 | items w/ point-cost; categories; insufficient-points badge |
| EDU-033 | استبدال: تأكيد / Redemption — Confirmation / Checkout | 🔵 | S-EDU-029 | sub-screen | EDU-032 | item; cost; balance-after; confirm; parent-approval-required note |
| EDU-034 | استبدال: السجل / Redemption — History | 🔵 | S-EDU-029 | sub-screen | EDU-032 | claimed items; status (pending/approved/fulfilled) |
| EDU-035 | XP والمستويات: لوحة / XP & Levels Dashboard | All | S-EDU-058 | sub-screen | EDU-001 | current level; XP bar; next-level; rewards; empty (new) |
| EDU-036 | XP: تقدم المستوى / XP — Level Progression & Rewards | All | S-EDU-058 | sub-screen | EDU-035 | milestone list; unlocked/per-locked; level-up animation |

### 5.6 Focus Mode

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| EDU-037 | Focus Mode: بدء / Focus Mode — Start Setup | 🔵 | S-EDU-034/035 | sub-screen | EDU-001 | subject; duration; distractions-toggle; start; ↔ PAR-040 |
| EDU-038 | Focus Mode: جلسة نشطة / Focus Mode — Active Session | 🔵 | S-EDU-034/035 | primary | EDU-037 | timer ring; locked-distractions; pause; emergency-exit |
| EDU-039 | Focus Mode: ملخص الجلسة / Focus Mode — Session Summary | 🔵 | S-EDU-034 | state-variant | EDU-038 | duration; focus-score; XP earned; distractions-blocked count |
| EDU-040 | مؤقت Focus: إعداد / Focus Timer — Setup | 🔵 | S-EDU-035 | sheet | EDU-037 | duration picker; preset (25/45/60); break-reminder |
| EDU-041 | مؤقت Focus: اكتمال / Focus Timer — Complete | 🔵 | S-EDU-035 | state-variant | EDU-038 | done; XP; log-session; start-break |

### 5.7 Quran — Memorization & Recitation

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| EDU-042 | قرآن: اختيار السورة/الآية / Quran — Surah & Ayah Selector | All | S-EDU-038/039 | sub-screen | EDU-001 | surah list; juz; ayah range; reciter picker |
| EDU-043 | قرآن: جلسة تحفيظ / Quran — Memorization Session | 🔵 | S-EDU-038 | primary | EDU-042 | ayah display; repeat; hide-text test; mark-memorized |
| EDU-044 | قرآن: متابعة التحفيظ / Quran — Memorization Tracker | All | S-EDU-038 | sub-screen | EDU-042 | surah progress rings; review-due; streak |
| EDU-045 | قرآن: جلسة تلاوة / Quran — Recitation Session | 🔵 | S-EDU-039 | primary | EDU-042 | record; ayah-follow; playback; re-record |
| EDU-046 | قرآن: تحليل التلاوة / Quran — Recitation Analysis & Tajweed | 🔵 | S-EDU-039 + AI-008 | sub-screen | EDU-045 | tajweed errors; accuracy score; per-word highlight; ↔ AIE-011 |

### 5.8 AI Tutor, Adaptive Learning, Placement, Exercises, Recommendations

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| EDU-047 | معلم AI: محادثة / AI Tutor Chat Session | 🔵 | S-EDU-046 + AI-003 | primary | EDU-001 / AI tab | chat; subject-context; hints; ↔ AIE-006; all 8 |
| EDU-048 | معلم AI: اختيار الموضوع / AI Tutor — Topic Selection | 🔵 | S-EDU-046 | sub-screen | EDU-047 | subject; topic; difficulty; recent-topics |
| EDU-049 | التعلم التكيفي: المسار / Adaptive Learning — Path Overview | 🔵 | S-EDU-047 + AI-020 | sub-screen | EDU-001 | skill tree; current node; recommended next; ↔ AIE-010 |
| EDU-050 | التعلم التكيفي: بطاقة توصية / Adaptive — Recommendation Card | 🔵 | S-EDU-047 + AI-007 | state-variant | EDU-001/049 | why-recommended; start; dismiss; ↔ AIE-009 |
| EDU-051 | تمارين متدرجة: أداء / Graded Exercises — Exercise Screen | 🔵 | S-EDU-051 | primary | EDU-049 | question; difficulty-adapts; hint; submit; progress |
| EDU-052 | تمارين متدرجة: النتائج / Graded Exercises — Results | 🔵 | S-EDU-051 | state-variant | EDU-051 | score; mastery-level; next-step; XP |
| EDU-053 | تقييم المستوى: مقدمة / Placement Test — Intro & Start | 🔵 | S-EDU-052 | sub-screen | EDU-001 | subject; duration; instructions; start |
| EDU-054 | تقييم المستوى: أداء / Placement Test — Taking | 🔵 | S-EDU-052 | primary | EDU-053 | adaptive questions; timer; progress; auto-submit |
| EDU-055 | تقييم المستوى: النتائج / Placement Test — Results & Placement | 🔵 | S-EDU-052 | sub-screen | EDU-054 | level; recommended path; strengths/gaps; start-path |
| EDU-056 | توصيات المحتوى التعليمي: تدفق / Educational Content Recommendations Feed | All | AI-007 | sub-screen | EDU-001 | cards; relevance reason; save; start; ↔ AIE-009 |
| EDU-057 | توصيات المحتوى: تفصيل / Educational Content — Detail | All | AI-007 | sub-screen | EDU-056 | preview; start-lesson; difficulty; related |

## 6. AI Screens (AIE)

### 6.1 Family AI Assistant (Gemini 2.5 Flash + RAG)

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| AIE-001 | المساعد الذكي العائلي: محادثة / Family AI Assistant Chat | All | AI-001 | primary | AI tab / Today | chat; context-aware (family RAG); suggested-prompts; citations; all 8 |
| AIE-002 | المساعد: بطاقات اقتراح / AI Assistant Suggestion Cards | All | AI-001 | state-variant | Today dashboard | proactive cards (summary, reminders, insights); dismiss; act |
| AIE-003 | المساعد: مصادر السياق (RAG) / AI Assistant Context Sources | 🟢 | AI-001 | sub-screen | More / AIE-001 | toggle which family data the assistant can read (calendar, tasks, edu, monitoring) |

### 6.2 Sentiment Analysis (behind-the-scenes → surfaced)

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| AIE-004 | تحليل المشاعر: مؤشر / Sentiment Indicator (in-chat state) | All | AI-002 | state-variant | COM-002/003 | subtle tone chip on message/thread; tap → detail; (inline UI) |
| AIE-005 | تحليل المشاعر: مراجعة التنبيه / Sentiment Alert Review (parent) | 🟢🟡 | AI-002 + S-PAR-021 | sub-screen | PAR-037/038 | flagged exchange; sentiment trend; context; → conversation |

### 6.3 AI Private Tutor & Auto-Grading (AI-owned entry points)

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| AIE-006 | معلم خصوصي AI: جلسة / AI Private Tutor Session | 🔵 | AI-003 | primary | AI tab | Socratic dialogue; step-hints; ↔ EDU-047; subject memory |
| AIE-007 | معلم خصوصي: اختيار / AI Tutor — Subject & Mode | 🔵 | AI-003 | sub-screen | AIE-006 | subject; mode (explain/practice/quiz); difficulty |
| AIE-008 | تصحيح تلقائي: مراجعة / Auto Assignment Grading — Review | 🟢🟡 | AI-004 | sub-screen | EDU-018 | AI score; confidence; rubric; override; ↔ EDU-019 |

### 6.4 Recommendations & Quran Analysis (AI-owned entry points)

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| AIE-009 | توصيات تعليمية: تدفق / Educational Recommendations Feed | All | AI-007 | sub-screen | Today / Learn | ranked cards; reason; start; ↔ EDU-056 |
| AIE-010 | توصيات تعليمية ذكية: مسار / Smart Educational Recommendations Path | 🔵 | AI-020 | sub-screen | AIE-009 / EDU-049 | adaptive path; gaps; next-best-action; ↔ EDU-049 |
| AIE-011 | تحليل تلاوة: نتائج / Quran Recitation Analysis Results | 🔵 | AI-008 | sub-screen | EDU-045 | Whisper+Gemini output; tajweed; pronunciation; ↔ EDU-046 |

### 6.5 AI Settings

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| AIE-012 | إعدادات الذكاء الاصطناعي / AI Settings (model/provider/quota) | 🟢 | AI-001/003/008 | sub-screen | More | Gemini/Whisper status; usage quota; data-sharing toggle; off-line degrade |

## 7. Administration Screens (ADM)

### 7.1 Today Dashboard & Admin Hub

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| ADM-001 | لوحة اليوم (الأهل) / Today Dashboard — Parent | 🟢🟡 | S-ADM-033 | primary | Today tab | greeting; family-status cards; alerts; today's events; quick-actions; all 8 |
| ADM-002 | لوحة اليوم (الطفل) / Today Dashboard — Child | 🔵 | S-ADM-033 | primary | My Time tab | screen-time ring; tasks; XP; next-lesson; school-time status |
| ADM-003 | لوحة الإدارة / Admin Hub | 🟢 | S-ADM-001 | primary | More tab | member/device/premium/privacy entry-grid; family-health summary |
| ADM-004 | قائمة المزيد / More Menu Hub (per role) | All | — | primary | More tab | role-gated links: settings, profile, members, premium, help, about |

### 7.2 Invitations & Roles

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| ADM-005 | دعوة أعضاء: طريقة / Invite Members — Method | 🟢 | S-ADM-002 | sub-screen | ADM-003 | Dynamic Link / QR; role-to-invite; share |
| ADM-006 | دعوة أعضاء: قائمة المعلقة / Invite — Pending List | 🟢 | S-ADM-002 | sub-screen | ADM-005 | sent; pending; accepted; expired; resend/revoke |
| ADM-007 | دعوة: تفصيل / Invite — Detail / Resend-Revoke | 🟢 | S-ADM-002 | sub-screen | ADM-006 | status; role; expiry; actions |
| ADM-008 | قبول الدعوة: وصول / Accept Invitation — Landing | 🟡🔵 | S-ADM-004 | state-variant | SHR-048 | family-preview; inviter; role; accept / reject |
| ADM-009 | قبول الدعوة: انضمام / Accept Invitation — Join Flow | 🟡🔵 | S-ADM-004 | onboarding | ADM-008 | profile-confirm; role-confirm; → SHR-009 |
| ADM-010 | إدارة الأدوار: قائمة / Role Management — Roles List | 🟢 | S-ADM-003 | sub-screen | ADM-003 | father/mother/child; member count per role |
| ADM-011 | إدارة الأدوار: مصفوفة الصلاحيات / Role — Permissions Matrix | 🟢 | S-ADM-003 | sub-screen | ADM-010 | feature × role grid; toggle (mother configurable) |
| ADM-012 | إدارة الأدوار: تعديل صلاحيات الأم / Role — Edit Mother Permissions | 🟢 | S-ADM-003 | sub-screen | ADM-011 | per-feature toggles for limited_admin; save; audit |
| ADM-013 | أعضاء العائلة: قائمة / Family Members Roster | 🟢🟡 | S-ADM-006 | sub-screen | ADM-003 | members; role; device-count; status; limits 6/4/1 indicator |
| ADM-014 | عضو العائلة: تفصيل / Family Member Detail | 🟢🟡 | S-ADM-003 | sub-screen | ADM-013 | profile; role; devices; permissions; activity; remove |
| ADM-015 | حدود العائلة 6/4/1 / Family Limits Overview | 🟢 | S-ADM-006 | sub-screen | ADM-013 | current counts; max; upgrade-to-premium for more; enforcement note |

### 7.3 Devices & Permissions

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| ADM-016 | ربط جهاز طفل: معالج / Device Linking Wizard | 🟢 | S-ADM-009 | sub-screen | ADM-003 | step: select child → generate code → pair → verify |
| ADM-017 | ربط جهاز: توليد الرمز / Device Linking — Pairing Code Gen | 🟢 | S-ADM-009 | sub-screen | ADM-016 | QR + code; expiry; regenerate; ↔ SHR-019 |
| ADM-018 | إدارة الأجهزة: قائمة / Device Management — Devices List | 🟢🟡 | S-ADM-010 | sub-screen | ADM-003 | devices; owner; status; battery; last-seen; offline banner |
| ADM-019 | جهاز: تفصيل / Device Detail | 🟢🟡 | S-ADM-010 | sub-screen | ADM-018 | specs; OS; app-version; permissions status; sync; last-location link |
| ADM-020 | جهاز: إعدادات / Device Settings (rename/unlink/relink) | 🟢 | S-ADM-010 | sub-screen | ADM-019 | rename; unlink (confirm); re-link; push-test |
| ADM-021 | الصلاحيات الحساسة: قائمة / Sensitive Permissions — List & Status | 🟢 | S-ADM-013 | sub-screen | ADM-019 | per-permission status (granted/denied); per-device; remediate |
| ADM-022 | صلاحية حساسة: طلب/منح / Sensitive Permission — Request/Grant Flow | 🟢🔵 | S-ADM-013 | state-variant | ADM-021 | rationale → system settings deep-link → verify → confirmed |

### 7.4 Premium, Paywall & Trial

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| ADM-023 | Premium: الباقات / Premium Plans & Pricing | 🟢 | S-ADM-014 | sub-screen | ADM-003/More | free vs 49 SAR; features; trial banner; currency SAR |
| ADM-024 | Premium: اشتراك / Premium Subscribe — Checkout | 🟢 | S-ADM-014 | sub-screen | ADM-023 | payment method; 49 SAR; confirm; processing; error; success |
| ADM-025 | Premium: الاشتراك النشط / Premium Active Subscription | 🟢 | S-ADM-014 | sub-screen | ADM-003 | plan; renew date; manage; cancel; receipt link |
| ADM-026 | Premium: سجل الفواتير / Premium Billing History | 🟢 | S-ADM-014 | sub-screen | ADM-025 | invoices; download; receipts; empty |
| ADM-027 | Paywall: ميزة مقفلة / Paywall — Feature-Locked (generic trigger) | All | S-ADM-016 | state-variant | any premium feature | locked preview; 49 SAR CTA → ADM-023; ↔ SHR-061 |
| ADM-028 | الفترة التجريبية: المتابعة / Trial — 14-Day Tracker | 🟢 | S-ADM-038 | sub-screen | ADM-003 | days-left ring; features-unlocked; upgrade-early |
| ADM-029 | الفترة التجريبية: تحذير الانتهاء / Trial — Expiry Warning | 🟢 | S-ADM-038 | state-variant | banner / ADM-028 | "X days left"; upgrade CTA; dismiss |
| ADM-030 | الفترة التجريبية: منتهية / Trial — Expired State | All | S-ADM-038 | state-variant | any | feature-locked; upgrade CTA; ↔ SHR-060 |

### 7.5 Notifications

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| ADM-031 | الإشعارات: التفضيلات / Notification Preferences (master) | All | S-ADM-020 | sub-screen | More / Settings | master toggle; per-category group toggles; preview |
| ADM-032 | الإشعارات: القنوات / Notification Channels (per 29 categories) | All | S-ADM-022 | sub-screen | ADM-031 | channel list (push/in-app/email/sound); per-category assign |
| ADM-033 | الإشعارات: الجدولة / Notification Scheduling / Quiet Hours | All | S-ADM-023 | sub-screen | ADM-031 | quiet-hours range; Hijri-day override; per-channel schedule |

### 7.6 Settings, Privacy, Language

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| ADM-034 | الإعدادات: الرئيسية / Settings Home (per role) | All | S-ADM-026 | primary | More tab | grouped links; account; privacy; language; notifications; data; about |
| ADM-035 | الإعدادات: الخصوصية / Settings — Privacy | All | S-ADM-026 | sub-screen | ADM-034 | data-sharing toggles; analytics; linked-apps; consent log |
| ADM-036 | الإعدادات: اللغة / Settings — Language (AR/EN) | All | S-ADM-027 | sub-screen | ADM-034 | AR default; EN; instant apply; RTL/LTR switch |
| ADM-037 | خصوصية الطفل: إعدادات (الأب) / Child Privacy Settings — Father | 🟢 | S-ADM-028 | sub-screen | ADM-034 | what child sees about monitoring; data retention; opt-outs |
| ADM-038 | خصوصية الطفل: عرض الطفل / Child Privacy — Child View | 🔵 | S-ADM-028 | sub-screen | More / child | transparency: what is monitored; data rights; request-explanation |

### 7.7 Data Export & Deletion (GDPR/PDPL)

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| ADM-039 | تصدير البيانات: طلب / Data Export — Request & Download | 🟢🟡 | S-ADM-029 | sub-screen | ADM-034 | scope select; format (JSON/CSV); request; privacy-policy link |
| ADM-040 | تصدير البيانات: تقدم / Data Export — Progress & Download | 🟢🟡 | S-ADM-029 | state-variant | ADM-039 | preparing; ready (download link); expired-link; error |
| ADM-041 | حذف البيانات: تأكيد / Data Deletion — Confirm (GDPR/PDPL) | 🟢 | S-ADM-029 | dialog | ADM-034 | warning; type-to-confirm; grace-period note; irreversible; cancel |

### 7.8 School Schedule (Hijri)

| ID | Screen (AR / EN) | Roles | P0 Services | Type | Parent | Key UI States |
|----|------------------|-------|-------------|------|--------|---------------|
| ADM-042 | جدول المدرسة: عرض / School Schedule — View (Hijri) | 🟢🟡 | S-ADM-035/S-PAR-052 | sub-screen | ADM-003/More | Hijri week grid; periods; ↔ PAR-047; active highlight |
| ADM-043 | جدول المدرسة: إنشاء/تعديل / School Schedule — Create/Edit | 🟢 | S-ADM-035 | sub-screen | ADM-042 | periods; subjects; Hijri-day; breaks; ↔ PAR-048 |

## 8. Cross-System Integration Map

The 91 P0 services do not live in silos. Events cascade across systems; each cascade produces integration surfaces already enumerated above. This map records the principal cascades so reviewers can verify no integration screen was missed.

| Trigger (Service) | Cascade Path | Integration Screens Touched |
|-------------------|--------------|------------------------------|
| Geofence breach (S-PAR-014/032) | geofence engine → alert → system message in chat → push notification → Today card | PAR-023/024/025 → PAR-037/038 → COM-002 (system msg) → SHR-033/034 → ADM-001 |
| SOS / crash (S-COM-039) | child trigger → parent full-screen alert → live location → call → log | COM-041/042 → COM-043/044/045 → PAR-018 → COM-011 → ADM-001 |
| Suspicious keyword (S-PAR-021 + AI-002) | detection → sentiment alert → chat flag → parent review | PAR-036/AIE-005 → COM-002 (flag) → PAR-037/038 → ADM-001 |
| Extra-time request (S-PAR-009) | child request → parent alert → approve/deny → time-adjust → child status | PAR-014/015 → PAR-016 → PAR-002 (updated) → ADM-002 |
| Assignment AI grading (S-EDU-013 + AI-004) | submit → AI grade → results → parent/tutor review → points/XP | EDU-016/017 → EDU-018/AIE-008 → EDU-019 → EDU-028/035 |
| Focus Mode (S-EDU-034 + S-PAR-034) | child starts → parent monitor → screen-time accounting → Today | EDU-037/038 → PAR-040/041 → PAR-002 → ADM-001/002 |
| Kill Switch (S-PAR-041) | parent pause → child paused-state → monitoring log → resume | PAR-045/046 → ADM-001 |
| School Time (S-PAR-052 + S-ADM-035) | schedule active → child restricted-mode → parent status → app-rules | ADM-042/043 → PAR-047/048/049 → PAR-026/027 |
| Trial expiry (S-ADM-038) | expiry → paywall on premium features → upgrade flow | SHR-060/ADM-030 → ADM-027 → ADM-023/024 |
| Invite accept (S-ADM-002/004) | link → landing → join → role-confirm → onboarding | SHR-048 → ADM-008/009 → SHR-009 |
| Device pairing (S-ADM-009) | father generates code → child scans → permissions → verified | ADM-016/017 → SHR-019/020/021 → SHR-011–018 → ADM-018/021 |
| Quran recitation (S-EDU-039 + AI-008) | record → Whisper+Gemini analysis → tajweed feedback → progress | EDU-045 → AIE-011/EDU-046 → EDU-044 |

## 9. Summary Counts

### 9.1 By System

| System | ID Prefix | Count |
|--------|-----------|-------|
| Shared / Meta | SHR | 61 |
| Communications | COM | 52 |
| Monitoring | PAR | 49 |
| Education | EDU | 57 |
| AI | AIE | 12 |
| Administration | ADM | 43 |
| **Total** | | **274** |

### 9.2 By Screen Type

| Type | Count | Notes |
|------|-------|-------|
| primary | 30 | tab-level / top-level navigable surfaces |
| sub-screen | 155 | drilled-into detail / creation / edit / list surfaces |
| state-variant | 38 | distinct navigable states (call, SOS, trial-expired, paywall, locked, paused) |
| onboarding | 22 | first-launch flow steps incl. 8 permission grants + join flow |
| sheet | 13 | bottom sheets / action sheets / inline pickers |
| template | 7 | shared state-variant design specs referenced by all screens |
| component-screen | 5 | reusable full-screen overlays (date picker, media viewers, photo picker) |
| dialog | 4 | modals (confirmations, deletion, logout) |

> The ~274 figure is the sum of genuinely distinct surfaces. It is not padded: each of the 7 state-variant **templates** (SHR-055→061) documents the mandatory eight states once and is referenced by every screen's "Key UI states" column rather than multiplied per screen. If every screen's eight states were enumerated as separate rows the count would exceed 2,000 — that would obscure, not aid, planning. State variants appear as their own rows only where they are meaningfully distinct navigable surfaces (e.g. call ringing vs. in-call vs. ended; SOS trigger vs. active vs. received; trial-expired; paywall; device-locked; kill-switch-paused).

### 9.3 Growth vs. Prior Catalog

| Pass | Count | Method |
|------|-------|--------|
| Prior (frozen) | 62 | collapsed multi-service rows (e.g. 8 services in "Conversation detail") |
| Expanded (this) | 274 | one row per genuinely distinct surface, sub-screen, dialog, sheet, state, onboarding step, permission grant, and integration screen |

The delta is driven by: (a) decomposing collapsed rows — calendar (1→7), assignments (1→10), quiz (1→7), monitoring (12→49), admin (11→43); (b) adding 22 onboarding/permission steps the prior pass omitted entirely; (c) adding 7 reusable component-screens and 7 state templates; (d) adding system/recovery screens (offline, sync, crash, force-update, deep-link, legal/help); (e) enumerating call states, SOS states, chat-lock flow, and cross-system alert surfaces.

## 10. P0 Coverage Check Matrix

Every one of the 91 P0 services must map to at least one screen. ✓ = covered; the screens column lists the primary screen(s) that deliver the service. A service is "covered" if a user can complete its function via the listed screens.

### 10.1 Communications (S-COM) — 20 P0

| ID | Service | Covered | Screen(s) |
|----|---------|---------|-----------|
| S-COM-001 | محادثة جماعية | ✓ | COM-001, COM-002, COM-007 |
| S-COM-002 | محادثة فردية | ✓ | COM-001, COM-003, COM-007 |
| S-COM-003 | مجموعة فرعية | ✓ | COM-001, COM-004, COM-005, COM-006 |
| S-COM-004 | رد على رسالة | ✓ | COM-002/003/004 (COM-020 state) |
| S-COM-006 | مكالمة صوت P2P | ✓ | COM-009/010/011/012/013 |
| S-COM-010 | وسائط | ✓ | COM-014, COM-008, SHR-038/039 |
| S-COM-011 | تأكيد قراءة | ✓ | COM-002/003, COM-019 |
| S-COM-025 | إرسال ملف | ✓ | COM-014, COM-017, SHR-040 |
| S-COM-029 | إرسال صوت | ✓ | COM-015 |
| S-COM-030 | إضافة حدث تقويمي | ✓ | COM-021/022/023, COM-024, SHR-037 |
| S-COM-031 | تعديل/حذف حدث | ✓ | COM-025, COM-026, COM-027 |
| S-COM-032 | تذكيرات/مهام | ✓ | COM-028/029/030/031 |
| S-COM-033 | قائمة تسوق مشتركة | ✓ | COM-032/033/034 |
| S-COM-035 | بث موقع لحظي | ✓ | COM-035/036/037 |
| S-COM-036 | استطلاعات | ✓ | COM-038/039/040 |
| S-COM-039 | SOS + كشف حوادث | ✓ | COM-041/042/043/044/045/046 |
| S-COM-041 | رسالة صوتية + تفريغ | ✓ | COM-015, COM-016 |
| S-COM-044 | ترجمة لحظية | ✓ | COM-047, COM-048, COM-011 (in-call) |
| S-COM-048 | ردود تفاعلية سريعة | ✓ | COM-018 |
| S-COM-052 | قفل محادثة | ✓ | COM-049/050/051/052 |

### 10.2 Monitoring (S-PAR) — 20 P0

| ID | Service | Covered | Screen(s) |
|----|---------|---------|-----------|
| S-PAR-001 | حد يومي وقت الشاشة | ✓ | PAR-002, PAR-003 |
| S-PAR-002 | تقارير الاستخدام | ✓ | PAR-004, PAR-005, PAR-006 |
| S-PAR-003 | جداول ذكية | ✓ | PAR-007/008/009 |
| S-PAR-005 | قفل فوري | ✓ | PAR-010, PAR-011 |
| S-PAR-006 | جدول وقت النوم | ✓ | PAR-012, PAR-013 |
| S-PAR-009 | طلب وقت إضافي | ✓ | PAR-014/015/016 |
| S-PAR-011 | تتبع GPS لحظي | ✓ | PAR-017, PAR-018 |
| S-PAR-012 | سجل مواقع | ✓ | PAR-019, PAR-020 |
| S-PAR-014 | مناطق آمنة | ✓ | PAR-021/022/023/024/025 |
| S-PAR-015 | حظر/سماح تطبيقات | ✓ | PAR-026, PAR-027 |
| S-PAR-016 | قواعد فئات التطبيقات | ✓ | PAR-028, PAR-029 |
| S-PAR-017 | فلترة ويب | ✓ | PAR-030, PAR-031 |
| S-PAR-018 | استثناءات ويب | ✓ | PAR-032, PAR-033 |
| S-PAR-021 | كشف كلمات مريبة | ✓ | PAR-034/035/036 |
| S-PAR-032 | تنبيه وصول/مغادرة | ✓ | PAR-024, PAR-025 |
| S-PAR-034 | Focus في المراقبة | ✓ | PAR-040, PAR-041 |
| S-PAR-038 | Anti-bypass | ✓ | PAR-042/043/044 |
| S-PAR-041 | Kill Switch | ✓ | PAR-045, PAR-046 |
| S-PAR-045 | 29 فئة تنبيهات | ✓ | PAR-037/038/039 |
| S-PAR-052 | School Time | ✓ | PAR-047/048/049, ADM-042 |

### 10.3 Education (S-EDU) — 24 P0

| ID | Service | Covered | Screen(s) |
|----|---------|---------|-----------|
| S-EDU-001 | إضافة مادة | ✓ | EDU-004 |
| S-EDU-002 | عرض المواد | ✓ | EDU-001, EDU-002, EDU-003 |
| S-EDU-003 | إضافة درس | ✓ | EDU-008, EDU-009 |
| S-EDU-004 | عرض درس | ✓ | EDU-006, EDU-007 |
| S-EDU-009 | إنشاء واجب | ✓ | EDU-012/013/014 |
| S-EDU-010 | عرض واجب | ✓ | EDU-015 |
| S-EDU-011 | إرسال واجب | ✓ | EDU-016, EDU-017 |
| S-EDU-013 | تصحيح AI | ✓ | EDU-018, EDU-019, AIE-008 |
| S-EDU-014 | حالة الواجب | ✓ | EDU-011, EDU-020 |
| S-EDU-017 | إنشاء اختبار | ✓ | EDU-021/022/023 |
| S-EDU-019 | أداء اختبار | ✓ | EDU-024, EDU-025 |
| S-EDU-020 | نتائج الاختبار | ✓ | EDU-026, EDU-027 |
| S-EDU-024 | نقاط | ✓ | EDU-028, EDU-029 |
| S-EDU-028 | شارات | ✓ | EDU-030, EDU-031 |
| S-EDU-029 | استبدال نقاط | ✓ | EDU-032/033/034 |
| S-EDU-034 | Focus Mode | ✓ | EDU-037/038/039, PAR-040/041 |
| S-EDU-035 | Focus timer | ✓ | EDU-040, EDU-041 |
| S-EDU-038 | تحفيظ قرآن | ✓ | EDU-042, EDU-043, EDU-044 |
| S-EDU-039 | تلاوة قرآن | ✓ | EDU-042, EDU-045, EDU-046 |
| S-EDU-046 | معلم AI | ✓ | EDU-047, EDU-048, AIE-006/007 |
| S-EDU-047 | تعلم تكيفي | ✓ | EDU-049, EDU-050, AIE-010 |
| S-EDU-051 | تمارين متدرجة | ✓ | EDU-051, EDU-052 |
| S-EDU-052 | تقييم مستوى | ✓ | EDU-053/054/055 |
| S-EDU-058 | XP + مستويات | ✓ | EDU-035, EDU-036 |

### 10.4 AI — 7 P0

| ID | Service | Covered | Screen(s) |
|----|---------|---------|-----------|
| AI-001 | المساعد الذكي العائلي | ✓ | AIE-001, AIE-002, AIE-003 |
| AI-002 | تحليل مشاعر الرسائل | ✓ | AIE-004, AIE-005 |
| AI-003 | معلم خصوصي | ✓ | AIE-006, AIE-007, EDU-047/048 |
| AI-004 | تصحيح واجبات تلقائي | ✓ | AIE-008, EDU-018/019 |
| AI-007 | توصيات محتوى تعليمي | ✓ | AIE-009, EDU-056/057 |
| AI-008 | تحليل تلاوة القرآن | ✓ | AIE-011, EDU-046 |
| AI-020 | توصيات تعليمية ذكية | ✓ | AIE-010, EDU-049/050 |

### 10.5 Administration (S-ADM) — 20 P0

| ID | Service | Covered | Screen(s) |
|----|---------|---------|-----------|
| S-ADM-001 | لوحة الإدارة | ✓ | ADM-003, ADM-004 |
| S-ADM-002 | دعوة أعضاء | ✓ | ADM-005/006/007 |
| S-ADM-003 | إدارة الأدوار | ✓ | ADM-010/011/012, ADM-014 |
| S-ADM-004 | قبول/رفض دعوة | ✓ | ADM-008, ADM-009, SHR-048 |
| S-ADM-006 | حدود العائلة 6/4/1 | ✓ | ADM-013, ADM-015 |
| S-ADM-009 | ربط جهاز طفل | ✓ | ADM-016/017, SHR-019/020/021 |
| S-ADM-010 | إدارة أجهزة | ✓ | ADM-018/019/020 |
| S-ADM-013 | صلاحيات حساسة | ✓ | ADM-021, ADM-022 |
| S-ADM-014 | Premium 49 ر.س | ✓ | ADM-023/024/025/026 |
| S-ADM-016 | Paywall | ✓ | ADM-027, SHR-061 |
| S-ADM-020 | إشعارات — تفضيلات | ✓ | ADM-031 |
| S-ADM-022 | إشعارات — قنوات | ✓ | ADM-032 |
| S-ADM-023 | إشعارات — جدولة | ✓ | ADM-033 |
| S-ADM-026 | إعدادات + خصوصية | ✓ | ADM-034, ADM-035 |
| S-ADM-027 | اللغة AR/EN | ✓ | ADM-036, SHR-002 |
| S-ADM-028 | خصوصية الطفل | ✓ | ADM-037, ADM-038 |
| S-ADM-029 | تصدير + حذف | ✓ | ADM-039/040/041 |
| S-ADM-033 | لوحة اليوم | ✓ | ADM-001, ADM-002 |
| S-ADM-035 | جدول المدرسة | ✓ | ADM-042, ADM-043 |
| S-ADM-038 | الفترة التجريبية | ✓ | ADM-028/029/030, SHR-060 |

### 10.6 Coverage Result

| System | P0 Count | Covered | Uncovered |
|--------|----------|---------|-----------|
| Communications | 20 | 20 | 0 |
| Monitoring | 20 | 20 | 0 |
| Education | 24 | 24 | 0 |
| AI | 7 | 7 | 0 |
| Administration | 20 | 20 | 0 |
| **Total** | **91** | **91** | **0** |

**All 91 P0 services map to at least one screen. No service is uncovered.** AI services that overlap Education (AI-003/004/007/008/020) are covered from both the AI entry point (AIE-*) and the Education surface (EDU-*); both are listed so the cross-system integration is explicit.

---

*End of catalog. Counts are derived, not capped.*
