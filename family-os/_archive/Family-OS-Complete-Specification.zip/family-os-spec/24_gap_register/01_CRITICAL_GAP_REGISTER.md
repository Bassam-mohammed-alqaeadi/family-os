# Family OS — Critical Gap Register

> **Document status:** Comprehensive gap analysis — all categories
> **Purpose:** Surface what remains unresolved before engineering can begin full implementation
> **Companion docs:** Screen Specifications Master · Edge Cases & Error States

---

## Summary

| Category | Gaps | Critical/High | Medium | Low |
|----------|------|---------------|--------|-----|
| Requirements | 5 | 3 | 1 | 1 |
| Screen | 4 | 3 | 1 | 0 |
| Data | 3 | 2 | 1 | 0 |
| Workflow | 3 | 2 | 1 | 0 |
| Security | 3 | 3 | 0 | 0 |
| Compliance | 2 | 2 | 0 | 0 |
| AI | 3 | 3 | 0 | 0 |
| Testing | 2 | 2 | 0 | 0 |
| Operational | 3 | 2 | 1 | 0 |
| Open Decisions | 12 | 6 | 4 | 2 |
| **Total** | **40** | **28** | **8** | **3** |

---

## 1. Requirements Gaps

### GAP-REQ-01
| Field | Value |
|---|---|
| **Gap ID** | GAP-REQ-01 |
| **Category** | Requirements |
| **Description** | **SOS escalation protocol** — the SOS feature references emergency contacts and escalation to authorities, but no spec defines: who are emergency contacts (family-external?), how are they provisioned, what data they receive, what liability disclaimers are needed, and whether integration with local emergency services (911, 999, 112) is supported or only contact calling. |
| **Impact** | **High** |
| **Affected components** | SCR-COM-07, EC-SAF-01, EC-SAF-02, EC-COM-05 |
| **Recommendation** | Define a complete SOS escalation chain: child → parents → emergency contacts (family-external) → local emergency services. Specify data each tier receives, consent requirements for emergency contacts, and liability limitations. Consult legal for country-specific emergency calling requirements (KSA 911, UAE 999, Egypt 122). |
| **Priority** | P0 — safety-critical, must resolve before MVP |

### GAP-REQ-02
| Field | Value |
|---|---|
| **Gap ID** | GAP-REQ-02 |
| **Category** | Requirements |
| **Description** | **Mother permissions default set (Open Decision #6)** — when a Mother joins, which of the 8 exclusive features is she granted by default? No default set is specified. This blocks the Create Family and Member onboarding flows from producing a deterministic result. |
| **Impact** | **High** |
| **Affected components** | SCR-SHR-04, SCR-ADM-02, SCR-PAR-01, all 8 exclusive screens |
| **Recommendation** | Define a default permission set: recommend "monitoring view" by default (Screen Time, Map, Device Lock, Content Alerts visible; Safe Zones, App Rules, Web Filter, Kill Switch, Anti-bypass, Members, Devices, Child Privacy remain Father-only). Father can escalate Mother's access from SCR-ADM-02. |
| **Priority** | P0 — blocks onboarding flow |

### GAP-REQ-03
| Field | Value |
|---|---|
| **Gap ID** | GAP-REQ-03 |
| **Category** | Requirements |
| **Description** | **Family size limits** — no specification exists for maximum family members, maximum children, or maximum devices per family. This affects data architecture, subscription pricing, and UX design (e.g., child selector scalability). |
| **Impact** | **Medium** |
| **Affected components** | SCR-ADM-02, SCR-ADM-03, SCR-PAR-01, all monitoring screens |
| **Recommendation** | Define limits: recommend max 2 parents, 10 children, 3 devices per member. Premium tier may extend limits. Validate UX with 10+ children (scrolling, selectors). |
| **Priority** | P1 — blocks data model finalization |

### GAP-REQ-04
| Field | Value |
|---|---|
| **Gap ID** | GAP-REQ-04 |
| **Category** | Requirements |
| **Description** | **Notification sound design** — the spec references notification sounds for various priorities (Critical, High, Normal, Low) and SOS, but no audio design spec exists. Sound design is culturally significant for an Arabic-first product. |
| **Impact** | **Low** |
| **Affected components** | SCR-ADM-05, SCR-COM-07, all notification surfaces |
| **Recommendation** | Commission sound design: SOS (urgent, culturally neutral), educational rewards, message arrival. Define 4 notification tiers + SOS. |
| **Priority** | P2 — does not block engineering; blocks polish |

### GAP-REQ-05
| Field | Value |
|---|---|
| **Gap ID** | GAP-REQ-05 |
| **Category** | Requirements |
| **Description** | **Quran curriculum scope** — the Quran recitation feature (SCR-EDU-10) does not specify: which qira'at are supported (Hafs only? Warsh?), which masahif are displayed (Medina Mushaf? Uthmani?), which Qari audio sources are licensed, and whether the curriculum covers Tajweed theory in addition to practice. |
| **Impact** | **High** |
| **Affected components** | SCR-EDU-10, SCR-AI-04, QuranProgress entity |
| **Recommendation** | Initial scope: Hafs an Asim reading only, Medina Mushaf (Uthmani script), 3 licensed Qari audio options (e.g., Al-Husary, Al-Minshawi, Abdul Basit). Tajweed theory as separate lesson track under Education. Future: additional qira'at as expansion. Obtain audio licensing agreements. |
| **Priority** | P0 — blocks Quran feature development |

---

## 2. Screen Gaps

### GAP-SCR-01
| Field | Value |
|---|---|
| **Gap ID** | GAP-SCR-01 |
| **Category** | Screen |
| **Description** | **Onboarding flow screens missing** — no dedicated onboarding screens exist for: first-time Father setup (post-family creation), first-time Mother setup (post-invite acceptance), first-time Child setup (post-device enrollment). These are critical for retention and feature discovery. |
| **Impact** | **High** |
| **Affected components** | Post-SCR-SHR-04, post-enrollment flows |
| **Recommendation** | Design 3 onboarding flows: Father (5 steps: set profile → invite members → enroll child device → configure monitoring → explore dashboard), Mother (3 steps: set profile → review permissions → explore features), Child (3 steps: set profile → take placement test → start first lesson). Each flow: skippable, re-accessible, progress-tracked. |
| **Priority** | P0 — blocks user activation |

### GAP-SCR-02
| Field | Value |
|---|---|
| **Gap ID** | GAP-SCR-02 |
| **Category** | Screen |
| **Description** | **Child's view of monitoring surfaces** — the spec describes parent-facing monitoring screens, but the child's lived experience of BEING monitored is underspecified. What does the child see when: screen time is almost up? Device is about to lock? They're outside a safe zone? A content alert was triggered about their message? |
| **Impact** | **High** |
| **Affected components** | Child's version of SCR-PAR-02, -03, -06, -09 |
| **Recommendation** | Design child-facing monitoring surfaces: Screen Time → countdown bar overlay + "انتهى وقتك" full-screen; Device Lock → warning countdown → lock screen UX with always-allowed apps; Safe Zone → "خرجت من المنطقة الآمنة" notification; Content Alert → no notification to child (parent-only, to preserve trust). Each with age-appropriate Arabic language. |
| **Priority** | P0 — blocks child UX |

### GAP-SCR-03
| Field | Value |
|---|---|
| **Gap ID** | GAP-SCR-03 |
| **Category** | Screen |
| **Description** | **Device enrollment flow screens** — the spec references device enrollment via QR code but no screen spec exists for: the enrollment setup screen on parent device, the enrollment receiver screen on child device, the permission granting guided flow on child device, and the enrollment confirmation/success screen. |
| **Impact** | **High** |
| **Affected components** | SCR-ADM-03, child device setup |
| **Recommendation** | Design device enrollment flow: Parent → generate QR with enrollment token (SCR-ADM-03); Child device → scan QR or enter code → install/open app → guided permission grant (step-by-step: Device Admin, Accessibility, Usage Stats, Location, Notification) → confirmation → sync → parent receives "تم ربط جهاز [child]" notification. |
| **Priority** | P0 — blocks device management |

### GAP-SCR-04
| Field | Value |
|---|---|
| **Gap ID** | GAP-SCR-04 |
| **Category** | Screen |
| **Description** | **Call/voice chat screens** — conversation detail (SCR-COM-02) references a call icon for 1:1, but no screen spec exists for voice/video calling within the family. It's unclear whether the product supports in-app VoIP calling or only facilitates native phone dialing. |
| **Impact** | **Medium** |
| **Affected components** | SCR-COM-02, SCR-COM-07 (SOS call), communication system |
| **Recommendation** | Decide: in-app VoIP (WebRTC, significant engineering) vs. native phone dialer (`tel:` intent, trivial). Recommend MVP: native phone dialer. V2: in-app VoIP. Design screen if VoIP is chosen. |
| **Priority** | P1 — does not block core messaging |

---

## 3. Data Gaps

### GAP-DATA-01
| Field | Value |
|---|---|
| **Gap ID** | GAP-DATA-01 |
| **Category** | Data |
| **Description** | **Complete entity relationship diagram missing** — screen specs reference 40+ entity types (User, Family, Device, Message, Conversation, Event, Task, ShoppingItem, ScreenTimeSession, SafeZone, AppRule, ContentAlert, LearnerProfile, AdaptivePath, Badge, XPHistory, etc.) but no formal ERD or data model document exists with relationships, cardinalities, key fields, and cascade rules. |
| **Impact** | **High** |
| **Affected components** | All screens, API design, database schema |
| **Recommendation** | Author a complete data model document: all entities, their fields (with types), relationships (1:1, 1:N, N:N), required vs. optional, default values, validation rules, cascade rules for deletion, and soft-delete policies. This is a prerequisite for API design. |
| **Priority** | P0 — blocks API and database design |

### GAP-DATA-02
| Field | Value |
|---|---|
| **Gap ID** | GAP-DATA-02 |
| **Category** | Data |
| **Description** | **Encryption specification missing** — locked conversations (SCR-COM-11) reference encryption, but no spec defines: encryption algorithm, key management (generation, storage, rotation, recovery), end-to-end vs. server-side encryption, and how parental content monitoring coexists with encryption (the fundamental tension between privacy and safety). |
| **Impact** | **High** |
| **Affected components** | SCR-COM-11, SCR-COM-02, SCR-PAR-09 content alerts, SCR-ADM-07 child privacy |
| **Recommendation** | Define encryption architecture: E2E for parent-to-parent locked conversations (fully private); server-side encryption for child conversations (allows content analysis for safety). Key management: per-conversation keys, stored in device keystore, recovered via parent re-auth. Algorithm: AES-256-GCM for messages, RSA-2048 for key exchange. |
| **Priority** | P0 — blocks security architecture |

### GAP-DATA-03
| Field | Value |
|---|---|
| **Gap ID** | GAP-DATA-03 |
| **Category** | Data |
| **Description** | **Offline data storage limits and eviction policy** — the offline architecture caches data locally but no spec defines: maximum local cache size, cache eviction policy (LRU? priority-based?), what happens when device storage is full, and how large families with many messages/media manage local storage. |
| **Impact** | **Medium** |
| **Affected components** | All offline features, SCR-COM-08 cache management, SCR-ADM-06 settings |
| **Recommendation** | Define cache policy: max cache size configurable (default 500 MB); priority-based eviction (SOS data never evicted, monitoring rules next, messages next, media last); warning at 80% capacity; user can clear from settings. Media: compressed cached versions, full-res on demand. |
| **Priority** | P1 — blocks offline architecture |

---

## 4. Workflow Gaps

### GAP-WF-01
| Field | Value |
|---|---|
| **Gap ID** | GAP-WF-01 |
| **Category** | Workflow |
| **Description** | **Member removal workflow incomplete** — SCR-ADM-02 lists removal as an action, but no spec defines: what happens to the removed member's data, their active sessions, their conversations, their learning progress (if child), their device enrollment, and notification to the removed member. |
| **Impact** | **High** |
| **Affected components** | SCR-ADM-02, SCR-ADM-03, all conversation/data screens |
| **Recommendation** | Define removal workflow: • Child removed: data preserved in family (visible to parents), child device unlinked, child app shows "تمت إزالتك من العائلة", learning progress preserved and transferable, conversations archived read-only. • Mother removed: conversations archived, monitoring access revoked immediately, own data exportable for 30 days. • Father cannot be removed (must transfer ownership first). |
| **Priority** | P0 — blocks family management |

### GAP-WF-02
| Field | Value |
|---|---|
| **Gap ID** | GAP-WF-02 |
| **Category** | Workflow |
| **Description** | **Curriculum content creation pipeline** — Education screens assume curriculum content exists (subjects, lessons, quizzes, assignments), but no spec describes: who creates the content, the content management system, content approval workflow, content versioning, or localization pipeline. |
| **Impact** | **High** |
| **Affected components** | SCR-EDU-01 through SCR-EDU-15, all education features |
| **Recommendation** | Define content pipeline: content team or licensed curriculum partner creates lessons; CMS with approval workflow (draft → review → approved → published); content versioned so students mid-lesson aren't affected by updates; Arabic-first; English phased. AI-generated supplementary exercises with human review. |
| **Priority** | P0 — blocks education feature |

### GAP-WF-03
| Field | Value |
|---|---|
| **Gap ID** | GAP-WF-03 |
| **Category** | Workflow |
| **Description** | **Family transfer / merge workflow** — no spec exists for: transferring a child from one family to another (divorce/custody change), merging two families, or handling a child who is in one family and wants to join another. |
| **Impact** | **Medium** |
| **Affected components** | SCR-ADM-02, SCR-SHR-04, family model |
| **Recommendation** | Design transfer flow: Father of origin approves transfer → child removed from origin (data exportable) → child invited to new family → placement test optional → new adaptive path. Divorce scenario: consult legal + cultural advisors for MENA-specific custody norms. |
| **Priority** | P1 — not MVP but inevitable for real families |

---

## 5. Security Gaps

### GAP-SEC-01
| Field | Value |
|---|---|
| **Gap ID** | GAP-SEC-01 |
| **Category** | Security |
| **Description** | **API authentication and authorization specification** — no spec defines: API authentication mechanism (JWT? OAuth?), token lifecycle (access/refresh), token storage on device, RBAC enforcement model on every endpoint, rate limiting strategy, or brute force protection. |
| **Impact** | **High** |
| **Affected components** | All API endpoints, all screens |
| **Recommendation** | Define API security architecture: JWT with short-lived access tokens (15 min) + refresh tokens (30 days); token stored in encrypted SharedPreferences (Android Keystore backed); RBAC middleware on every endpoint enforcing role+permission checks; rate limiting (60 req/min standard, 5 req/min auth); brute force lockout (5 failed attempts → 15 min cooldown). |
| **Priority** | P0 — blocks API development |

### GAP-SEC-02
| Field | Value |
|---|---|
| **Gap ID** | GAP-SEC-02 |
| **Category** | Security |
| **Description** | **Child impersonation attack surface** — if someone gains physical access to a child's device, they could send messages as the child, trigger false SOS, access educational content, or exfiltrate family data visible to the child role. No spec addresses device-level auth for children, session timeout, or suspicious activity detection. |
| **Impact** | **High** |
| **Affected components** | All child-accessible screens, SCR-COM-07 SOS, messaging |
| **Recommendation** | Define child session security: simplified PIN (4-digit) or pattern for child app access; session timeout configurable by parent (default 30 min inactive); SOS false-trigger protection (3 s hold); suspicious activity detection (unusual messaging patterns, location jumps); parent notification for new device login on child's account. |
| **Priority** | P0 — blocks security model |

### GAP-SEC-03
| Field | Value |
|---|---|
| **Gap ID** | GAP-SEC-03 |
| **Category** | Security |
| **Description** | **Location data security** — GPS tracking generates highly sensitive personal data. No spec addresses: location data encryption in transit and at rest, granular access controls, retention policy, anonymization for analytics, or protection against unauthorized access to location history. |
| **Impact** | **High** |
| **Affected components** | SCR-PAR-05, SCR-PAR-06, SCR-COM-06, SCR-COM-07 |
| **Recommendation** | Define location security: TLS 1.3 in transit; AES-256 at rest; location history retention max 90 days (configurable by parent down to 7); access log for every location data read; location data never shared with third parties; anonymized aggregate data only for analytics; geo-data separated from PII in database architecture. |
| **Priority** | P0 — blocks compliance and safety |

---

## 6. Compliance Gaps

### GAP-CMP-01
| Field | Value |
|---|---|
| **Gap ID** | GAP-CMP-01 |
| **Category** | Compliance |
| **Description** | **COPPA / GDPR-K / MENA data law compliance specification** — the app processes children's data extensively. No comprehensive compliance document addresses: parental consent mechanism, children's rights, age verification, data minimization, and country-specific variations (Saudi PDPL Art. 14, UAE Federal Decree-Law 45/2021, Egypt Data Protection Law No. 151/2020, Jordan, Iraq). |
| **Impact** | **High** |
| **Affected components** | SCR-ADM-07, SCR-ADM-08, all child data processing, onboarding, deletion |
| **Recommendation** | Commission a compliance review covering: Saudi PDPL (primary market), UAE data law, Egypt data law, COPPA (if US market), GDPR Article 8 (if EU). Define: verifiable parental consent mechanism, data minimization policy, children's data retention policy, age-gated rights, annual compliance review process. |
| **Priority** | P0 — legal blocker for launch |

### GAP-CMP-02
| Field | Value |
|---|---|
| **Gap ID** | GAP-CMP-02 |
| **Category** | Compliance |
| **Description** | **AI processing transparency** — GDPR/PDPL require transparency about automated decision-making. The app uses AI for: content analysis, Quran analysis, adaptive learning, recommendations. No spec addresses: informing users about AI processing, right to explanation, opt-out mechanisms, human override paths, or AI bias auditing. |
| **Impact** | **High** |
| **Affected components** | SCR-AI-01 through SCR-AI-05, SCR-PAR-09, SCR-EDU-13, all AI features |
| **Recommendation** | Define AI transparency framework: "لماذا هذا الاقتراح؟" explainability link on all AI outputs; opt-out for non-safety AI; human override for AI grading/alerts; annual AI bias audit; clear disclosure in privacy policy about AI processing types and purposes. |
| **Priority** | P0 — legal requirement |

---

## 7. AI Gaps

### GAP-AI-01
| Field | Value |
|---|---|
| **Gap ID** | GAP-AI-01 |
| **Category** | AI |
| **Description** | **AI safety guardrails specification** — AI Tutor/Assistant interact directly with children but no spec defines: content safety filters, response boundaries, topic restrictions, handling of sensitive questions (suicide, abuse, self-harm), escalation to parents for concerning interactions, model version management, or prompt injection defense. |
| **Impact** | **High** |
| **Affected components** | SCR-EDU-11, SCR-AI-01, SCR-AI-02, all AI chat interfaces |
| **Recommendation** | Define AI safety framework: topic allowlist (educational, family, general knowledge); topic blocklist (violence, sexual, political, extremism); sensitive topic handling (self-harm, abuse → immediate parent alert + resource links); response validation layer between model and user; model version pinning; output toxicity scoring; prompt injection defense (system prompt hardening, input sanitization, output filtering); regular red-team testing. |
| **Priority** | P0 — child safety critical |

### GAP-AI-02
| Field | Value |
|---|---|
| **Gap ID** | GAP-AI-02 |
| **Category** | AI |
| **Description** | **Gemini model selection, fallback chain, and cost control** — the spec references "Gemini" but doesn't specify: which model per feature (Flash, Pro, Ultra), fallback chain when primary model is unavailable, cost budgeting per feature, daily/monthly spend caps, or token usage tracking. Directly relates to Open Decision #4. |
| **Impact** | **High** |
| **Affected components** | All AI features, cost model, reliability architecture |
| **Recommendation** | Define model matrix: AI Tutor → Gemini Pro (quality); Translation → Gemini Flash (speed/cost); Content Analysis → Gemini Flash (volume); Quran Analysis → specialized fine-tuned model; Recommendations → Gemini Flash (batch). Fallback: Pro → Flash → cached → manual. Cost: define per-user monthly AI budget ($1.50 target), implement token tracking per feature, rate limiting per feature and per family. |
| **Priority** | P0 — blocks architecture and cost model |

### GAP-AI-03
| Field | Value |
|---|---|
| **Gap ID** | GAP-AI-03 |
| **Category** | AI |
| **Description** | **Arabic-specific content analysis challenges** — the content alerts feature uses AI for cyberbullying, predatory contact, self-harm, and radicalization detection. No spec addresses: Arabic NLP challenges (MSA vs. dialects, code-switching, Arabizi/Franco-Arab), Arabic cyberbullying lexicon, Islamic radicalization indicators vs. legitimate religious content (HIGH sensitivity), or accuracy benchmarks. |
| **Impact** | **High** |
| **Affected components** | SCR-PAR-09, all content analysis |
| **Recommendation** | Define requirements: MSA + major dialect support (Gulf, Egyptian, Levantine, Maghrebi); Arabizi detection; code-switching handling; Arabic cyberbullying lexicon; radicalization indicators calibrated for MENA context (distinguish devout expression from extremism — require scholar consultation); accuracy target: >90% precision, >85% recall for critical categories; regular model retraining with regional annotators. |
| **Priority** | P0 — accuracy is safety-critical |

---

## 8. Testing Gaps

### GAP-TEST-01
| Field | Value |
|---|---|
| **Gap ID** | GAP-TEST-01 |
| **Category** | Testing |
| **Description** | **No test strategy document** — no spec for: test pyramid ratios, testing tools, CI/CD integration, device matrix (Samsung, Huawei, Xiaomi are top 3 in MENA), Arabic/RTL testing methodology, offline simulation testing, or performance benchmarks. |
| **Impact** | **High** |
| **Affected components** | All engineering, QA |
| **Recommendation** | Author test strategy: unit (80% coverage target, critical paths 100%), integration (API contract tests), E2E (Appium/Espresso, 50 critical user journeys), device matrix (Samsung + Huawei + Xiaomi + Pixel baseline), Arabic RTL visual regression (Playwright screenshot comparison), offline simulation, performance (app launch <2 s, screen transition <300 ms, API P95 <500 ms). |
| **Priority** | P0 — blocks engineering setup |

### GAP-TEST-02
| Field | Value |
|---|---|
| **Gap ID** | GAP-TEST-02 |
| **Category** | Testing |
| **Description** | **No penetration testing plan** — given children's data, real-time location, and device control, no pen-test plan covers: API security, client storage, communication interception, privilege escalation (child → parent), anti-bypass evasion, or location spoofing. |
| **Impact** | **High** |
| **Affected components** | All security surfaces |
| **Recommendation** | Engage third-party pen-test firm (MENA-experienced, child-safety domain) for: pre-launch pen test (API, client, communication), anti-bypass evasion testing, child-to-parent privilege escalation, location spoofing. Annual re-assessment. Budget: $15-25K. |
| **Priority** | P0 — launch blocker (child safety) |

---

## 9. Operational Gaps

### GAP-OPS-01
| Field | Value |
|---|---|
| **Gap ID** | GAP-OPS-01 |
| **Category** | Operations |
| **Description** | **No incident response plan** — critical incidents (SOS system down, location tracking failure, data breach, AI service outage) have no defined response protocol: severity levels, escalation chain, user communication, SLA targets, rollback procedures, or post-incident review. |
| **Impact** | **High** |
| **Affected components** | All production systems |
| **Recommendation** | Define incident response: SEV-1 (SOS/safety down → 15 min response), SEV-2 (monitoring/education down → 1 h), SEV-3 (non-critical → 4 h); escalation chain; user communication templates (in-app banner, push, email); rollback procedures per service; post-incident review within 48 h. |
| **Priority** | P0 — blocks production readiness |

### GAP-OPS-02
| Field | Value |
|---|---|
| **Gap ID** | GAP-OPS-02 |
| **Category** | Operations |
| **Description** | **No monitoring and observability spec** — no specification for: application metrics (latency, error rates, AI token usage), infrastructure metrics, business metrics (DAU, messages, lessons completed, SOS triggered), alerting thresholds, dashboards, or distributed tracing. |
| **Impact** | **High** |
| **Affected components** | All backend services |
| **Recommendation** | Define observability stack: application metrics + infrastructure metrics + business metrics; alerting (PagerDuty/equivalent, per-SEV thresholds); dashboards (Grafana/equivalent); distributed tracing for cross-service requests; AI-specific metrics (token usage, cost, latency, fallback rate). |
| **Priority** | P0 — blocks production readiness |

### GAP-OPS-03
| Field | Value |
|---|---|
| **Gap ID** | GAP-OPS-03 |
| **Category** | Operations |
| **Description** | **No customer support integration** — the spec references "تواصل مع الدعم" links but no spec exists for: support channel (in-app chat? email? phone?), support tier structure, SLA per issue type, knowledge base, ticket routing (safety issues escalated), or language support. |
| **Impact** | **Medium** |
| **Affected components** | SCR-SHR-03, SCR-ADM-08, all error recovery flows |
| **Recommendation** | Define support architecture: in-app chat (Zendesk/Intercom), Arabic-first support team, ticket categories (safety → immediate, billing → 24 h, feature/bug → 48 h), escalation for SOS/safety reports (1 h SLA), Arabic knowledge base, in-app FAQ. |
| **Priority** | P1 — not launch-blocking but critical for retention |

---

## 10. Open Decisions

The 12 open decisions below were identified in the first-pass specification. Each must be resolved before the affected component can proceed to engineering.

### OD-01 — Google Play Accessibility Policy Risk
| Field | Value |
|---|---|
| **Decision ID** | OD-01 |
| **Category** | Platform / Compliance |
| **Description** | Google Play restricts Accessibility Service usage to apps that genuinely assist users with disabilities. Family OS uses Accessibility for: app blocking enforcement, web content monitoring, anti-bypass detection. Google may reject the app or remove it post-launch. |
| **Impact** | **Critical** — removal from Play Store kills distribution |
| **Affected components** | SCR-PAR-07, SCR-PAR-08, SCR-PAR-09, SCR-PAR-12, all monitoring enforcement |
| **Options** | A) Apply for Google Play "Family" program exception (similar to Google Family Link). B) Use Device Policy Controller (DPC) APIs instead (more limited but policy-safe). C) Enterprise MDM enrollment (BYOD) with work profile. D) Sideload-only distribution (avoids Play policy, limits reach). |
| **Recommendation** | Start with Option B (DPC APIs) + apply for Option A (Family program) in parallel. Design enforcement layer to be pluggable — swap Accessibility for DPC without rewriting monitoring logic. Option D as emergency fallback. |
| **Priority** | **P0 — resolve before architecture lock** |

### OD-02 — Kill Switch Legality (VPN + Accessibility)
| Field | Value |
|---|---|
| **Decision ID** | OD-02 |
| **Category** | Legal / Compliance |
| **Description** | Kill Switch uses VPN and Accessibility to remotely freeze a child's device. In some jurisdictions, remotely controlling another person's device may raise legal concerns. VPN usage may also conflict with local regulations in certain MENA countries. |
| **Impact** | **High** — legal risk in target markets |
| **Affected components** | SCR-PAR-11, EC-SAF-04 |
| **Options** | A) Ship in all markets (accept risk). B) Geo-gate per country legal review. C) Implement via DPC/MDM (established precedent). D) Reframe as "Study Mode / وضع الدراسة" (softer language). |
| **Recommendation** | Legal review per target country (KSA, UAE, Egypt, Jordan, Iraq). Option C + D: implement via DPC, market as "وضع الدراسة" for app blocking, reserve full network isolation for explicit parental opt-in with informed consent. |
| **Priority** | **P0 — legal review before feature lock** |

### OD-03 — Location-Stop Prevention Mechanism
| Field | Value |
|---|---|
| **Decision ID** | OD-03 |
| **Category** | Technical / Policy |
| **Description** | What prevents a child from disabling location tracking? Balance between child safety and child privacy/autonomy. |
| **Impact** | **High** — core safety vs. privacy tension |
| **Affected components** | SCR-PAR-05, SCR-PAR-06, SCR-PAR-12 |
| **Options** | A) Prevent toggle (aggressive — requires Device Admin). B) Allow toggle + immediate parent alert (transparent). C) Age-based: <13 prevent; 13-17 alert only. D) Configurable by parent. |
| **Recommendation** | Option D with defaults from Option C. Under 13 default: prevent. 13-17 default: alert. Always alert parent regardless. Document in SCR-ADM-07. |
| **Priority** | **P0 — affects safety architecture** |

### OD-04 — Gemini Cost at Scale ($2-4/user/month)
| Field | Value |
|---|---|
| **Decision ID** | OD-04 |
| **Category** | Business / Technical |
| **Description** | At $2-4/user/month for Gemini API, a family of 4 with active AI features could cost $8-16/month in AI alone, potentially exceeding subscription revenue for MENA-priced tiers. |
| **Impact** | **Critical** — unit economics |
| **Affected components** | All AI features, pricing model, GAP-AI-02 |
| **Options** | A) Price subscription accordingly ($10-15/month). B) Aggressive caching + rate limiting. C) Model tiering (cheaper models for bulk). D) Fine-tune own models for specific tasks. E) On-device inference for simple tasks. |
| **Recommendation** | Combination B + C + E. Target: <$1.50/user/month blended AI cost. See GAP-AI-02 for model matrix. |
| **Priority** | **P0 — blocks pricing and AI architecture** |

### OD-05 — Child Device Enrollment Without Phone Number
| Field | Value |
|---|---|
| **Decision ID** | OD-05 |
| **Category** | Product / Technical |
| **Description** | Many children have tablet-only or Wi-Fi-only devices without phone numbers. Current auth flow assumes phone OTP. |
| **Impact** | **High** — blocks child onboarding for many families |
| **Affected components** | SCR-SHR-02, SCR-SHR-04, SCR-ADM-03 |
| **Options** | A) Parent-mediated enrollment (parent authenticates on behalf). B) Email OTP. C) Username + password. D) Device-bound enrollment token (parent enrolls, device gets persistent token). |
| **Recommendation** | Option D with A as setup: parent enrolls child device via QR → device receives persistent enrollment token → no child login needed. If child switches device: parent re-enrolls. |
| **Priority** | **P0 — blocks child onboarding** |

### OD-06 — Mother Permissions Default Set
| Field | Value |
|---|---|
| **Decision ID** | OD-06 |
| **Category** | Product |
| **Description** | See GAP-REQ-02. Which of the 8 exclusive features does Mother get by default? |
| **Impact** | **High** — blocks onboarding |
| **Affected components** | SCR-SHR-04, SCR-ADM-02, all exclusive screens |
| **Recommendation** | Monitoring view by default (Screen Time, Map, Device Lock, Content Alerts — view only, no config power). Father escalates via SCR-ADM-02. |
| **Priority** | **P0 — resolve before onboarding** |

### OD-07 — School Time GPS Accuracy vs. Battery
| Field | Value |
|---|---|
| **Decision ID** | OD-07 |
| **Category** | Technical |
| **Description** | High-accuracy GPS (10 m) drains battery; low-accuracy (100 m) may false-trigger geofence events. Child device needs to last a school day. |
| **Impact** | **Medium** |
| **Affected components** | SCR-PAR-10, SCR-PAR-05, SCR-PAR-06 |
| **Recommendation** | Fused provider (FusedLocationProviderClient) + geofence-triggered high accuracy. Default: fused every 5 min during school; high-accuracy GPS for 2 min at zone boundary. Target: <5% battery per school day. |
| **Priority** | **P1 — refinement after MVP** |

### OD-08 — Content Alert False Positive Rate
| Field | Value |
|---|---|
| **Decision ID** | OD-08 |
| **Category** | AI / Product |
| **Description** | AI content analysis will produce false positives. High FP erodes parent trust; low FP may miss real threats. No target metrics or user-adjustable sensitivity defined. |
| **Impact** | **Medium** |
| **Affected components** | SCR-PAR-09, GAP-AI-03 |
| **Recommendation** | Tiered thresholds: Critical categories (self-harm, predator) → aggressive (>95% recall, accept FP). Warning categories → parent-adjustable (default medium, >90% precision). Info categories → conservative (>95% precision). All FPs feed model improvement. |
| **Priority** | **P0 — affects safety model** |

### OD-09 — Quran Recitation Accuracy Threshold
| Field | Value |
|---|---|
| **Decision ID** | OD-09 |
| **Category** | AI / Product |
| **Description** | What Tajweed score constitutes a "pass"? Too strict demotivates; too lenient doesn't teach. No academic benchmark for AI Tajweed assessment. |
| **Impact** | **Medium** |
| **Affected components** | SCR-EDU-10, SCR-AI-04 |
| **Recommendation** | Age-based + progressive: under 10 = 50%, 10-14 = 65%, 14+ = 80%, increasing per surah advancement. Show score + feedback always; "pass" is encouragement, not gate. Consult Quran education scholars. Label AI as "مساعد" not "حكم". |
| **Priority** | **P1 — needs scholar consultation** |

### OD-10 — Offline AI Fallback Strategy
| Field | Value |
|---|---|
| **Decision ID** | OD-10 |
| **Category** | Technical |
| **Description** | When offline, all AI features (Tutor, Translation, Content Analysis, Recommendations) cannot reach the cloud. Significant in MENA regions with connectivity gaps. |
| **Impact** | **Medium** |
| **Affected components** | All AI features |
| **Recommendation** | Combination approach: Translation → on-device Gemini Nano (<500 MB). Tutor → cached FAQ + pre-generated explanations per lesson. Exercises → pre-generated non-adaptive sets. Content analysis → cached pattern matching. Clearly label "وضع بدون إنترنت". |
| **Priority** | **P0 — blocks offline architecture** |

### OD-11 — Multi-Device Per Child Timing
| Field | Value |
|---|---|
| **Decision ID** | OD-11 |
| **Category** | Product / Technical |
| **Description** | If a child has phone + tablet, how is screen time tracked? Separately or combined? Affects monitoring accuracy. |
| **Impact** | **Low** |
| **Affected components** | SCR-PAR-02, SCR-PAR-03, SCR-ADM-03 |
| **Recommendation** | Combined total limit across all devices + per-device breakdown visible to parent. When limit hit: all devices locked. MVP: single device. V2: multi-device. |
| **Priority** | **P2 — post-MVP** |

### OD-12 — Apple App Store Future Feasibility
| Field | Value |
|---|---|
| **Decision ID** | OD-12 |
| **Category** | Platform / Strategy |
| **Description** | Current spec is Android-first. iOS has fundamentally different capabilities (no Accessibility for monitoring, no Device Admin, no VPN for filtering). |
| **Impact** | **Low** (MVP is Android-only) |
| **Affected components** | All monitoring features on iOS |
| **Recommendation** | Phase 1: Android-only. Phase 2: iOS companion for parents (view monitoring from iPhone, child stays Android). Phase 3: iOS child app with ScreenTime API (reduced monitoring). Design monitoring abstraction layer NOW for future iOS integration. |
| **Priority** | **P2 — architectural decision needed now for abstraction layer** |

---

## Priority Resolution Order

### Before Architecture Lock (Immediate)
1. **GAP-DATA-01**: Complete entity relationship diagram
2. **GAP-SEC-01**: API auth and authorization spec
3. **OD-01**: Google Play Accessibility policy resolution
4. **OD-04**: Gemini cost model and model matrix (GAP-AI-02)
5. **OD-05**: Child device enrollment without phone number
6. **OD-06**: Mother permissions default set (GAP-REQ-02)
7. **GAP-DATA-02**: Encryption architecture
8. **GAP-AI-01**: AI safety guardrails

### Before Engineering Starts
9. **GAP-SCR-01**: Onboarding flow design
10. **GAP-SCR-02**: Child monitoring surfaces design
11. **GAP-SCR-03**: Device enrollment flow design
12. **GAP-REQ-01**: SOS escalation protocol
13. **GAP-REQ-05**: Quran curriculum scope
14. **GAP-WF-01**: Member removal workflow
15. **GAP-WF-02**: Curriculum content pipeline
16. **GAP-CMP-01**: MENA data law compliance review
17. **OD-02**: Kill Switch legal review
18. **OD-03**: Location-stop prevention mechanism
19. **OD-10**: Offline AI fallback strategy

### Before Launch
20. **GAP-TEST-01**: Test strategy document
21. **GAP-TEST-02**: Penetration testing engagement
22. **GAP-OPS-01**: Incident response plan
23. **GAP-OPS-02**: Monitoring and observability
24. **GAP-CMP-02**: AI transparency framework
25. **GAP-AI-03**: Arabic NLP accuracy benchmarks
26. **GAP-SEC-02**: Child impersonation defense
27. **GAP-SEC-03**: Location data security
28. **OD-08**: Content alert FP thresholds

### Post-MVP
29. **GAP-SCR-04**: In-app VoIP calling
30. **GAP-WF-03**: Family transfer workflow
31. **GAP-OPS-03**: Customer support integration
32. **OD-07**: GPS accuracy vs. battery optimization
33. **OD-09**: Quran recitation threshold (scholar consultation)
34. **OD-11**: Multi-device per child
35. **OD-12**: iOS feasibility

---

*End of Critical Gap Register. 40 items identified: 28 Critical/High, 8 Medium, 3 Low.*
