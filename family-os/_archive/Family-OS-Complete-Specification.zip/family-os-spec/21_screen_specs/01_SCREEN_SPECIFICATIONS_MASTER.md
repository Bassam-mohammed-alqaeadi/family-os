# Family OS — Screen Specifications Master

> **Document status:** Master specification — all major screens
> **Language:** Arabic-first (RTL), Hijri calendar
> **Design tokens:** Background `--ink-50 #F8FAFC` · Primary Jade `#1B6B5A` · Accent Coral `#E76F51` · AI Violet `#7C3AED`
> **Roles:** Father (admin) · Mother (limited_admin) · Child (child)
> **Universal states:** every screen defines loading (shimmer), empty, populated/success, error, denied-permission, locked (child), trial-expired (premium features)

---

## Table of Contents

1. [Shared Screens (SCR-SHR)](#1-shared-screens-scr-shr)
2. [Communication Screens (SCR-COM)](#2-communication-screens-scr-com)
3. [Monitoring Screens (SCR-PAR)](#3-monitoring-screens-scr-par)
4. [Education Screens (SCR-EDU)](#4-education-screens-scr-edu)
5. [AI Screens (SCR-AI)](#5-ai-screens-scr-ai)
6. [Administration Screens (SCR-ADM)](#6-administration-screens-scr-adm)
7. [Cross-Screen Conventions](#7-cross-screen-conventions)

---

## 1. Shared Screens (SCR-SHR)

### SCR-SHR-01 — Splash (شاشة البداية)

| Field | Value |
|---|---|
| **Screen ID** | SCR-SHR-01 |
| **Name (AR)** | شاشة البداية |
| **Name (EN)** | Splash |
| **Roles** | All (unauthenticated) |
| **P0 services** | Auth bootstrap, session restore, feature-flag fetch |
| **Purpose** | Initialize app, validate session token, route to Login or Home in ≤2 s. |

**Layout:**
- **Header:** none (full-screen)
- **Body:** centered animated logo (Jade gradient → Coral accent pulse), family name fades in if session is valid, thin loading indicator below
- **Footer/nav:** none
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | Shimmer pulse on logo; "جارٍ التحميل…" subtitle |
| Empty | N/A (not a data screen) |
| Success | Logo holds 800 ms → auto-route to Home/Login |
| Error | Connection error → retry sheet (Coral CTA "إعادة المحاولة"); auth server down → offline mode banner → Login |
| Denied-permission | N/A |
| Locked (child) | N/A |
| Trial-expired | N/A (checked post-auth) |

**Data displayed:** App version, build hash (debug only), family name (if session cached).

**Actions:** Tap-to-skip animation (debug), automatic transition.

**Navigation:** → SCR-SHR-02 Login (no session) / → SCR-SHR-05 Profile → SCR-ADM-09 Today Dashboard (valid session).

**Permissions required:** `INTERNET`, `ACCESS_NETWORK_STATE`.

**Offline behavior:** If no network, skip token validation, route to Login with offline banner. Cached session token honored for offline re-entry if within 24 h.

**Edge cases:** App upgraded cold-start with schema migration pending → show "جارٍ التحديث…" then migrate; session token expired mid-splash → transparent refresh, fail → Login.

---

### SCR-SHR-02 — Login (تسجيل الدخول)

| Field | Value |
|---|---|
| **Screen ID** | SCR-SHR-02 |
| **Name (AR)** | تسجيل الدخول |
| **Name (EN)** | Login |
| **Roles** | All (unauthenticated) |
| **P0 services** | Authentication (phone OTP / email), family resolution |
| **Purpose** | Authenticate the user and resolve which family + role they belong to. |

**Layout:**
- **Header:** back arrow (from recovery), app logo small
- **Body:** phone number field (RTL, country code dropdown defaulting +966/+971/+20/+962/+964/+974/+963/+961/+968/+974/+212/+213), "إرسال رمز التحقق" CTA (Jade), OTP input (6-digit segmented, auto-focus), "تسجيل الدخول بالبريد" toggle link
- **Footer/nav:** "إنشاء عائلة جديدة" link → SCR-SHR-04 · "نسيت رقمي؟" → SCR-SHR-03
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | OTP send: button spinner + disabled; OTP verify: full-form shimmer |
| Empty | Pre-input: phone field placeholder "+966 5x xxx xxxx" |
| Success | OTP verified → brief Jade checkmark → route to Home/Profile setup |
| Error | Invalid OTP → Coral border + "رمز غير صحيح"; rate-limited → "محاولات كثيرة، انتظر 60 ثانية" countdown; number not registered → "هذا الرقم غير مسجل، أنشئ عائلة" link |
| Denied-permission | SMS auto-fill denied → manual entry fallback, no re-prompt |
| Locked (child) | N/A |
| Trial-expired | N/A (post-auth) |

**Data displayed:** Saved phone (if any), country code list, remaining OTP attempts.

**Actions:** Send OTP, verify OTP, resend OTP (cooldown 60 s), switch to email login, navigate to recovery/create family.

**Navigation:** ← SCR-SHR-01 · → SCR-ADM-09 Today Dashboard (parent) / SCR-EDU-01 Learning Home (child) / SCR-SHR-04 Create Family (new number) · → SCR-SHR-03 Recovery.

**Permissions required:** `INTERNET`, `READ_SMS` (optional, auto-fill OTP — gracefully declined), `PHONE` (optional, auto-detect number).

**Offline behavior:** Cannot send/verify OTP offline; show "الاتصال مطلوب لتسجيل الدخول" with cached session fallback (if token valid).

**Edge cases:** OTP intercepted by another SMS app on device → manual entry always available; dual-SIM device → user selects which SIM received SMS; number ported → verify against server-side account lookup not carrier.

---

### SCR-SHR-03 — Account Recovery (استرجاع الحساب)

| Field | Value |
|---|---|
| **Screen ID** | SCR-SHR-03 |
| **Name (AR)** | استرجاع الحساب |
| **Name (EN)** | Account Recovery |
| **Roles** | All (unauthenticated) |
| **P0 services** | Auth recovery flow, identity verification |
| **Purpose** | Restore access for a user who lost their device or forgot their number. |

**Layout:**
- **Header:** back arrow → SCR-SHR-02
- **Body:** step indicator (1 Verify Identity → 2 Select Recovery Method → 3 Reset). Step 1: family ID or email + security question. Step 2: choose alternate phone / email / family member verification. Step 3: new phone number entry + OTP
- **Footer/nav:** "تواصل مع الدعم" link
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | Step transition spinner |
| Empty | Pre-fill with any cached family ID |
| Success | Recovery complete → "تم استرجاع حسابك" → Login with new number |
| Error | Security question wrong → "إجابة غير صحيح" + attempt counter; no recovery method set → guided support sheet; family ID not found → "لم نجد عائلة بهذا المعرف" |
| Denied-permission | N/A |
| Locked (child) | N/A |
| Trial-expired | N/A |

**Data displayed:** Family ID, security question hint, recovery methods on file, remaining attempts.

**Actions:** Enter family ID/email, answer security question, select recovery method, enter new phone, verify OTP, contact support.

**Navigation:** ← SCR-SHR-02 · → SCR-SHR-02 Login (on success).

**Permissions required:** `INTERNET`.

**Offline behavior:** Fully offline-deferred — "استرجاع الحساب يتطلب اتصالاً بالإنترنت."

**Edge cases:** Recovery method also inaccessible (alt email lost) → family member verification path (another parent approves from their device); security question brute-force → lock after 5 attempts, 24 h cooldown; family has only one parent and recovery exhausted → support ticket with ID verification.

---

### SCR-SHR-04 — Create Family (إنشاء عائلة)

| Field | Value |
|---|---|
| **Screen ID** | SCR-SHR-04 |
| **Name (AR)** | إنشاء عائلة |
| **Name (EN)** | Create Family |
| **Roles** | Father (creator default), or first member self-assigns role |
| **P0 services** | Family provisioning, member invite, role assignment |
| **Purpose** | Provision a new family unit with the creator as the first admin. |

**Layout:**
- **Header:** back arrow, "إنشاء عائلة" title
- **Body:** Step 1 — family name (Arabic), creator role selector (default Father). Step 2 — invite members: phone number or share invite link / QR. Step 3 — set family defaults: Hijri/Gregorian toggle, notification language, timezone auto-detect. Step 4 — review summary card → "إنشاء" Jade CTA
- **Footer/nav:** step back / forward, skip invite (can invite later)
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | "إنشاء" button spinner; invite SMS send progress per invitee |
| Empty | Pre-invite placeholder: illustration + "ادعُ أفراد عائلتك" |
| Success | Family created → confetti micro-animation → route to Today Dashboard |
| Error | Family name taken → "اسم العائلة مستخدم، اختر اسمًا آخر"; invite SMS fail → retry per-recipient; provisioning fail → "تعذّر الإنشاء، حاول مرة أخرى" + rollback |
| Denied-permission | Contacts read denied → manual phone entry (no re-prompt) |
| Locked (child) | N/A |
| Trial-expired | N/A (trial starts on creation) |

**Data displayed:** Family name, creator role, invitee list with send status, family defaults, generated family ID + QR.

**Actions:** Enter family name, select role, add invitees, generate QR/link, toggle calendar type, set timezone, create, skip invite.

**Navigation:** ← SCR-SHR-02 · → SCR-ADM-09 Today Dashboard · → SCR-SHR-05 Profile (creator setup).

**Permissions required:** `INTERNET`, `READ_CONTACTS` (optional, to pick invitees).

**Offline behavior:** Creation deferred — requires server provisioning. QR/link generation cached for later send.

**Edge cases:** Creator picks "Mother" role → system warns "الأم لها صلاحيات محدودة، الأب الكامل مطلوب" and requires a Father invite before completing; invitee already in another family → "هذا الرقم ينتمي لعائلة أخرى" with transfer-request path; family creation timeout → rollback and allow retry.

---

### SCR-SHR-05 — Profile (الملف الشخصي)

| Field | Value |
|---|---|
| **Screen ID** | SCR-SHR-05 |
| **Name (AR)** | الملف الشخصي |
| **Name (EN)** | Profile |
| **Roles** | All (each sees own profile; parents see family members' profiles) |
| **P0 services** | User profile, avatar, notification preferences, device binding |
| **Purpose** | View and edit personal profile, manage linked devices, access personal settings. |

**Layout:**
- **Header:** back arrow, "الملف الشخصي" title, overflow menu (if viewing child: "عرض كأب")
- **Body:** avatar (circular, tap to change — camera/gallery), display name, role badge (Father/Mother/Child), phone, email, linked devices list with status dot, notification preferences toggles, "تغيير اللغة" → SCR-SHR-06, "الخصوصية" (parents → SCR-ADM-07, child → limited), "تسجيل الخروج" Coral text
- **Footer/nav:** bottom nav (if parent) — Home, Chat, Calendar, Tasks, Settings
- **FAB:** none (child: SOS FAB)

**UI States:**
| State | Presentation |
|---|---|
| Loading | Avatar + fields shimmer |
| Empty | New user: placeholder avatar + "أضف اسمك وصورتك" CTA |
| Success | All fields populated, device dots green |
| Error | Profile fetch fail → "تعذّر تحميل الملف" + retry; avatar upload fail → "فشل رفع الصورة" + retry |
| Denied-permission | Camera/gallery denied → "اسمح بالوصول للكاميرا لتغيير الصورة" + settings link |
| Locked (child) | Child viewing parent profile → name + role only, no phone/email; edits disabled |
| Trial-expired | Profile accessible (not premium) |

**Data displayed:** User entity (name, avatar, role, phone, email), Device entities (name, model, last-seen, status), NotificationPreference entity.

**Actions:** Change avatar, edit name, toggle notifications, view linked devices, unlink device (parent), change language, logout.

**Navigation:** ← Settings/Today Dashboard · → SCR-SHR-06 Language · → SCR-ADM-03 Devices (parent) · → SCR-ADM-07 Child Privacy (parent).

**Permissions required:** `CAMERA` (avatar), `READ_EXTERNAL_STORAGE` / `READ_MEDIA_IMAGES` (gallery avatar).

**Offline behavior:** Cached profile displayed; edits queued and synced on reconnect; avatar upload deferred.

**Edge cases:** Avatar >5 MB → auto-compress to 512×512; user tries to unlink last parent device → blocked "يجب أن يبقى جهاز أحد الوالدين مرتبطًا"; name contains emoji → allowed but sanitized for display.

---

### SCR-SHR-06 — Language Settings (إعدادات اللغة)

| Field | Value |
|---|---|
| **Screen ID** | SCR-SHR-06 |
| **Name (AR)** | إعدادات اللغة |
| **Name (EN)** | Language Settings |
| **Roles** | All (child: limited to UI language only, not calendar) |
| **P0 services** | Localization, calendar system toggle |
| **Purpose** | Set app interface language (Arabic/English), calendar system (Hijri/Gregorian), and regional formatting. |

**Layout:**
- **Header:** back arrow, "اللغة والمنطقة" title
- **Body:** Language selector (radio: العربية (default), English), Calendar system (radio: هجري (default), ميلادي, both), Date format preview, Time format (12 h / 24 h), Number system (Arabic-Indic / Western), "تطبيق" Jade CTA
- **Footer/nav:** none
- **FAB:** none (child: SOS FAB)

**UI States:**
| State | Presentation |
|---|---|
| Loading | Current settings fetched instantly (local) |
| Empty | N/A (always has defaults) |
| Success | Selection highlighted, preview updates live, "تم" toast on apply |
| Error | N/A (local operation) |
| Denied-permission | N/A |
| Locked (child) | Calendar toggle hidden for child; only UI language + time format |
| Trial-expired | N/A (not premium) |

**Data displayed:** Current language, calendar, date/time format, number system, live preview.

**Actions:** Select language, select calendar, select time format, select number system, apply.

**Navigation:** ← SCR-SHR-05 Profile / SCR-ADM-06 Settings · back to source.

**Permissions required:** None.

**Offline behavior:** Fully offline — all settings are local preferences synced to server when available.

**Edge cases:** Language switch mid-session → instant RTL/LTR flip without restart; Hijri date computed via Umm al-Qura calendar (not approximate); "both" calendar → dates display as "15 ربيع الأول 1447 هـ / 6 سبتمبر 2026 م".

## 2. Communication Screens (SCR-COM)

### SCR-COM-01 — Chat List (قائمة المحادثات)

| Field | Value |
|---|---|
| **Screen ID** | SCR-COM-01 |
| **Name (AR)** | قائمة المحادثات |
| **Name (EN)** | Chat List |
| **Roles** | All |
| **P0 services** | Family messaging, read receipts, last-seen |
| **Purpose** | Show all family conversations in one list with unread counts and last message preview. |

**Layout:**
- **Header:** "العائلة" title, search icon, overflow (message settings → SCR-COM-08)
- **Body:** conversation list cards (avatar, name, last message preview, timestamp Hijri, unread badge Coral, pinned indicator), filtered tabs: All / Family / 1:1
- **Footer/nav:** bottom nav (parent) — Home, Chat (active), Calendar, Tasks, Settings; child: Home, Chat, SOS
- **FAB:** new chat (opens member picker for 1:1 or group)

**UI States:**
| State | Presentation |
|---|---|
| Loading | 6 shimmer conversation cards |
| Empty | Illustration (family gathered) + "لا توجد محادثات بعد، ابدأ بالضغط على +" |
| Success | Conversations sorted by last-message timestamp, pinned on top |
| Error | Fetch fail → "تعذّر تحميل المحادثات" + retry; WebSocket disconnect → yellow banner "غير متصل — عرض الرسائل الأخيرة" |
| Denied-permission | Notifications denied → "فعّل الإشعارات لتصلك الرسائل فورًا" dismissable banner |
| Locked (child) | Child sees family group + direct chats with parents only; no parent-to-parent chats visible |
| Trial-expired | Messaging accessible (P0 core); translation features show lock icon → SCR-ADM-04 |

**Data displayed:** Conversation entity (id, type, participants, last message, unread count, pinned), Message entity (preview, timestamp, sender).

**Actions:** Tap conversation → SCR-COM-02, long-press → pin/mute/delete, swipe → archive, search, new chat FAB.

**Navigation:** → SCR-COM-02 Conversation · → SCR-COM-08 Message Settings · ← bottom nav.

**Permissions required:** `INTERNET`, `POST_NOTIFICATIONS` (Android 13+).

**Offline behavior:** Cached conversation list with last-known messages; send queue visible as "قيد الإرسال" pending; reconnect triggers delta sync.

**Edge cases:** Conversation with removed member → grayed "عضو محذوف" label, read-only; 100+ unread in one chat → badge caps at "99+"; family group has 1 member (others left) → auto-converts to note-to-self.

---

### SCR-COM-02 — Conversation Detail (تفاصيل المحادثة)

| Field | Value |
|---|---|
| **Screen ID** | SCR-COM-02 |
| **Name (AR)** | تفاصيل المحادثة |
| **Name (EN)** | Conversation Detail |
| **Roles** | All |
| **P0 services** | Real-time messaging, media, voice, read receipts, translation, lock |
| **Purpose** | Display and send messages within a single conversation with full media and voice support. |

**Layout:**
- **Header:** back arrow, avatar + name + last-seen/typing indicator, call icon (if 1:1), overflow (translation toggle, lock, mute, search in chat)
- **Body:** message bubbles (own = Jade right-aligned RTL, others = white left-aligned), timestamps, read receipt ticks (single sent, double delivered, double Jade read), date separators (Hijri), media attachments inline, voice messages with waveform + play, system messages (member joined, event created)
- **Footer/nav:** input bar — text field, emoji button, attachment button (image/video/file/location), voice hold-to-record button; translation pill bar when enabled
- **FAB:** none (child: SOS FAB above keyboard)

**UI States:**
| State | Presentation |
|---|---|
| Loading | 8 shimmer bubbles descending |
| Empty | "ابدأ المحادثة" centered illustration + suggested stickers |
| Success | Messages rendered, scroll to latest, unread divider line |
| Error | Send fail → bubble shows Coral retry icon; fetch fail → "تعذّر تحميل الرسائل" + retry; voice upload fail → "فشل رفع الرسالة الصوتية" + retry |
| Denied-permission | Mic denied → voice button replaced with "اسمح بالمايك للتسجيل" pill; storage denied → attachment → "اسمح بالوصول للملفات" |
| Locked (child) | Child cannot start new 1:1 with non-parent; group chat limited to family; translation may be parent-locked |
| Trial-expired | Translation toggle locked with Violet lock icon → SCR-ADM-04 paywall; messaging itself works |

**Data displayed:** Message entities (text, media, voice, location, system), User entities (sender avatar/name), Conversation metadata.

**Actions:** Send text, send media, record voice, play voice, toggle translation, forward, reply, react (emoji), delete (own), pin message, lock conversation (→ SCR-COM-11), search in chat, scroll to unread.

**Navigation:** ← SCR-COM-01 · → SCR-COM-10 Voice (on voice play) · → SCR-COM-09 Translation Settings · → SCR-COM-11 Lock.

**Permissions required:** `INTERNET`, `RECORD_AUDIO` (voice), `READ_MEDIA_IMAGES`/`READ_MEDIA_VIDEO` (attachments), `ACCESS_FINE_LOCATION` (location share), `POST_NOTIFICATIONS`.

**Offline behavior:** Messages queued locally with "قيد الإرسال" status; sent on reconnect in order; received messages cached; media upload deferred with placeholder.

**Edge cases:** Message >1000 chars → truncation with "اقرأ المزيد"; media >50 MB → compressed before upload; voice >5 min → split into segments; deleted message while others reply → "تم حذف هذه الرسالة" placeholder; user blocked by parent mid-conversation → input disabled with "تم تقييد هذه المحادثة".

---

### SCR-COM-03 — Family Calendar (التقويم العائلي)

| Field | Value |
|---|---|
| **Screen ID** | SCR-COM-03 |
| **Name (AR)** | التقويم العائلي |
| **Name (EN)** | Family Calendar |
| **Roles** | All (child: view-only + create personal reminders) |
| **P0 services** | Shared calendar, reminders, event sync, Hijri display |
| **Purpose** | Show all family events in a shared calendar with Hijri/Gregorian dual display. |

**Layout:**
- **Header:** current month/year (Hijri primary, Gregorian secondary), view toggle (month/week/day/agenda), today button, search
- **Body:** month grid (Hijri day numbers primary, Gregorian small), event dots per day color-coded by member, selected day expands to event list below grid; week view = timeline with event blocks; agenda = sorted list
- **Footer/nav:** bottom nav; child: SOS FAB
- **FAB:** "+ حدث" (add event) — parents: any event type; child: personal reminder only

**UI States:**
| State | Presentation |
|---|---|
| Loading | Calendar grid shimmer |
| Empty | "لا توجد أحداث هذا الشهر" + illustration; day with no events → "لا أحداث اليوم" |
| Success | Events populated, color-coded, today highlighted with Jade ring |
| Error | Sync fail → "تعذّر تحميل الأحداث" + cached view + retry; create fail → "فشل إنشاء الحدث" + retry |
| Denied-permission | Calendar write denied (device calendar sync) → "لن تتم المزامنة مع تقويم الهاتف" dismissable |
| Locked (child) | Child sees family events (read-only) + own reminders (editable); cannot see parent-only events |
| Trial-expired | Calendar accessible (P0); advanced sync to device calendar locked |

**Data displayed:** Event entities (title, date/time, type, attendees, recurrence, reminder, color, location), Hijri date mapping.

**Actions:** Navigate months, switch view, tap day, tap event → SCR-COM-05, create event, long-press day → quick add, search events.

**Navigation:** → SCR-COM-05 Event Detail · ← bottom nav · → SCR-SHR-06 (calendar type from settings).

**Permissions required:** `INTERNET`, `READ/WRITE_CALENDAR` (device sync optional), `POST_NOTIFICATIONS` (reminders).

**Offline behavior:** Cached calendar for current ±3 months; local edits queued; recurring events computed locally.

**Edge cases:** Event spans midnight → rendered across both days in week view; recurring event edited → "هذه فقط / الكل / المستقبلية" choice sheet; Hijri month length varies (29/30) → grid adjusts dynamically; event created by removed member → "منشئ محذوف" with option to reassign or delete.

---

### SCR-COM-04 — Tasks & Shopping (المهام والتسوق)

| Field | Value |
|---|---|
| **Screen ID** | SCR-COM-04 |
| **Name (AR)** | المهام والتسوق |
| **Name (EN)** | Tasks & Shopping |
| **Roles** | All (child: receives assigned tasks, can add shopping items) |
| **P0 services** | Task assignment, shopping list, completion tracking, notifications |
| **Purpose** | Manage family task assignments and shared shopping list in one screen. |

**Layout:**
- **Header:** "المهام والتسوق" title, segmented control: Tasks (المهام) | Shopping (التسوق)
- **Body (Tasks):** task cards grouped by status (Pending/In Progress/Done), each card: title, assignee avatar, due date (Hijri), priority dot (Coral high, Jade normal), checkbox; swipe right = complete, swipe left = reassign
- **Body (Shopping):** checkbox list of items, quantity, assigned shopper, store category tag; "+ إضافة عنصر" inline; total estimated cost if prices entered; "شارك القائمة" share button
- **Footer/nav:** bottom nav; child: SOS FAB
- **FAB:** "+ مهمة" (Tasks) / auto-inline add (Shopping)

**UI States:**
| State | Presentation |
|---|---|
| Loading | 5 shimmer task cards |
| Empty (Tasks) | "لا توجد مهام، أضف أول مهمة" + illustration |
| Empty (Shopping) | "القائمة فارغة، أضف ما تحتاجه" |
| Success | Tasks sorted by priority then due date; shopping sorted by category |
| Error | Sync fail → cached + "أوفلاين — التغييرات تُحفظ محليًا"; create fail → retry |
| Denied-permission | N/A |
| Locked (child) | Child sees own assigned tasks + full shopping list; cannot assign tasks to others; can mark own complete |
| Trial-expired | Accessible (P0) |

**Data displayed:** Task entities (title, assignee, due, priority, status, notes), ShoppingItem entities (name, qty, shopper, category, price, checked).

**Actions:** Create task, assign, complete, reassign, delete, create shopping item, check off, share list, mark all checked, clear checked.

**Navigation:** ← bottom nav · → SCR-COM-02 (task discussion if linked to chat).

**Permissions required:** `INTERNET`, `POST_NOTIFICATIONS`.

**Offline behavior:** Full offline CRUD; sync on reconnect with conflict resolution (last-write-wins for completion, merge for new items).

**Edge cases:** Task assigned to removed member → auto-reassign to creator with "تمت إعادة تعيين المهمة" notification; shopping item duplicated by two members simultaneously → merge into one with max quantity; all tasks complete → celebration micro-animation.

---

### SCR-COM-05 — Calendar Event (تفاصيل الحدث)

| Field | Value |
|---|---|
| **Screen ID** | SCR-COM-05 |
| **Name (AR)** | تفاصيل الحدث |
| **Name (EN)** | Calendar Event Detail |
| **Roles** | All (child: view + RSVP own attendance) |
| **P0 services** | Event CRUD, reminders, location, recurrence |
| **Purpose** | View, edit, or delete a single calendar event with full details. |

**Layout:**
- **Header:** back arrow, event title, overflow (edit/delete/share) — edit/delete: parents only or event creator
- **Body:** date/time (Hijri + Gregorian), duration, recurrence pattern, location (map preview thumbnail), attendees (avatars + RSVP status), reminder setting, notes, color tag, linked chat (if created from conversation)
- **Footer/nav:** "حضور" RSVP segmented (أحضر / لا أحضر / ربما) for each attendee
- **FAB:** none (child: SOS FAB)

**UI States:**
| State | Presentation |
|---|---|
| Loading | Event fields shimmer |
| Empty | N/A (opened with event) |
| Success | All fields populated, map preview loaded, RSVP shown |
| Error | Fetch fail → "تعذّر تحميل الحدث" + retry; edit fail → "فشل الحفظ" + retry; location geocode fail → "تعذّر تحديد الموقع" + manual entry |
| Denied-permission | Location denied → map shows "اسمح بالوصول للموقع" placeholder; manual address still available |
| Locked (child) | Child can RSVP, view, but not edit/delete parent-created events; can edit own reminders |
| Trial-expired | Accessible (P0) |

**Data displayed:** Event entity (all fields), User entities (attendees with RSVP), Location entity.

**Actions:** Edit, delete, share, RSVP, set reminder, open in maps, link to chat, duplicate event.

**Navigation:** ← SCR-COM-03 · → maps app (external) · → SCR-COM-02 (linked chat).

**Permissions required:** `INTERNET`, `ACCESS_FINE_LOCATION` (location preview), `POST_NOTIFICATIONS`.

**Offline behavior:** Cached event displayed; edits queued; RSVP cached.

**Edge cases:** Event in past → edit restricted to notes only; recurring event with exceptions → exception indicator; all attendees declined → "لا أحد يحضر" warning to creator; location is a safe zone → auto-link to SCR-PAR-06.

---

### SCR-COM-06 — Quick Location (الموقع السريع)

| Field | Value |
|---|---|
| **Screen ID** | SCR-COM-06 |
| **Name (AR)** | الموقع السريع |
| **Name (EN)** | Quick Location Share |
| **Roles** | All (child: share with parents only; parent: share with family) |
| **P0 services** | One-tap location share, live tracking timeout, map display |
| **Purpose** | Share current location with family in one tap with a configurable live duration. |

**Layout:**
- **Header:** back arrow, "مشاركة الموقع"
- **Body:** full-screen map with user's pin (Jade), accuracy circle, duration selector (15 min / 30 min / 1 h / until I stop), "مشاركة" Jade CTA, currently-sharing indicator with countdown
- **Footer/nav:** none
- **FAB:** none (child: SOS FAB)

**UI States:**
| State | Presentation |
|---|---|
| Loading | Map tiles loading, pin shimmer |
| Empty | Map centered on last-known location; no GPS → "ابحث عن موقعك" |
| Success | Pin placed, accuracy circle visible, share active countdown |
| Error | GPS fail → "تعذّر تحديد موقعك" + retry + manual address fallback; share fail → "فشل بدء المشاركة" + retry |
| Denied-permission | Location denied → rationale sheet "الموقع مطلوب لمشاركة موقعك" + "السماح" / "الإعدادات" buttons |
| Locked (child) | Child can share with parents; cannot change recipients; parent can force-enable child location from monitoring |
| Trial-expired | Quick location accessible (P0 safety) |

**Data displayed:** User location (lat/lng, accuracy, heading), sharing status, remaining time, recipient list.

**Actions:** Select duration, start sharing, stop sharing, open in maps, call (shortcut to parent).

**Navigation:** ← chat / monitoring hub · → SCR-PAR-05 Map (parent view of shared location).

**Permissions required:** `ACCESS_FINE_LOCATION`, `ACCESS_COARSE_LOCATION`, `INTERNET`, `FOREGROUND_SERVICE` (live share), `POST_NOTIFICATIONS`.

**Offline behavior:** Cannot start live share offline; last-known cached location shown; "المشاركة تتطلب اتصالاً".

**Edge cases:** GPS accuracy >100 m → warning "الدقة منخفضة، تحقق من إعدادات الموقع"; user moves during share → live update every 10 s; battery <15% during live share → "البطارية منخفضة، قد تتوقف المشاركة" warning; duration expires while in background → auto-stop + notification to recipient.

---

### SCR-COM-07 — SOS (الطوارئ)

| Field | Value |
|---|---|
| **Screen ID** | SCR-COM-07 |
| **Name (AR)** | الطوارئ |
| **Name (EN)** | SOS Emergency |
| **Roles** | All (child: FAB on every screen → this screen; parent: from monitoring hub) |
| **P0 services** | SOS broadcast, live location + audio, emergency contacts, escalation |
| **Purpose** | Trigger an immediate emergency alert to all family parents with location and optional live audio. |

**Layout:**
- **Header:** none (full-screen overlay, Jade→Coral gradient urgency)
- **Body:** large "SOS" hold button (hold 3 s to trigger, prevents accidental), countdown ring, on trigger: live status panel — "تم إرسال التنبيه" ✓, parent response indicators (who acknowledged), live location map inset, "إرسال صوت مباشر" button, "اتصل بالطوارئ 911/999" external call button, "إلغاء" (cancel within 10 s)
- **Footer/nav:** none
- **FAB:** this IS the FAB destination

**UI States:**
| State | Presentation |
|---|---|
| Loading | Trigger: "جارٍ إرسال التنبيه…" spinner |
| Empty | Pre-trigger: hold button + instruction "اضغط مع الاستمرار 3 ثوانٍ" |
| Success | Alert sent, parents acknowledging (green checkmarks), location streaming, audio optional |
| Error | Send fail (offline) → see edge case EC-SAF-01; partial delivery → "تم إرسال لـ X من Y" + retry to remaining; GPS fail → alert still sends with last-known location |
| Denied-permission | Location denied → SOS still sends without location + "فعّل الموقع لتحديد موقعك" notification to user; mic denied → audio button disabled |
| Locked (child) | Child SOS always available (never locked); this is the safety guarantee |
| Trial-expired | SOS always available (never locked, even expired trial) |

**Data displayed:** SOS alert entity (status, timestamp, location, audio), parent acknowledgment status, emergency contact list.

**Actions:** Hold to trigger, cancel (10 s window), start live audio, call emergency services, call parent, stop SOS.

**Navigation:** triggered from any screen FAB (child) / monitoring hub (parent) · → SCR-PAR-05 Map (parent receiving).

**Permissions required:** `ACCESS_FINE_LOCATION`, `RECORD_AUDIO`, `SEND_SMS` (SMS fallback if no data), `CALL_PHONE`, `VIBRATE`, `FOREGROUND_SERVICE`, `POST_NOTIFICATIONS` (critical priority).

**Offline behavior:** SMS fallback to all parents with location in SMS body; queued data alert sends on reconnect; audio recording cached locally and uploaded when available.

**Edge cases:** No parent online within 60 s → auto-escalate to emergency contacts; SOS triggered while another SOS active → merge/update existing; child device in airplane mode → SMS still sends if SIM active; SOS canceled after parent acknowledged → "تم إلغاء التنبيه" notification to all who acknowledged; battery critical during SOS → force low-power mode (GPS at 30 s intervals, audio disabled).

---

### SCR-COM-08 — Message Settings (إعدادات الرسائل)

| Field | Value |
|---|---|
| **Screen ID** | SCR-COM-08 |
| **Name (AR)** | إعدادات الرسائل |
| **Name (EN)** | Message Settings |
| **Roles** | Father (all), Mother (subset), Child (own preferences only) |
| **P0 services** | Notification preferences, read receipts, media auto-download, encryption |
| **Purpose** | Configure messaging behavior across all conversations. |

**Layout:**
- **Header:** back arrow, "إعدادات الرسائل"
- **Body:** sections — Notifications (per-conversation type, sound, vibration), Privacy (read receipts toggle, last-seen toggle, typing indicator toggle), Media (auto-download on Wi-Fi/data/never, compression quality), Storage (cache size, clear cache), Encryption (status indicator, key fingerprint), Translation (→ SCR-COM-09), Locked conversations (→ SCR-COM-11 list)
- **Footer/nav:** none
- **FAB:** none (child: SOS FAB)

**UI States:**
| State | Presentation |
|---|---|
| Loading | Settings sections shimmer |
| Empty | N/A (defaults exist) |
| Success | All toggles reflect saved state |
| Error | Settings save fail → "فشل الحفظ، حاول مرة أخرى"; encryption key fetch fail → "تعذّر التحقق من التشفير" |
| Denied-permission | N/A |
| Locked (child) | Child sees: own notification preferences, media auto-download, storage; cannot toggle read receipts if parent locked them; cannot access encryption details |
| Trial-expired | Translation settings locked → SCR-ADM-04 |

**Data displayed:** NotificationPreference, PrivacySetting, MediaSetting, EncryptionKey entities.

**Actions:** Toggle each setting, clear cache, view encryption fingerprint, navigate to translation/lock sub-settings.

**Navigation:** ← SCR-COM-01 overflow · → SCR-COM-09 Translation · → SCR-COM-11 Lock.

**Permissions required:** `INTERNET`, `POST_NOTIFICATIONS` (notification channel config).

**Offline behavior:** All settings local; synced on reconnect.

**Edge cases:** Parent disables read receipts for family → all members lose read receipt visibility; cache clear while media is being viewed → graceful fallback; encryption key rotation → all members get re-keyed automatically with notification.

---

### SCR-COM-09 — Translation Settings (إعدادات الترجمة)

| Field | Value |
|---|---|
| **Screen ID** | SCR-COM-09 |
| **Name (AR)** | إعدادات الترجمة |
| **Name (EN)** | Translation Settings |
| **Roles** | Father (all), Mother (all — not in exclusive 8), Child (if parent-enabled) |
| **P0 services** | Real-time translation, language pair config, auto-translate toggle |
| **Purpose** | Configure automatic message translation between family members speaking different languages. |

**Layout:**
- **Header:** back arrow, "الترجمة"
- **Body:** auto-translate toggle (master), source language (auto-detect default), target language (Arabic default), per-conversation override list, translate on send vs. receive toggle, show original alongside toggle, translation quality indicator (Gemini model badge)
- **Footer/nav:** none
- **FAB:** none (child: SOS FAB)

**UI States:**
| State | Presentation |
|---|---|
| Loading | Settings load instantly (local) |
| Empty | N/A |
| Success | Toggles reflect state, language selectors populated |
| Error | Translation service unreachable → "خدمة الترجمة غير متاحة حاليًا" + cached mode; language pair unsupported → "هذه اللغة غير مدعومة بعد" |
| Denied-permission | N/A |
| Locked (child) | Child access only if parent explicitly enabled; otherwise "مفعّل بواسطة والدك" label, read-only |
| Trial-expired | Entire screen locked → Violet lock icon → SCR-ADM-04 paywall. Translation is a premium feature. |

**Data displayed:** TranslationConfig entity (auto, source, target, per-conversation overrides, mode).

**Actions:** Toggle auto-translate, select languages, add per-conversation override, toggle show-original, toggle send/receive mode.

**Navigation:** ← SCR-COM-08 · → SCR-ADM-04 Paywall (if trial expired).

**Permissions required:** `INTERNET`.

**Offline behavior:** Settings editable; translation deferred until online; cached translations for previously seen phrases shown.

**Edge cases:** Auto-detect misidentifies language → user can manually override source; translation for emoji-only message → no translation needed, pass-through; very long message → chunked translation with "ترجمة جزئية" indicator; dialect variation (MSA vs. Gulf Arabic) → Gemini handles but quality indicator shows "لهجة محلية".

---

### SCR-COM-10 — Voice & Transcription (الرسالة الصوتية والتفريغ)

| Field | Value |
|---|---|
| **Screen ID** | SCR-COM-10 |
| **Name (AR)** | الرسالة الصوتية والتفريغ |
| **Name (EN)** | Voice Message & Transcription |
| **Roles** | All |
| **P0 services** | Voice recording, playback, speech-to-text transcription, transcription translation |
| **Purpose** | Record, play, and auto-transcribe voice messages with optional translation. |

**Layout:**
- **Header:** back arrow (if standalone) or inline within conversation (SCR-COM-02)
- **Body (recording):** live waveform animation, timer, "إيقاف" / "إرسال" buttons, slide-to-cancel
- **Body (playback):** static waveform with progress scrubber, play/pause, speed control (0.75×/1×/1.5×/2×), transcription text below (expandable), translate button on transcription
- **Footer/nav:** inline
- **FAB:** none (child: SOS FAB)

**UI States:**
| State | Presentation |
|---|---|
| Loading (transcription) | Waveform visible, "جارٍ التفريغ النصي…" with shimmer text lines |
| Empty | Pre-record: "اضغط مع الاستمرار للتسجيل" |
| Success | Waveform + transcription text displayed; playback functional |
| Error | Transcription fail → see EC-COM-06; playback fail → "تعذّر تشغيل التسجيل" + retry; upload fail → "فشل رفع التسجيل" + retry |
| Denied-permission | Mic denied → "اسمح بالوصول للمايك" + settings link; transcription still works for received messages |
| Locked (child) | Voice recording enabled by default for child; parent can disable from message settings |
| Trial-expired | Transcription is premium → transcription text replaced with Violet lock → SCR-ADM-04; voice send/receive still works |

**Data displayed:** VoiceMessage entity (audio URL, duration, waveform, transcription, translation, language).

**Actions:** Record (hold), cancel (slide), send, play, pause, scrub, speed change, view transcription, translate transcription, delete.

**Navigation:** inline within SCR-COM-02 · → SCR-ADM-04 (premium lock).

**Permissions required:** `RECORD_AUDIO`, `INTERNET`, `FOREGROUND_SERVICE` (recording in background — limited).

**Offline behavior:** Recording stored locally; upload deferred; transcription deferred until online; playback of cached messages works offline.

**Edge cases:** Recording >5 min → auto-split; background interruption (call) → auto-pause + resume prompt; transcription for noisy audio → "جودة الصوت منخفضة، قد تكون الترجمة غير دقيقة" warning; transcription contains profanity → shown as-is (no filter); transcription language mismatch → user can re-request with different language hint.

---

### SCR-COM-11 — Lock Conversation (قفل المحادثة)

| Field | Value |
|---|---|
| **Screen ID** | SCR-COM-11 |
| **Name (AR)** | قفل المحادثة |
| **Name (EN)** | Lock Conversation |
| **Roles** | Father, Mother (can lock/unlock own conversations), Child (cannot lock) |
| **P0 services** | Conversation encryption, biometric/PIN access, hidden conversation mode |
| **Purpose** | Provide a private, encrypted conversation space accessible only via biometric or PIN. |

**Layout:**
- **Header:** back arrow, "المحادثات المقفلة"
- **Body:** list of locked conversations (name masked as "محادثة مقفلة" until unlocked), unlock prompt (biometric/PIN) on tap; if creating new lock: select conversation → set PIN / enable biometric → confirm
- **Footer/nav:** none
- **FAB:** "+ قفل محادثة جديدة"

**UI States:**
| State | Presentation |
|---|---|
| Loading | List shimmer |
| Empty | "لا توجد محادثات مقفلة" + "اقفل محادثة للخصوصية" illustration |
| Success | Locked list shown; tapping → biometric prompt → conversation revealed |
| Error | Biometric fail → PIN fallback; PIN wrong 3× → 30 s cooldown; unlock fail (key corruption) → "تعذّر فتح المحادثة" + recovery via parent re-auth |
| Denied-permission | Biometric not enrolled → PIN-only mode; biometric hardware unavailable → PIN-only |
| Locked (child) | Child cannot access this screen at all; locked conversations invisible in chat list |
| Trial-expired | Conversation lock accessible (P0 privacy) |

**Data displayed:** Conversation entity (locked flag, encryption key reference, display mask).

**Actions:** Lock conversation, unlock (biometric/PIN), add to locked, remove from locked, change PIN.

**Navigation:** ← SCR-COM-08 Message Settings · → SCR-COM-02 (on unlock).

**Permissions required:** `USE_BIOMETRIC`, no special Android permission for PIN.

**Offline behavior:** Lock/unlock fully offline (keys stored locally encrypted); new lock queued for server sync.

**Edge cases:** User forgets PIN → recovery via parent re-auth (father) or security question; biometric changed (new fingerprint enrolled) → re-prompt for PIN once, then re-authorize biometric; locked conversation's other party leaves family → conversation archived read-only, lock maintained; multiple failed unlock attempts → exponential cooldown (30 s → 1 min → 5 min → 15 min).

## 3. Monitoring Screens (SCR-PAR)

### SCR-PAR-01 — Monitoring Hub (مركز المراقبة)

| Field | Value |
|---|---|
| **Screen ID** | SCR-PAR-01 |
| **Name (AR)** | مركز المراقبة |
| **Name (EN)** | Monitoring Hub |
| **Roles** | Father (all), Mother (subset — no Safe Zones/App Rules/Web Filter/Kill Switch/Anti-bypass unless mother_permissions grants) |
| **P0 services** | Monitoring dashboard, aggregated status, quick actions |
| **Purpose** | Central dashboard showing all children's monitoring status with quick access to each feature. |

**Layout:**
- **Header:** "المراقبة" title, child selector (dropdown or horizontal avatar pills)
- **Body:** status cards grid — Screen Time (current usage / limit bar), Location (map mini-preview + last update), App Rules (active/blocked count), Web Filter (active toggle + blocked count), Content Alerts (unread alert count, Coral if >0), School Time (active/inactive status), Safe Zones (current zone + status), Anti-bypass (status), Kill Switch (status). Each card → respective screen
- **Footer/nav:** bottom nav (parent) — Home, Chat, Calendar, Tasks, Settings; Monitoring Hub accessible from Home
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | 8 shimmer status cards |
| Empty | No children linked → "اربط جهاز طفلك للبدء" + illustration + "إضافة جهاز" button |
| Success | All cards green/normal; any alert → Coral indicator on relevant card |
| Error | Child device offline → card shows "جهاز غير متصل" + last-seen; data fetch fail → "تعذّر تحميل البيانات" + retry |
| Denied-permission | Mother accessing exclusive card → "هذه الميزة متاحة للأب فقط" with request-access path |
| Locked (child) | N/A (parent-only screen) |
| Trial-expired | Monitoring hub accessible (P0 safety); individual premium features show lock on their cards |

**Data displayed:** ChildDevice entity (status, last-seen, battery), ScreenTimeSession, LocationPoint, AppRule, WebFilterRule, ContentAlert, SchoolTimeSession, SafeZone, Anti-bypass status, KillSwitch status.

**Actions:** Select child, tap any card → respective screen, pull-to-refresh, quick toggle on simple cards (Kill Switch, Web Filter).

**Navigation:** → SCR-PAR-02 through SCR-PAR-12 · ← Home/Today Dashboard.

**Permissions required:** `INTERNET` (parent device reads from server).

**Offline behavior:** Last-cached monitoring data shown with "آخر تحديث: [time]" timestamp; real-time features paused.

**Edge cases:** Multiple children → selector required, default to most recently active; child device offline >24 h → "جهاز غير متصل منذ يوم" alert; all cards error → single "تعذّر الاتصال" state with retry.

---

### SCR-PAR-02 — Screen Time (وقت الشاشة)

| Field | Value |
|---|---|
| **Screen ID** | SCR-PAR-02 |
| **Name (AR)** | وقت الشاشة |
| **Name (EN)** | Screen Time |
| **Roles** | Father, Mother |
| **P0 services** | Usage tracking, daily limits, schedules, extra-time requests |
| **Purpose** | View and control child's daily screen time with limits, schedules, and usage breakdown. |

**Layout:**
- **Header:** back arrow, child name, date selector (today default, Hijri)
- **Body:** circular progress ring (used / limit, Coral fill on Jade track), time remaining large text, category breakdown bar (Education Jade, Social Coral, Entertainment Violet, Other gray), hourly usage chart (bar chart), app-by-app usage list with icons + minutes, schedule timeline (allowed/blocked time blocks)
- **Footer/nav:** bottom nav
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | Ring + chart shimmer |
| Empty | No usage data (new device) → "لا توجد بيانات استخدام بعد" |
| Success | Ring, chart, app list populated; limit reached → ring full Coral + "انتهى الوقت المحدد" |
| Error | Usage fetch fail → cached + retry; device offline → "البيانات قد لا تكون محدّثة" |
| Denied-permission | Usage access not granted on child device → "فعّل وصول الاستخدام على جهاز طفلك" + instructions |
| Locked (child) | N/A (parent screen); child sees own SCR-PAR-02 simplified view |
| Trial-expired | Screen time tracking accessible (P0); advanced analytics locked |

**Data displayed:** ScreenTimeSession entities (app, category, start, end, duration), ScreenTimeLimit entity, ScreenTimeSchedule entity.

**Actions:** Set daily limit, set schedule, block/unblock specific app, extend time (manual), view history, reset day.

**Navigation:** ← SCR-PAR-01 · → SCR-PAR-03 Device Lock · → SCR-PAR-04 Extra Time Request.

**Permissions required:** `PACKAGE_USAGE_STATS` (child device), `INTERNET`.

**Offline behavior:** Cached usage shown; limit enforcement continues locally on child device.

**Edge cases:** Child in different timezone → usage computed in child's local day; app uninstalled mid-session → session ended gracefully; limit changed mid-day → applies immediately with prorated calculation; usage data gap (device was off) → shown as gray gap in chart.

---

### SCR-PAR-03 — Device Lock (قفل الجهاز)

| Field | Value |
|---|---|
| **Screen ID** | SCR-PAR-03 |
| **Name (AR)** | قفل الجهاز |
| **Name (EN)** | Device Lock |
| **Roles** | Father, Mother |
| **P0 services** | Remote device lock, unlock, lock scheduling, override |
| **Purpose** | Remotely lock or unlock the child's device with optional time-based scheduling. |

**Layout:**
- **Header:** back arrow, child name, "قفل الجهاز"
- **Body:** big lock toggle (locked = Coral locked icon, unlocked = Jade open icon), current status text, lock duration selector (15 min / 30 min / 1 h / until I unlock), schedule section (recurring lock times — bedtime, study time), "قفل فوري" CTA, override section (always-allowed apps during lock: phone, SOS, education apps), last lock history
- **Footer/nav:** bottom nav
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | Status fetching |
| Empty | No lock history → "لم يتم قفل الجهاز بعد" |
| Success | Current status displayed, toggle responsive |
| Error | Lock command fail → "تعذّر قفل الجهاز" + retry; device offline → "جهاز غير متصل، سيُقفل عند الاتصال" queued command |
| Denied-permission | Device admin not granted on child device → "يجب منح صلاحيات مدير الجهاز على جهاز طفلك" + instructions |
| Locked (child) | N/A (parent screen) |
| Trial-expired | Device lock accessible (P0 safety) |

**Data displayed:** DeviceLockState entity (status, locked-since, unlock-scheduled, schedule), DeviceLockHistory.

**Actions:** Lock now, unlock now, set duration, set schedule, add/remove always-allowed app, view history.

**Navigation:** ← SCR-PAR-01 / SCR-PAR-02 · → SCR-PAR-11 Kill Switch (related).

**Permissions required:** `DEVICE_ADMIN` (child device), `INTERNET`.

**Offline behavior:** Lock command queued; child device enforces lock locally once command syncs; parent sees "أمر pending".

**Edge cases:** Lock command during SOS → SOS and always-allowed apps remain accessible; child unlocks via factory reset → Anti-bypass detects and alerts parent (SCR-PAR-12); scheduled lock while child on a call → call continues, lock applies after; parent locks then loses their device → other parent can unlock.

---

### SCR-PAR-04 — Extra Time Request (طلب وقت إضافي)

| Field | Value |
|---|---|
| **Screen ID** | SCR-PAR-04 |
| **Name (AR)** | طلب وقت إضافي |
| **Name (EN)** | Extra Time Request |
| **Roles** | Child (initiates), Father/Mother (approves/denies) |
| **P0 services** | Request workflow, approval notification, time grant |
| **Purpose** | Allow child to request additional screen time when their limit is reached, with parent approval. |

**Layout:**
- **Child view:** modal sheet — "انتهى وقت الشاشة" message, "طلب وقت إضافي" button, duration selector (15/30/60 min), reason field (optional), "إرسال الطلب" CTA; after send: "تم إرسال طلبك، انتظر موافقة والدك" with status indicator
- **Parent view:** notification card in Today Dashboard / push notification — child avatar, requested duration, reason, "موافقة" (Jade) / "رفض" (Coral) / "تعديل المدة" buttons
- **Footer/nav:** N/A (modal/sheet)
- **FAB:** none (child: SOS FAB)

**UI States:**
| State | Presentation |
|---|---|
| Loading | Send: button spinner; parent: approval processing |
| Empty | Child: no pending request; parent: no pending requests |
| Success | Child: request sent, waiting; parent: approval/denial processed, child notified |
| Error | Send fail → "تعذّر إرسال الطلب" + retry; parent approval fail → "تعذّر المعالجة" + retry |
| Denied-permission | N/A |
| Locked (child) | This screen accessible when screen time locked (that's its purpose) |
| Trial-expired | Accessible (P0) |

**Data displayed:** TimeRequest entity (child, duration, reason, status, timestamp, parent response).

**Actions:** Child: send request, cancel pending. Parent: approve, deny, modify duration, approve with conditions.

**Navigation:** triggered from child's locked screen · parent → SCR-PAR-02 Screen Time.

**Permissions required:** `INTERNET`, `POST_NOTIFICATIONS`.

**Offline behavior:** Child request queued; sends on reconnect; parent can approve cached request; time grant syncs to child device when online.

**Edge cases:** Two parents receive request → first response wins, other gets "تمت المعالجة" notification; child sends multiple requests → only latest is active, previous auto-cancelled; request expired (parent didn't respond in 30 min) → auto-deny with "انتهت صلاحية الطلب"; parent grants time but child device offline → time credited when device reconnects.

---

### SCR-PAR-05 — Map & GPS (الخريطة وتحديد الموقع)

| Field | Value |
|---|---|
| **Screen ID** | SCR-PAR-05 |
| **Name (AR)** | الخريطة وتحديد الموقع |
| **Name (EN)** | Map & GPS Tracking |
| **Roles** | Father, Mother |
| **P0 services** | Live GPS tracking, location history, geofence events, battery-efficient updates |
| **Purpose** | View child's real-time location on a map with history trail and geofence overlay. |

**Layout:**
- **Header:** back arrow, child name, map type toggle (standard/satellite), last-update timestamp
- **Body:** full-screen map — child pin (Jade avatar) with accuracy circle, safe zones drawn (green fill, dashed border), location history trail (faded dots, last 24 h), current speed (if moving), battery level indicator; tap pin → details card (address, last update, accuracy, battery, moving/stationary)
- **Footer/nav:** bottom nav
- **FAB:** "اتصال" (call child), "الاتجاهات" (open in maps for directions)

**UI States:**
| State | Presentation |
|---|---|
| Loading | Map tiles + pin shimmer |
| Empty | No location data → "لا توجد بيانات موقع، تأكد من تفعيل الموقع على جهاز طفلك" |
| Success | Pin on map, trail visible, zones drawn |
| Error | GPS fail on child device → "تعذّر تحديد موقع طفلك" + last-known with timestamp; map tiles fail → offline tiles |
| Denied-permission | Location not granted on child device → "الموقع غير مفعّل على جهاز طفلك" + instructions link |
| Locked (child) | N/A (parent screen) |
| Trial-expired | Live tracking accessible (P0 safety); history >7 days locked |

**Data displayed:** LocationPoint entities (lat/lng, accuracy, speed, bearing, battery, timestamp), SafeZone entities, GeofenceEvent entities.

**Actions:** Pan/zoom map, tap pin, view history, toggle satellite, call child, get directions, refresh, toggle history trail.

**Navigation:** ← SCR-PAR-01 · → SCR-PAR-06 Safe Zones · → SCR-PAR-10 School Time (if in school zone).

**Permissions required:** Child device: `ACCESS_FINE_LOCATION`, `ACCESS_BACKGROUND_LOCATION`, `FOREGROUND_SERVICE`. Parent: `INTERNET`.

**Offline behavior:** Cached last-known location shown with stale indicator; history cached locally; live updates resume on reconnect.

**Edge cases:** Location spoofing detected (jump >100 km in <5 min) → Anti-bypass flag (SCR-PAR-12); child in airplane mode → last-known + "جهاز غير متصل"; GPS in building → accuracy circle large, "الدقة منخفضة"; multiple children → pin clustering at low zoom, individual pins at high zoom.

---

### SCR-PAR-06 — Safe Zones (المناطق الآمنة)

| Field | Value |
|---|---|
| **Screen ID** | SCR-PAR-06 |
| **Name (AR)** | المناطق الآمنة |
| **Name (EN)** | Safe Zones (Geofences) |
| **Roles** | Father only (exclusive — one of the 8); Mother only if mother_permissions grants |
| **P0 services** | Geofence CRUD, entry/exit alerts, zone types, radius config |
| **Purpose** | Define geographic zones (home, school, mosque, park) where child is expected to be, with entry/exit notifications. |

**Layout:**
- **Header:** back arrow, "المناطق الآمنة", "+ منطقة جديدة"
- **Body:** map with all zones drawn (color by type: Home = Jade, School = Blue, Mosque = Violet, Other = gray), zone list below map — each: name, type icon, address, radius, status (child inside ✓ / outside), alert toggle
- **Footer/nav:** bottom nav
- **FAB:** "+ منطقة" (add zone)

**UI States:**
| State | Presentation |
|---|---|
| Loading | Map + list shimmer |
| Empty | "لا توجد مناطق آمنة، أضف منطقة لحماية طفلك" + illustration |
| Success | Zones drawn on map, list with status, child's current pin visible |
| Error | Geofence registration fail → "تعذّر حفظ المنطقة" + retry; location services off → "فعّل خدمات الموقع على جهاز طفلك" |
| Denied-permission | Mother without grant → "هذه الميزة متاحة للأب فقط" + request access path |
| Locked (child) | N/A (parent screen) |
| Trial-expired | Safe zones accessible (P0 safety); >5 zones locked (premium) |

**Data displayed:** SafeZone entity (name, type, center lat/lng, radius, address, alert on entry, alert on exit, schedule), child's current location for status.

**Actions:** Create zone (tap map or enter address), set radius (slider), set type, toggle alerts, edit, delete, test zone.

**Navigation:** ← SCR-PAR-01 / SCR-PAR-05 · → SCR-PAR-05 Map.

**Permissions required:** Child: `ACCESS_FINE_LOCATION`, `ACCESS_BACKGROUND_LOCATION`. Parent: `INTERNET`.

**Offline behavior:** Zones cached; geofence monitoring continues locally on child device; alerts queued.

**Edge cases:** Overlapping zones → child in multiple zones, all show "inside"; zone radius <50 m → "نطاق صغير قد يسبب تنبيهات كاذبة" warning; zone at same location as School Time → auto-linked; max zones reached (free: 5) → paywall for more; child exits zone during School Time → combined alert.

---

### SCR-PAR-07 — App Rules (قواعد التطبيقات)

| Field | Value |
|---|---|
| **Screen ID** | SCR-PAR-07 |
| **Name (AR)** | قواعد التطبيقات |
| **Name (EN)** | App Rules |
| **Roles** | Father only (exclusive); Mother only if mother_permissions grants |
| **P0 services** | App blocking, time limits per app, category rules, install monitoring |
| **Purpose** | Control which apps the child can use, when, and for how long. |

**Layout:**
- **Header:** back arrow, child name, "قواعد التطبيقات", category filter tabs (All / Social / Games / Education / Entertainment)
- **Body:** app list — each row: app icon, name, category tag, status (Allowed / Blocked / Time-limited), time used today / limit, toggle; category-level rule section at top (block all social, etc.); "تطبيقات مثبتة حديثًا" section if new installs detected
- **Footer/nav:** bottom nav
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | 10 shimmer app rows |
| Empty | No apps installed/enumerated → "لا توجد تطبيقات، تأكد من ربط جهاز طفلك" |
| Success | Apps listed with status, new installs highlighted |
| Error | App list fetch fail → cached + retry; rule change fail → "فشل تحديث القاعدة" + retry |
| Denied-permission | Usage stats not granted on child device → "فعّل وصول الاستخدام"; Accessibility not granted → "فعّل خدمة الوصول لمراقبة التطبيقات" |
| Locked (child) | N/A (parent screen) |
| Trial-expired | Basic block/unblock accessible (P0); per-app time limits locked (premium) |

**Data displayed:** App entity (name, package, icon, category), AppRule entity (status, time limit, schedule, category rule).

**Actions:** Block/unblock app, set per-app time limit, set category rule, allow new install, block new installs by default, view app usage.

**Navigation:** ← SCR-PAR-01 · → SCR-PAR-02 Screen Time (app usage detail).

**Permissions required:** Child: `PACKAGE_USAGE_STATS`, `BIND_ACCESSIBILITY_SERVICE` (for blocking enforcement), `DEVICE_ADMIN`. Parent: `INTERNET`.

**Offline behavior:** Rules cached on child device; enforcement continues locally; rule changes queued.

**Edge cases:** New app installed → auto-ruled based on default (block by default / allow by default parent setting); app uses VPN to bypass → Kill Switch / Anti-bypass intercept; system app blocked accidentally → safety check prevents blocking phone/SOS/settings; app reinstalled with different package name → treated as new app.

---

### SCR-PAR-08 — Web Filter (تصفية الويب)

| Field | Value |
|---|---|
| **Screen ID** | SCR-PAR-08 |
| **Name (AR)** | تصفية الويب |
| **Name (EN)** | Web Filter |
| **Roles** | Father only (exclusive); Mother only if mother_permissions grants |
| **P0 services** | URL/category blocking, safe search, browser enforcement, DNS filtering |
| **Purpose** | Filter web content on the child's device by category, domain, and safe-search enforcement. |

**Layout:**
- **Header:** back arrow, child name, "تصفية الويب", master toggle
- **Body:** category list with toggles (Adult, Violence, Gambling, Social Media, Gaming, Shopping, News, etc.), blocked domains list (add/remove), allowed domains list (whitelist), safe search toggle (forces safe mode on Google/YouTube/Bing), browsing activity (recent domains visited with allow/block indicator), "طلبات فتح موقع" section (child requests to unblock a site)
- **Footer/nav:** bottom nav
- **FAB:** "+ حظر موقع" (add domain to block)

**UI States:**
| State | Presentation |
|---|---|
| Loading | Category list shimmer |
| Empty | Web filter disabled → "فعّل تصفية الويب لحماية طفلك" + enable CTA |
| Success | Categories toggled, activity populated, requests shown |
| Error | Filter engine fail on child device → "تعذّر تفعيل التصفية" + retry; DNS fail → fallback to local blocklist |
| Denied-permission | Accessibility/VPN not granted → "فعّل خدمة الوصول/VPN لتطبيق التصفية" |
| Locked (child) | N/A (parent screen) |
| Trial-expired | Basic category blocking accessible (P0); custom domain lists + browsing history locked (premium) |

**Data displayed:** WebFilterRule entity (categories, blocked domains, allowed domains, safe search), BrowsingHistory entity, SiteUnblockRequest entity.

**Actions:** Toggle master, toggle categories, add/remove domain, toggle safe search, approve/deny site request, view browsing history, clear history.

**Navigation:** ← SCR-PAR-01 · → SCR-PAR-09 Content Alerts.

**Permissions required:** Child: `BIND_ACCESSIBILITY_SERVICE` (browser monitoring), `BIND_VPN_SERVICE` (DNS filtering), `INTERNET`. Parent: `INTERNET`.

**Offline behavior:** Blocklist cached locally; DNS filtering continues offline (cached DNS); category updates deferred.

**Edge cases:** Child uses private browsing → Accessibility detects and blocks; child uses VPN app to bypass → Kill Switch / Anti-bypass intercept; category misclassification → parent can whitelist specific domain; site request while parent offline → queued, child sees "بانتظار الموافقة".

---

### SCR-PAR-09 — Content Alerts (تنبيهات المحتوى)

| Field | Value |
|---|---|
| **Screen ID** | SCR-PAR-09 |
| **Name (AR)** | تنبيهات المحتوى |
| **Name (EN)** | Content Alerts |
| **Roles** | Father, Mother |
| **P0 services** | AI content analysis, alert generation, alert review, false-positive feedback |
| **Purpose** | Display AI-detected content concerns from child's messages and browsing for parent review. |

**Layout:**
- **Header:** back arrow, "تنبيهات المحتوى", filter (All / Unread / Critical / Resolved)
- **Body:** alert cards — each: severity indicator (Critical = Coral, Warning = amber, Info = gray), alert type (cyberbullying, inappropriate content, predatory contact, self-harm, radicalization), source (chat / web / app), timestamp (Hijri), excerpt (blurred preview, tap to reveal), AI confidence %, actions: "عرض التفاصيل" / "تجاهل (إيجابية كاذبة)" / "حظر" / "محادثة مع الطفل"
- **Footer/nav:** bottom nav
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | 5 shimmer alert cards |
| Empty | "لا توجد تنبيهات، طفلك بأمان" + shield illustration |
| Success | Alerts listed by severity + recency, unread bold |
| Error | AI analysis service fail → "خدمة التحليل غير متاحة" + last cached alerts; fetch fail → retry |
| Denied-permission | Accessibility not granted on child device → "فعّل خدمة الوصول لتحليل المحتوى" |
| Locked (child) | N/A (parent screen) |
| Trial-expired | Basic alerts accessible (P0 safety); AI-powered contextual analysis locked (premium) |

**Data displayed:** ContentAlert entity (type, severity, source, excerpt, confidence, timestamp, status, AI model), linked Message/BrowsingHistory.

**Actions:** View detail, mark as false positive, block source, initiate chat with child, resolve alert, escalate (report to authorities for critical), adjust sensitivity.

**Navigation:** ← SCR-PAR-01 / Today Dashboard · → SCR-COM-02 (chat with child) · → SCR-PAR-08 Web Filter (block site).

**Permissions required:** Child: `BIND_ACCESSIBILITY_SERVICE` (content scanning), `INTERNET`. Parent: `INTERNET`.

**Offline behavior:** Cached alerts shown; AI analysis deferred; alerts generated locally for known patterns.

**Edge cases:** Critical alert (self-harm/predator) → immediate push notification bypassing DND; false positive rate high → parent can adjust sensitivity slider; alert for child's own message → still shown (safety priority over privacy); alert evidence deleted by child → alert preserved with "المحتوى المحذوف" note; multiple alerts same source → grouped with count.

---

### SCR-PAR-10 — School Time (وقت المدرسة)

| Field | Value |
|---|---|
| **Screen ID** | SCR-PAR-10 |
| **Name (AR)** | وقت المدرسة |
| **Name (EN)** | School Time Mode |
| **Roles** | Father, Mother |
| **P0 services** | School schedule enforcement, GPS verification, restricted mode, educational app allowlist |
| **Purpose** | Enforce a restricted device mode during school hours with GPS-verified school location. |

**Layout:**
- **Header:** back arrow, child name, "وقت المدرسة", status badge (Active/Inactive)
- **Body:** schedule card (school days + start/end times, Hijri), school zone link (→ SCR-PAR-06 if not set), restricted mode preview (allowed apps list: education, phone, SOS), GPS verification toggle (verify child is at school zone to activate), today's status (active periods timeline, any violations), override section ("تعطيل اليوم" / "تمديد الوقت")
- **Footer/nav:** bottom nav
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | Schedule + status shimmer |
| Empty | No school schedule set → "اضبط جدول المدرسة لتفعيل الوضع" + setup CTA |
| Success | Schedule shown, today's status active/inactive, violations logged |
| Error | GPS verification fail → "تعذّر التحقق من موقع المدرسة" + fallback to schedule-only; sync fail → retry |
| Denied-permission | Location denied → "الموقع مطلوب للتحقق من وجود طفلك في المدرسة" + schedule-only fallback |
| Locked (child) | N/A (parent screen) |
| Trial-expired | School Time accessible (P0 safety/education) |

**Data displayed:** SchoolSchedule entity (days, times, zone reference), SchoolTimeSession entity (status, start, end, GPS verified, violations), allowed app list.

**Actions:** Set schedule, link school zone, toggle GPS verification, add/remove allowed apps, disable for today, extend time, view history.

**Navigation:** ← SCR-PAR-01 / SCR-ADM-10 School Schedule · → SCR-PAR-06 Safe Zones (school zone) · → SCR-PAR-07 App Rules.

**Permissions required:** Child: `ACCESS_FINE_LOCATION`, `DEVICE_ADMIN`, `PACKAGE_USAGE_STATS`. Parent: `INTERNET`.

**Offline behavior:** Schedule enforcement continues locally; GPS verification cached (last-known); violations logged locally.

**Edge cases:** School zone not set → schedule-only mode (no GPS verification); child at school but GPS inaccurate → grace period (5 min) before violation; half-day schedule → parent sets custom end time; school holiday → parent can disable for the day; GPS accuracy vs battery tradeoff → Open Decision #7.

---

### SCR-PAR-11 — Kill Switch (مفتاح الإيقاف)

| Field | Value |
|---|---|
| **Screen ID** | SCR-PAR-11 |
| **Name (AR)** | مفتاح الإيقاف |
| **Name (EN)** | Kill Switch (Emergency Shutdown) |
| **Roles** | Father only (exclusive); Mother only if mother_permissions grants |
| **P0 services** | Emergency device shutdown, VPN kill, network isolation, app freeze |
| **Purpose** | Immediately freeze all non-essential functionality on the child's device in an emergency. |

**Layout:**
- **Header:** back arrow, "مفتاح الإيقاف", warning banner "هذه الميزة توقف جميع وظائف الجهاز عدا الطوارئ"
- **Body:** big toggle switch (Off = Jade, On = Coral with pulsing ring), current status, scope selector (freeze apps only / block network / full lockdown), always-allowed (phone, SOS, parent calls), timer option (auto-release after X min), confirmation step (hold 3 s to activate), activity log (last activations with reason)
- **Footer/nav:** bottom nav
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | Status fetching |
| Empty | Never activated → "لم يتم تفعيل مفتاح الإيقاف من قبل" |
| Success | Status displayed, toggle responsive |
| Error | Activation fail → "تعذّر تفعيل مفتاح الإيقاف" + retry; VPN conflict → see EC-SAF-04; device offline → queued command "سيُفعّل عند الاتصال" |
| Denied-permission | VPN not granted → "مطلوب صلاحية VPN لعزل الشبكة"; Accessibility not granted → "مطلوب صلاحية الوصول لتجميد التطبيقات" |
| Locked (child) | N/A (parent screen) |
| Trial-expired | Kill Switch accessible (P0 safety) |

**Data displayed:** KillSwitchState entity (status, scope, activated-at, auto-release, reason), KillSwitchHistory.

**Actions:** Activate (hold 3 s), deactivate, set scope, set timer, set reason, view history, test (simulation).

**Navigation:** ← SCR-PAR-01 / SCR-PAR-03 · → SCR-PAR-12 Anti-bypass (related).

**Permissions required:** Child: `BIND_VPN_SERVICE`, `BIND_ACCESSIBILITY_SERVICE`, `DEVICE_ADMIN`, `INTERNET`. Parent: `INTERNET`.

**Offline behavior:** Activation command queued; child device enforces locally when command syncs; deactivation also queued.

**Edge cases:** Kill Switch + SOS → SOS remains functional; Kill Switch while child on call → call continues, then freezes; VPN conflict with child's VPN app → Kill Switch's VPN takes priority, child VPN killed (see EC-SAF-04); auto-release timer expires while offline → releases locally on child device; legal risk → Open Decision #2.

---

### SCR-PAR-12 — Anti-Bypass (مضاد التجاوز)

| Field | Value |
|---|---|
| **Screen ID** | SCR-PAR-12 |
| **Name (AR)** | مضاد التجاوز |
| **Name (EN)** | Anti-Bypass Detection |
| **Roles** | Father only (exclusive); Mother only if mother_permissions grants |
| **P0 services** | Bypass detection, tamper alerts, factory reset detection, VPN/proxy detection, location spoofing detection |
| **Purpose** | Detect and alert parents when the child attempts to bypass monitoring controls. |

**Layout:**
- **Header:** back arrow, "مضاد التجاوز", status (Protected/At Risk), last scan timestamp
- **Body:** detection modules list — each with status indicator:
  - Factory reset detection (enabled, last check)
  - VPN/proxy detection (enabled, active VPNs seen)
  - Location spoofing detection (enabled, anomalies detected)
  - Accessibility service tampering (enabled)
  - Device admin removal attempt (enabled)
  - USB debugging detection (enabled)
  - Safe mode boot detection (enabled)
  - App side-loading detection (enabled)
  - Time/zone tampering detection (enabled)
  - System update bypass detection (enabled)
- Each module: toggle, alert count, last event, "عرض السجل" → event log
- **Footer/nav:** bottom nav
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | Module list shimmer |
| Empty | All clear → "جميع أنظمة الحماية تعمل" + shield checkmark |
| Success | Modules listed with green/amber/red status |
| Error | Scan fail → "تعذّر فحص الحماية" + retry; module disabled by system update → see EC-SAF-05 |
| Denied-permission | Accessibility not granted → module shows "غير مفعّل" with enable button; Device admin removed → "تمت إزالة صلاحيات مدير الجهاز" critical alert |
| Locked (child) | N/A (parent screen) |
| Trial-expired | Anti-bypass accessible (P0 safety) |

**Data displayed:** AntiBypassModule entities (type, status, enabled, last-event, alert-count), BypassEvent entity (type, timestamp, detail, severity).

**Actions:** Toggle modules, view event log per module, view all events, export log, trigger manual scan, re-enable disabled modules.

**Navigation:** ← SCR-PAR-01 / SCR-PAR-11 · → event log detail.

**Permissions required:** Child: `BIND_ACCESSIBILITY_SERVICE`, `DEVICE_ADMIN`, `PACKAGE_USAGE_STATS`, `ACCESS_FINE_LOCATION`, `INTERNET`. Parent: `INTERNET`.

**Offline behavior:** Detection continues locally; alerts queued; event log cached.

**Edge cases:** System update disables Accessibility → see EC-SAF-05 (re-prompt flow); child uses safe mode → detected on next boot, alert sent; location spoofing app installed → detected via mock-location flag; USB debugging enabled → alert (could be used for sideloading); Google Play policy risk → Open Decision #1; multiple bypass attempts → escalation to parent notification with "محاولات متكررة" warning.

## 4. Education Screens (SCR-EDU)

### SCR-EDU-01 — Learning Home (الصفحة الرئيسية للتعلم)

| Field | Value |
|---|---|
| **Screen ID** | SCR-EDU-01 |
| **Name (AR)** | الصفحة الرئيسية للتعلم |
| **Name (EN)** | Learning Home |
| **Roles** | Child (primary IA — Home IS Learning), Parent (view child's progress) |
| **P0 services** | Learning dashboard, adaptive path, points/XP, daily goals, streak |
| **Purpose** | Child's home screen showing learning progress, daily goals, and recommended next lessons. |

**Layout:**
- **Header:** greeting ("صباح الخير، [name]") Hijri date, streak flame icon with count, XP bar, notifications bell
- **Body:** daily goal ring (lessons completed / target), "أكمل دروس اليوم" CTA, recommended next lesson card (subject, topic, difficulty, estimated time), subjects grid (icon, name, progress %), pending assignments section (if any), badges showcase (recent badges), "وضع التركيز" entry, Quran practice streak
- **Footer/nav:** child bottom nav — Home (active), Chat, Tasks, SOS
- **FAB:** SOS (always present)

**UI States:**
| State | Presentation |
|---|---|
| Loading | Greeting + cards shimmer |
| Empty | New learner (no placement) → "أكمل اختبار التحديد لبدء رحلتك" + CTA → SCR-EDU-12 |
| Success | Progress, recommendations, subjects all populated |
| Error | Fetch fail → cached dashboard + retry; adaptive engine fail → fallback to sequential path |
| Denied-permission | N/A |
| Locked (child) | N/A (this IS the child's home) |
| Trial-expired | Core learning accessible (P0); AI Tutor + adaptive recommendations locked |

**Data displayed:** LearnerProfile entity (level, XP, streak, daily goal), Subject entity (name, progress, icon), Assignment entity (pending), Badge entity, AdaptivePath entity, QuranProgress entity.

**Actions:** Start daily goal, tap recommended lesson, tap subject, tap assignment, enter Focus Mode, view badges, view Quran progress, take placement test (if needed).

**Navigation:** → SCR-EDU-02 Subjects · → SCR-EDU-03 Lessons · → SCR-EDU-05 Assignment · → SCR-EDU-09 Focus Mode · → SCR-EDU-10 Quran · → SCR-EDU-12 Placement · → SCR-EDU-15 Level + XP.

**Permissions required:** `INTERNET`, `POST_NOTIFICATIONS` (learning reminders).

**Offline behavior:** Cached lessons accessible; progress cached; recommendations from last online session; adaptive updates deferred.

**Edge cases:** Streak broken (missed yesterday) → "فقدت سلسلتك، ابدأ جديدة اليوم!" with encouragement; daily goal already met → "أحسنت! اكتمل هدف اليوم" celebration; placement test incomplete → home shows placement CTA prominently; no internet for >3 days → adaptive path degrades to last cached, "اتصل لتحديث مسارك التعليمي" banner.

---

### SCR-EDU-02 — Subjects (المواد الدراسية)

| Field | Value |
|---|---|
| **Screen ID** | SCR-EDU-02 |
| **Name (AR)** | المواد الدراسية |
| **Name (EN)** | Subjects |
| **Roles** | Child (primary), Parent (view) |
| **P0 services** | Subject catalog, curriculum mapping, progress tracking |
| **Purpose** | Browse all available subjects with curriculum progress and lesson navigation. |

**Layout:**
- **Header:** back arrow, "المواد الدراسية", filter (grade level / all)
- **Body:** subject cards grid — each: icon, name (Arabic), grade level, progress bar (lessons completed / total), last accessed, difficulty level, "متابعة" button if in progress, "ابدأ" if new
- **Footer/nav:** child bottom nav; SOS FAB
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | 6 shimmer subject cards |
| Empty | No subjects assigned → "لا توجد مواد، سيتم إضافتها قريبًا" |
| Success | Subjects grid populated with progress |
| Error | Fetch fail → cached subjects + retry |
| Denied-permission | N/A |
| Locked (child) | N/A |
| Trial-expired | Core subjects accessible (P0); advanced electives locked |

**Data displayed:** Subject entities (name, icon, grade, total lessons, completed, difficulty, last-accessed), Curriculum mapping.

**Actions:** Tap subject → SCR-EDU-03 Lessons, filter by grade, sort by progress/name.

**Navigation:** ← SCR-EDU-01 · → SCR-EDU-03 Lessons.

**Permissions required:** `INTERNET`.

**Offline behavior:** Cached subject catalog; progress cached.

**Edge cases:** Subject added mid-term → shows as new with 0% progress; subject removed → grayed out, accessible for completed lessons; grade level changed → curriculum re-maps, progress transferred where applicable.

---

### SCR-EDU-03 — Lessons (قائمة الدروس)

| Field | Value |
|---|---|
| **Screen ID** | SCR-EDU-03 |
| **Name (AR)** | قائمة الدروس |
| **Name (EN)** | Lessons List |
| **Roles** | Child (primary), Parent (view) |
| **P0 services** | Lesson catalog, lesson types, completion status, prerequisites |
| **Purpose** | Browse all lessons within a subject with completion status and prerequisites. |

**Layout:**
- **Header:** back arrow, subject name + icon, progress bar
- **Body:** lesson list (vertical) — each: lesson number, title, type icon (video/interactive/reading/quiz), duration, status (completed ✓ / in-progress / locked), prerequisite lock indicator, "ابدأ" / "إعادة" / "متابعة" button
- **Footer/nav:** child bottom nav; SOS FAB
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | 8 shimmer lesson rows |
| Empty | No lessons in subject → "الدروس قيد الإعداد" |
| Success | Lessons listed with status, next lesson highlighted |
| Error | Fetch fail → cached lessons + retry |
| Denied-permission | N/A |
| Locked (child) | Locked lessons (prerequisite not met) → lock icon + "أكمل الدرس السابق أولاً" |
| Trial-expired | Core lessons accessible (P0); interactive lessons locked (premium) |

**Data displayed:** Lesson entities (number, title, type, duration, status, prerequisites, content reference).

**Actions:** Tap lesson → SCR-EDU-04 Interactive Lesson, filter by status, sort by number.

**Navigation:** ← SCR-EDU-02 · → SCR-EDU-04 Interactive Lesson · → SCR-EDU-05 Assignment (if lesson has assignment) · → SCR-EDU-06 Quiz (if lesson has quiz).

**Permissions required:** `INTERNET`.

**Offline behavior:** Cached lesson list; downloaded lessons accessible offline.

**Edge cases:** Lesson content not downloaded → "حمّل الدرس للمشاهدة بدون إنترنت" CTA; prerequisite completed but cache stale → refresh on open; lesson retired → hidden but completion record kept.

---

### SCR-EDU-04 — Interactive Lesson (الدرس التفاعلي)

| Field | Value |
|---|---|
| **Screen ID** | SCR-EDU-04 |
| **Name (AR)** | الدرس التفاعلي |
| **Name (EN)** | Interactive Lesson Player |
| **Roles** | Child (primary), Parent (view) |
| **P0 services** | Lesson player, interactive elements, progress save, media playback |
| **Purpose** | Deliver lesson content interactively with video, text, exercises, and progress tracking. |

**Layout:**
- **Header:** back arrow (confirms exit), lesson title, progress bar (within lesson), "تم" completion indicator
- **Body:** content sections — video player (if video lesson), text content (RTL Arabic, formatted), interactive elements (tap-to-reveal, drag-and-drop, fill-in-blank), "التالي" / "السابق" navigation, section indicator
- **Footer/nav:** hidden during lesson (immersive)
- **FAB:** SOS (always present, top-right during lesson)

**UI States:**
| State | Presentation |
|---|---|
| Loading | Content section shimmer, video buffer |
| Empty | N/A (lesson has content) |
| Success | Content rendered, interactive elements functional, progress saved |
| Error | Content load fail → "تعذّر تحميل الدرس" + retry + offline download option; video fail → "تعذّر تشغيل الفيديو" + audio-only fallback |
| Denied-permission | N/A |
| Locked (child) | Lesson locked → "أكمل الدروس السابقة أولاً" + back |
| Trial-expired | Reading/video lessons accessible (P0); interactive exercises locked (premium) |

**Data displayed:** Lesson content (sections, media, interactive elements), LessonProgress entity (current section, completion %).

**Actions:** Play/pause video, navigate sections, interact with elements, save progress, complete lesson, exit (with confirm).

**Navigation:** ← SCR-EDU-03 · → SCR-EDU-05 Assignment · → SCR-EDU-06 Quiz (auto-prompt on completion).

**Permissions required:** `INTERNET`, media playback (no special permission).

**Offline behavior:** Downloaded lessons fully interactive offline; progress cached; non-downloaded lessons require internet.

**Edge cases:** Exit mid-lesson → progress saved, "متابعة من حيث توقفت" on return; interactive element timeout → skip with "تخطّي" option; video transcript available for accessibility; lesson completed twice → highest score kept.

---

### SCR-EDU-05 — Assignment & Submit (الواجب والتسليم)

| Field | Value |
|---|---|
| **Screen ID** | SCR-EDU-05 |
| **Name (AR)** | الواجب والتسليم |
| **Name (EN)** | Assignment & Submission |
| **Roles** | Child (submit), Parent (view + grade for manual), AI (auto-grade) |
| **P0 services** | Assignment CRUD, file upload, AI grading, manual grading, feedback |
| **Purpose** | Complete and submit assignments with automatic or parent/AI grading. |

**Layout:**
- **Header:** back arrow, assignment title, due date (Hijri, Coral if overdue), status badge
- **Body:** assignment description, instructions, attached resources (reference lessons), submission area — text input, file upload (image/PDF/audio), drawing canvas (for math/handwriting), "حفظ مسودة" / "تسليم" CTA; after submission: grade card (score, AI feedback, parent feedback if manual), rubric
- **Footer/nav:** hidden during assignment
- **FAB:** SOS

**UI States:**
| State | Presentation |
|---|---|
| Loading | Assignment detail + submission area shimmer |
| Empty | No submission yet → blank submission area with instructions |
| Success | Assignment submitted, grade displayed (if auto-graded) or "بانتظار التقييم" (if manual) |
| Error | Upload fail → "فشل رفع الملف" + retry; submit fail → "فشل التسليم" + retry; AI grading fail → see EC-EDU-01 |
| Denied-permission | Camera/files denied → "اسمح بالوصول لإرفاق الملفات" + manual text fallback |
| Locked (child) | N/A (child completes own assignments) |
| Trial-expired | Assignment submission accessible (P0); AI grading locked (premium) → manual grading only |

**Data displayed:** Assignment entity (title, description, due, resources, rubric, type), Submission entity (content, files, timestamp, grade, feedback, status).

**Actions:** Read assignment, view resources, type/upload/draw submission, save draft, submit, view grade, view feedback, resubmit (if allowed).

**Navigation:** ← SCR-EDU-01 / SCR-EDU-03 · → SCR-EDU-06 Quiz (if linked).

**Permissions required:** `INTERNET`, `CAMERA` (photo submission), `READ_EXTERNAL_STORAGE` / `READ_MEDIA_IMAGES` (file upload).

**Offline behavior:** Drafts saved locally; submission deferred until online; downloaded resources accessible.

**Edge cases:** Submit after due date → "تسليم متأخر" flag, parent notified; file too large → auto-compress; resubmission after grading → "إعادة التسليم" allowed if parent enabled; AI grade contested → parent review path; assignment deleted by parent while child working → "تم حذف الواجب" + draft saved.

---

### SCR-EDU-06 — Quiz (الاختبار)

| Field | Value |
|---|---|
| **Screen ID** | SCR-EDU-06 |
| **Name (AR)** | الاختبار |
| **Name (EN)** | Quiz |
| **Roles** | Child (take), Parent (view results) |
| **P0 services** | Quiz engine, question types, timer, scoring, anti-cheat |
| **Purpose** | Assess understanding through interactive quiz with multiple question types and immediate scoring. |

**Layout:**
- **Header:** quiz title, question counter (Q 3/10), timer (if timed), exit (with confirm)
- **Body:** question card — question text (RTL), question type (multiple choice, true/false, fill-in, matching, ordering), answer options (tappable, selected = Jade border), image/diagram if applicable, "السؤال التالي" / "السابق" navigation; progress bar
- **Footer/nav:** hidden (immersive)
- **FAB:** SOS

**UI States:**
| State | Presentation |
|---|---|
| Loading | Question card shimmer |
| Empty | N/A (quiz has questions) |
| Success | All questions answered, "إنهاء الاختبار" → SCR-EDU-07 Results |
| Error | Submit fail → "تعذّر تسليم الاختبار" + retry + save answers locally; fetch fail → cached questions |
| Denied-permission | N/A |
| Locked (child) | N/A (child takes own quizzes) |
| Trial-expired | Core quizzes accessible (P0); adaptive quizzes locked (premium) |

**Data displayed:** Quiz entity (questions, type, timer, scoring), Answer entity (selected, correct, timestamp).

**Actions:** Select answer, navigate questions, flag question for review, submit quiz, exit (confirm), pause (if allowed).

**Navigation:** ← SCR-EDU-03/04 · → SCR-EDU-07 Quiz Results.

**Permissions required:** `INTERNET`.

**Offline behavior:** Downloaded quizzes takeable offline; results cached; sync on reconnect.

**Edge cases:** Timer expires → auto-submit; exit mid-quiz → confirm "ستفقد تقدمك" + save state; all questions not answered → "أجب عن جميع الأسئلة" warning; internet drops during submit → retry with cached answers; quiz retake → new attempt, best score kept.

---

### SCR-EDU-07 — Quiz Results (نتائج الاختبار)

| Field | Value |
|---|---|
| **Screen ID** | SCR-EDU-07 |
| **Name (AR)** | نتائج الاختبار |
| **Name (EN)** | Quiz Results |
| **Roles** | Child (view own), Parent (view child's) |
| **P0 services** | Scoring, answer review, feedback, XP award, retry |
| **Purpose** | Display quiz results with score, correct/incorrect review, and feedback for improvement. |

**Layout:**
- **Header:** back arrow, quiz title, score ring (score / total, Jade if pass, Coral if fail), XP earned badge
- **Body:** summary stats (correct, incorrect, skipped, time taken), question review list — each: question, your answer (green ✓ / red ✗), correct answer, explanation; "إعادة الاختبار" CTA (if retries allowed), "الدرس التالي" CTA
- **Footer/nav:** child bottom nav; SOS FAB
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | Score ring + review shimmer |
| Empty | N/A (results exist) |
| Success | Score, review, XP, navigation all populated |
| Error | Results fetch fail → "تعذّر تحميل النتائج" + retry; XP award fail → "تعذّر منح النقاط" + retry |
| Denied-permission | N/A |
| Locked (child) | N/A |
| Trial-expired | Results accessible (P0); detailed AI feedback locked (premium) |

**Data displayed:** QuizResult entity (score, total, correct/incorrect/skipped, time, XP), AnswerReview entities (question, user answer, correct answer, explanation).

**Actions:** View review, retry quiz, go to next lesson, share result with parent (auto-shared), view progress.

**Navigation:** ← SCR-EDU-06 · → SCR-EDU-03 (retry) / SCR-EDU-04 (next lesson) · → SCR-EDU-15 Level + XP.

**Permissions required:** `INTERNET`.

**Offline behavior:** Cached results viewable; retry requires online if quiz not downloaded.

**Edge cases:** Score exactly pass threshold → "نجحت!" + encouragement; score 0 → "لا تقلق، حاول مرة أخرى" + link to lesson review; perfect score → bonus XP + celebration animation; parent views results → same screen with "عرض الوالد" badge.

---

### SCR-EDU-08 — Points & Badges (النقاط والأوسمة)

| Field | Value |
|---|---|
| **Screen ID** | SCR-EDU-08 |
| **Name (AR)** | النقاط والأوسمة |
| **Name (EN)** | Points & Badges |
| **Roles** | Child (view own), Parent (view child's) |
| **P0 services** | Gamification, XP system, badges, achievements, leaderboards (family) |
| **Purpose** | Motivate learning through points, badges, and achievements. |

**Layout:**
- **Header:** back arrow, "النقاط والأوسمة", total XP large, level badge
- **Body:** tabs — Badges (الأوسمة) | Achievements (الإنجازات) | History (السجل)
  - Badges: grid of earned + locked badges (icon, name, description, earned date)
  - Achievements: list with progress bars (e.g., "أكمل 50 درسًا" — 35/50)
  - History: timeline of XP earned events (lesson completed +50, quiz passed +30, streak bonus +10, etc.)
- **Footer/nav:** child bottom nav; SOS FAB
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | Badge grid + XP shimmer |
| Empty | New learner → "ابدأ التعلم لكسب النقاط والأوسمة" |
| Success | Badges, achievements, history populated |
| Error | Fetch fail → cached + retry |
| Denied-permission | N/A |
| Locked (child) | N/A |
| Trial-expired | Basic gamification accessible (P0); premium badge packs locked |

**Data displayed:** Badge entity (id, name, icon, description, earned-date), Achievement entity (id, name, target, current, reward), XPHistory entity (event, amount, timestamp).

**Actions:** Tap badge for detail, view achievement progress, scroll history, share badge (family).

**Navigation:** ← SCR-EDU-01 · → SCR-EDU-15 Level + XP.

**Permissions required:** `INTERNET`.

**Offline behavior:** Cached badges/XP; new XP events queued.

**Edge cases:** Badge earned while offline → shown on reconnect with delayed celebration; XP sync conflict → server-side reconciliation (highest authoritative); level up → full-screen celebration + parent notification.

---

### SCR-EDU-09 — Focus Mode (وضع التركيز)

| Field | Value |
|---|---|
| **Screen ID** | SCR-EDU-09 |
| **Name (AR)** | وضع التركيز |
| **Name (EN)** | Focus Mode |
| **Roles** | Child (activate), Parent (configure/override) |
| **P0 services** | Distraction blocking, Pomodoro timer, focus analytics, notification suppression |
| **Purpose** | Block distractions and provide a focused study environment with timed sessions. |

**Layout:**
- **Header:** "وضع التركيز" title, timer (large circular, Jade), session counter
- **Body:** session setup — duration selector (Pomodoro 25/5, 50/10, custom), subject selector, goal text field; during session: timer counting down, "وقت التركيز" message, blocked apps count, session progress; break: "استراحة" + countdown; completed: session summary (time focused, distractions blocked)
- **Footer/nav:** hidden during focus (only exit)
- **FAB:** SOS (always present)

**UI States:**
| State | Presentation |
|---|---|
| Loading | Timer init |
| Empty | Pre-session setup |
| Success | Timer running, distractions blocked, focused state |
| Error | Block engine fail → "تعذّر حجب التشتيت" + manual DND fallback; timer fail → manual timer |
| Denied-permission | DND not granted → "فعّل وضع عدم الإزعاج" + instructions; Accessibility not granted → limited blocking |
| Locked (child) | N/A (child controls focus mode) |
| Trial-expired | Basic Pomodoro accessible (P0); advanced analytics + custom schedules locked (premium) |

**Data displayed:** FocusSession entity (duration, subject, goal, distractions-blocked, start, end), FocusConfig entity (Pomodoro settings, blocked apps).

**Actions:** Set duration, set subject, set goal, start, pause, resume, end early, view summary, view focus history.

**Navigation:** ← SCR-EDU-01 · → session summary · → SCR-EDU-15 Level + XP (XP from focus).

**Permissions required:** `ACCESS_NOTIFICATION_POLICY` (DND), `BIND_ACCESSIBILITY_SERVICE` (app blocking), `INTERNET`.

**Offline behavior:** Focus timer works offline; blocking continues locally; analytics cached.

**Edge cases:** SOS during focus → focus pauses, SOS takes priority, focus resumes after; parent calls during focus → call allowed (always-allowed), focus pauses; focus session interrupted by device lock → session paused, can resume; Pomodoro break over + no interaction → auto-start next session with notification.

---

### SCR-EDU-10 — Quran Recitation (تلاوة القرآن)

| Field | Value |
|---|---|
| **Screen ID** | SCR-EDU-10 |
| **Name (AR)** | تلاوة القرآن |
| **Name (EN)** | Quran Recitation Practice |
| **Roles** | Child (practice), Parent (view progress, set targets) |
| **P0 services** | Quran audio, recitation recording, AI analysis (Tajweed), memorization tracking |
| **Purpose** | Practice Quran recitation with AI-powered Tajweed analysis and memorization tracking. |

**Layout:**
- **Header:** back arrow, Surah selector + Ayah range, Hijri date
- **Body:** Ayah display (Arabic text, large, RTL, Uthmani script), play reference recitation button (audio from Qari), record button (hold to recite), waveform during recording; after analysis: Tajweed feedback card — errors highlighted on Ayah text (Coral = error, amber = improvement), pronunciation score, Tajweed rules checked, "أعد المحاولة" / "الآية التالية"
- **Footer/nav:** child bottom nav; SOS FAB
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading (analysis) | "جارٍ تحليل التلاوة…" with audio waveform animation |
| Empty | No recitation recorded → Ayah display + record prompt |
| Success | Tajweed feedback displayed, score shown, errors highlighted |
| Error | Audio too short → see EC-EDU-02; analysis fail → "تعذّر تحليل التلاوة" + retry; reference audio fail → "تعذّر تشغيل التلاوة المرجعية" + retry |
| Denied-permission | Mic denied → "اسمح بالوصول للمايك للتلاوة" + settings link |
| Locked (child) | N/A |
| Trial-expired | Basic recitation + recording accessible (P0); AI Tajweed analysis locked (premium) |

**Data displayed:** Ayah entity (text, surah, number, audio URL), Recitation entity (audio, score, errors, Tajweed rules, timestamp), QuranProgress entity (memorized, reviewed, streak).

**Actions:** Select surah/ayah, play reference, record, stop, view analysis, retry, next ayah, mark as memorized, view progress.

**Navigation:** ← SCR-EDU-01 · → SCR-AI-04 Recitation Analysis · → SCR-EDU-08 Points (badges for Quran).

**Permissions required:** `RECORD_AUDIO`, `INTERNET`.

**Offline behavior:** Reference audio cached for downloaded surahs; recording works offline; analysis deferred until online.

**Edge cases:** Recitation too short → EC-EDU-02; background noise → "بيئة صوتية ضوضاء عالية، قد تتأثر الدقة" warning; wrong ayah recited → AI detects mismatch, "تبدو أنك تلوت آية مختلفة" + option to select correct ayah; accuracy threshold → Open Decision #9.

---

### SCR-EDU-11 — AI Tutor (المعلم الذكي)

| Field | Value |
|---|---|
| **Screen ID** | SCR-EDU-11 |
| **Name (AR)** | المعلم الذكي |
| **Name (EN)** | AI Tutor |
| **Roles** | Child (interact), Parent (monitor + set boundaries) |
| **P0 services** | AI tutoring, Socratic method, curriculum-aware, safety-filtered responses |
| **Purpose** | Provide personalized AI tutoring that helps the child learn through guided questioning rather than direct answers. |

**Layout:**
- **Header:** back arrow, "المعلم الذكي", subject context indicator, session timer
- **Body:** chat interface — AI messages (Violet bubble, left RTL), child messages (white bubble, right), rich content (math formulas rendered, diagrams, code blocks), suggested questions chips, "شرح إضافي" / "مثال آخر" / "اختبرني" quick actions, context card (current subject/lesson)
- **Footer/nav:** chat input bar with text field, voice input button, "مسح المحادثة"
- **FAB:** SOS (always present)

**UI States:**
| State | Presentation |
|---|---|
| Loading (AI response) | Violet typing indicator (animated dots) |
| Empty | New session → "مرحبًا! أنا معلمك الذكي. بماذا تريد أن نبدأ؟" + suggested topics |
| Success | Conversation flowing, responses rendered |
| Error | AI service fail → see EC-EDU-05 offline fallback; response timeout → "استغرق الرد وقتًا طويلاً، حاول مرة أخرى" |
| Denied-permission | Mic denied → voice input disabled, text-only |
| Locked (child) | N/A |
| Trial-expired | AI Tutor is premium → entire screen locked with Violet lock → SCR-ADM-04. Limited preview (3 questions/day) in expired trial. |

**Data displayed:** ChatMessage entities (role, content, timestamp, subject context), TutorSession entity (subject, lesson, start, message count).

**Actions:** Send text, send voice, use quick actions, clear chat, switch subject, view session history, report inappropriate response.

**Navigation:** ← SCR-EDU-01 · → SCR-AI-02 Private Tutor (advanced) · → SCR-ADM-04 Paywall.

**Permissions required:** `RECORD_AUDIO` (voice), `INTERNET`.

**Offline behavior:** Offline fallback → see EC-EDU-05 and Open Decision #10; cached Q&A for common questions; "المعلم الذكي يتطلب اتصالاً" for new questions.

**Edge cases:** Child asks for direct answer → Socratic redirect "دعنا نفكر معًا، ما الخطوة الأولى؟"; inappropriate question → safety filter, "هذا خارج نطاق الدروس، هل لديك سؤال دراسي؟"; AI gives wrong answer → child can "تبليغ" + parent review; session too long → "لنأخذ استراحة" after 45 min; Gemini cost concern → Open Decision #4.

---

### SCR-EDU-12 — Placement Test (اختبار التحديد)

| Field | Value |
|---|---|
| **Screen ID** | SCR-EDU-12 |
| **Name (AR)** | اختبار التحديد |
| **Name (EN)** | Placement Test |
| **Roles** | Child (take), Parent (view results + override) |
| **P0 services** | Adaptive placement, multi-subject assessment, level assignment |
| **Purpose** | Assess the child's current knowledge level across subjects to place them at the correct starting point. |

**Layout:**
- **Header:** back arrow (with confirm), "اختبار التحديد", subject selector (or all subjects), progress bar
- **Body:** question card (adaptive — difficulty adjusts based on answers), question counter, timer (if configured), "لا أعرف" option (skips without penalty); after completion: results summary — subject-level placement (grade level assigned per subject), recommended starting lesson
- **Footer/nav:** hidden (immersive)
- **FAB:** SOS

**UI States:**
| State | Presentation |
|---|---|
| Loading | Question fetch + adaptive engine calculation |
| Empty | Pre-test → subject selection + "ابدأ الاختبار" CTA |
| Success | Test completed, results shown, level assigned |
| Error | Engine fail → "تعذّر تحديد المستوى" + retry; incomplete → see EC-EDU-04 |
| Denied-permission | N/A |
| Locked (child) | N/A |
| Trial-expired | Placement test accessible (P0 — required for onboarding) |

**Data displayed:** PlacementTest entity (subjects, questions, answers, results, level per subject), adaptive question chain.

**Actions:** Select answer, "I don't know", navigate, submit, view results, retake (parent permission).

**Navigation:** ← SCR-EDU-01 (if required) · → SCR-EDU-13 Adaptive Path (on completion) · → SCR-ADM-01 (parent review).

**Permissions required:** `INTERNET`.

**Offline behavior:** Cannot take placement offline (requires adaptive engine); cached results viewable.

**Edge cases:** Test interrupted → see EC-EDU-04 (resume within 24 h); inconsistent answers (random pattern) → flag for parent review "قد يحتاج الطفل لإعادة الاختبار"; child places below expected grade → parent notification with recommendation; parent disagrees with placement → manual override available.

---

### SCR-EDU-13 — Adaptive Path (المسار التكيفي)

| Field | Value |
|---|---|
| **Screen ID** | SCR-EDU-13 |
| **Name (AR)** | المسار التكيفي |
| **Name (EN)** | Adaptive Learning Path |
| **Roles** | Child (follow), Parent (view + adjust) |
| **P0 services** | Adaptive learning engine, path generation, difficulty adjustment, remediation |
| **Purpose** | Display and follow the personalized learning path generated from placement test and ongoing performance. |

**Layout:**
- **Header:** back arrow, "مسارك التعليمي", overall progress
- **Body:** path visualization — vertical timeline / roadmap with milestones (subjects branching), completed nodes (Jade ✓), current node (pulsing Jade), upcoming nodes (gray), prerequisite connections; current focus card (what to study next, why, estimated time); "لماذا هذا الدرس؟" explanation link
- **Footer/nav:** child bottom nav; SOS FAB
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | Path nodes shimmer |
| Empty | No placement → "أكمل اختبار التحديد لإنشاء مسارك" → SCR-EDU-12 |
| Success | Path rendered, current focus highlighted |
| Error | Path generation fail → "تعذّر إنشاء المسار" + fallback to sequential; level corruption → see EC-EDU-03 |
| Denied-permission | N/A |
| Locked (child) | N/A |
| Trial-expired | Adaptive path is premium → sequential path only (P0 basic); adaptive features locked → SCR-ADM-04 |

**Data displayed:** AdaptivePath entity (nodes, connections, current position, difficulty), LearnerProfile (level, performance history).

**Actions:** View path, tap node → SCR-EDU-04, view explanation, parent: adjust path (override), reset path.

**Navigation:** ← SCR-EDU-01 · → SCR-EDU-04 (lesson) · → SCR-ADM-01 (parent view).

**Permissions required:** `INTERNET`.

**Offline behavior:** Cached path viewable; path updates deferred until online.

**Edge cases:** Child consistently fails lessons → path auto-adjusts (remedial branch); child accelerates → path compresses (skip redundant lessons); parent override → custom path with "مسار مخصص من قبل والدك" label; multiple subjects → branching path, child chooses order.

---

### SCR-EDU-14 — Adaptive Exercise (تمرين تكيفي)

| Field | Value |
|---|---|
| **Screen ID** | SCR-EDU-14 |
| **Name (AR)** | تمرين تكيفي |
| **Name (EN)** | Adaptive Exercise |
| **Roles** | Child (practice), Parent (view) |
| **P0 services** | Adaptive question generation, real-time difficulty, performance analytics |
| **Purpose** | Provide practice exercises that adapt in real-time to the child's performance. |

**Layout:**
- **Header:** back arrow (with confirm), subject + topic, difficulty indicator (stars), streak counter
- **Body:** question card (generated by AI based on performance), answer input (type/select/draw), immediate feedback (correct = Jade ✓ + explanation, incorrect = Coral ✗ + correct answer + explanation), "التالي" auto-loads next question at adjusted difficulty
- **Footer/nav:** hidden (immersive)
- **FAB:** SOS

**UI States:**
| State | Presentation |
|---|---|
| Loading (next question) | Card shimmer + "جارٍ تجهيز السؤال التالي…" |
| Empty | N/A (exercises generated on demand) |
| Success | Questions flowing, feedback immediate, difficulty adjusting |
| Error | Generation fail → "تعذّر إنشاء السؤال" + retry + fallback to cached exercises; AI service fail → offline cached question bank |
| Denied-permission | N/A |
| Locked (child) | N/A |
| Trial-expired | Adaptive exercises are premium → static exercise set only (P0 basic); adaptive locked → SCR-ADM-04 |

**Data displayed:** Exercise entity (question, answer, explanation, difficulty, topic), PerformanceMetric (accuracy, speed, streak, difficulty trend).

**Actions:** Answer, view explanation, next, end session, view performance summary.

**Navigation:** ← SCR-EDU-01/04/13 · → performance summary · → SCR-EDU-15 Level + XP.

**Permissions required:** `INTERNET`.

**Offline behavior:** Cached question bank (non-adaptive); adaptive requires online; performance cached.

**Edge cases:** Child answers too fast (guessing) → AI increases difficulty or adds "أكد إجابتك" confirmation; child stuck (5 wrong in a row) → "لنراجع الدرس" redirect to SCR-EDU-04; exercise topic exhausted → "أحسنت! أكملت جميع تمارين هذا الموضوع" + next topic suggestion; AI generates inappropriate question → safety filter + fallback.

---

### SCR-EDU-15 — Level & XP (المستوى والنقاط)

| Field | Value |
|---|---|
| **Screen ID** | SCR-EDU-15 |
| **Name (AR)** | المستوى والنقاط |
| **Name (EN)** | Level & XP Dashboard |
| **Roles** | Child (view own), Parent (view child's) |
| **P0 services** | Leveling system, XP tracking, rank, family leaderboard |
| **Purpose** | Show the child's learning level, XP, rank, and progress toward the next level. |

**Layout:**
- **Header:** back arrow, "المستوى والنقاط", current level badge (large, tiered: Bronze/Silver/Gold/Platinum), rank title
- **Body:** XP progress bar (current XP / next level XP), level history timeline, XP breakdown by source (lessons, quizzes, assignments, Quran, focus, streaks), family leaderboard (if multiple children — ranked by XP this week), next level rewards preview, "كيف أكسب النقاط؟" info sheet
- **Footer/nav:** child bottom nav; SOS FAB
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | Level badge + XP bar shimmer |
| Empty | New learner (level 1, 0 XP) → "ابدأ رحلتك لكسب النقاط" |
| Success | Level, XP, history, leaderboard populated |
| Error | Fetch fail → cached + retry; XP sync conflict → server reconciliation |
| Denied-permission | N/A |
| Locked (child) | N/A |
| Trial-expired | Basic level/XP accessible (P0); premium rank cosmetics locked |

**Data displayed:** LearnerProfile entity (level, XP, rank, tier), XPHistory entity, Leaderboard entity (family ranking).

**Actions:** View XP history, view leaderboard, view next level, view rewards, share level badge.

**Navigation:** ← SCR-EDU-01 / SCR-EDU-08 · → SCR-EDU-08 Badges.

**Permissions required:** `INTERNET`.

**Offline behavior:** Cached level/XP; leaderboard cached; XP events queued.

**Edge cases:** Level up → full-screen celebration + parent notification + possible badge; only child in family → leaderboard shows just them with "استمر!" encouragement; XP inflation (too fast) → anti-cheat validation; parent adjusts XP → audit logged.

## 5. AI Screens (SCR-AI)

### SCR-AI-01 — AI Assistant (المساعد الذكي)

| Field | Value |
|---|---|
| **Screen ID** | SCR-AI-01 |
| **Name (AR)** | المساعد الذكي |
| **Name (EN)** | AI Assistant (Family) |
| **Roles** | Father, Mother (family management assistance) |
| **P0 services** | Family-aware AI assistant, schedule help, summary generation, recommendation engine |
| **Purpose** | Provide parents with an AI assistant that understands family context and helps with scheduling, summaries, and recommendations. |

**Layout:**
- **Header:** back arrow, "المساعد الذكي" (Violet accent), context indicator (family-aware), session timer
- **Body:** chat interface — AI messages (Violet bubble, left RTL), user messages (white bubble, right), rich content (cards, lists, schedule previews, quick-action buttons inline), suggested prompts chips ("لخص اليوم", "اقترح وقتًا لنزهة", "كيف أداء طفلي؟"), context chips showing what AI knows (family members, schedule)
- **Footer/nav:** chat input bar, voice input, "مسح"
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading (AI response) | Violet typing indicator |
| Empty | "كيف أساعدك اليوم؟" + suggested prompts |
| Success | Conversation flowing with rich content |
| Error | AI service fail → "المساعد غير متاح حاليًا" + retry; timeout → retry |
| Denied-permission | Mic denied → voice disabled, text-only |
| Locked (child) | Child cannot access this screen (parent-only) |
| Trial-expired | AI Assistant is premium → locked with Violet lock → SCR-ADM-04. Limited preview (5 queries/day) in expired trial. |

**Data displayed:** ChatMessage entities, FamilyContext (members, schedule, tasks, alerts), AIResponse with citations.

**Actions:** Send text/voice, use suggested prompts, clear chat, take action from inline cards (e.g., "أضف للتقويم"), view session history.

**Navigation:** ← Today Dashboard · → SCR-AI-03 Recommendations · → SCR-ADM-04 Paywall.

**Permissions required:** `RECORD_AUDIO` (voice), `INTERNET`.

**Offline behavior:** Offline fallback → Open Decision #10; cached responses for common queries; "المساعد يتطلب اتصالاً" for new queries.

**Edge cases:** AI suggests action parent doesn't have permission for → "هذا يتطلب صلاحيات الأب" if mother; AI accesses child data → privacy boundary, only aggregated/anonymized for AI context; AI hallucinates schedule → parent can correct, "هذا غير صحيح، الصحيح هو…" feedback; Gemini cost → Open Decision #4.

---

### SCR-AI-02 — Private Tutor (المعلم الخاص)

| Field | Value |
|---|---|
| **Screen ID** | SCR-AI-02 |
| **Name (AR)** | المعلم الخاص |
| **Name (EN)** | AI Private Tutor |
| **Roles** | Child (interact), Parent (configure + monitor) |
| **P0 services** | Personalized AI tutoring, curriculum integration, Socratic method, progress reporting |
| **Purpose** | Provide the child with a dedicated AI tutor that adapts to their learning style and curriculum. |

**Layout:**
- **Header:** back arrow, "المعلم الخاص" (Violet), subject + lesson context, tutor avatar (customizable), session timer
- **Body:** chat interface with enhanced learning features — AI messages (Violet, with rich content: formulas, diagrams, step-by-step), child messages, "اشرح بطريقة أخرى" / "أعطني تمرينًا" / "تحقق من إجابتي" quick actions, whiteboard mode (drawing canvas for math), progress indicator (concepts mastered this session), parent-configured boundaries indicator
- **Footer/nav:** chat input, voice, whiteboard toggle, "إنهاء الجلسة"
- **FAB:** SOS

**UI States:**
| State | Presentation |
|---|---|
| Loading (AI response) | Violet typing + "أفكر في أفضل طريقة لشرح هذا…" |
| Empty | New session → "مرحبًا [name]! أنا معلمك الخاص. ماذا تريد أن نتعلم اليوم؟" + subject picker |
| Success | Interactive tutoring session flowing |
| Error | AI fail → "المعلم غير متاح" + retry + offline cached lessons fallback; timeout → retry |
| Denied-permission | Mic denied → voice disabled |
| Locked (child) | N/A (child's screen) |
| Trial-expired | Private Tutor is premium → locked → SCR-ADM-04. No free preview (unlike general AI Tutor which has 3/day). |

**Data displayed:** TutorSession entity (subject, lesson, concepts, start, duration, messages), LearnerProfile (style, preferences, boundaries), ChatMessage entities.

**Actions:** Send text/voice, use whiteboard, quick actions, switch subject, end session, view session summary, report issue.

**Navigation:** ← SCR-EDU-11 · → SCR-EDU-14 (exercise from tutor) · → SCR-ADM-04 Paywall.

**Permissions required:** `RECORD_AUDIO`, `INTERNET`, touch screen (whiteboard).

**Offline behavior:** Offline cached tutorial content; AI interaction requires online; Open Decision #10.

**Edge cases:** Child asks non-educational question → "هذا خارج الدرس، هل لديك سؤال دراسي؟"; child frustrated → adaptive tone shift "لا بأس، لنأخذها خطوة بخطوة"; parent boundaries (e.g., "no answers after 9 PM") → enforced, "حان وقت الراحة، نكمل غدًا"; session summary auto-shared with parent; AI gives incorrect info → "تبليغ" + parent review.

---

### SCR-AI-03 — AI Recommendations (توصيات الذكاء الاصطناعي)

| Field | Value |
|---|---|
| **Screen ID** | SCR-AI-03 |
| **Name (AR)** | توصيات الذكاء الاصطناعي |
| **Name (EN)** | AI Recommendations |
| **Roles** | Father, Mother |
| **P0 services** | Family analytics, recommendation engine, actionable suggestions |
| **Purpose** | Surface AI-generated recommendations for family scheduling, child learning, and safety. |

**Layout:**
- **Header:** back arrow, "توصيات الذكاء الاصطناعي" (Violet), last-generated timestamp, refresh
- **Body:** recommendation cards organized by category:
  - **Schedule:** "اقترح وقتًا لنزهة عائلية يوم الجمعة" (with calendar preview + add button)
  - **Learning:** "طفلك يواجه صعوبة في الجبر، اقترح مراجعة درس X" (with lesson link)
  - **Safety:** "طفلك يستخدم الهاتف لساعات متأخرة، اقترح تعديل جدول وقت الشاشة" (with settings link)
  - **Health:** "طفلك لم يأخذ استراحة كافية، اقترح وقت راحة"
  - Each card: icon, title, rationale, action button, dismiss, "لماذا هذا الاقتراح؟" explainable AI link
- **Footer/nav:** bottom nav (parent)
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | 4 shimmer recommendation cards |
| Empty | "لا توجد توصيات حاليًا" + "تحقق لاحقًا" |
| Success | Cards populated with actionable recommendations |
| Error | AI engine fail → "تعذّر توليد التوصيات" + cached + retry; partial fail → show available categories |
| Denied-permission | N/A |
| Locked (child) | N/A (parent screen) |
| Trial-expired | AI recommendations are premium → locked → SCR-ADM-04 |

**Data displayed:** Recommendation entity (category, title, rationale, action, confidence, timestamp), FamilyContext, LearnerProfile.

**Actions:** Accept (take action), dismiss, view explanation, refresh, filter by category, mark as helpful/not helpful (feedback loop).

**Navigation:** ← SCR-AI-01 / Today Dashboard · → action targets (Calendar, Screen Time, Lessons, etc.) · → SCR-ADM-04 Paywall.

**Permissions required:** `INTERNET`.

**Offline behavior:** Cached recommendations viewable; new generation requires online.

**Edge cases:** Recommendation references stale data → "هذه التوصية تعتمد على بيانات قديمة، حدّث للمزامنة"; parent dismisses all → "شكرًا، سنولّد توصيات جديدة لاحقًا"; recommendation for mother-exclusive feature she can't access → "هذه الميزة متاحة للأب" note; AI suggests contradictory recommendation → flagged with "مراجعة يدوية" tag.

---

### SCR-AI-04 — Recitation Analysis (تحليل التلاوة)

| Field | Value |
|---|---|
| **Screen ID** | SCR-AI-04 |
| **Name (AR)** | تحليل التلاوة |
| **Name (EN)** | Quran Recitation Analysis |
| **Roles** | Child (view own), Parent (view child's) |
| **P0 services** | Audio analysis, Tajweed rule detection, pronunciation scoring, feedback generation |
| **Purpose** | Display detailed AI analysis of the child's Quran recitation with Tajweed feedback. |

**Layout:**
- **Header:** back arrow, surah + ayah, recitation date (Hijri), overall score ring
- **Body:** analysis sections:
  - **Pronunciation score:** overall + per-letter breakdown
  - **Tajweed rules:** checklist (Noon Sakinah, Meem Sakinah, Madd, Ghunnah, Qalqalah, etc.) — each: pass/improvement/error with audio snippet
  - **Ayah annotation:** Arabic text with color-coded errors (Coral = mispronunciation, amber = improvement needed, Jade = correct)
  - **Audio comparison:** side-by-side playback of child's recitation vs. reference Qari
  - **Progress over time:** trend chart of recitation scores
- **Footer/nav:** child bottom nav; SOS FAB
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | Score ring + analysis sections shimmer |
| Empty | No recitation to analyze → "سجّل تلاوتك للتحليل" → SCR-EDU-10 |
| Success | Full analysis displayed, audio playable |
| Error | Audio too short → EC-EDU-02; analysis fail → "تعذّر التحليل" + retry; audio corrupt → "ملف صوتي تالف، أعد التسجيل" |
| Denied-permission | N/A (analysis of existing recording) |
| Locked (child) | N/A |
| Trial-expired | Recitation analysis is premium → basic score only (P0: pass/fail); detailed Tajweed locked → SCR-ADM-04 |

**Data displayed:** RecitationAnalysis entity (score, per-letter, Tajweed rules, annotations, audio URLs, comparison), RecitationHistory trend.

**Actions:** Play child audio, play reference, view per-rule, view annotated ayah, retry recitation, view progress, share with parent (auto).

**Navigation:** ← SCR-EDU-10 · → SCR-EDU-10 (retry) · → SCR-EDU-08 (badges) · → SCR-ADM-04 Paywall.

**Permissions required:** `INTERNET`, audio playback.

**Offline behavior:** Cached analysis viewable; audio cached for downloaded surahs; new analysis requires online.

**Edge cases:** Accuracy threshold → Open Decision #9; recitation of wrong ayah → "تبدو آية مختلفة" + correct ayah suggestion; very short audio → EC-EDU-02; noisy background → "جودة صوت منخفضة" warning; perfect recitation → bonus XP + celebration; dialectal variation in recitation → AI handles Hafs reading primarily, other qira'at flagged.

---

### SCR-AI-05 — Smart Edu Recommendations (توصيات تعليمية ذكية)

| Field | Value |
|---|---|
| **Screen ID** | SCR-AI-05 |
| **Name (AR)** | توصيات تعليمية ذكية |
| **Name (EN)** | Smart Education Recommendations |
| **Roles** | Child (view + act), Parent (view + configure) |
| **P0 services** | Learning analytics, personalized content recommendation, curriculum optimization |
| **Purpose** | Provide AI-driven educational recommendations tailored to the child's performance and learning style. |

**Layout:**
- **Header:** back arrow, "توصيات تعليمية" (Violet), child selector (parent view)
- **Body:** recommendation cards:
  - **Next lesson:** "درسك التالي: الكسور في الرياضيات" (with difficulty, estimated time, start button)
  - **Review needed:** "يوصى بمراجعة: الجمع والطرح" (based on quiz performance, with link)
  - **Challenge:** "تحدي الأسبوع: مسألة منطقية" (bonus XP, optional)
  - **Quran practice:** "حفظ اليوم: آية الكرسي" (with start button)
  - **Learning style insight:** "يتعلم طفلك أفضل بالطرق البصرية" (parent-facing)
  - Each card: rationale ("بناءً على أدائك في اختبار الجمع"), action button, dismiss
- **Footer/nav:** child bottom nav; SOS FAB
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | 5 shimmer cards |
| Empty | No data yet → "أكمل بعض الدروس للحصول على توصيات مخصصة" |
| Success | Cards populated with personalized recommendations |
| Error | AI engine fail → "تعذّر توليد التوصيات" + cached + retry |
| Denied-permission | N/A |
| Locked (child) | N/A (child's screen) |
| Trial-expired | Smart recommendations are premium → static "next lesson" only (P0 basic); AI-driven locked → SCR-ADM-04 |

**Data displayed:** EduRecommendation entity (type, content, rationale, action, priority), LearnerProfile (performance, style, history).

**Actions:** Accept (start lesson/review/challenge), dismiss, view rationale, "عرض الكل" (see more), mark helpful.

**Navigation:** ← SCR-EDU-01 · → SCR-EDU-04 (lesson) · → SCR-EDU-14 (exercise) · → SCR-EDU-10 (Quran) · → SCR-ADM-04 Paywall.

**Permissions required:** `INTERNET`.

**Offline behavior:** Cached recommendations; new generation requires online.

**Edge cases:** Child dismisses all → "سنعاود生成 التوصيات لاحقًا"; recommendation below current level (remedial) → could demotivate, AI adds encouragement; conflicting recommendations (review vs. new) → priority system (review first if failing); parent views → same cards + learning style insight + configuration options.

## 6. Administration Screens (SCR-ADM)

### SCR-ADM-01 — Admin Hub (مركز الإدارة)

| Field | Value |
|---|---|
| **Screen ID** | SCR-ADM-01 |
| **Name (AR)** | مركز الإدارة |
| **Name (EN)** | Admin Hub |
| **Roles** | Father (all), Mother (subset — no Members, Devices, Child Privacy unless granted) |
| **P0 services** | Family administration dashboard, settings navigation, premium status |
| **Purpose** | Central admin screen for family configuration, member management, and system settings. |

**Layout:**
- **Header:** "الإدارة" title, family name, premium status badge (Trial/Active/Expired)
- **Body:** admin sections grid — Members (→ SCR-ADM-02), Devices & Permissions (→ SCR-ADM-03), Premium & Paywall (→ SCR-ADM-04), Notifications (→ SCR-ADM-05), Settings (→ SCR-ADM-06), Child Privacy (→ SCR-ADM-07), Export & Delete (→ SCR-ADM-08), School Schedule (→ SCR-ADM-10), Trial Status (→ SCR-ADM-11); each section: icon, title, brief status text, arrow
- **Footer/nav:** bottom nav (parent) — Home, Chat, Calendar, Tasks, Settings (active)
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | Section grid shimmer |
| Empty | N/A (always has sections) |
| Success | All sections visible, statuses current |
| Error | Fetch fail → cached + retry; premium status unknown → "تعذّر التحقق من الاشتراك" |
| Denied-permission | Mother accessing exclusive section → "متاح للأب فقط" + request access |
| Locked (child) | N/A (parent screen) |
| Trial-expired | Admin hub accessible; premium-gated sub-features show lock on their section icons |

**Data displayed:** Family entity (name, plan, member count, device count), PremiumStatus, section statuses.

**Actions:** Tap any section → respective screen, view premium status.

**Navigation:** → SCR-ADM-02 through SCR-ADM-11 · ← bottom nav (Settings tab).

**Permissions required:** `INTERNET`.

**Offline behavior:** Cached admin data; changes queued.

**Edge cases:** Family has 1 member (creator only) → Members shows "أضف أفراد العائلة"; all devices offline → Devices shows "جميع الأجهزة غير متصلة"; premium expired → banner on hub "انتهت التجربة، اشترك للمتابعة" → SCR-ADM-04.

---

### SCR-ADM-02 — Members (الأعضاء)

| Field | Value |
|---|---|
| **Screen ID** | SCR-ADM-02 |
| **Name (AR)** | الأعضاء |
| **Name (EN)** | Family Members |
| **Roles** | Father only (exclusive — one of the 8); Mother only if mother_permissions grants |
| **P0 services** | Member CRUD, role assignment, invitation, removal |
| **Purpose** | Manage family members: add, edit roles, remove, and view member details. |

**Layout:**
- **Header:** back arrow, "الأعضاء", "+ دعوة عضو"
- **Body:** member list — each: avatar, name, role badge (Father/Mother/Child), phone, device count, status (active/inactive), joined date (Hijri); tap → member detail (edit role, change permissions for mother, remove, transfer ownership); invite section: QR code, invite link, phone invite
- **Footer/nav:** bottom nav
- **FAB:** "+ دعوة" (invite new member)

**UI States:**
| State | Presentation |
|---|---|
| Loading | Member list shimmer |
| Empty | Only creator → "أضف أفراد عائلتك" + invite CTA |
| Success | Members listed with roles and status |
| Error | Fetch fail → cached + retry; remove fail → "تعذّر إزالة العضو" + retry; role change fail → retry |
| Denied-permission | Mother without grant → "متاح للأب فقط" |
| Locked (child) | N/A (parent screen) |
| Trial-expired | Accessible (P0 admin) |

**Data displayed:** User entities (name, role, phone, avatar, status, joined), Device count per member, Invitation entity.

**Actions:** Invite (QR/link/phone), edit member, change role, configure mother permissions, remove member, transfer ownership (Father → another Father), view member activity.

**Navigation:** ← SCR-ADM-01 · → SCR-ADM-03 (member's devices) · → SCR-ADM-07 (child privacy for child member).

**Permissions required:** `INTERNET`, `READ_CONTACTS` (optional, for invite).

**Offline behavior:** Cached member list; invites queued; role changes queued.

**Edge cases:** Remove last Father → blocked "يجب أن يبقى أب واحد على الأقل"; remove member with active SOS → blocked "لا يمكن الإزالة أثناء طوارئ"; transfer ownership → confirmation hold 3 s; role change Father→Mother → warning "سي فقد صلاحيات الإدارة الكاملة"; member in another family → transfer request flow.

---

### SCR-ADM-03 — Devices & Permissions (الأجهزة والصلاحيات)

| Field | Value |
|---|---|
| **Screen ID** | SCR-ADM-03 |
| **Name (AR)** | الأجهزة والصلاحيات |
| **Name (EN)** | Devices & Permissions |
| **Roles** | Father only (exclusive); Mother only if mother_permissions grants |
| **P0 services** | Device enrollment, linking, permission management, device health |
| **Purpose** | Manage all family devices: enrollment, permissions, status, and unlinking. |

**Layout:**
- **Header:** back arrow, "الأجهزة والصلاحيات", "+ ربط جهاز"
- **Body:** device list grouped by member — each device: name, model, OS, status (online/offline, last-seen), battery, permissions status (green = all granted, amber = partial, red = missing critical), "عرض الصلاحيات" → permission detail; enrollment section: QR code for device enrollment, enrollment instructions
- **Footer/nav:** bottom nav
- **FAB:** "+ ربط جهاز" (enroll new device)

**UI States:**
| State | Presentation |
|---|---|
| Loading | Device list shimmer |
| Empty | No devices linked → "اربط أول جهاز" + enrollment CTA |
| Success | Devices listed with status and permissions |
| Error | Fetch fail → cached + retry; unbind fail → "تعذّر فك الارتباط" + retry |
| Denied-permission | Mother without grant → "متاح للأب فقط" |
| Locked (child) | N/A (parent screen) |
| Trial-expired | Accessible (P0 admin) |

**Data displayed:** Device entities (name, model, OS, status, battery, last-seen), PermissionState per device, Enrollment entity.

**Actions:** Enroll device (QR), view permissions, grant/revoke permissions (on child device via remote command), unlink device, rename device, view device health.

**Navigation:** ← SCR-ADM-01 / SCR-ADM-02 · → permission detail sheet.

**Permissions required:** Parent: `INTERNET`. Child device: all monitoring permissions managed here.

**Offline behavior:** Cached device list; permission commands queued; enrollment requires online.

**Edge cases:** Unlink last parent device → blocked "يجب أن يبقى جهاز أحد الوالدين"; child device unlinked → see EC-DEV-01; permission revoked on child device → Anti-bypass alert (SCR-PAR-12); device enrollment without phone number → Open Decision #5; multi-device per child → Open Decision #11.

---

### SCR-ADM-04 — Premium & Paywall (الاشتراك والدفع)

| Field | Value |
|---|---|
| **Screen ID** | SCR-ADM-04 |
| **Name (AR)** | الاشتراك والدفع |
| **Name (EN)** | Premium & Paywall |
| **Roles** | Father (purchase/manage), Mother (view only) |
| **P0 services** | Subscription management, billing, paywall, trial management |
| **Purpose** | Display premium plans, manage subscription, and gate premium features behind a paywall. |

**Layout:**
- **Header:** back arrow, "الاشتراك"
- **Body:** current plan card (Trial: days remaining countdown / Active: next billing date / Expired: "انتهت التجربة"), plan comparison table (Free vs. Premium: features list with ✓/✗), pricing cards (Monthly / Annual — savings highlighted), payment methods (Google Play Billing, direct), "اشترك الآن" CTA (Jade), "إلغاء الاشتراك" link, "استعادة الشراء" link, premium feature showcase carousel
- **Footer/nav:** bottom nav
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | Plan/pricing shimmer |
| Empty | N/A (always has plans) |
| Success | Plans displayed, current status clear |
| Error | Billing fail → EC-ACC-03; purchase fail → "فشل الشراء، حاول مرة أخرى" + retry; restore fail → "لم يتم العثور على اشتراك" |
| Denied-permission | N/A |
| Locked (child) | N/A (parent screen) |
| Trial-expired | This IS the trial-expired destination — all premium-gated screens route here; expired state shows "تجربتك انتهت" + plans + "اشترك للاستمرار" |

**Data displayed:** Subscription entity (plan, status, trial-end, billing-date, price), Plan entities (features, pricing), PaymentHistory.

**Actions:** View plans, subscribe, cancel subscription, restore purchase, change plan, update payment, view billing history.

**Navigation:** ← any premium-gated screen · ← SCR-ADM-01 · → payment flow (Google Play).

**Permissions required:** `INTERNET`, Google Play Billing (billing library).

**Offline behavior:** Cached plan info; purchase requires online; subscription status cached with grace period.

**Edge cases:** Payment failed → EC-ACC-03; subscription lapsed with grace period → features continue during grace, then lock; price change → grandfathered old price until renewal; currency localization (SAR, AED, EGP, etc.); annual plan refund → prorated per store policy.

---

### SCR-ADM-05 — Notifications (الإشعارات)

| Field | Value |
|---|---|
| **Screen ID** | SCR-ADM-05 |
| **Name (AR)** | الإشعارات |
| **Name (EN)** | Notification Settings |
| **Roles** | Father, Mother (own + family), Child (own, limited) |
| **P0 services** | Notification channels, priorities, quiet hours, per-feature config |
| **Purpose** | Configure notification preferences across all app features and channels. |

**Layout:**
- **Header:** back arrow, "الإشعارات", master toggle
- **Body:** notification channels — Messages, Calendar, Tasks, SOS (always on, can't disable), Monitoring alerts, Content alerts, School Time, Education reminders, AI recommendations, System; each: toggle, sound selector, vibration pattern, priority (Critical/High/Normal/Low), quiet hours section (start/end, days, exceptions for SOS), per-child filter (parent)
- **Footer/nav:** bottom nav
- **FAB:** none (child: SOS FAB)

**UI States:**
| State | Presentation |
|---|---|
| Loading | Channel list shimmer |
| Empty | N/A (defaults exist) |
| Success | All toggles reflect saved state |
| Error | Save fail → "فشل الحفظ" + retry |
| Denied-permission | `POST_NOTIFICATIONS` denied (Android 13+) → "فعّل الإشعارات لتصبح التنبيهات" + settings link |
| Locked (child) | Child sees: own notifications (messages, education, SOS); cannot disable SOS; cannot see/modify monitoring alerts |
| Trial-expired | Basic notifications accessible (P0); AI recommendation notifications locked |

**Data displayed:** NotificationPreference entity (channel, enabled, sound, vibration, priority, quiet hours).

**Actions:** Toggle channels, select sound, set vibration, set priority, configure quiet hours, test notification, per-child filter.

**Navigation:** ← SCR-ADM-01 / SCR-ADM-06 · → Android notification settings (external).

**Permissions required:** `POST_NOTIFICATIONS` (Android 13+), `VIBRATE`.

**Offline behavior:** All local; synced when online.

**Edge cases:** SOS notifications always bypass quiet hours and DND — cannot be disabled; quiet hours overlap with SOS → SOS overrides; notification channel deleted by user in Android settings → re-create on next app open with "تمت إعادة تفعيل قناة الإشعارات" notification; multiple children → per-child toggle for monitoring alerts.

---

### SCR-ADM-06 — Settings, Language & Privacy (الإعدادات واللغة والخصوصية)

| Field | Value |
|---|---|
| **Screen ID** | SCR-ADM-06 |
| **Name (AR)** | الإعدادات واللغة والخصوصية |
| **Name (EN)** | Settings, Language & Privacy |
| **Roles** | Father (all), Mother (subset), Child (own preferences) |
| **P0 services** | App settings, localization, privacy controls, data preferences |
| **Purpose** | Central settings screen for app configuration, language, privacy, and data management. |

**Layout:**
- **Header:** back arrow, "الإعدادات"
- **Body:** settings sections:
  - **General:** Language (→ SCR-SHR-06), Theme (light/dark/system), Calendar type
  - **Privacy:** Data collection toggle, analytics opt-in, crash reports opt-in, ad personalization (if applicable)
  - **Security:** App lock (biometric/PIN), auto-lock timer, screenshot prevention
  - **Data:** Sync settings, cache management, export data (→ SCR-ADM-08)
  - **About:** Version, build, licenses, terms, privacy policy, support
  - **Account:** Profile (→ SCR-SHR-05), logout
- **Footer/nav:** bottom nav
- **FAB:** none (child: SOS FAB)

**UI States:**
| State | Presentation |
|---|---|
| Loading | Settings sections shimmer |
| Empty | N/A (defaults exist) |
| Success | All settings reflect saved state |
| Error | Save fail → "فشل الحفظ" + retry; sync fail → "تعذّر المزامنة" |
| Denied-permission | Biometric not enrolled → PIN fallback for app lock |
| Locked (child) | Child sees: General (language, theme), About; privacy/data/security limited or hidden |
| Trial-expired | Settings accessible (not premium) |

**Data displayed:** AppSettings entity (theme, language, calendar, sync, cache, privacy toggles, security config).

**Actions:** Change language, change theme, toggle privacy settings, set app lock, manage cache, export data, view about, logout.

**Navigation:** ← SCR-ADM-01 · → SCR-SHR-05 Profile · → SCR-SHR-06 Language · → SCR-ADM-08 Export/Delete.

**Permissions required:** `USE_BIOMETRIC` (app lock), `INTERNET` (sync).

**Offline behavior:** All settings local; sync deferred.

**Edge cases:** Theme set to system → follows Android dark/light; app lock with biometric unavailable → PIN-only; privacy policy update → re-consent flow; analytics opt-out → stops all telemetry immediately; cache clear while sync in progress → "تعذّر المسح، المزامنة قيد التشغيل".

---

### SCR-ADM-07 — Child Privacy (خصوصية الطفل)

| Field | Value |
|---|---|
| **Screen ID** | SCR-ADM-07 |
| **Name (AR)** | خصوصية الطفل |
| **Name (EN)** | Child Privacy Controls |
| **Roles** | Father only (exclusive); Mother only if mother_permissions grants |
| **P0 services** | Child data visibility, monitoring scope, privacy boundaries, age-based rules |
| **Purpose** | Configure what child data is visible to parents and set privacy boundaries appropriate to the child's age. |

**Layout:**
- **Header:** back arrow, "خصوصية الطفل", child selector
- **Body:** privacy control sections:
  - **Message visibility:** full content / metadata only / none
  - **Location granularity:** exact / approximate (city-level) / none
  - **Browsing history:** full / domains only / none
  - **Content alerts scope:** all messages / suspicious only / none
  - **Age-based presets:** Under 10 (maximum monitoring) / 10-13 (balanced) / 14-17 (privacy-focused)
  - **Child's visible data:** what the child can see about themselves
  - **Consent log:** privacy changes with timestamps (for compliance)
- **Footer/nav:** bottom nav
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | Privacy sections shimmer |
| Empty | No child selected → "اختر طفلاً" |
| Success | All privacy settings displayed with current values |
| Error | Save fail → "فشل حفظ الإعدادات" + retry; consent log fail → retry |
| Denied-permission | Mother without grant → "متاح للأب فقط" |
| Locked (child) | N/A (parent screen) |
| Trial-expired | Basic privacy controls accessible (P0); advanced age-based presets locked (premium) |

**Data displayed:** ChildPrivacyConfig entity (visibility settings, granularity, age preset, consent log).

**Actions:** Select child, set message visibility, set location granularity, set browsing scope, set alert scope, apply age preset, view consent log, export consent log.

**Navigation:** ← SCR-ADM-01 / SCR-ADM-02 · → SCR-ADM-08 Export (consent log).

**Permissions required:** `INTERNET`.

**Offline behavior:** Cached config; changes queued; consent log cached.

**Edge cases:** Reduce monitoring for teenager → logged with consent record; increase monitoring → child notification "تم تحديث إعدادات الخصوصية" (transparency); GDPR minor data request → see EC-CMP-02; age preset applied → overwrites individual settings with warning "سيؤدي هذا إلى تغيير جميع الإعدادات"; conflicting settings (full alerts + no message visibility) → warning "لا يمكن تنبيه المحتوى بدون رؤية الرسائل".

---

### SCR-ADM-08 — Export & Delete (تصدير وحذف البيانات)

| Field | Value |
|---|---|
| **Screen ID** | SCR-ADM-08 |
| **Name (AR)** | تصدير وحذف البيانات |
| **Name (EN)** | Data Export & Deletion |
| **Roles** | Father (all family data), Mother (own data), Child (own data, if age permits) |
| **P0 services** | Data export (GDPR), data deletion, account deletion, audit trail |
| **Purpose** | Provide GDPR-compliant data export and deletion capabilities. |

**Layout:**
- **Header:** back arrow, "تصدير وحذف البيانات"
- **Body:** 
  - **Export:** scope selector (all family / own data / specific child), format (JSON, PDF report), "تصدير" CTA → progress bar → download link; export history list
  - **Delete:** scope (own account / specific data types / full family deletion), confirmation flow (type family name to confirm full deletion), "حذف" Coral CTA with multiple warnings, grace period explanation ("سيتم الحذف خلال 30 يومًا، يمكن التراجع")
  - **Audit trail:** deletion requests, export requests with timestamps
- **Footer/nav:** bottom nav
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading (export) | Progress bar "جارٍ تجهيز البيانات…" |
| Empty | No export/delete history → "لم تقم بأي عمليات تصدير أو حذف" |
| Success | Export ready (download link), deletion scheduled (grace period shown) |
| Error | Export fail → "فشل التصدير" + retry; delete fail → "فشل جدولة الحذف" + retry; export in progress when delete requested → see EC-CMP-01 |
| Denied-permission | Storage denied → "اسمح بالوصول للملفات لحفظ التصدير" + settings link |
| Locked (child) | Child: own data export only (if age permits); no family deletion |
| Trial-expired | Accessible (P0 compliance — always available regardless of subscription) |

**Data displayed:** ExportRequest entity (scope, format, status, timestamp, URL), DeletionRequest entity (scope, status, grace-period-end, timestamp), AuditLog.

**Actions:** Select export scope, select format, export, download, select delete scope, confirm deletion, cancel deletion (within grace), view audit trail.

**Navigation:** ← SCR-ADM-01 / SCR-ADM-06 · → download (external) · → SCR-SHR-02 Login (after account deletion).

**Permissions required:** `INTERNET`, `WRITE_EXTERNAL_STORAGE` / `READ_MEDIA_IMAGES` (for download).

**Offline behavior:** Export/deletion requests require online (server-side processing); cached status viewable.

**Edge cases:** Export in progress + deletion requested → EC-CMP-01; GDPR request for child data → EC-CMP-02; full family deletion by Father → all members notified, 30-day grace, reversible; deletion during active SOS → blocked "لا يمكن الحذف أثناء الطوارئ"; export file large → email link + in-app download; audit log overflow → EC-CMP-03.

---

### SCR-ADM-09 — Today Dashboard (لوحة اليوم)

| Field | Value |
|---|---|
| **Screen ID** | SCR-ADM-09 |
| **Name (AR)** | لوحة اليوم |
| **Name (EN)** | Today Dashboard |
| **Roles** | Father, Mother (family view), Child (own learning view) |
| **P0 services** | Daily summary, agenda, alerts, quick actions, family overview |
| **Purpose** | Show everything happening today in one glance: schedule, tasks, alerts, child status, learning progress. |

**Layout:**
- **Header:** "اليوم" title, Hijri date + Gregorian, greeting
- **Body (parent):** 
  - **Family status strip:** each child — avatar, location status (home/school/away), screen time ring, last alert if any
  - **Today's agenda:** timeline of family events (calendar), color-coded
  - **Pending tasks:** count + top 3 tasks due today
  - **Alerts:** content alerts (Coral if critical), monitoring alerts, extra-time requests
  - **Learning summary:** each child's lesson progress today
  - **Quick actions:** "قفل جهاز", "إضافة حدث", "إرسال رسالة"
- **Body (child):** redirects to SCR-EDU-01 Learning Home (child's home IS learning)
- **Footer/nav:** bottom nav — Home (active), Chat, Calendar, Tasks, Settings; child: Home, Chat, SOS
- **FAB:** none (child: SOS FAB)

**UI States:**
| State | Presentation |
|---|---|
| Loading | All sections shimmer |
| Empty | New family, no data → "ابدأ بإضافة أفراد وأحداث" + setup CTAs |
| Success | All sections populated, live-updating |
| Error | Partial fail → section-level error cards with retry; full fail → "تعذّر تحميل البيانات" + retry |
| Denied-permission | N/A (aggregation screen) |
| Locked (child) | Child sees Learning Home (SCR-EDU-01) not parent dashboard |
| Trial-expired | Dashboard accessible (P0); AI-powered summaries locked |

**Data displayed:** Calendar events (today), Task entities (due today), ContentAlert entities, MonitoringStatus per child, LearningProgress per child, LocationStatus per child.

**Actions:** Tap any section → detail screen, quick actions (lock, add event, message), pull-to-refresh, dismiss alerts, approve/deny extra-time requests.

**Navigation:** → SCR-PAR-01 Monitoring · → SCR-COM-03 Calendar · → SCR-COM-04 Tasks · → SCR-PAR-09 Alerts · → SCR-EDU-01 Learning · → SCR-COM-02 Chat · → SCR-PAR-03 Device Lock.

**Permissions required:** `INTERNET`, `POST_NOTIFICATIONS`, `ACCESS_FINE_LOCATION` (own location for context).

**Offline behavior:** Cached dashboard; live features pause; "أحدث البيانات المتاحة" timestamp.

**Edge cases:** No children linked → family status hidden, "أضف طفلاً" CTA; all children offline → "جميع الأجهزة غير متصلة" with last-seen; critical alert → pushes to top with Coral pulse and sound even in quiet hours (SOS-level priority); very long agenda → scrollable with "عرض الكل" link to calendar; multi-child → horizontal scroll or stacked cards.

---

### SCR-ADM-10 — School Schedule (الجدول المدرسي)

| Field | Value |
|---|---|
| **Screen ID** | SCR-ADM-10 |
| **Name (AR)** | الجدول المدرسي |
| **Name (EN)** | School Schedule |
| **Roles** | Father, Mother |
| **P0 services** | School schedule CRUD, holiday management, sync with School Time (SCR-PAR-10) |
| **Purpose** | Configure the child's school schedule including days, times, holidays, and exam periods. |

**Layout:**
- **Header:** back arrow, child selector, "الجدول المدرسي"
- **Body:** weekly schedule grid (days × periods), each period: subject, teacher (optional), start/end time; holiday calendar (mark holidays, exam periods); term/semester settings (start/end dates, Hijri); sync toggle with School Time (→ SCR-PAR-10); import from school (if integration available)
- **Footer/nav:** bottom nav
- **FAB:** "+ فترة" (add period)

**UI States:**
| State | Presentation |
|---|---|
| Loading | Schedule grid shimmer |
| Empty | No schedule → "اضبط جدول المدرسة لتفعيل وقت المدرسة" + setup CTA |
| Success | Schedule grid populated, holidays marked, School Time synced |
| Error | Save fail → "فشل الحفظ" + retry; import fail → "تعذّر الاستيراد" + manual entry |
| Denied-permission | N/A |
| Locked (child) | N/A (parent screen) |
| Trial-expired | Basic schedule accessible (P0); school integration import locked (premium) |

**Data displayed:** SchoolSchedule entity (days, periods, subjects, times), Holiday entity, Term entity.

**Actions:** Add/edit/delete period, set holidays, set term dates, toggle School Time sync, import schedule, view in calendar.

**Navigation:** ← SCR-ADM-01 · → SCR-PAR-10 School Time · → SCR-COM-03 Calendar (sync).

**Permissions required:** `INTERNET`, `READ/WRITE_CALENDAR` (optional device sync).

**Offline behavior:** Schedule cached; changes queued; School Time enforcement uses cached schedule.

**Edge cases:** Schedule conflicts (two periods same time) → warning; holiday during exam → exam takes priority; schedule changes mid-term → School Time auto-updates; different children different schedules → per-child config; weekend definition varies by country (Fri-Sat vs. Sat-Sun) → locale-aware.

---

### SCR-ADM-11 — Trial (التجربة المجانية)

| Field | Value |
|---|---|
| **Screen ID** | SCR-ADM-11 |
| **Name (AR)** | التجربة المجانية |
| **Name (EN)** | Trial Status |
| **Roles** | Father (manage), Mother (view) |
| **P0 services** | Trial lifecycle, countdown, conversion prompts, trial feature gating |
| **Purpose** | Display trial status, remaining days, and guide conversion to paid subscription. |

**Layout:**
- **Header:** back arrow, "التجربة المجانية"
- **Body:** trial status card — large countdown (days remaining), progress bar (used/total), features included list (all premium features ✓), "اشترك الآن" CTA (appears at 7 days, 3 days, 1 day, 0 days with increasing urgency), trial start date (Hijri), trial end date (Hijri), "ماذا يحدث بعد انتهاء التجربة؟" expandable section (free features list vs. locked premium list), conversion banner if expired
- **Footer/nav:** bottom nav
- **FAB:** none

**UI States:**
| State | Presentation |
|---|---|
| Loading | Status card shimmer |
| Empty | N/A (trial always exists for new families) |
| Success | Countdown, features, conversion CTA displayed |
| Error | Trial status fetch fail → "تعذّر التحقق من حالة التجربة" + cached + retry |
| Denied-permission | N/A |
| Locked (child) | N/A (parent screen) |
| Trial-expired | This IS the trial screen — shows "انتهت التجربة" + full paywall integration with SCR-ADM-04 |

**Data displayed:** Trial entity (start, end, days-remaining, status, features-included), Subscription entity (if converted).

**Actions:** View countdown, view features, subscribe (→ SCR-ADM-04), extend trial (if promotional), view what changes on expiry.

**Navigation:** ← SCR-ADM-01 · → SCR-ADM-04 Paywall.

**Permissions required:** `INTERNET`.

**Offline behavior:** Cached trial status; countdown computed locally from cached end date; conversion requires online.

**Edge cases:** Trial extended (promotion) → new end date, notification "تم تمديد تجربتك"; trial expired with no payment → graceful degradation to free tier, all premium features show lock → SCR-ADM-04; trial clock manipulation (device time changed) → server-side validation, "تم اكتشاف تغيير الوقت" warning; trial grace period (if offered) → "فترة سماح: X أيام متبقية" with reduced features.

## 7. Cross-Screen Conventions

### 7.1 Universal UI States

Every screen in Family OS implements these states. The table below defines the canonical implementation for each:

| State | Visual Treatment | Behavior |
|---|---|---|
| **Loading (shimmer)** | Skeleton elements in `--ink-100` with shimmer animation sweeping left→right (RTL: right→left) | No interactive elements; 2 s timeout → error state if data not loaded |
| **Empty** | Centered illustration (flat, Jade/Coral palette) + Arabic headline + subtext + primary CTA | CTA navigates to the action that would populate the screen |
| **Populated / Success** | Real data rendered, all interactions enabled | Pull-to-refresh available on all list/dashboard screens |
| **Error** | Coral error icon + Arabic message + "إعادة المحاولة" button | Retry triggers same data fetch; 3 consecutive failures → "تواصل مع الدعم" option |
| **Denied-permission** | Rationale card: icon + why permission needed (Arabic) + "السماح" (opens system settings) + "تجاهل" (degraded mode) | System settings deep-link to app's permission page; degraded mode clearly indicated |
| **Locked (child)** | Coral lock icon + "هذه الشاشة متاحة للوالدين فقط" + back button | Child cannot access parent screens; attempting deep-link → locked screen |
| **Trial-expired** | Violet lock icon over premium feature + "ميزة مميزة" label + "اشترك للمتابعة" CTA → SCR-ADM-04 | Core P0 features always accessible; only premium features gate |

### 7.2 Navigation Architecture

```
Parent IA:                          Child IA:
┌─────────────────────────┐         ┌─────────────────────────┐
│  Today Dashboard (Home) │         │  Learning Home (Home)   │
├──────┬──────┬──────┬─────┤         ├──────┬──────┬───────────┤
│ Chat │ Cal. │Tasks │Set. │         │ Chat │Tasks │    SOS    │
├──────┴──────┴──────┴─────┤         ├──────┴──────┴───────────┤
│  Monitoring Hub         │         │  (No monitoring access)  │
│  Admin Hub              │         │  (No admin access)       │
│  AI Assistant           │         │  AI Tutor (premium)      │
└─────────────────────────┘         └─────────────────────────┘
```

- **SOS FAB** is present on EVERY child screen, always accessible, always top-priority overlay.
- **Bottom nav** is persistent for both roles (5 items parent, 3 items child + SOS FAB).
- **Deep links** from notifications route to the relevant screen, respecting role access (locked if child accesses parent screen).

### 7.3 RTL & Arabic Typography

- All text is right-aligned by default; layout flows right-to-left.
- Icons that imply direction (back arrow, chevrons) are mirrored for RTL.
- Numbers: Arabic-Indic (٠١٢٣) by default, Western (0123) optional per user preference.
- Dates: Hijri primary (Umm al-Qura calendar), Gregorian secondary, both display when configured.
- Font: system Arabic font (Noto Naskh Arabic / system default), 16 sp body, 24 sp headings.

### 7.4 Color Semantics

| Color | Token | Usage |
|---|---|---|
| Jade | `#1B6B5A` | Primary actions, success states, parent's own messages, allowed/enabled status |
| Coral | `#E76F51` | Accent, urgency, errors, critical alerts, SOS, locked/disabled, delete actions |
| Violet | `#7C3AED` | AI features (tutor, assistant, recommendations), premium features |
| Ink-50 | `#F8FAFC` | Screen background |
| Ink-100 | shimmer | Skeleton loading elements |
| Gray | neutral | Disabled, secondary text, empty states |
| Amber | warning | Warnings, improvements needed, moderate alerts |

### 7.5 Permission Hierarchy

| Permission Level | Father | Mother (default) | Child |
|---|---|---|---|
| Members management | ✓ | ✗ (exclusive) | ✗ |
| Devices & permissions | ✓ | ✗ (exclusive) | ✗ |
| Child privacy | ✓ | ✗ (exclusive) | ✗ |
| Safe zones | ✓ | ✗ (exclusive) | ✗ |
| App rules | ✓ | ✗ (exclusive) | ✗ |
| Web filter | ✓ | ✗ (exclusive) | ✗ |
| Kill switch | ✓ | ✗ (exclusive) | ✗ |
| Anti-bypass | ✓ | ✗ (exclusive) | ✗ |
| Monitoring hub | ✓ | ✓ (subset) | ✗ |
| Screen time | ✓ | ✓ | view own |
| Device lock | ✓ | ✓ | ✗ |
| Calendar | ✓ | ✓ | view + own reminders |
| Tasks | ✓ | ✓ | own assigned |
| Chat | ✓ | ✓ | family + parents |
| Learning | ✓ | view | ✓ full |
| AI Assistant | ✓ | ✓ | ✗ |
| AI Tutor | ✓ | configure | ✓ (premium) |
| Premium/purchase | ✓ | view only | ✗ |
| Settings | ✓ | subset | own preferences |
| Export/delete | ✓ (all family) | own data | own data (if age permits) |

Mother can be granted any of the 8 exclusive features via `mother_permissions` configuration by the Father.

### 7.6 Offline Resilience Tiers

| Tier | Features | Offline Behavior |
|---|---|---|
| **Tier 1 (always offline)** | Local settings, cached data view, SOS (SMS fallback), Focus Mode timer, lesson playback (downloaded) | Full functionality |
| **Tier 2 (queued sync)** | Messages (send queued), task CRUD, calendar CRUD, profile edits, rule changes | Local operation, sync on reconnect |
| **Tier 3 (online required)** | AI Tutor, AI Assistant, AI recommendations, Quran analysis, adaptive exercises, real-time GPS, translation | Graceful degradation with cached fallback or "requires connection" message |
| **Tier 4 (server-authoritative)** | Authentication, subscription billing, placement test, device enrollment, export/delete processing | Blocked with clear message |

### 7.7 Notification Priority Levels

| Priority | Channels | Bypasses DND | Bypasses Quiet Hours |
|---|---|---|---|
| **Critical** | SOS, Kill Switch activation, critical content alerts (self-harm, predator) | Yes | Yes |
| **High** | Extra-time request, geofence violation, anti-bypass alert, device offline >1h | No | Yes (with override) |
| **Normal** | Messages, calendar reminders, task due, school time start/end | No | No |
| **Low** | Education reminders, badge earned, AI recommendations, daily summary | No | No |

---

*End of Screen Specifications Master.*
