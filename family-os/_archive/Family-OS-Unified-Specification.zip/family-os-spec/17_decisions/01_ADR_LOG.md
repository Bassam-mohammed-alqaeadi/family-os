---
title: "Architecture Decision Records (ADRs)"
tags: [decisions, adr, architecture, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification
---

# Architecture Decision Records (ADRs)

---

## ADR-001: Flutter as Sole UI Framework

| Field | Value |
|-------|-------|
| **Decision** | Flutter (Dart) for all UI, navigation, state, business logic |
| **Context** | Need cross-platform UI with native Android bridges; future iOS support |
| **Options** | (A) Flutter + Kotlin bridges · (B) React Native · (C) Native Android (Kotlin/Jetpack Compose) · (D) Flutter + Jetpack Compose |
| **Chosen** | A — Flutter + Kotlin/Java bridges only |
| **Why** | Single codebase for future iOS; Riverpod for state; GoRouter for navigation; rich Arabic font support; large ecosystem |
| **Rejected** | B (RN: weaker native bridge story); C (no cross-platform); D (Constitution forbids Compose as UI) |
| **Trade-offs** | + One codebase, future iOS; − Native bridges add complexity |
| **Consequences** | All UI in Dart; Kotlin/Java only for Platform Channels |
| **Reversal cost** | High — would require complete UI rewrite |

---

## ADR-002: Drift (SQLite) as Local Database

| Field | Value |
|-------|-------|
| **Decision** | Drift (SQLite) for offline-first local storage |
| **Context** | Need offline-first architecture with reliable local DB |
| **Options** | (A) Drift (SQLite) · (B) Isar · (C) Hive |
| **Chosen** | A — Drift |
| **Why** | SQLite compatibility; migration support; query capabilities; SQLCipher encryption; mature ecosystem |
| **Rejected** | B (Isar: Constitution explicitly excludes); C (Hive: less query power) |
| **Trade-offs** | + SQL power, migrations, encryption; − Slightly more boilerplate than Isar |
| **Consequences** | All local data in Drift; sync queue in Drift |
| **Reversal cost** | Medium — data layer rewrite |

---

## ADR-003: Email/Password Authentication

| Field | Value |
|-------|-------|
| **Decision** | Firebase Auth Email/Password + optional biometric |
| **Context** | Need authentication that works for children (may not have phones) and parents |
| **Options** | (A) Email/Password + biometric · (B) Phone OTP · (C) OAuth (Google/Apple) |
| **Chosen** | A — Email/Password + biometric |
| **Why** | Children may not have phones; email is universal; biometric for convenience; Constitution freezes this |
| **Rejected** | B (phone: children may not have phones; Constitution excludes); C (OAuth: not in MVP) |
| **Trade-offs** | + Universal, child-friendly; − Less frictionless than phone OTP |
| **Consequences** | All auth via email; phone for communication only |
| **Reversal cost** | Medium — auth flow + screens change |

---

## ADR-004: Kill Switch via VPN + AccessibilityService

| Field | Value |
|-------|-------|
| **Decision** | Kill Switch uses local VPN (stop internet) + AccessibilityService (prevent bypass) |
| **Context** | Need to reliably pause internet on child device |
| **Options** | (A) VPN + Accessibility · (B) VPN only · (C) Accessibility only · (D) DevicePolicyManager |
| **Chosen** | A — Both |
| **Why** | VPN stops traffic; Accessibility prevents force-stop/uninstall; together robust |
| **Rejected** | B (can be bypassed by killing app); C (doesn't stop internet); D (partially deprecated) |
| **Trade-offs** | + Robust anti-bypass; − Two permissions needed; Google Play policy risk |
| **Consequences** | Two native bridges for Kill Switch; permission denial path required |
| **Reversal cost** | Medium — bridge rewrite |

---

## ADR-005: Single Premium Plan (49 SAR/month)

| Field | Value |
|-------|-------|
| **Decision** | One Premium plan at 49 SAR/month with 14-day trial |
| **Context** | MVP monetization; Constitution freezes single plan |
| **Options** | (A) Single Premium · (B) 4-tier (Free/Family/Premium AI/Large Family) · (C) Freemium with usage limits |
| **Chosen** | A — Single Premium |
| **Why** | Simpler to launch; clearer value; Constitution freezes; multi-tier is P1 |
| **Rejected** | B (too complex for MVP); C (harder to communicate value) |
| **Trade-offs** | + Simple, clear; − May leave revenue on table for power users |
| **Consequences** | One paywall screen; one billing flow; trial auto-starts |
| **Reversal cost** | Low — add tiers later |

---

## ADR-006: 91 P0 Services (Frozen)

| Field | Value |
|-------|-------|
| **Decision** | 91 P0 services across 5 systems (frozen by owner) |
| **Context** | Scope definition for MVP; evolved from 55 → 71 → 91 |
| **Options** | (A) 55 (original) · (B) 71 (enhanced) · (C) 91 (full competitive parity) |
| **Chosen** | C — 91 |
| **Why** | Full competitive parity + differentiation; includes Kill Switch, Anti-bypass, 29 categories, School Time, adaptive learning, XP, etc. |
| **Rejected** | A/B (would miss critical safety features competitors have) |
| **Trade-offs** | + Full market parity; − Larger MVP scope |
| **Consequences** | 91 services → 62 screens → full design + implementation scope |
| **Reversal cost** | Very high — scope change affects everything |

---

## ADR-007: Low Child Transparency

| Field | Value |
|-------|-------|
| **Decision** | Low transparency for child — no "what parents see" screen (SCR-SHR-07 cancelled) |
| **Context** | Balance safety vs privacy vs child trust |
| **Options** | (A) Low (remaining time, locked apps, school mode) · (B) Medium (show categories) · (C) High (show all alerts, rules) |
| **Chosen** | A — Low |
| **Why** | Constitution freezes low; showing all alerts may cause child to bypass; child sees effects (locked apps, remaining time) |
| **Rejected** | B/C (Constitution excludes; safety risk) |
| **Trade-offs** | + Prevents bypass attempts; − Less child trust |
| **Consequences** | SCR-SHR-07 cancelled; child sees effects not rules |
| **Reversal cost** | Low — add screen later if desired |

---

## ADR-008: Gemini 2.5 Flash as Primary AI Model

| Field | Value |
|-------|-------|
| **Decision** | Gemini 2.5 Flash for all AI capabilities; Whisper for STT |
| **Context** | Need Arabic-capable, cost-effective AI model |
| **Options** | (A) Gemini 2.5 Flash · (B) GPT-4o · (C) Claude 3.5 · (D) Self-hosted |
| **Chosen** | A — Gemini 2.5 Flash |
| **Why** | Low cost ($0.07–0.29/M tokens); good Arabic; Google ecosystem integration; fast |
| **Rejected** | B (expensive); C (no image analysis by default); D (too expensive to host) |
| **Trade-offs** | + Low cost, fast, Arabic; − Google dependency; quality may vary |
| **Consequences** | All AI through Gemini; cost tracking per family; fallback to Flash-Lite |
| **Reversal cost** | Medium — AI Orchestrator abstracts model, but prompts tuned for Gemini |

---

## ADR-009: Offline-First with Drift + Sync Queue

| Field | Value |
|-------|-------|
| **Decision** | All domains support offline via Drift cache + sync queue |
| **Context** | Target market may have unreliable connectivity |
| **Options** | (A) Offline-first (Drift + queue) · (B) Online-only with cache · (C) Offline for comms only |
| **Chosen** | A — Offline-first for all |
| **Why** | Monitoring must enforce rules offline; education works offline; comms queue messages; safety is critical |
| **Rejected** | B (monitoring fails offline); C (incomplete) |
| **Trade-offs** | + Always functional; − Sync complexity; conflict resolution needed |
| **Consequences** | Every operation writes to Drift first, then syncs; conflict resolution per data type |
| **Reversal cost** | High — architecture-level decision |

---

## ADR-010: PostgreSQL + RLS for Multi-Tenant Isolation

| Field | Value |
|-------|-------|
| **Decision** | Cloud SQL PostgreSQL with Row-Level Security for family isolation |
| **Context** | Multi-tenant: each family must only see their own data |
| **Options** | (A) PostgreSQL + RLS · (B) Separate schema per family · (C) Separate DB per family |
| **Chosen** | A — RLS |
| **Why** | Scalable; no schema-per-family overhead; enforced at DB level; Firestore Security Rules complement |
| **Rejected** | B (schema management overhead); C (too expensive at scale) |
| **Trade-offs** | + Scalable, enforced at DB; − RLS policies must be carefully written |
| **Consequences** | Every family-scoped table has RLS policy; every query scoped by family_id |
| **Reversal cost** | High — data architecture change |
