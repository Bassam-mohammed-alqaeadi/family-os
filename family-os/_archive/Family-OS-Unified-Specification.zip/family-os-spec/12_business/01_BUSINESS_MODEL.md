---
title: "Business Model & Monetization"
tags: [business, monetization, subscription, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification
---

# Business Model & Monetization

---

## 1. Revenue Model

> **Single Premium plan — 49 SAR/month ($13/month) + 14-day free trial.**

The frozen MVP business model (per Product Constitution) is a single Premium plan. The enhanced analysis explored 4 tiers; the Constitution froze it to one. This is the MVP reality.

### MVP Plan (Frozen)

| Aspect | Value |
|--------|-------|
| Plan name | Premium |
| Price | 49 SAR/month |
| Trial | 14 days free, auto-starts on registration |
| Trial behavior | All features active; NO auto-charge at end |
| Payment | Google Play Billing |
| Cancel | Effective at period end |

### Free Tier (After Trial Expires)

| Feature | Free |
|---------|------|
| Family chat | ✅ |
| 1:1 chat | ✅ |
| SOS | ✅ |
| Family calendar | ✅ |
| Basic tasks/shopping | ✅ |
| Screen time basic | ✅ |
| Location view | ✅ |

### Premium Tier (Paid)

| Feature | Premium |
|---------|---------|
| Everything in Free | ✅ |
| Advanced monitoring (29 categories, Kill Switch, Anti-bypass) | ✅ |
| School Time | ✅ |
| AI Assistant | ✅ |
| AI Tutor | ✅ |
| AI auto-grading | ✅ |
| AI recitation analysis | ✅ |
| Adaptive learning | ✅ |
| Placement test | ✅ |
| XP + levels | ✅ |
| Smart recommendations | ✅ |
| Translation | ✅ |
| Voice transcription | ✅ |

### Future Tiers (P1+ — Not MVP)

| Plan | Price | Target |
|------|-------|--------|
| Family | $7.99/mo | Average family |
| Premium AI | $14.99/mo | Education-focused |
| Large Family | $24.99/mo | Large family + B2B |

> **Decision:** MVP launches with single Premium at 49 SAR. Multi-tier is a P1 evolution based on conversion data.

---

## 2. Family Limits (Frozen)

| Limit | Value |
|-------|-------|
| Family members | Up to 6 |
| Children | Up to 4 |
| Devices per child | 1 |
| AI Assistant messages/day | Premium: unlimited |
| AI Tutor questions/day | Premium: unlimited |
| Storage per family | Fair use (monitored) |

---

## 3. Subscription Lifecycle

```
Registration → Free Trial (14 days, all features)
    ↓ Day 11: FCM reminder "3 days left"
    ↓ Day 14: Trial expires
Trial Expired → Free tier (limited) OR Subscribe (49 SAR)
    ↓ Subscribe: Google Play Billing → Premium active
Premium Active → Monthly billing cycle
    ↓ Cancel: Effective at period end → Free tier
    ↓ Payment fails: 7-day grace → Free tier
```

---

## 4. Revenue Projections

| Year | Users | Paid Conversion | Paid Users | ARPU | Annual Revenue |
|------|-------|-----------------|------------|------|----------------|
| 2026 (launch) | 50K | 15% | 7.5K | $13 | $1.17M |
| 2027 | 2M | 20% | 400K | $14 | $67.2M |
| 2028 | 5.5M | 25% | 1.375M | $15 | $247.5M |

> **Strategic target: $900M valuation by 2028** — revenue + growth rate + market position.

---

## 5. AI Cost Management

| Metric | Value |
|--------|-------|
| Gemini 2.5 Flash | $0.07/M input, $0.29/M output |
| Whisper | $0.006/min |
| text-embedding-004 | $0.006/M tokens |
| Estimated cost per premium user/month | $2–4 |
| Margin per premium user (49 SAR ≈ $13) | ~$9–11 gross |

### Cost Controls

1. Rate limiting per plan
2. Redis caching for translations (1hr TTL)
3. Batch sentiment analysis (not every message)
4. Local computation for adaptive level transitions
5. Fallback to Flash-Lite if Gemini cost rises

---

## 6. Growth Strategy

| Phase | Timeline | Market |
|-------|----------|--------|
| 1. Arab market first | 2026 | Saudi Arabia + UAE + Egypt + Jordan |
| 2. Islamic expansion | 2027 | Indonesia + Malaysia + Turkey + Pakistan |
| 3. Global expansion | 2027–2028 | Latin America + Africa + Asia |
| 4. B2B integration | 2028+ | Schools + telecoms + device manufacturers |

---

## 7. Revenue Opportunities (Future — Not MVP)

| Opportunity | Monetization | Priority |
|-------------|-------------|----------|
| Multi-tier pricing | $7.99 / $14.99 / $24.99 | P1 |
| Usage-based AI add-on | $5/month extra AI credits | P2 |
| School B2B licenses | Per-student pricing | P2 |
| Telecom partnerships | Bundle with mobile plans | P2 |
| Device manufacturer bundling | Pre-installed | P3 |
| Premium content marketplace | Paid lesson packs | P3 |
