---
title: "Quality, Testing & Traceability"
tags: [quality, testing, traceability, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification
---

# Quality, Testing & Traceability

---

## 1. Test Strategy

### 1.1 Test Pyramid

| Layer | Scope | Tools | Coverage Target |
|-------|-------|-------|----------------|
| Unit | ViewModels, models, utilities | flutter_test, mockito | > 80% |
| Widget | UI components, screens | flutter_test (widget testing) | > 70% |
| Integration | Repository → API → DB | integration_test | Key flows |
| E2E | Full user journeys | integration_test + manual | All P0 flows |
| API | Cloud Functions | Jest, supertest | > 80% |
| Database | SQL migrations, RLS | pgTAP | All RLS policies |
| Sync | Offline → online sync | Custom harness | All sync paths |
| Security | Auth, permissions, encryption | Static analysis + manual | All sensitive ops |
| Performance | Load, latency | Firebase Performance | NFR targets |
| Accessibility | Screen reader, contrast | flutter_test + manual | WCAG AA |
| Localization | AR + EN, RTL/LTR | flutter_test + manual | All screens |

### 1.2 Key Test Scenarios (P0)

| ID | Scenario | Layers |
|----|----------|--------|
| T-001 | Send text message online | Unit + Widget + Integration |
| T-002 | Send message offline → sync on reconnect | Unit + Integration + Sync |
| T-003 | Voice message → transcription | Unit + Integration + API |
| T-004 | Translation (cache hit + miss) | Unit + Integration |
| T-005 | SOS launch (child) → receive (parent) | E2E + Integration |
| T-006 | Screen time limit → lock → request extra time | E2E |
| T-007 | App blocking (Accessibility) | Integration + Manual (real device) |
| T-008 | Kill Switch activate → child blocked → resume | E2E + Manual |
| T-009 | Anti-bypass: disable Accessibility → alert | Manual (real device) |
| T-010 | School Time activate → restrictions applied | E2E |
| T-011 | Content alert: type in WhatsApp → Gemini classify → parent FCM | Integration + API |
| T-012 | Assignment submit → AI grade → result | Integration + API |
| T-013 | Quiz take → submit → score | E2E |
| T-014 | Focus Mode → apps blocked → timer → XP | Integration |
| T-015 | Quran recitation → Whisper → Gemini → accuracy | Integration + API |
| T-016 | Placement test → adaptive path generated | Integration + API |
| T-017 | XP earn → level up → badge | Unit + Widget |
| T-018 | Family create → trial starts → features active | E2E |
| T-019 | Trial expires → features locked → paywall | E2E |
| T-020 | Subscribe → Google Play Billing → premium active | Integration + Manual |
| T-021 | Mother permissions change → UI updates | Widget + Integration |
| T-022 | Language switch AR→EN → RTL→LTR | Widget |
| T-023 | Permission denied → UX-PERM-DENIED dialog | Widget |
| T-024 | Data export → JSON+ZIP | API + Manual |
| T-025 | Account deletion → 30-day grace → cleanup | API + Manual |
| T-026 | Geofence enter → system message + notification | Integration |
| T-027 | AI assistant rate limit → 429 → upgrade prompt | API |
| T-028 | Today Dashboard aggregates all systems | Integration + Widget |
| T-029 | AI recommendation → shown → accepted → completed | E2E |
| T-030 | Invitation → accept → join family → monitoring starts | E2E |

---

## 2. Traceability Matrix

### 2.1 Traceability Chain

```
Business Goal → User Need → Requirement → Capability → Domain → Feature (Service ID)
    → Use Case → Workflow → Entity → API/Event → Screen (SCR ID) → Test
```

### 2.2 Sample Traceability (Key Flows)

| Business Goal | User Need | Service | Screen | Event | Test |
|---------------|-----------|---------|--------|-------|------|
| Protect children | Know when child is in danger | S-COM-039 | SCR-COM-07 | sos.activated | T-005 |
| Protect children | Block inappropriate content | S-PAR-021/045 | SCR-PAR-09 | content.alert_triggered | T-011 |
| Protect children | Limit screen time | S-PAR-001 | SCR-PAR-02 | screentime.limit_reached | T-006 |
| Protect children | Prevent internet access | S-PAR-041 | SCR-PAR-11 | killswitch.activated | T-008 |
| Protect children | Prevent monitoring bypass | S-PAR-038 | SCR-PAR-12 | antibypass.attempt_detected | T-009 |
| Organize family | Shared calendar | S-COM-030/031 | SCR-COM-03/05 | event.created | — |
| Organize family | Tasks + shopping | S-COM-032/033 | SCR-COM-04 | task.created/completed | — |
| Educate children | Assignment + AI grading | S-EDU-009/011/013 | SCR-EDU-05 | assignment.graded | T-012 |
| Educate children | Adaptive learning | S-EDU-047/051/052 | SCR-EDU-12/13/14 | placement.completed | T-016 |
| Educate children | Quran memorization | S-EDU-038/039 + AI-008 | SCR-EDU-10 | quran.verified | T-015 |
| Educate children | Gamification | S-EDU-024/028/058 | SCR-EDU-08/15 | xp.earned, level.up | T-017 |
| Communicate | Family chat | S-COM-001 | SCR-COM-01/02 | message.sent | T-001 |
| Communicate | Voice messages | S-COM-041 | SCR-COM-10 | voice.transcribed | T-003 |
| Communicate | Translation | S-COM-044 | SCR-COM-09 | message.translated | T-004 |
| AI assistance | Family assistant | AI-001 | SCR-AI-01 | ai.response_generated | T-027 |
| AI assistance | Tutor | AI-003 | SCR-AI-02/SCR-EDU-11 | — | — |
| AI assistance | Sentiment | AI-002 | (behind scenes) | ai.sentiment_analyzed | T-011 |
| AI assistance | Recommendations | AI-007/020 | SCR-AI-03/05 | ai.recommendation_generated | T-029 |
| Manage family | Today Dashboard | S-ADM-033 | SCR-ADM-09 | — | T-028 |
| Manage family | Subscription | S-ADM-014/038 | SCR-ADM-04/11 | subscription.activated | T-018/19/20 |
| Manage family | Members + devices | S-ADM-002/009 | SCR-ADM-02/03 | member.joined, device.linked | T-030 |

### 2.3 Coverage Verification

| Metric | Target | Status |
|--------|--------|--------|
| P0 services with ≥1 screen | 91/91 | ✅ |
| P0 services with ≥1 diagram | 91/91 | ✅ |
| P0 services with test scenario | 91/91 | ✅ (30 key scenarios + remaining covered by unit/integration) |
| Screens with contract | 62/62 | ✅ |
| Entities with owner | 72/72 | ✅ |
| Events with producer/consumer | All P0 events | ✅ |
| Permissions per operation | All operations | ✅ |

---

## 3. Real-Device Validation

| Device | Android Version | Priority |
|--------|----------------|----------|
| Samsung Galaxy A-series | 14 (API 34) | Critical (most common in target market) |
| Samsung Galaxy S-series | 14 | High |
| Xiaomi Redmi Note | 13–14 | High (popular in target market) |
| Google Pixel | 14 | Medium (reference) |
| Huawei (no GMS) | 12+ | Low (MVP requires GMS) |

### Critical Real-Device Tests

| Test | Why Real Device |
|------|----------------|
| AccessibilityService blocking | Cannot be tested on emulator reliably |
| UsageStatsManager | Emulator may not report usage |
| GeofencingClient | Emulator GPS simulation unreliable |
| Kill Switch (VPN) | Emulator VPN behavior differs |
| Battery consumption | Emulator has no real battery |
| FusedLocationProvider | Emulator location accuracy differs |
| MediaRecorder (Quran) | Emulator audio input differs |
| Anti-bypass | Emulator may not have Settings app |
