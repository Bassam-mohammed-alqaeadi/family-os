---
title: "State Machines — Critical System Flows"
tags: [state, machines, flows, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification (Pass 2)
---

# State Machines — Critical System Flows

> Formal state definitions for the platform's most critical behavioral sequences. Each state machine defines states, transitions, guards, and actions.

---

## 1. Authentication State Machine

```
                    ┌──────────┐
                    │  UNAUTH  │ ← app launch, no valid session
                    └────┬─────┘
                         │ email + password entered
                         ▼
                    ┌──────────┐
         ┌────────→ │ AUTHING  │ ←─ Firebase Auth in progress
         │          └────┬─────┘
         │               │ success
         │               ▼
         │          ┌──────────┐
         │          │  AUTHED  │ ←─ session active, JWT valid
         │          └────┬─────┘
         │               │ token expired / sign out
         │               ▼
         │          ┌──────────┐
         │          │ EXPIRED  │ ←─ refresh token
         │          └────┬─────┘
         │               │ refresh success → AUTHED
         │               │ refresh fail → UNAUTH
         └──────────────┘
```

| State | Entry Condition | Exit Condition |
|-------|----------------|----------------|
| UNAUTH | App launch with no valid token | User submits credentials |
| AUTHING | Credentials submitted | Firebase responds (success/fail) |
| AUTHED | Firebase returns valid JWT | Token expires or user signs out |
| EXPIRED | JWT expired, refresh attempt | Refresh succeeds (→AUTHED) or fails (→UNAUTH) |

---

## 2. SOS Emergency State Machine

```
┌──────────┐    hold 3s    ┌───────────┐    confirmed    ┌───────────┐
│  IDLE    │ ──────────→  │ COUNTDOWN │ ─────────────→ │ BROADCAST │
└──────────┘              │ (3..1)    │                 │  location  │
     ↑                     └─────┬─────┘                 └─────┬─────┘
     │                     cancel│                            │
     │                           ↓                            │
     │                     ┌──────────┐                       │
     │                     │ CANCELLED│                       │
     │                     └──────────┘                       │
     │                                                        ↓
     │                  ┌───────────┐    parent responds   ┌──────────┐
     │                  │ NOTIFIED  │ ←─────────────────  │  PARENT  │
     │                  └─────┬─────┘                      │ RECEIVES │
     │                        │                            └─────┬─────┘
     │                        │ parent opens SOS                 │
     │                        ▼                                  │
     │                  ┌───────────┐                            │
     │                  │  ACTIVE   │ ←──────────────────────────┘
     │                  │ RESCUE   │
     │                  └─────┬─────┘
     │                        │ parent resolves
     │                        ▼
     └────────────────── ┌───────────┐
                         │  RESOLVED │
                         └───────────┘
```

| State | Trigger | Actions | Timeout |
|-------|---------|---------|---------|
| IDLE | Child holds SOS FAB 3s | — | — |
| COUNTDOWN | IDLE trigger | Show 3-2-1 countdown; cancel if released | 3 seconds |
| CANCELLED | Child releases before 0 | Return to previous screen | — |
| BROADCAST | Countdown reaches 0 | Start live location broadcast; send FCM to parents; begin auto-call sequence | 5 seconds to parent receipt |
| NOTIFIED | FCM delivered to parent | Parent device rings/vibrates; notification shown | 30 seconds to parent open |
| PARENT_RECEIVES | Parent taps notification | Open SCR-COM-07 receive mode; show map + call button | — |
| ACTIVE_RESCUE | Parent opens SOS screen | Two-way location; parent can call/locate/resolve | — |
| RESOLVED | Parent taps "resolve" | Save emergency_event; send FCM to child "parent is coming"; log audit | — |

**Critical rules:**
- SOS bypasses ALL locks: device lock, screen time limit, Kill Switch
- SOS sends even offline: queued at highest priority, sends on any connectivity
- SOS cannot be disabled by child or parent — always available
- Rate limit: 10 SOS/hour (prevent abuse, but never block a real emergency)

---

## 3. Screen Time Enforcement State Machine

```
┌──────────────┐    within limit    ┌──────────────┐
│  TRACKING    │ ←────────────────→ │  ALLOWED     │
│  (monitoring)│                    │  (apps open) │
└──────┬───────┘                    └──────┬───────┘
       │ limit reached                     │ limit reached
       ▼                                   ▼
┌──────────────┐    child requests    ┌──────────────┐
│ LIMIT_REACHED│ ─────────────────→  │  PENDING_REQ │
│ (show warn)  │                     │ (wait parent)│
└──────┬───────┘                     └──────┬───────┘
       │ grace period (5 min)               │
       ▼                                    │
┌──────────────┐             approved ┌────┴──────┐
│  GRACE       │ ←────────────────── │ APPROVED   │
│  (5 min)     │                     │ (extra time)│
└──────┬───────┘                     └───────────┘
       │ grace expires
       ▼
┌──────────────┐    bedtime reached  ┌──────────────┐
│  LOCKED      │ ←─────────────────  │  BEDTIME     │
│ (device lock)│                     │  (lock + dim)│
└──────┬───────┘                     └──────────────┘
       │ parent unlocks / morning
       ▼
┌──────────────┐
│  TRACKING    │
└──────────────┘
```

---

## 4. Subscription / Trial State Machine

```
┌──────────┐    register     ┌──────────┐    day 14    ┌──────────┐
│  NEW      │ ──────────→   │  TRIAL   │ ──────────→ │ EXPIRED  │
│  USER     │               │ (14 days)│             │ (free)   │
└──────────┘               └────┬─────┘             └────┬─────┘
                                │ subscribe                │ subscribe
                                ▼                          ▼
                           ┌──────────┐             ┌──────────┐
                           │ PREMIUM  │             │ PREMIUM  │
                           │ (active) │             │ (active) │
                           └────┬─────┘             └──────────┘
                                │ cancel / payment fail
                                ▼
                           ┌──────────┐
                           │ GRACE    │
                           │ (7 days) │
                           └────┬─────┘
                                │ grace expires
                                ▼
                           ┌──────────┐
                           │ FREE     │
                           │ TIER     │
                           └──────────┘
```

**Trial timeline:**
- Day 0: Trial starts automatically on registration
- Day 1–13: All features active; no payment required
- Day 11: FCM reminder "٣ أيام متبقية في الفترة التجريبية"
- Day 14: Trial expires → features gate → Free tier OR subscribe
- No auto-charge at trial end (explicit subscribe required)

**Premium cancellation:**
- Cancel effective at period end (not immediate)
- During remaining period: full access continues
- After period end: → FREE_TIER

**Payment failure:**
- 7-day grace period with full access
- After grace: → FREE_TIER
- If payment recovers during grace: → PREMIUM (active)

---

## 5. Device Link State Machine

```
┌──────────┐   father generates   ┌──────────┐   child opens   ┌──────────┐
│  NEW     │ ──────────────────→ │ LINK     │ ──────────────→ │ PENDING  │
│  DEVICE  │   invite link       │ SENT     │                 │ APPROVAL │
└──────────┘                      └──────────┘                 └────┬─────┘
                                                                   │
                                                    father approves│
                                                                   ▼
                              ┌──────────┐                   ┌──────────┐
                              │ ACTIVE   │ ←──────────────── │ LINKED   │
                              │ (linked) │                   │ (perms)  │
                              └────┬─────┘                   └──────────┘
                                   │ father unlinks
                                   ▼
                              ┌──────────┐
                              │ UNLINKED │
                              │ (cached) │
                              └──────────┘
```

**Permission cascade during LINKED state:**
1. Accessibility Service → denied? → show explanation → retry
2. Usage Stats → denied? → show explanation → retry
3. Location (fine + background) → denied? → show explanation → retry
4. Overlay → denied? → show explanation → retry
5. Notifications → denied? → show explanation → retry
6. Device Admin → denied? → show explanation → retry
7. VPN (for Kill Switch) → denied? → show explanation → retry

If ANY permission denied: device is LINKED but DEGRADED. Father sees warning.

---

## 6. Sync State Machine (Offline-First)

```
┌──────────┐    connectivity     ┌──────────┐    sync success    ┌──────────┐
│ OFFLINE  │ ←─────────────────→ │ ONLINE   │ ────────────────→ │ SYNCED   │
│ (queued) │                     │ (active) │                    │ (clean)  │
└────┬─────┘                     └────┬─────┘                    └──────────┘
     │                                │ conflict detected
     │                                ▼
     │                           ┌──────────┐
     │                           │ CONFLICT │
     │                           │ (resolve)│
     │                           └────┬─────┘
     │                                │ resolved
     └←───────────────────────────────┘
```

| State | Queue Status | User Indicator |
|-------|-------------|----------------|
| OFFLINE | Operations queued in Drift | Offline banner (subtle, top) |
| ONLINE | Flushing queue | Sync spinner (brief) |
| SYNCED | Queue empty | No indicator (normal) |
| CONFLICT | Conflict detected | Dialog: "تعارض في البيانات — [اختر الإصدار]" |

**Conflict resolution by data type:**
- Messages: Append-only (no conflict possible)
- Calendar events: Last-writer-wins
- Screen time rules: Father's device authoritative
- Points/XP: Server-authoritative (recalculate)
- Settings: Last-writer-wins

---

## 7. Content Alert Flow State Machine

```
┌──────────┐   AI-002 detects    ┌──────────┐   severity check   ┌──────────┐
│ MESSAGE  │ ──────────────────→ │ ANALYZED │ ────────────────→ │ LOW_RISK │
│ SENT     │                     │ (AI-002) │                    │ (log only)│
└──────────┘                     └────┬─────┘                    └──────────┘
                                      │ high risk
                                      ▼
                                 ┌──────────┐   FCM to parent   ┌──────────┐
                                 │ ALERT    │ ────────────────→ │ PARENT   │
                                 │ TRIGGERED│                    │ NOTIFIED │
                                 └──────────┘                    └────┬─────┘
                                                                      │ parent opens
                                                                      ▼
                                                                 ┌──────────┐
                                                                 │ ALERT    │
                                                                 │ REVIEWED │
                                                                 └────┬─────┘
                                                                      │ dismiss / act
                                                                      ▼
                                                                 ┌──────────┐
                                                                 │ RESOLVED │
                                                                 └──────────┘
```

**Alert escalation rule:**
- 3 consecutive negative sentiments in 24h → escalated alert (higher severity)
- Bullying_risk = true → immediate high-severity alert
- Parent has 24h to review before re-escalation

---

## 8. Focus Mode State Machine

```
┌──────────┐   child starts     ┌──────────┐    timer ends     ┌──────────┐
│  IDLE    │ ─────────────────→ │  ACTIVE  │ ───────────────→ │ COMPLETE │
│          │                     │  (timer) │                    │ (report) │
└──────────┘                     └────┬─────┘                    └──────────┘
                                      │ child ends early / distraction
                                      ▼
                                 ┌──────────┐
                                 │ ENDED    │
                                 │ EARLY    │
                                 └──────────┘
```

**Active state actions:**
- Block all non-educational apps (via S-PAR app_rules)
- Start countdown timer (default 25 min)
- Track distractions (notifications, app switch attempts)
- Compute focus score at end
- Award XP based on duration + focus score

---

## 9. Quran Recitation Flow State Machine

```
┌──────────┐  child selects    ┌──────────┐  press record    ┌──────────┐
│  IDLE    │ ────────────────→ │  READY   │ ───────────────→ │RECORDING │
│          │   surah+ayah      │          │                  │          │
└──────────┘                   └──────────┘                  └────┬─────┘
                                                                 │ stop
                                                                 ▼
                                                           ┌──────────┐
                                                           │ UPLOADING│
                                                           │ (to cloud)│
                                                           └────┬─────┘
                                                                │ uploaded
                                                                ▼
                     ┌──────────┐    analysis    ┌──────────┐
                     │ RESULT   │ ←───────────── │ANALYZING │
                     │ SHOWN    │                │(Whisper+ │
                     │(accuracy)│                │ Gemini)  │
                     └──────────┘                └──────────┘
```

**Critical privacy rule:**
- Audio is DELETED after analysis — never stored permanently
- Only accuracy score + error list saved to `quran_memorization`
- Pass threshold: accuracy ≥ 80% → status = "memorized"

---

## 10. Kill Switch State Machine

```
┌──────────┐  father toggles   ┌──────────┐  timer expires   ┌──────────┐
│ INACTIVE │ ────────────────→ │ ACTIVE   │ ───────────────→ │ INACTIVE │
│          │                    │(internet │                   │(auto)    │
└──────────┘                    │  paused) │                   └──────────┘
                                └────┬─────┘
                                     │ father deactivates
                                     ▼
                                ┌──────────┐
                                │ INACTIVE │
                                └──────────┘
```

**Active state:**
- Local VPN blocks all internet traffic on child's device
- Educational apps can be whitelisted (if father configures)
- Phone calls still work (VPN only blocks data)
- SOS still works (bypasses VPN)
- Child sees notification: "تم إيقاف الإنترنت بواسطة والدك"

**Scheduled pause option:**
- Father can set: pause for X minutes/hours → auto-resume
- Or: pause until manually deactivated
- Audit log: every activation/deactivation logged with actor + duration
