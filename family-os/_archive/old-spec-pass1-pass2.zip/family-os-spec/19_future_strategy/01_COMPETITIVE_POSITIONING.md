---
title: "Competitive Positioning & Differentiation"
tags: [competitive, differentiation, moat, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification
---

# Competitive Positioning & Differentiation

---

## 1. Competitive Landscape

### Direct Competitors

| Competitor | Strength | Weakness | Price |
|-----------|----------|----------|-------|
| Bark | 29 categories, 30+ platforms, AI | No comms, no education, no Arabic | $14/mo |
| Qustodio | Web filter, internet pause | No AI, no education, no comms | $54.95/yr |
| FamiSafe | Most comprehensive monitoring | No comms, no education, no AI | $9.99/mo |
| Google Family Link | Free, School Time | No content monitoring, no AI | Free |
| Life360 | Location, crash detection, driving | No comms content, no monitoring | $4.99–14.99 |
| Cozi | Family organizer, calendar, meals | No chat, no monitoring, no education | $29.99/yr |
| Kroha | Anti-bypass, analytics | No AI, no Arabic | Emerging |

### Indirect Competitors

| Competitor | Space |
|-----------|-------|
| WhatsApp | Family communication |
| Khan Academy / Khanmigo | Education + AI tutor |
| Duolingo | Gamified learning |
| IXL | Adaptive learning |

---

## 2. Competitive Parity Analysis

### Must Match (Competitor Parity)

| Capability | Our Status | Benchmark |
|-----------|-----------|-----------|
| Screen time limits + schedules | ✅ | Qustodio, Family Link |
| App blocking | ✅ | FamiSafe, Qustodio |
| Web filtering | ✅ | Norton, Qustodio |
| GPS tracking | ✅ | Life360, FamiSafe |
| Geofences | ✅ | Life360, FamiSafe |
| Content alerts | ✅ (29 categories) | Bark |
| Kill Switch (internet pause) | ✅ | Qustodio |
| School Time | ✅ | Google Family Link |
| Anti-bypass | ✅ | Kroha |
| SOS | ✅ | FamiSafe, Life360 |
| Family chat | ✅ | WhatsApp |
| Family calendar | ✅ | Cozi |
| Task/shopping lists | ✅ | Cozi, OurHome |
| Subscription + trial | ✅ | Industry standard |
| Notifications | ✅ | Industry standard |

### Better Than Competitors

| Capability | Our Advantage |
|-----------|--------------|
| Integration | 5 systems in ONE app (no competitor matches) |
| Arabic-first | RTL + Arabic content + Arabic AI (no competitor) |
| Hierarchical roles | Father/Mother/Child with mother_permissions (no competitor) |
| Hijri calendar | Mandatory Hijri + Gregorian (no competitor) |
| Quran memorization + AI | Whisper + Gemini recitation analysis (globally unique) |
| AI tutor in Arabic | Gemini Socratic tutor in Arabic (no competitor) |
| Sentiment analysis | Arabic sentiment from family messages (no competitor) |
| Adaptive learning | Placement + adaptive path + XP (integrated, not standalone) |
| Focus Mode integrated | Blocks apps via monitoring bridge (no competitor integrates) |
| Today Dashboard | Unified parent view aggregating all systems (no competitor) |

### Differentiators (Defensible)

| Differentiator | Why It's Hard to Copy |
|---------------|----------------------|
| 5-system integration | Deep architectural coupling; can't bolt on |
| Arabic AI models | Requires Arabic NLP investment + training data |
| Quran recitation AI | Requires Whisper + Gemini + Quran text matching — niche expertise |
| mother_permissions | Requires hierarchical role model from ground up |
| Family Context | Real-time projection across all domains — architectural |
| Hijri calendar integration | Requires calendar system + date conversion throughout |

### Strategic Moat

> **The Family Operating System concept itself is the moat.** Competitors build tools; we build a platform. Copying any single feature is easy; copying the integration + Arabic + AI + roles + Hijri together requires rebuilding from scratch.

---

## 3. Feature Gap Analysis (From Competitive Research)

### 64 New Features Extracted from Competitors

| System | New Features | Added to P0 | Added to P1–P3 |
|--------|-------------|-------------|-----------------|
| Monitoring | 18 | 4 (Kill Switch, Anti-bypass, 29 categories, School Time) | 14 |
| Communications | 12 | 4 (Voice transcription, translation, reactions, chat lock) | 8 |
| Education | 14 | 4 (Adaptive, placement, exercises, XP) | 10 |
| AI | 9 | 1 (Smart recommendations) | 8 |
| Management | 11 | 3 (Today dashboard, school schedule, trial) | 8 |
| **Total** | **64** | **16** | **48** |

> **Principle applied:** Each feature was evaluated against "Does it serve the Family OS?" — not blindly copied. Features that serve the family were added; features that don't were rejected or deferred.

---

## 4. Market Position

```
         Integration Level
              HIGH
               │
    ┌──────────┼──────────┐
    │   US     │  ★ OUR    │
    │ (future) │  PLATFORM │
    │          │  Arabic +  │
    │          │  AI +      │
    │          │  Quran     │
    ───────────┼───────────│──────
    │          │           │
    │  Cozi    │  Bark     │
    │ (organize│  (monitor │
    │  only)   │   only)   │
    │          │           │
    └──────────┼──────────┘
              LOW
         LOW ←───→ HIGH
           Arabic Support
```

**We occupy the top-right quadrant: high integration + high Arabic support. No competitor is nearby.**
