---
title: "Open Decisions Register"
tags: [open, decisions, questions, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification
---

# Open Decisions Register

> Items that cannot be resolved from the source files and require human decision. Each has a recommended option with rationale.

---

## OD-001: Google Play Accessibility Policy

| Field | Value |
|-----------|-------|
| **Question** | Will Google Play accept AccessibilityService usage for content monitoring + app blocking? |
| **Why it matters** | Core monitoring features (app blocking, content alerts, anti-bypass) depend on AccessibilityService. If rejected, the product cannot function. |
| **Affected systems** | Safety & Monitoring (S-PAR-015/017/021/038/041/045/052) |
| **Options** | (A) Submit with strong justification + promo video · (B) Use DevicePolicyManager only (limited) · (C) Distribute outside Play Store |
| **Recommended** | A — Submit with justification; Google allows Accessibility for parental control with proper disclosure |
| **Impact** | High — blocking risk for core features |
| **Priority** | Critical — resolve before development |

---

## OD-002: Google Play SMS Policy

| Field | Value |
|-----------|-------|
| **Question** | Will Google Play approve READ_SMS for SMS monitoring? |
| **Why it matters** | SMS monitoring (S-PAR-027) is P1, but policy affects architecture decisions |
| **Affected systems** | Safety & Monitoring (S-PAR-027) |
| **Options** | (A) Request with strong justification · (B) Defer to P2+ or remove · (C) Use Accessibility to read SMS |
| **Recommended** | B — Defer |
| **Status** | ✅ **RESOLVED — 2026-09-14 (owner decision): option B.** `READ_SMS` is **removed from the manifest entirely**. It is requested by no screen and no service. |
| **Rationale** | Two independent reasons converge: (1) authentication no longer needs SMS at all (ADR-003 = email + password), so the permission lost its main pretext; (2) combining `READ_SMS` with `BIND_ACCESSIBILITY_SERVICE` in one submission compounds review risk on the single most sensitive request in the package (OD-001). Do not spend review capital on a P1 feature. |
| **Impact** | Medium — P1 feature deferred to P2+; Accessibility can capture message content in P1 without the SMS permission |
| **Priority** | Closed |

---

## OD-003: Gemini Cost at Scale

| Field | Value |
|-----------|-------|
| **Question** | What is the actual AI cost per user at scale (beyond estimates)? |
| **Why it matters** | Affects pricing, profitability, and feature gating |
| **Affected systems** | AI (all capabilities), Business Model |
| **Options** | (A) Negotiate enterprise pricing with Google · (B) Implement strict rate limiting · (C) Use Flash-Lite for non-critical |
| **Recommended** | A + B — Negotiate + strict rate limiting; monitor ai_cost_tracking closely |
| **Impact** | High — affects unit economics |
| **Priority** | High — resolve before scale |

---

## OD-004: School Partnership Strategy

| Field | Value |
|-----------|-------|
| **Question** | Should the platform integrate with school systems in MVP or defer? |
| **Why it matters** | School integration could be a strong B2B channel but adds complexity |
| **Affected systems** | Education, Administration |
| **Options** | (A) Defer to P2 · (B) MVP: basic school calendar import · (C) MVP: full school API |
| **Recommended** | A — Defer; focus on B2C first; school integration is P2 B2B expansion |
| **Impact** | Medium — B2B revenue path |
| **Priority** | Low — P2 |

---

## OD-005: 29 Categories — Final List

| Field | Value |
|-----------|-------|
| **Question** | Are the 29 content alert categories final, or will they expand? |
| **Why it matters** | Affects AI prompt design + classification model + UI |
| **Affected systems** | Safety & Monitoring (S-PAR-045), AI (AI-002) |
| **Options** | (A) 29 fixed for MVP · (B) Configurable per family · (C) Expand to 35+ |
| **Recommended** | A — 29 fixed for MVP; configurable is P1 |
| **Impact** | Low — categories are data-driven |
| **Priority** | Medium |

---

## OD-006: Translation Languages

| Field | Value |
|-----------|-------|
| **Question** | Which translation languages for MVP? |
| **Why it matters** | Affects Gemini prompt + cache keys |
| **Affected systems** | Communications (S-COM-044) |
| **Options** | (A) Arabic + English only · (B) 6 languages (AR/EN/FR/UR/TR/ES) · (C) Unlimited |
| **Recommended** | B — 6 languages covers target markets (Arab + future Islamic expansion) |
| **Impact** | Low — Gemini handles all |
| **Priority** | Low |

---

## OD-007: Kill Switch Legal Acceptability

| Field | Value |
|-----------|-------|
| **Question** | Is using local VPN for Kill Switch legally acceptable in target markets? |
| **Why it matters** | VPN usage may be regulated in some countries (e.g., Saudi Arabia, UAE) |
| **Affected systems** | Safety & Monitoring (S-PAR-041) |
| **Options** | (A) Legal review per market · (B) Use Accessibility only (no VPN) · (C) Use DNS filtering |
| **Recommended** | A — Legal review per market; use VPN where legal, Accessibility elsewhere |
| **Impact** | High — feature availability per market |
| **Priority** | High — before launch in each market |

---

## OD-008: Location-Stop Prevention Acceptability

| Field | Value |
|-----------|-------|
| **Question** | Is preventing child from stopping location sharing legally acceptable? |
| **Why it matters** | Core to monitoring; some jurisdictions may require consent for tracking |
| **Affected systems** | Safety & Monitoring (S-PAR-011), Family & Identity |
| **Options** | (A) Acceptable (parental authority) · (B) Require child consent at setup · (C) Allow opt-out at 13+ |
| **Recommended** | A — Acceptable under parental authority in target markets; COPPA compliant with parent consent |
| **Impact** | High — core feature |
| **Priority** | High — legal confirmation per market |

---

## OD-009: Trial Duration — 7 vs 14 Days

| Field | Value |
|-----------|-------|
| **Question** | Original analysis says 7-day trial; enhanced says 14-day; Constitution says 14-day. Final? |
| **Why it matters** | Affects conversion rate + revenue timing |
| **Affected systems** | Administration (S-ADM-038) |
| **Options** | (A) 7 days · (B) 14 days · (C) 30 days |
| **Recommended** | B — 14 days (Constitution frozen); industry trend favors longer trials for higher conversion |
| **Impact** | Low — configuration value |
| **Priority** | Resolved — Constitution freezes 14 days |

---

## OD-010: Child display_name Approval Workflow

| Field | Value |
|-----------|-------|
| **Question** | How does child display_name change get parent approval? |
| **Why it matters** | Original analysis mentions approval but no workflow defined |
| **Affected systems** | Family & Identity (S-ADM-006) |
| **Options** | (A) Auto-approve (no restriction) · (B) Permission request flow · (C) Father-only can edit child name |
| **Recommended** | A — Auto-approve for MVP; restriction adds complexity without clear value |
| **Impact** | Low |
| **Priority** | Low |

---

## OD-011: Multi-Tier Pricing Launch Timing

| Field | Value |
|-----------|-------|
| **Question** | When to introduce multi-tier pricing beyond single Premium? |
| **Why it matters** | Affects revenue optimization + market segmentation |
| **Affected systems** | Business Model |
| **Options** | (A) At launch · (B) 3 months post-launch · (C) 6 months post-launch based on data |
| **Recommended** | C — Launch with single Premium; introduce tiers based on conversion + usage data |
| **Impact** | Medium — revenue |
| **Priority** | P1 |

---

## OD-012: S-COM-052 ID Collision

| Field | Value |
|-----------|-------|
| **Question** | S-COM-052 is used for both "Restricted Chat (P0)" and "Custom Wallpaper (P2)" — which is canonical? |
| **Why it matters** | Service ID collision could cause confusion |
| **Affected systems** | Communications |
| **Options** | (A) S-COM-052 = Restricted Chat (P0) · (B) Renumber wallpaper to S-COM-053+ |
| **Recommended** | A — S-COM-052 = Restricted Chat (P0) per Constitution + Screen Catalog; wallpaper gets new ID if needed |
| **Impact** | Low — naming |
| **Priority** | Resolved — S-COM-052 = Chat Lock (P0) |
