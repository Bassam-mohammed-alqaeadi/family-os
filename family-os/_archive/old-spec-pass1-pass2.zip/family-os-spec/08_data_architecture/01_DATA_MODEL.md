---
title: "Unified Data Model"
tags: [data, architecture, ERD, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification
---

# Unified Data Model

> Rebuilt from scratch based on extracted entities, relationships, and requirements. The original ERD had 72 tables; this model preserves all entities while adding missing ones and normalizing relationships.

---

## 1. Storage Strategy

| Store | Technology | Purpose | Examples |
|-------|-----------|---------|----------|
| Relational | Cloud SQL (PostgreSQL + RLS) | System of record for structured data | Users, families, messages, assignments, rules |
| Real-time | Cloud Firestore | Live sync, presence, typing, locations | Presence, live locations, typing indicators |
| Cache | Redis | Translation cache, rate limiting, sessions | Cached translations, AI rate limits |
| Vector | Pinecone | AI RAG embeddings | Content embeddings for recommendations |
| Media | Firebase Storage | Files, images, audio, recordings | Message attachments, voice messages |
| Local | Drift (SQLite) | Offline-first cache, queue | All cached data, sync queue, pending operations |

---

## 2. Core Entities (System of Record)

### 2.1 Family & Identity

| Entity | PK | Key Attributes | Owner | Retention |
|--------|----|----------------|-------|-----------|
| `families` | id | name, owner_id, country_code, subscription_tier, locale, hijri_enabled, created_at | Father | Until family deletion |
| `users` | id | email, display_name, avatar_url, role, grade_level, birth_date, is_active, created_at | Self/Father | 30-day grace after deletion |
| `family_members` | id | family_id, user_id, role, permissions(jsonb), status, joined_at | Father | Soft delete |
| `devices` | id | family_id, user_id, device_name, model, os_version, is_monitored, last_sync_at | Father | Until unlinked |
| `invitations` | id | family_id, email, role, permissions(jsonb), status, expires_at | Father | 7 days then expired |
| `subscriptions` | id | family_id, plan_tier, billing_cycle, current_period_start/end, auto_renew, status | Father | Until expiry + 90 days |
| `subscription_trials` | id | family_id, started_at, expires_at, status | System | 90 days after expiry |

### 2.2 Communications

| Entity | PK | Key Attributes | Owner | Retention |
|--------|----|----------------|-------|-----------|
| `conversations` | id | family_id, type(family/1:1/subgroup), title, avatar_url, disappearing_after_hours, created_by | Creator | Until family deletion |
| `conversation_members` | id | conversation_id, user_id, role, permissions(jsonb) | Father | Soft delete |
| `messages` | id | conversation_id, sender_id, body, message_type, reply_to_id, scheduled_at, is_deleted, sent_at | Sender | Soft delete; hard delete 90 days |
| `message_attachments` | id | message_id, file_url, file_type, file_size, thumbnail_url, duration_ms | Sender | With message |
| `message_reads` | id | message_id, user_id, read_at | Reader | With message |
| `message_reactions` | id | message_id, user_id, emoji | Reactor | Until removed |
| `message_translations` | id | message_id, target_lang, translated_text, created_at | System | 30 days |
| `voice_transcriptions` | id | message_id, transcribed_text, language, confidence | System | With message |
| `family_events` | id | family_id, title, hijri_date, gregorian_date, time, attendees, reminder_minutes, created_by | Creator | Until deleted |
| `family_tasks` | id | family_id, title, assigned_to, due_date, priority, completed, completed_at | Creator | 90 days after completion |
| `shopping_list_items` | id | family_id, name, category, added_by, checked, checked_by | Any member | Until checked + 7 days |
| `emergency_events` | id | family_id, user_id, type(sos/crash), lat, lng, triggered_at, resolved_at, resolution | System | 1 year |

### 2.3 Safety & Monitoring

| Entity | PK | Key Attributes | Owner | Retention |
|--------|----|----------------|-------|-----------|
| `screen_time_rules` | id | user_id, daily_limit_minutes, day_of_week, bedtime_start/end, is_active | Father | Until changed |
| `screen_time_usage` | id | user_id, date, total_minutes, app_breakdown(jsonb) | System | 90 days |
| `app_rules` | id | user_id, package_name, app_name, status(blocked/allowed/timer), category | Father | Until changed |
| `app_usage_logs` | id | user_id, package_name, date, minutes_used, sessions_count | System | 90 days |
| `web_history` | id | user_id, url, title, blocked, timestamp | System | 60 days |
| `web_filter_exceptions` | id | family_id, url, type(allow/block) | Father | Until changed |
| `geofences` | id | family_id, user_id, name, lat, lng, radius_meters, type, notify_on_enter/exit, is_active | Father | Until deleted |
| `geofence_events` | id | geofence_id, user_id, event_type(enter/exit), timestamp | System | 30 days |
| `locations` | id | user_id, lat, lng, accuracy, speed, battery, timestamp | System | 30 days live; BigQuery archive |
| `content_alerts` | id | user_id, app_name, category, severity, recommendation, timestamp | System | 90 days |
| `social_media_alerts` | id | user_id, app_name, alert_type, severity, keywords_matched, timestamp | System | 90 days |
| `anti_bypass_events` | id | user_id, attempt_type, detected_at, resolved_at | System | 1 year |
| `internet_pause_events` | id | user_id, activated_by, activated_at, deactivated_at, duration_minutes | Father | 90 days |
| `school_time_schedules` | id | family_id, user_id, day_of_week, start_time, end_time, is_active | Father | Until changed |
| `permission_requests` | id | user_id, request_type, request_data(jsonb), status, reviewed_by, reviewed_at | Child/Father | 90 days |
| `mother_permissions` | id | family_id, mother_id, granted_by, permission_key, is_granted, granted_at | Father | Until changed |

### 2.4 Education

| Entity | PK | Key Attributes | Owner | Retention |
|--------|----|----------------|-------|-----------|
| `subjects` | id | family_id, user_id, name, grade_level, icon, color, order_index, is_deleted | Father/Mother | Soft delete |
| `lessons` | id | subject_id, title, content_type, content, order_index, is_deleted | Father/Mother | Soft delete |
| `lesson_completions` | id | lesson_id, user_id, completed_at, points_earned | System | Until account deletion |
| `assignments` | id | subject_id, title, description, type, due_hijri_date, due_gregorian_date, questions(jsonb), created_by | Father/Mother | Soft delete |
| `assignment_submissions` | id | assignment_id, user_id, answers(jsonb), status, grade, total_points, feedback, graded_by, submitted_at, graded_at | Child/System | 1 year |
| `quizzes` | id | subject_id, title, time_limit_minutes, passing_score, shuffle, created_by | Father/Mother | Soft delete |
| `quiz_questions` | id | quiz_id, question_type(mcq/true_false/short_answer/essay), question, options(jsonb), correct_answer, points | Father/Mother | With quiz |
| `quiz_attempts` | id | quiz_id, user_id, answers(jsonb), score, passed, started_at, completed_at | Child | 1 year |
| `learning_progress` | id | user_id, subject_id, overall_progress_percent, lessons_completed, last_activity | System | Until account deletion |
| `adaptive_learning_state` | id | user_id, subject_id, current_level, consecutive_correct, consecutive_wrong, last_exercise_at | System | Until account deletion |
| `adaptive_exercises` | id | user_id, subject_id, level, question, options(jsonb), correct_answer, is_answered, is_correct | System | 90 days |
| `placement_tests` | id | user_id, subject_id, questions(jsonb), answers(jsonb), result_level, weak_areas, strong_areas, completed_at | System | Until account deletion |
| `reward_transactions` | id | user_id, points, reason, type(earned/redeemed), created_at | System | 1 year |
| `user_xp` | id | user_id, total_xp, level, current_level_xp, next_level_xp | System | Until account deletion |
| `badges` | id | name, description, icon, category, requirement | System | — |
| `user_badges` | id | user_id, badge_id, earned_at | System | Until account deletion |
| `focus_sessions` | id | user_id, subject_id, planned_duration, actual_duration, started_at, ended_at, focus_score, distractions_count | Child | 90 days |
| `quran_memorization` | id | user_id, surah_number, surah_name, from_ayah, to_ayah, total_ayahs, status, progress_percent, memorized_at | Child | Until account deletion |
| `quran_revisions` | id | memorization_id, scheduled_date, completed, accuracy_percent | System | Until account deletion |
| `ai_tutor_sessions` | id | user_id, subject_id, messages(jsonb), started_at, ended_at | Child | 90 days |

### 2.5 AI

| Entity | PK | Key Attributes | Owner | Retention |
|--------|----|----------------|-------|-----------|
| `ai_conversations` | id | user_id, conversation_type, title, created_at | User | 90 days |
| `ai_messages` | id | conversation_id, user_id, content, role(user/assistant), metadata(jsonb), created_at | User | With conversation |
| `ai_usage_logs` | id | user_id, feature, model, input_tokens, output_tokens, cost_usd, created_at | System | 1 year |
| `ai_cost_tracking` | id | family_id, date, total_cost_usd, feature_breakdown(jsonb) | System | 1 year |
| `sentiment_logs` | id | message_id, user_id, sentiment, intensity, bullying_risk, recommendation, analyzed_at | System | 90 days — NO message text |
| `ai_recommendations` | id | user_id, type, content_ref, reason, status(generated/shown/accepted/dismissed/expired), created_at | System | 90 days |
| `content_embeddings` | id | content_type, content_id, content_text, embedding(vector), created_at | System | Until content deleted |

### 2.6 Administration

| Entity | PK | Key Attributes | Owner | Retention |
|--------|----|----------------|-------|-----------|
| `notifications` | id | family_id, user_id, type, title, body, data(jsonb), priority, is_read, read_at, created_at | System | 90 days |
| `notification_preferences` | id | user_id, type, enabled, quiet_hours_start, quiet_hours_end | User | Until changed |
| `family_settings` | id | family_id, locale, calendar_mode, timezone, week_start, hijri_adjustment | Father | Until changed |
| `user_settings` | id | user_id, theme, font_size, locale, auto_translate, translate_to | User | Until changed |
| `privacy_settings` | id | family_id, store_child_texts, child_transparency_level, data_retention_days | Father | Until changed |
| `audit_logs` | id | family_id, actor_id, action, target_type, target_id, metadata(jsonb), timestamp | System | 1 year |

---

## 3. Firestore Collections (Real-time)

| Collection | Document Key | Fields | Purpose |
|------------|-------------|--------|---------|
| `families/{id}/presence` | user_id | status, last_seen, device_type | Online status |
| `families/{id}/locations` | user_id | lat, lng, accuracy, speed, battery, updated_at | Live location |
| `families/{id}/typing` | conversation_id:user_id | is_typing, started_at | Typing indicator |
| `families/{id}/shopping_list` | item_id | name, category, checked, added_by | Real-time shopping list |
| `calls/{id}/signaling` | event_id | type, sdp, ice, from, to | WebRTC signaling |
| `calls/{id}/ice_candidates` | candidate_id | candidate, sdp_mid, sdp_m_line_index | ICE exchange |

---

## 4. System of Record

| Data Type | System of Record | Sync To |
|-----------|------------------|---------|
| Family/members/roles | Cloud SQL | Drift (cache) |
| Messages | Cloud SQL + Firestore | Drift (cache) |
| Media | Firebase Storage | — |
| Screen time rules | Cloud SQL | Drift (enforce offline) |
| Usage logs | Drift → Cloud SQL (sync) | BigQuery (archive) |
| Location | Firestore (live) → Cloud SQL (history) | Drift (cache) |
| Geofence events | Cloud SQL | Firestore (system messages) |
| Assignments | Cloud SQL | Drift (cache) |
| Quiz attempts | Cloud SQL | — |
| Points/XP/badges | Cloud SQL | Drift (cache) |
| AI conversations | Cloud SQL | — |
| Sentiment logs | Cloud SQL | — (NO message text) |
| Notifications | Cloud SQL + FCM | Drift (cache) |
| Settings | Cloud SQL | Drift (enforce offline) |
| Audit logs | Cloud SQL | — (append-only) |

---

## 5. Key Relationships

```
Family ||--o{ FamilyMember
FamilyMember }o--|| User
User ||--o{ Device
Family ||--o{ Conversation
Conversation ||--o{ ConversationMember
ConversationMember }o--|| User
Conversation ||--o{ Message
Message }o--o| Message (reply_to)
Message ||--o{ MessageAttachment
Message ||--o{ MessageRead
Message ||--o{ MessageReaction
Message ||--o{ MessageTranslation
Message ||--o{ VoiceTranscription
Message }o--|| SentimentLog (behind scenes)
Family ||--o{ FamilyEvent
Family ||--o{ FamilyTask
Family ||--o{ ShoppingListItem
Family ||--o{ EmergencyEvent
User ||--o{ ScreenTimeRule
User ||--o{ AppRule
User ||--o{ ScreenTimeUsage
Family ||--o{ Geofence
Geofence ||--o{ GeofenceEvent
User ||--o{ Location
User ||--o{ ContentAlert
User ||--o{ SocialMediaAlert
User ||--o{ AntiBypassEvent
User ||--o{ InternetPauseEvent
Family ||--o{ SchoolTimeSchedule
User ||--o{ PermissionRequest
Family ||--o{ MotherPermission
User ||--o{ Subject
Subject ||--o{ Lesson
Lesson ||--o{ LessonCompletion
Subject ||--o{ Assignment
Assignment ||--o{ AssignmentSubmission
Subject ||--o{ Quiz
Quiz ||--o{ QuizQuestion
Quiz ||--o{ QuizAttempt
User ||--o{ LearningProgress
User ||--o{ AdaptiveLearningState
User ||--o{ AdaptiveExercise
User ||--o{ PlacementTest
User ||--o{ RewardTransaction
User ||--|| UserXP
User ||--o{ UserBadge
User ||--o{ FocusSession
User ||--o{ QuranMemorization
QuranMemorization ||--o{ QuranRevision
User ||--o{ AITutorSession
User ||--o{ AIConversation
AIConversation ||--o{ AIMessage
User ||--o{ AIUsageLog
User ||--o{ AIRecommendation
Family ||--o{ Notification
User ||--o{ NotificationPreference
Family ||--|| FamilySetting
User ||--|| UserSetting
Family ||--|| PrivacySetting
Family ||--o{ AuditLog
```

---

## 6. Data Sensitivity Classification

| Sensitivity | Entities | Handling |
|-------------|----------|----------|
| **Public** | Family name, subject names | No encryption at rest needed |
| **Internal** | Messages, calendar events, tasks | TLS in transit, AES-256 at rest |
| **Confidential** | User profiles, device info, location | TLS + AES-256 + RLS |
| **Restricted** | Content alerts, sentiment logs, anti-bypass events | TLS + AES-256 + RLS + audit + NO raw text |
| **Critical** | Child personal data (messages, recitations) | TLS + AES-256 + RLS + audit + deletion after processing + NO raw text to AI logs |
