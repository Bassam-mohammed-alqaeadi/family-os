# Family OS — Edge Cases & Error States

> **Document status:** Comprehensive edge case and error state design
> **Scope:** Network, permissions, accounts, data, safety, education, communication, concurrency, device, compliance
> **Design principle:** Every error is recoverable, every failure is communicable, every edge case is designed — never defaulted

---

## Table of Contents

1. [Network States](#1-network-states)
2. [Permission States](#2-permission-states)
3. [Account States](#3-account-states)
4. [Data States](#4-data-states)
5. [Safety Edge Cases](#5-safety-edge-cases)
6. [Education Edge Cases](#6-education-edge-cases)
7. [Communication Edge Cases](#7-communication-edge-cases)
8. [Concurrency Edge Cases](#8-concurrency-edge-cases)
9. [Device Edge Cases](#9-device-edge-cases)
10. [Compliance Edge Cases](#10-compliance-edge-cases)

---

## 1. Network States

### EC-NET-01 — Complete Offline (انقطاع كامل للإنترنت)

| Field | Value |
|---|---|
| **Scenario** | User opens or uses the app with no network connectivity at all |
| **Current state** | App is operational; user is interacting with a screen |
| **Trigger** | Network connection lost (Wi-Fi off, mobile data off, airplane mode, no coverage) |
| **Expected system behavior** | 1) Detect network loss within 5 s via connectivity monitor. 2) Switch to offline mode: Tier 1-2 features continue locally, Tier 3-4 features show "يتطلب اتصالاً" state. 3) Queue all mutations (sends, edits, rule changes) to local outbox. 4) Show non-intrusive offline banner "غير متصل — التغييرات تُحفظ محليًا". 5) Suppress non-critical background sync attempts. |
| **User-facing UI** | Yellow offline banner at top of screen (below header); Tier 3-4 actions replaced with "يتطلب اتصالاً بالإنترنت" label; queued sends show "قيد الإرسال" status; no error toasts for background failures |
| **Recovery path** | On reconnect: 1) Detect connection. 2) Remove banner. 3) Flush outbox in FIFO order. 4) Trigger delta sync. 5) Show "تمت المزامنة" toast. |
| **Prevention** | Aggressive local caching of last 7 days of data; prefetch critical content (lessons, schedules); offline-capable architecture from ground up |

### EC-NET-02 — Poor Connection (اتصال ضعيف)

| Field | Value |
|---|---|
| **Scenario** | User has network but throughput is very low or latency very high (2G, congested Wi-Fi, roaming) |
| **Current state** | App attempting data operations |
| **Trigger** | Request timeout (>10 s) or throughput <10 KB/s detected |
| **Expected system behavior** | 1) Switch to low-bandwidth mode: reduce image quality, defer media uploads, batch small requests. 2) Increase request timeout to 30 s. 3) Prioritize critical data (SOS, alerts, location) over non-critical (recommendations, history). 4) Show degraded quality indicator. |
| **User-facing UI** | Amber "اتصال ضعيف" indicator; images load at reduced resolution; media upload shows "جارٍ الرفع (قد يستغرق وقتًا)"; voice transcription deferred "سيتم التفريغ عند تحسن الاتصال" |
| **Recovery path** | On bandwidth improvement: auto-switch to normal mode, resume deferred operations, increase quality |
| **Prevention** | Adaptive quality based on connection class; request prioritization; differential sync (only changed fields, not full entities) |

### EC-NET-03 — Reconnection Sync (إعادة المزامنة بعد الاتصال)

| Field | Value |
|---|---|
| **Scenario** | Device regains connectivity after an offline period; local changes need to sync to server and server changes need to pull to device |
| **Current state** | Device has been offline (minutes to hours); local outbox has queued mutations; server may have new data from other family devices |
| **Trigger** | Network connectivity restored |
| **Expected system behavior** | 1) Detect connection. 2) Perform handshake: send device's last-sync timestamp. 3) Server responds with delta (changes since last-sync). 4) Apply server delta to device. 5) Flush local outbox to server in FIFO order. 6) Resolve any conflicts (see EC-NET-04). 7) Update last-sync timestamp. 8) Emit "synced" event. |
| **User-facing UI** | Brief "جارٍ المزامنة…" indicator (non-blocking, 2 s max visible); then "تمت المزامنة" toast; any new data appears in relevant screens |
| **Recovery path** | N/A (this IS the recovery from offline) |
| **Prevention** | Delta sync (not full refresh); idempotent mutations; sync window tracking per entity type |

### EC-NET-04 — Sync Conflict (تعارض المزامنة)

| Field | Value |
|---|---|
| **Scenario** | Two family members edit the same entity while offline (or near-simultaneously online); both sync and conflict arises |
| **Current state** | Two different versions of the same entity exist on two devices, both syncing to server |
| **Trigger** | Server receives a mutation for an entity that has been modified since the client's last-sync timestamp |
| **Expected system behavior** | 1) Server detects version mismatch. 2) Apply conflict resolution strategy per entity type: • **Last-write-wins** (messages, task completion, location): highest timestamp wins. • **Merge** (shopping list, calendar events): union of non-overlapping changes. • **Field-level merge** (settings, rules): per-field last-write-wins. • **Manual resolution** (critical family settings): both versions preserved, both clients notified. 3) Log conflict in audit trail. 4) Push resolved version to all devices. |
| **User-facing UI** | Auto-resolved: no notification (seamless). Manual: "حدث تعارض في [entity]. نسختك: A. نسخة [other]: B. اختر:" with both versions displayed and "احتفظ بنسختي" / "استخدم نسخة [other]" / "ادمج" options |
| **Recovery path** | Resolved version propagated to all devices; audit trail preserves both versions for 30 days |
| **Prevention** | Optimistic concurrency control with version vectors; real-time WebSocket updates reduce offline divergence window; field-level versioning for complex entities |

---

## 2. Permission States

### EC-PERM-01 — Permission Denied (رفض الإذن)

| Field | Value |
|---|---|
| **Scenario** | User denies a permission requested by the app (location, microphone, camera, contacts, notifications) |
| **Current state** | App needs a permission to perform an action; user was shown system permission dialog |
| **Trigger** | User taps "رفض" / "Deny" on system permission dialog |
| **Expected system behavior** | 1) Record permission state as "denied". 2) Feature requiring permission enters degraded mode. 3) Do NOT immediately re-prompt (Android may suppress after 2 denials). 4) Show rationale card on the affected screen explaining why the permission is needed and what the user misses. 5) Provide "السماح" button that opens system app settings (not re-prompting system dialog directly). 6) Continue operating with reduced functionality. |
| **User-facing UI** | Rationale card: permission icon + "نحتاج [permission] من أجل [purpose]. بدونها: [consequence]." + "السماح" (→ system settings) + "تجاهل" (accept degraded mode). Degraded features show a small lock/minus icon. |
| **Recovery path** | User opens system settings → grants permission → returns to app → app detects permission now granted → enables feature → removes rationale card → toast "تم تفعيل [feature]" |
| **Prevention** | Pre-permission rationale (explain before requesting); contextual requests (ask when user attempts the action, not on startup); graceful degradation design for every permission-dependent feature |

### EC-PERM-02 — Permission Revoked Mid-Session (إلغاء الإذن أثناء الاستخدام)

| Field | Value |
|---|---|
| **Scenario** | User grants a permission, uses the app, then revokes it from system settings while the app is running |
| **Current state** | App is running with a previously-granted permission; user revokes from Android Settings > App > Permissions |
| **Trigger** | App's permission check returns "denied" on next access attempt (or Android's `onPermissionsResult` callback for runtime revocation) |
| **Expected system behavior** | 1) Detect permission revocation on next API call requiring it. 2) Stop the affected feature immediately. 3) Release any resources held (camera, mic, location updates). 4) Enter degraded mode for that feature. 5) Show rationale card on next access. 6) If the revoked permission is critical for child monitoring (location, accessibility, device admin), alert the parent device: "تم إلغاء إذن [permission] على جهاز طفلك" — Anti-bypass detection (SCR-PAR-12). |
| **User-facing UI** | Feature stops silently; rationale card appears on next attempt; parent notification for child device permission revocation |
| **Recovery path** | Same as EC-PERM-01 (user re-grants from settings) |
| **Prevention** | Periodic permission health checks (every 5 min on child device); parent alerts on critical permission revocation; Anti-bypass monitors for permission tampering |

### EC-PERM-03 — Re-prompt Flow (إعادة طلب الإذن)

| Field | Value |
|---|---|
| **Scenario** | User previously denied a permission (possibly with "Don't ask again"); app needs to guide them to re-grant it |
| **Current state** | Permission state is "denied" or "permanently denied" (Android won't show system dialog anymore) |
| **Trigger** | User attempts an action requiring the denied permission, or app identifies the permission is needed for a critical feature |
| **Expected system behavior** | 1) Detect "permanently denied" state (system dialog won't show). 2) Show enhanced rationale card with: icon, purpose explanation, what they're missing, and "افتح الإعدادات" button. 3) "افتح الإعدادات" launches `ACTION_APPLICATION_DETAILS_SETTINGS` intent deep-linked to the app. 4) On user return from settings, re-check permission state. 5) If granted: enable feature + success toast. 6) If still denied: show "لا يزال الإذن مرفوضًا" + retry option. |
| **User-facing UI** | Enhanced rationale card → system settings → return → check → success/retry. Non-blocking, user-driven (no forced loops). |
| **Recovery path** | User grants in system settings → returns → feature enabled |
| **Prevention** | Explain permission value BEFORE first request (pre-rationale); request in context (when user needs it, not preemptively); never spam re-prompts |

## 3. Account States

### EC-ACC-01 — Trial Expired (انتهاء التجربة المجانية)

| Field | Value |
|---|---|
| **Scenario** | Family's free trial period ends without conversion to paid subscription |
| **Current state** | Trial was active; all premium features were available; trial end date reached |
| **Trigger** | Server-side cron checks trial end date; client receives trial-expired push notification or detects on next sync |
| **Expected system behavior** | 1) Server marks trial as "expired". 2) Push notification to all parents: "انتهت تجربتك المجانية". 3) Client switches to free-tier feature gating: • Free-tier features remain accessible per `12_business` §3.1 (messaging, calls, calendar, tasks, **basic screen time = daily total + top 5 apps**, **live location + 24 h history**, 1 safe zone, basic learning, **SOS and critical-safety alerts — never gated**). • Premium features (AI Tutor, AI Assistant, AI recommendations, adaptive learning, translation, advanced analytics, voice transcription, Tajweed analysis) show Violet lock icon → route to SCR-ADM-04. 4) Today Dashboard shows banner "تجربتك انتهت — اشترك للمتابعة" with paywall CTA. 5) No data loss — all data preserved, only access gated. 6) Graceful degradation: in-progress premium sessions complete, new ones blocked. |
| **User-facing UI** | Trial-expired banner on Today Dashboard; Violet lock icons on all premium features; tapping locked feature → SCR-ADM-04 paywall with plans; degraded experience clearly communicated; no error toasts — designed state, not an error |
| **Recovery path** | User subscribes (SCR-ADM-04) → premium features immediately unlocked → banner removed → all data still accessible |
| **Prevention** | Trial countdown notifications at 7, 3, 1, 0 days; "اشترك الآن" CTAs throughout trial; trial-extension promotions possible |

### EC-ACC-02 — Subscription Lapsed (انتهاء الاشتراك)

| Field | Value |
|---|---|
| **Scenario** | Paid subscription ends (cancellation effective, billing failure past grace period, voluntary cancellation end of billing cycle) |
| **Current state** | Subscription was "active"; billing cycle ended or cancellation took effect |
| **Trigger** | Server-side subscription state change (Google Play billing callback, or cron check) |
| **Expected system behavior** | 1) Server marks subscription as "lapsed" or "cancelled". 2) Check for grace period (Google Play offers up to 30 days for payment issues): • Within grace: features continue, banner "اشتراكك في فترة سماح — حدّث طريقة الدفع". • Grace expired: same behavior as EC-ACC-01 (trial expired gating). 3) Push notification to purchasing parent. 4) All data preserved. 5) Re-subscription restores immediate access. |
| **User-facing UI** | Grace period: amber banner "فترة السماح — X أيام متبقية" + "حدّث الدفع" CTA. Lapsed: same as trial-expired state. |
| **Recovery path** | User updates payment method (Google Play) → Google Play retries billing → success → subscription reactivated → features unlocked. Or user manually re-subscribes via SCR-ADM-04. |
| **Prevention** | Pre-expiry notifications (7, 3, 1 day); payment method update prompts; grace period utilization; easy re-subscription flow |

### EC-ACC-03 — Payment Failed (فشل عملية الدفع)

| Field | Value |
|---|---|
| **Scenario** | Subscription renewal payment fails (expired card, insufficient funds, bank rejection) |
| **Current state** | Subscription is "active" but renewal payment attempt failed |
| **Trigger** | Google Play Billing notifies payment failure |
| **Expected system behavior** | 1) Google Play enters grace period (typically 30 days with retry attempts). 2) App receives billing state "grace_period". 3) Show amber banner: "فشل تجديد الاشتراك — حدّث طريقة الدفع خلال X أيام". 4) "حدّث طريقة الدفع" → Google Play subscription settings (deep link). 5) Features remain active during grace period. 6) If Google Play retries and succeeds: banner removed, subscription continues. 7) If grace period expires without payment: → EC-ACC-02 (lapsed). |
| **User-facing UI** | Amber banner with countdown days + "حدّث الدفع" CTA; non-blocking but persistent; notification also sent |
| **Recovery path** | User updates payment in Google Play → Google Play retries → success → subscription active → banner removed |
| **Prevention** | Pre-expiry payment method check (if possible); clear communication; multiple notification channels (in-app + push + email if available) |

### EC-ACC-04 — Account Suspended (تعليق الحساب)

| Field | Value |
|---|---|
| **Scenario** | Account is suspended by Family OS (violation of terms, abuse detection, fraud) |
| **Current state** | Family account is operational |
| **Trigger** | Server-side suspension action (admin or automated abuse detection) |
| **Expected system behavior** | 1) Server marks account as "suspended". 2) All sessions invalidated; next API call returns 403 with suspension reason. 3) Client shows suspension screen (replaces normal app): "تم تعليق حسابك. السبب: [reason]. تواصل مع الدعم للاستفسار." 4) No data access except: SOS (safety override — always works), contact support link, view terms/privacy. 5) Child devices: SOS continues working; monitoring paused; learning paused; messaging to parents only. 6) Suspension is reversible (admin action) or permanent (severe violations). |
| **User-facing UI** | Full-screen suspension notice (Coral accent); reason displayed; "تواصل مع الدعم" link; SOS still accessible from this screen for child |
| **Recovery path** | User contacts support → review → if resolved, suspension lifted → account restored → normal operation resumes. If permanent: data export offered before final deletion. |
| **Prevention** | Clear terms of service; progressive enforcement (warnings before suspension); appeal process; abuse detection with human review |

---

## 4. Data States

### EC-DATA-01 — Empty Data (بيانات فارغة)

| Field | Value |
|---|---|
| **Scenario** | A screen has no data to display (new family, no messages, no events, no tasks) |
| **Current state** | Screen loaded successfully but server returned empty result set |
| **Trigger** | Data fetch returns 0 items |
| **Expected system behavior** | 1) Render empty state illustration (context-appropriate, flat design). 2) Show Arabic headline + subtext explaining the state. 3) Show primary CTA that would populate the screen (e.g., "أضف حدثًا", "ابدأ محادثة", "أكمل اختبار التحديد"). 4) No error message (empty is not an error). 5) If data arrives later (push, sync), transition smoothly to populated state. |
| **User-facing UI** | Centered illustration + Arabic headline + subtext + CTA button; no error styling; encouraging tone |
| **Recovery path** | User takes the suggested action → data created → screen populates |
| **Prevention** | Well-designed empty states for every screen (see Screen Spec §7.1); contextual CTAs; onboarding flows that seed initial data |

### EC-DATA-02 — Corrupted Data (بيانات تالفة)

| Field | Value |
|---|---|
| **Scenario** | Locally cached or server-returned data is malformed, unparseable, or structurally invalid |
| **Current state** | App receives data that fails schema validation |
| **Trigger** | JSON parse error, schema validation failure, checksum mismatch, or deserialization exception |
| **Expected system behavior** | 1) Catch exception at data layer; do NOT crash. 2) Log corruption event with entity type, ID, and error detail (sent to crash/analytics if opted in). 3) Discard corrupted local copy. 4. Attempt re-fetch from server (authoritative source). 5) If server copy is also corrupt: log server-side, fall back to default/empty state. 6) If entity is critical (e.g., user profile): show "تعذّر تحميل [entity]" + retry + contact support. 7) If entity is non-critical (e.g., one message): skip it, render the rest. |
| **User-facing UI** | Critical entity: error card + retry. Non-critical: silent skip (rest of data renders normally). Neither shows "corrupted" to user — shows "تعذّر تحميل" generically. |
| **Recovery path** | Re-fetch from server → if clean, renders normally. If still corrupt: support ticket. For local-only corruption: clear cache + re-sync. |
| **Prevention** | Schema validation on all data ingress; checksums for cached data; periodic cache integrity checks; server-side data validation; graceful error handling at data layer |

### EC-DATA-03 — Stale Data (بيانات قديمة)

| Field | Value |
|---|---|
| **Scenario** | Displayed data is outdated because the device was offline or sync hasn't run recently |
| **Current state** | Screen showing cached data that may not reflect current server state |
| **Trigger** | Data age exceeds freshness threshold (varies by entity: location = 5 min, messages = 1 min, schedule = 1 h, profile = 24 h) |
| **Expected system behavior** | 1) Tag cached data with timestamp. 2) If data age > freshness threshold AND device is online: trigger background refresh. 3) If offline: show "آخر تحديث: [relative time]" indicator in subtle gray. 4) If data is critically stale (e.g., location >1 h for monitoring): amber indicator "قد لا تكون البيانات محدّثة" + "تحديث" button. 5) On refresh success: update data + remove stale indicator. 6) On refresh failure: keep cached data + maintain indicator. |
| **User-facing UI** | Subtle "آخر تحديث: منذ X دقيقة" timestamp; amber indicator for critically stale data; "تحديث" button to force refresh |
| **Recovery path** | Device reconnects or manual refresh → fresh data replaces stale → indicator removed |
| **Prevention** | Smart background sync with adaptive frequency; freshness metadata on all cached entities; visible staleness indicators; pull-to-refresh on all data screens |

### EC-DATA-04 — Data Conflict (تعارض البيانات)

| Field | Value |
|---|---|
| **Scenario** | Same entity modified on two devices; both versions exist and need resolution |
| **Current state** | Two divergent versions of the same entity |
| **Trigger** | Sync detects version mismatch (same entity ID, different version vector, both modified since common ancestor) |
| **Expected system behavior** | See EC-NET-04 (Sync Conflict) — resolution strategy per entity type: last-write-wins, merge, field-level merge, or manual resolution. Additionally: 1) Preserve both versions in audit trail. 2) Log conflict for debugging. 3) If manual resolution: notify both clients with both versions. 4) Never silently destroy user data — worst case is manual resolution. |
| **User-facing UI** | Auto-resolved: seamless (no notification). Manual: "تعارض في [entity]" dialog with both versions and resolution options. |
| **Recovery path** | Resolved version propagated to all devices; both original versions in audit trail for 30 days |
| **Prevention** | Real-time WebSocket updates minimize divergence; optimistic concurrency; version vectors; entity-specific resolution strategies |

## 5. Safety Edge Cases

### EC-SAF-01 — SOS When Offline (الطوارئ بدون إنترنت)

| Field | Value |
|---|---|
| **Scenario** | Child triggers SOS but device has no data connectivity (airplane mode, no coverage, data roaming off) |
| **Current state** | Child pressed and held SOS button; alert needs to reach parents |
| **Trigger** | SOS activation + no internet connection detected |
| **Expected system behavior** | 1) Detect offline state immediately. 2) Activate SMS fallback: send SMS to all parent phone numbers with: "🚨 SOS من [child name] — الموقع: [lat/lng or last-known address] — الوقت: [timestamp]". 3) If SMS also unavailable (no SIM): activate Bluetooth/local broadcast (if supported) + store alert locally. 4) Start local GPS logging (location cached every 10 s). 5) Keep mic recording locally (caches audio). 6) Show child: "تم إرسال التنبيه عبر SMS" + "جارٍ محاولة الاتصال بالإنترنت…". 7) On reconnect: upload full SOS data (location trail, audio if recorded) to server → server pushes to parents' devices. 8) SMS sends even in airplane mode if SIM is active (SMS over control channel). |
| **User-facing UI** | "تم إرسال الطوارئ عبر SMS" confirmation; "جارٍ تسجيل موقعك locally" indicator; "سيتم رفع البيانات عند توفر الإنترنت" note; call parent button still works (phone call) |
| **Recovery path** | On reconnect: full SOS data syncs to server → parents receive complete alert with location trail + audio |
| **Prevention** | SMS fallback always configured; parent phone numbers cached locally; last-known location always cached; SOS is designed offline-first |

### EC-SAF-02 — SOS Battery Critical (الطوارئ مع بطارية منخفضة)

| Field | Value |
|---|---|
| **Scenario** | Child triggers SOS but device battery is at or below 5% |
| **Current state** | SOS activated; battery critical; device may die soon |
| **Trigger** | SOS activation + battery level ≤5% |
| **Expected system behavior** | 1) Enter SOS Low-Power Mode immediately. 2) Reduce GPS update interval from 10 s to 30 s (preserve battery). 3) Disable audio recording (power-intensive). 4) Disable screen brightness (dim screen). 5) Send highest-priority push to parents: "🚨 SOS من [child] — بطارية منخفضة (X%) — قد ينطفئ الجهاز". 6) Send SMS fallback immediately (in case device dies before data alert sends). 7) Cache final location + battery level. 8) Keep cellular radio on (for SMS/call) but disable Wi-Fi/Bluetooth scanning. 9) Show child: "بطارية منخفضة — وضع الطوارئ الموفّر مُفعّل". 10) If device dies: last cached location + timestamp + battery-at-death preserved; parents see "آخر موقع معروف قبل انقطاع الجهاز". |
| **User-facing UI** | "وضع الطوارئ الموفّر للبطارية" indicator; dimmed screen; "تم إرسال آخر موقع للوالدين"; call parent button still prominent |
| **Recovery path** | If device survives: normal SOS continues when charged. If device dies: parents have last-known location + can call the child's number (may go to voicemail). |
| **Prevention** | Battery monitoring during SOS; aggressive power-saving; SMS sent immediately; location cached before battery dies |

### EC-SAF-03 — Geofence GPS Denied (رفض إذن الموقع للمناطق الآمنة)

| Field | Value |
|---|---|
| **Scenario** | Safe zone geofence monitoring requires GPS but location permission is denied or revoked on child device |
| **Current state** | Safe zones configured; child device has location permission denied |
| **Trigger** | Location permission check fails on child device |
| **Expected system behavior** | 1) Child device: geofence monitoring cannot function without location. 2) Notify parent device: "تعذّر مراقبة المناطق الآمنة — إذن الموقع مرفوض على جهاز طفلك". 3) Parent monitoring hub (SCR-PAR-01): Safe Zones card shows amber "إذن الموقع مرفوض" status. 4. Safe Zone screen (SCR-PAR-06): show "لا يمكن مراقبة المناطق بدون إذن الموقع" + "إعادة طلب الإذن" action (sends remote prompt to child device). 5. Anti-bypass (SCR-PAR-12): log permission revocation as a bypass event. 6. If location was previously granted and then revoked: treat as potential deliberate bypass → critical alert to parent. 7. Child device: show rationale "إذن الموقع مطلوب لحمايتك — فعّله من الإعدادات". |
| **User-facing UI** | Parent: amber alert card + re-request action. Child: rationale card on location-dependent screens. |
| **Recovery path** | Child grants location permission (from settings or re-prompt) → geofence monitoring resumes → parent notified "تم استئناف مراقبة المناطق الآمنة" |
| **Prevention** | Location permission requested during device enrollment (not later); periodic permission health checks; parent alerts on revocation; Anti-bypass monitoring |

### EC-SAF-04 — Kill Switch VPN Conflict (تعارض VPN مع مفتاح الإيقاف)

| Field | Value |
|---|---|
| **Scenario** | Kill Switch activates VPN-based network isolation, but child has a third-party VPN app running |
| **Current state** | Kill Switch is being activated; child device has an active VPN connection from another app |
| **Trigger** | Kill Switch `BIND_VPN_SERVICE` attempt conflicts with existing VPN tunnel |
| **Expected system behavior** | 1) Android only allows one VPN at a time. 2) Kill Switch VPN requests establishment → Android system prompts user (or auto-accepts if Device Admin grants). 3) Existing VPN is terminated by Android system. 4) Kill Switch VPN establishes → network isolation active. 5) If child's VPN app tries to re-establish: blocked by Kill Switch VPN priority. 6) Log event in Anti-bypass: "تم إنهاء VPN تابع لجهة خارجية أثناء مفتاح الإيقاف" with VPN app package name. 7) Notify parent: "تم تفعيل مفتاح الإيقاف — تم حجب VPN خارجي ([app name])". 8) On Kill Switch deactivation: Kill Switch VPN torn down; child's VPN may re-establish (depending on that app's behavior). |
| **User-facing UI** | Parent: notification of Kill Switch activation + VPN conflict resolved. Child: network isolated (Kill Switch UX). No VPN conflict visible to child (seamless). |
| **Recovery path** | Kill Switch deactivated → Kill Switch VPN removed → child VPN may resume (or remains blocked if App Rules blocks it) |
| **Prevention** | VPN priority enforced by Android system; Device Admin elevation; Anti-bypass detects VPN installation; App Rules can preemptively block VPN apps |

### EC-SAF-05 — Anti-Bypass Disabled by System Update (إلغاء مضاد التجاوز بسبب تحديث النظام)

| Field | Value |
|---|---|
| **Scenario** | Android system update resets or revokes Accessibility Service / Device Admin permissions, disabling Anti-bypass modules |
| **Current state** | Anti-bypass is fully operational; child device receives a system update |
| **Trigger** | Post-boot after system update; Accessibility Service or Device Admin permission is found revoked/reset |
| **Expected system behavior** | 1) On boot, Anti-bypass runs health check: verifies Accessibility, Device Admin, Usage Stats, Location permissions. 2) If any critical permission is missing post-update: • Log event as "system_update_tamper". • Send immediate critical alert to parent: "⚠️ تحديث النظام ألغى صلاحيات الحماية على جهاز طفلك — يلزم إعادة التفعيل". • Lock non-essential apps (safety measure) until permissions restored. • Show child device: full-screen "يلزم إعادة تفعيل صلاحيات الحماية" with step-by-step instructions and "السماح" buttons for each permission. • Queue re-enrollment flow. 3) Parent device: SCR-PAR-12 shows red "خطر — صلاحيات معطلة" status with "إعادة التفعيل" action (sends remote re-enrollment prompt). 4) If child doesn't restore within 1 h: parent notified again with escalating urgency. 5) If child doesn't restore within 24 h: parent offered remote device lock (SCR-PAR-03) as safety measure. 6) All monitoring continues with degraded capability (what can work without the lost permissions). |
| **User-facing UI** | Child: full-screen re-authorization flow. Parent: critical alert + Anti-bypass status red + re-enrollment action. |
| **Recovery path** | Child re-grants permissions via guided flow → Anti-bypass health check passes → monitoring resumes full capability → parent notified "تم استعادة الحماية" |
| **Prevention** | Boot-time health check; post-update detection; guided re-authorization; parent alerts with escalation; safety lock as fallback. Also: Open Decision #1 (Google Play Accessibility policy risk). |

## 6. Education Edge Cases

### EC-EDU-01 — AI Grading Failure Fallback (فشل التقييم الذكي)

| Field | Value |
|---|---|
| **Scenario** | Child submits an assignment; AI auto-grading service is unavailable or fails to produce a grade |
| **Current state** | Assignment submitted successfully; AI grading initiated; service times out or returns error |
| **Trigger** | AI grading API timeout (>30 s), service 500 error, or response fails validation |
| **Expected system behavior** | 1) Catch grading failure at service layer. 2) Mark submission as "بانتظار التقييم اليدوي" (awaiting manual grading). 3) Notify parent (if Father or Mother configured as grader): "يتطلب [assignment] تقييمًا يدويًا — تعذّر التقييم الذكي". 4) Fallback grading chain: • Attempt 1: AI grading (failed). • Attempt 2: Retry with simplified prompt (if partial AI available). • Attempt 3: Queue for manual parent grading. • Attempt 4: If no parent available within 48 h: assign provisional "مكتمل" (completed) grade with note "تم الإكمال — التقييم المؤجل". 5) Preserve submission; never lose the child's work. 6) When AI service recovers: optionally re-grade and update if parent hasn't already graded. |
| **User-facing UI** | Child: "تم التسليم — التقييم قيد المعالجة" (no error shown to child). Parent: notification + assignment in "needs grading" queue. After manual grade: child sees grade + feedback. |
| **Recovery path** | AI service recovers → next submissions auto-graded; or parent grades manually; provisional grade replaced by real grade |
| **Prevention** | Grading timeout with fallback chain; manual grading always available as ultimate fallback; AI service health monitoring; offline cached grading for simple question types |

### EC-EDU-02 — Quran Analysis Audio Too Short (تلاوة قصيرة جدًا)

| Field | Value |
|---|---|
| **Scenario** | Child records Quran recitation but audio is too short for meaningful Tajweed analysis |
| **Current state** | Child recorded recitation and submitted for analysis |
| **Trigger** | Audio duration <3 s or audio contains <5 words |
| **Expected system behavior** | 1) Pre-analysis: check audio duration and word count. 2) If too short: do NOT send to AI (save credits). 3) Return specific feedback: "التلاوة قصيرة جدًا للتحليل — سجّل آية كاملة على الأقل (3 ثوانٍ أو أكثر)". 4) Keep the recording available for retry. 5) Suggest: "جرّب تسجيل [suggested ayah] — [estimated duration]". 6) If audio is silent or just noise: "لم نسمع تلاوة — تحقق من الميكروفون". 7) If audio is in wrong language/no Arabic detected: "لم نكتشف قرآنًا في التسجيل — تأكد من تلاوة آية بالعربية". |
| **User-facing UI** | "التلاوة قصيرة جدًا" message + guidance + "أعد التسجيل" button; no score assigned; recording preserved for review |
| **Recovery path** | Child re-records with longer recitation → analysis proceeds normally |
| **Prevention** | Pre-analysis validation before AI call (saves cost); minimum duration guidance shown before recording; real-time waveform to show child they are recording |

### EC-EDU-03 — Adaptive Level Corruption (تلف مستوى التكيف)

| Field | Value |
|---|---|
| **Scenario** | The child's adaptive learning level data becomes corrupted, invalid, or inconsistent |
| **Current state** | AdaptivePath and LearnerProfile contain invalid level data (e.g., level = -1, or performance history is null) |
| **Trigger** | Data validation fails on adaptive level read; or level value is outside expected range |
| **Expected system behavior** | 1) Detect corruption via data validation on read. 2) Do NOT crash or show error to child. 3) Fall back to last known valid level (if available in history). 4) If no valid history: reset to placement test result level. 5) If no placement test: default to grade-appropriate starting level. 6) Log corruption event. 7) Notify parent (non-critical): "تمت إعادة ضبط مستوى [child] التعليمي — يُنصح بإعادة اختبار التحديد". 8) Preserve all completed lesson records (those are separate from level). 9) Adaptive engine re-calibrates from remaining performance data. 10) Offer child: "لنبدأ من هنا" with appropriate-level lesson. |
| **User-facing UI** | Child: seamless (no visible error); sees appropriate-level lesson. Parent: non-critical notification suggesting placement retake. |
| **Recovery path** | Child continues at recalibrated level; adaptive engine learns from new performance; optionally retakes placement test for accuracy |
| **Prevention** | Data validation on all writes; level history snapshots (keep last 10 valid levels); separation of level data from completion data; periodic consistency checks |

### EC-EDU-04 — Placement Test Incomplete (اختبار التحديد غير مكتمل)

| Field | Value |
|---|---|
| **Scenario** | Child starts placement test but exits before completion (app crash, intentional exit, device dies) |
| **Current state** | Placement test in progress; some answers recorded; test not submitted |
| **Trigger** | App exit, crash, or background kill during placement test |
| **Expected system behavior** | 1) Save all answered questions locally immediately after each answer (not just on submit). 2) On app relaunch: detect incomplete placement test. 3) Show child: "لديك اختبار تحديد غير مكتمل — تابع من السؤال X". 4) Resume from last answered question with same adaptive difficulty chain. 5) If test was interrupted >24 h ago: offer "متابعة" or "إعادة من البداية" (answers may be stale). 6) If test was interrupted >7 days ago: auto-expire, require restart. 7) If child refuses to resume: learning home shows placement CTA (cannot proceed without placement). 8) Parent can override: manually assign level if child won't complete test. |
| **User-facing UI** | "تابع اختبار التحديد" prompt with progress indicator; resume or restart options; no penalty for resumption |
| **Recovery path** | Child resumes and completes → level assigned → adaptive path generated. Or parent manually assigns level. |
| **Prevention** | Incremental save after each answer; resume capability; no time pressure (unless configured); parent override available |

## 7. Communication Edge Cases

### EC-COM-01 — Message Send Failure (فشل إرسال الرسالة)

| Field | Value |
|---|---|
| **Scenario** | User sends a message but it fails to deliver to the server |
| **Current state** | User tapped send; message entered local outbox; upload to server failed |
| **Trigger** | Network error, server 500, timeout, or WebSocket disconnect during send |
| **Expected system behavior** | 1) Message stays in conversation with "قيد الإرسال" (pending) status — single clock icon. 2) Auto-retry with exponential backoff: 3 s, 10 s, 30 s, 1 min, up to 5 min. 3) After 3 failed retries: show Coral retry icon on the message bubble. 4) User can tap retry icon for manual retry. 5) If offline: message queued, sends on reconnect automatically. 6) If server rejects (e.g., conversation deleted): mark as "فشل الإرسال" with delete option. 7) Preserve message locally; never lose user's text. 8) If message was partially uploaded: resume from offset (not re-upload entire). |
| **User-facing UI** | Pending: single clock icon. Failed: Coral retry icon (tap to retry). Permanently failed: "فشل الإرسال" + tap for options (retry, delete, copy text). |
| **Recovery path** | Auto-retry succeeds → message delivered → double-tick appears. Manual retry → same. On reconnect → flush queue. |
| **Prevention** | Local outbox with persistent queue; auto-retry with backoff; resume-able uploads; offline-first messaging design |

### EC-COM-02 — Voice Transcription Failure (فشل التفريغ الصوتي)

| Field | Value |
|---|---|
| **Scenario** | Voice message is sent but speech-to-text transcription fails |
| **Current state** | Voice message uploaded successfully; transcription service called; service fails or returns empty |
| **Trigger** | Transcription API timeout, service unavailable, audio quality too poor for transcription |
| **Expected system behavior** | 1) Voice message is delivered (transcription failure does NOT block message delivery). 2) Show waveform + playback normally. 3) Transcription area shows "التفريغ الصوتي غير متاح حاليًا" + retry icon. 4) Auto-retry transcription up to 3 times with 10 s intervals. 5) If all retries fail: keep "غير متاح" state; retry available on user tap. 6) If audio quality is the issue: "جودة الصوت منخفضة — تعذّر التفريغ" (no auto-retry for quality issue). 7) On transcription success (eventual): update the message in-place with text. 8) If recipient also can't get transcription: same fallback on their device. |
| **User-facing UI** | Voice message plays normally; transcription area shows "غير متاح" + retry; no blocking error; message is fully usable without transcription |
| **Recovery path** | Service recovers → auto-retry or manual retry → transcription appears. Or user can always listen to the voice message. |
| **Prevention** | Transcription is non-blocking (message delivers regardless); retry mechanism; quality pre-check; offline transcription for common phrases (future) |

### EC-COM-03 — Translation Failure (فشل الترجمة)

| Field | Value |
|---|---|
| **Scenario** | Auto-translation is enabled but the translation service fails for a specific message |
| **Current state** | Message received; auto-translation triggered; Gemini translation API fails |
| **Trigger** | Translation API timeout, service unavailable, unsupported language pair detected |
| **Expected system behavior** | 1) Show original message normally (translation failure does NOT block reading). 2) Translation area shows "الترجمة غير متاحة" + retry icon. 3) Auto-retry up to 3 times. 4) If language pair unsupported: "هذه اللغة غير مدعومة للترجمة" (no retry). 5) If translation is premium and trial expired: show Violet lock instead of translation → SCR-ADM-04. 6) If service is down for all messages: show banner "خدمة الترجمة غير متاحة مؤقتًا" + dismiss. 7) On recovery: translate pending messages in background; update in-place. |
| **User-facing UI** | Original message visible; translation area shows "غير متاحة" + retry; non-blocking; user can always read original |
| **Recovery path** | Service recovers → translations populate; or user reads original language |
| **Prevention** | Translation is non-blocking; retry mechanism; supported language check before API call; graceful premium gating |

### EC-COM-04 — Media Upload Failure (فشل رفع الوسائط)

| Field | Value |
|---|---|
| **Scenario** | User sends an image/video/file in chat but the upload to storage fails |
| **Current state** | User selected media and tapped send; upload to cloud storage initiated; failed |
| **Trigger** | Storage API timeout, network interruption mid-upload, file too large after compression, storage quota exceeded |
| **Expected system behavior** | 1) Show media placeholder in conversation with "جارٍ الرفع" progress indicator. 2) Auto-retry with resume capability (upload from offset if possible). 3) After 3 failures: show Coral retry icon on media placeholder. 4) If file too large: auto-compress further and retry (up to 3 compression levels). 5) If quota exceeded: notify "مساحة التخزين ممتلئة — تواصل مع الدعم" + store locally (can be re-uploaded when quota available). 6) On success: replace placeholder with actual media. 7) Recipient sees placeholder until upload completes, then media loads. 8) Never lose the original file — keep in local outbox until confirmed uploaded. |
| **User-facing UI** | Progress indicator during upload; retry icon on failure; compression feedback "جارٍ الضغط…" if needed; non-blocking (can continue chatting) |
| **Recovery path** | Upload succeeds on retry → media appears for both sender and recipient. Or user can delete failed upload and re-select. |
| **Prevention** | Auto-compression before upload; resume-able uploads; progressive quality reduction; local persistence of originals; quota monitoring |

### EC-COM-05 — SOS No Parent Online (الطوارئ بدون ولي أمر متصل)

| Field | Value |
|---|---|
| **Scenario** | Child triggers SOS but no parent device is online to receive the alert |
| **Current state** | SOS activated; alert sent to server; no parent devices are connected |
| **Trigger** | SOS alert pushed to server + all parent devices are offline/disconnected |
| **Expected system behavior** | 1) Send push notification (high priority, bypasses DND) to all parent devices — they will receive on reconnect even if offline now. 2) Send SMS to all parent phone numbers immediately (doesn't require data). 3) If no parent acknowledges within 60 s: auto-escalate to emergency contacts (configured in profile). 4) If no emergency contacts configured: attempt to call the first parent's phone number (voice call). 5) Show child: "تم إرسال التنبيه لوالديك" + "جارٍ انتظار الرد…" + timer. 6) After 2 min with no acknowledgment: "لم يرد والديك بعد — اتصل بالطوارئ؟" with 911/999 button. 7) Keep location streaming and audio recording active throughout. 8) When any parent comes online: they receive the full SOS with location trail. 9) Log escalation event in audit trail. |
| **User-facing UI** | Child: "تم الإرسال" + waiting timer + escalation prompt after 2 min + "اتصل بالطوارئ" option. Parent (on reconnect): full SOS alert with backlog. |
| **Recovery path** | Parent comes online → receives SOS → acknowledges → child notified "رد [parent name] على تنبيهك". If no parent ever responds: child can call emergency services. |
| **Prevention** | SMS fallback (no data needed); emergency contacts configured during onboarding; escalation timer; emergency services call option; push notifications survive offline |

## 8. Concurrency Edge Cases

### EC-CON-01 — Two Parents Editing Rules Simultaneously (تعديل القواعد في وقت واحد)

| Field | Value |
|---|---|
| **Scenario** | Father and Mother are both editing monitoring rules (e.g., App Rules, Screen Time limits) for the same child at the same time |
| **Current state** | Both parents have the rules screen open and are making changes |
| **Trigger** | Both submit rule changes within a short window (seconds) |
| **Expected system behavior** | 1) Server receives both mutations. 2) Detect concurrent modification via version vector mismatch. 3) Resolution strategy: **Field-level last-write-wins** — each individual rule field is updated by the latest timestamp. 4) If both edit the SAME field: last-write-wins by server-received timestamp. 5) Push updated rule set to both devices. 6) Show both parents a brief notification: "تم تحديث القواعد بواسطة [other parent]". 7) If edits are to different fields (e.g., Father blocks Instagram, Mother extends screen time by 15 min): both changes merge — both take effect. 8) Log concurrent edit event in audit trail. 9) If Mother edits a field she doesn't have permission for (exclusive feature without grant): her edit is rejected with "هذه الميزة متاحة للأب فقط". |
| **User-facing UI** | Both parents see the merged result; brief toast "تم تحديث بواسطة [other parent]" if the other's change affected what they were viewing. No conflict dialog needed for field-level merge. |
| **Recovery path** | Merged rules propagate to both devices and child device. If a parent disagrees with the other's change, they can edit again. |
| **Prevention** | Real-time WebSocket updates (parent sees other's changes live); field-level versioning; optimistic concurrency; clear attribution of changes |

### EC-CON-02 — Child Submitting While Parent Locks Device (التسليم أثناء قفل الجهاز)

| Field | Value |
|---|---|
| **Scenario** | Child is in the middle of submitting an assignment/quiz, and parent triggers Device Lock at the same moment |
| **Current state** | Child's submission is in-flight (uploading); parent activates Device Lock |
| **Trigger** | Parent taps "قفل فوري" while child's assignment upload is in progress |
| **Expected system behavior** | 1) Device Lock command received by child device. 2) Check for in-flight educational operations (submission, quiz). 3) If submission is in-flight: allow it to COMPLETE before locking (grace period up to 60 s). 4) Show child: "جارٍ إنهاء التسليم… ثم سيُقفل الجهاز" + countdown. 5) Once submission completes: apply lock. 6) If submission takes >60 s: force lock with "تم قفل الجهاز — تسجيلك سيكتمل في الخلفية". 7) Continue upload in background even after lock (education app is always-allowed during lock). 8) Notify parent: "تم قفل الجهاز — اكتمل تسليم [child] في الخلفية". 9) If child is mid-quiz (not submitting yet): lock applies immediately (quiz state saved, can resume on unlock). |
| **User-facing UI** | Child: "جارٍ إنهاء التسليم ثم سيُقفل الجهاز" countdown → lock screen. Parent: lock confirmed + note about background submission. |
| **Recovery path** | Device unlocked later → child sees submission was completed → normal operation |
| **Prevention** | In-flight operation detection; grace period for submissions; background completion; always-allowed education apps during lock |

### EC-CON-03 — Subscription State Race (سباق حالة الاشتراك)

| Field | Value |
|---|---|
| **Scenario** | User's subscription is being processed (purchase or renewal) while they simultaneously access a premium feature |
| **Current state** | Payment is processing; subscription state is "pending"; user opens a premium feature |
| **Trigger** | Premium feature access while Google Play billing is in "pending" state |
| **Expected system behavior** | 1) Client checks subscription state before granting premium access. 2) If state is "active": grant access. 3) If state is "pending" (purchase in progress): show "جارٍ معالجة الاشتراك…" + allow temporary access for 5 min (optimistic). 4) If state is "expired" or "free": show paywall (SCR-ADM-04). 5) If optimistic access granted and purchase completes: access becomes permanent. 6) If optimistic access granted and purchase fails: show "فشل الشراء — ميزات مميزة معطّلة" + revert to free tier + paywall. 7) If state transitions during use (e.g., subscription lapses while using AI Tutor): allow current session to complete, block new sessions. 8) Server is authoritative — client state syncs within 30 s of server change. |
| **User-facing UI** | Pending: "جارٍ المعالجة" + temporary access. Success: seamless. Failure: "فشل الشراء" + paywall. Mid-session lapse: current session completes, next session blocked. |
| **Recovery path** | Purchase completes → permanent access. Purchase fails → paywall → retry purchase. |
| **Prevention** | Optimistic access with timeout; server-authoritative state; grace period for in-progress operations; clear state transitions |

## 9. Device Edge Cases

### EC-DEV-01 — Child Device Unlinked (فك ربط جهاز الطفل)

| Field | Value |
|---|---|
| **Scenario** | The child's device is unlinked from the family (intentional by parent or accidental by child/factory reset) |
| **Current state** | Child device was previously enrolled; monitoring, education, messaging all active |
| **Trigger** | Parent unlinks from SCR-ADM-03; child performs factory reset; enrollment token invalidated; or device admin removed |
| **Expected system behavior** | 1) If parent-initiated: a) confirm with hold-3 s; b) server marks device as "unlinked"; c) child device receives "device unlinked" message; d) child app reverts to standalone mode (messages cached, lessons cached, monitoring off); e) parent's monitoring hub shows "جهاز غير مرتبط" for that child; f) all monitoring data frozen at last-known state. 2) If child/factory-reset initiated: a) Anti-bypass detects (SCR-PAR-12); b) send critical alert to parent: "تم فك ربط جهاز [child] — يحتمل إعادة ضبط المصنع"; c) parent monitoring hub: "تم فك الارتباط بدون إذن" red alert; d) offer re-enrollment instructions. 3) Historical data preserved on server (not dependent on device). 4) Lessons completed, grades, XP preserved (tied to user, not device). |
| **User-facing UI** | Parent: "جهاز غير مرتبط" status + "إعادة الربط" CTA. Child: "جهازك غير مرتبط بالعائلة" + standalone mode + "تواصل مع والدك لإعادة الربط". |
| **Recovery path** | Parent re-enrolls child device via QR (SCR-ADM-03) → monitoring resumes → data syncs from server → "تم إعادة الربط بنجاح" |
| **Prevention** | Factory reset detection (Anti-bypass); device admin removal alert; enrollment token persistence; server-side data preservation |

### EC-DEV-02 — Father Device Lost (فقدان جهاز الأب)

| Field | Value |
|---|---|
| **Scenario** | Father (primary admin) loses their device — stolen, broken, or permanently inaccessible |
| **Current state** | Father was the sole admin; device is now inaccessible |
| **Trigger** | Father cannot access their device or app |
| **Expected system behavior** | 1) Family OS app is account-based, not device-based — losing the device does not lose the account. 2) Father uses recovery flow (SCR-SHR-03) from a new device: • Verify identity via family ID + security question or recovery email/phone. • OR: Mother verifies Father's identity from her device (if Mother exists and is online). 3) On successful verification: old session invalidated (prevents thief from using), new session on new device. 4) All data intact on server. 5) If Father had biometric/PIN lock: thief cannot access the app on lost device (app-level security). 6) Father can remotely log out the lost device from the new device (SCR-SHR-05 > linked devices > "إلغاء ربط هذا الجهاز"). 7) If Father was the only parent: family continues operational, Mother/children can still use the app, but admin functions wait for Father's recovery. |
| **User-facing UI** | New device: normal login/recovery flow. Mother: notified if Father logged out old device. Children: unaffected (monitoring continues on cached rules). |
| **Recovery path** | Father recovers account on new device → invalidates old → re-links new device → full admin restored |
| **Prevention** | Account-based architecture (not device-dependent); app-level lock (biometric/PIN); remote session invalidation; account recovery flow; server-side data |

### EC-DEV-03 — Mother Device Offline (جهاز الأم غير متصل)

| Field | Value |
|---|---|
| **Scenario** | Mother's device is offline for extended period (no battery, no network, powered off) while she has monitoring and messaging roles |
| **Current state** | Mother has monitoring visibility and receives alerts; her device goes offline |
| **Trigger** | Mother's device loses connectivity for >1 h |
| **Expected system behavior** | 1) Alerts and notifications queue on server for Mother's device. 2) Father continues to receive all alerts (he always receives all). 3) If an alert requires Mother's action (extra-time request she's supposed to handle): route to Father after 30 min timeout. 4) On Mother's reconnect: flush queued notifications (prioritize critical first, deduplicate with stale ones). 5) Monitoring hub shows her the current state (not stale); "آخر اتصال: X ساعات" on her device entry in Father's device list. 6) If both parents are offline simultaneously: child device operates on last-known rules; child SOS escalates to emergency contacts. |
| **User-facing UI** | Mother (on reconnect): catches up with queued notifications; monitoring hub refreshed. Father: sees Mother's device status as "غير متصل". Children: unaffected (rules cached locally). |
| **Recovery path** | Mother comes online → queued notifications delivered → monitoring state refreshed → normal operation |
| **Prevention** | Dual-parent alert routing; Father as fallback for Mother's delayed actions; rule caching on child device; escalation to emergency contacts if both parents offline |

### EC-DEV-04 — Device Time Tampered (تلاعب بتوقيت الجهاز)

| Field | Value |
|---|---|
| **Scenario** | Child manually changes device time to bypass time-based restrictions (screen time, school time, bedtime lock) |
| **Current state** | Child device has tampered time (set to wrong date/time to circumvent restrictions) |
| **Trigger** | Anti-bypass detects time discrepancy between device clock and server timestamp (NTP check) |
| **Expected system behavior** | 1) Anti-bypass module detects time discrepancy >5 min between device clock and NTP/server time. 2) Log tamper event. 3) Alert parent immediately: "تم اكتشاف تغيير وقت الجهاز على جهاز [child]". 4) Override to server time for all restriction calculations: • Screen time uses server timestamp (not device). • School Time uses server timestamp. • Bedtime lock uses server timestamp. 5) Show child: "تم اكتشاف تغيير في الوقت — سيتم استخدام الوقت الصحيح" (transparent, non-confrontational). 6) If "auto time" is disabled on child device: alert parent "التوقيت التلقائي معطّل". 7) Recommendations to parent: "فعّل التوقيت التلقائي على جهاز طفلك" with instructions. 8) Flag in Anti-bypass (SCR-PAR-12) as "time_tamper" event. |
| **User-facing UI** | Child: warning that server time is used; restrictions still apply. Parent: alert notification + event in Anti-bypass log + recommendation. |
| **Recovery path** | Parent or child restores correct device time + enables auto-time → Anti-bypass clears flag → normal operation |
| **Prevention** | All time-based restrictions use server-authoritative time; NTP validation; Anti-bypass time monitoring; periodic time drift checks; "auto-time enabled" monitoring |

---

## 10. Compliance Edge Cases

### EC-CMP-01 — Export in Progress When Deletion Requested (تصدير أثناء طلب الحذف)

| Field | Value |
|---|---|
| **Scenario** | User requests full data export, and while export is processing, they also request account deletion |
| **Current state** | Export job is running server-side (may take minutes to hours for large families); deletion request arrives |
| **Trigger** | User taps "تصدير" (starts export job) → then navigates to delete → taps "حذف" before export completes |
| **Expected system behavior** | 1) Detect concurrent export + deletion. 2) Prioritize export completion (GDPR requires data access right to be fulfilled). 3) Pause deletion request: "يجب إكمال التصدير قبل حذف البيانات — سيبدأ الحذف تلقائيًا بعد اكتمال التصدير". 4) Mark deletion as "queued after export". 5) Export completes → user is notified with download link → 24 h to download. 6) After download window: deletion process begins (30-day grace period). 7) If user cancels deletion during this flow: export still available, deletion cancelled. 8) Log the entire flow in audit trail. |
| **User-facing UI** | "جارٍ التصدير… سيبدأ الحذف تلقائيًا بعد اكتمال التصدير" + progress for export + "إلغاء الحذف" option |
| **Recovery path** | Export completes → user downloads → deletion grace period begins → user can cancel within 30 days. Export fails → retry export → if export impossible (server failure), offer partial export + inform deletion will proceed with note about unexported data. |
| **Prevention** | Sequential processing of data rights requests; export-before-delete enforcement; audit trail; grace periods |

### EC-CMP-02 — GDPR Request for Child Data (طلب بيانات الطفل بموجب GDPR)

| Field | Value |
|---|---|
| **Scenario** | A GDPR/data rights request is made for a child's data — either by the child themselves (if they reach the age of capacity) or by a parent on behalf of the child |
| **Current state** | Child has accumulated data in the system (learning progress, messages, location history, monitoring data, AI interactions) |
| **Trigger** | Parent requests child data export from SCR-ADM-08, or child reaches age of capacity (varies by jurisdiction: 13 in US, 16 in EU) and requests their own data |
| **Expected system behavior** | 1) Validate requester identity and authority: • Parent: verified parent role in family → granted. • Child (below age of capacity): request routed to parent for approval. • Child (at/above age of capacity): request processed independently (child has own data rights). 2) Scope: ALL child-related data — learning records, messages (their sent + received in family context), location history, monitoring events, AI tutor sessions, quiz results, assignments, badges, content alerts (anonymized parental actions). 3) Format: JSON export + human-readable PDF summary. 4) Excluded: parent-to-parent messages about the child; parent's monitoring settings (parent's data, not child's); Anti-bypass technical data (security-sensitive). 5) If child requests deletion of their data: parental consent required if below age of capacity; above age → child can request independently. 6) Parent requesting deletion of child data: served immediately (parent has authority). 7) Age verification: server-side DOB check; jurisdiction-based age threshold. 8) Log in compliance audit trail. |
| **User-facing UI** | Parent: child data export option in SCR-ADM-08 → progress → download. Child (if age-eligible): own data export in their profile → progress → download. Deletion: confirmation flow with age/authority verification. |
| **Recovery path** | Export: download available for 48 h. Deletion: 30-day grace period, reversible. |
| **Prevention** | Data classification (whose data is it: child's, parent's, family's); age tracking; jurisdiction-aware consent; audit trail; data separation architecture |

### EC-CMP-03 — Audit Log Overflow (تجاوز سجل المراجعة)

| Field | Value |
|---|---|
| **Scenario** | Compliance audit log reaches storage limit or grows so large it impacts performance |
| **Current state** | Audit log has been accumulating events (every setting change, deletion, export, access, role change, consent) |
| **Trigger** | Audit log size exceeds threshold (server-defined, e.g., 1 M events per family or 1 GB) |
| **Expected system behavior** | 1) Detect threshold approach (80% warning, 100% hard limit). 2) At 80%: archive older entries (>12 months) to cold storage; maintain last 12 months in hot storage. 3) At 100%: enforce archival — oldest events auto-archived to cold storage to make room. 4) Cold storage: queryable but slower (acceptable for compliance; audits are rare). 5) Never DELETE audit entries — compliance requires retention (archive, don't purge). 6) If cold storage also reaches limit: alert system admin; raise threshold; compliance team review. 7) Export function always exports from both hot + cold storage. 8) For GDPR deletion requests: audit log entries themselves may need to be pseudonymized (replace names with IDs) but not deleted (legal retention requirement > deletion right for audit data). |
| **User-facing UI** | None visible to user (backend operation). Export includes all archived data. Admin dashboard (internal): storage alerts. |
| **Recovery path** | Automated archival; threshold adjustments; compliance review for very old data |
| **Prevention** | Tiered storage architecture; periodic archival cron; storage monitoring; efficient event format (not verbose); event deduplication for repetitive events (e.g., 1000 location updates → 1 summary event in audit) |

---

*End of Edge Cases & Error States.*
