---
title: "Implementation Roadmap"
tags: [roadmap, implementation, phases, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification
---

# Implementation Roadmap

> Phases are derived from actual system dependencies, not arbitrary V1/V2/V3 splits. Each phase builds on the previous one's foundations.

---

## Phase Dependency Map

```
Phase 1: Foundation
    ↓ (auth + family + DB + offline infrastructure)
Phase 2: Core Family Services
    ↓ (comms + admin + subscription)
Phase 3: Safety Layer
    ↓ (monitoring + native bridges)
Phase 4: Education Layer
    ↓ (subjects + assignments + gamification)
Phase 5: Intelligence Layer
    ↓ (AI capabilities)
Phase 6: Integration & Polish
    ↓ (Today Dashboard + cross-system events)
Phase 7: Commercialization
    ↓ (Paywall + trial + billing)
Phase 8: Scale Preparation
```

---

## Phase 1: Foundation (Weeks 1–4)

| Item | Services | Priority | Dependency |
|------|----------|----------|------------|
| Project setup (Flutter + Riverpod + GoRouter) | — | Critical | — |
| Firebase Auth (email/password + biometric) | S-ADM-001 (partial) | Critical | — |
| Drift local DB + schema | — | Critical | — |
| Cloud SQL schema + migrations | — | Critical | — |
| Firestore setup + Security Rules | — | Critical | — |
| Cloud Functions framework | — | Critical | — |
| RLS policies (all tables) | — | Critical | Cloud SQL |
| Family creation | S-ADM-001 | Critical | Auth + DB |
| Member invitation | S-ADM-002/003/004 | High | Family |
| Device registration | S-ADM-009/010/013 | High | Family |
| Profile + settings | S-ADM-026/027 | Medium | Auth |
| Language (AR/EN + RTL/LTR) | S-ADM-027 | High | Flutter i18n |
| Onboarding flow + permission requests | — | High | Auth + Family |
| Audit log infrastructure | — | High | Cloud SQL |

**Exit criteria:** User can register, create family, invite members, register devices, switch languages, all offline-capable.

---

## Phase 2: Core Family Services (Weeks 5–10)

| Item | Services | Priority | Dependency |
|------|----------|----------|------------|
| Family group chat | S-COM-001 | Critical | Phase 1 |
| 1:1 chat | S-COM-002 | Critical | Phase 1 |
| Sub-groups | S-COM-003 | High | Comms |
| Message reply + read receipts | S-COM-004/011 | Critical | Comms |
| Media sharing (images/files) | S-COM-010/025/029 | High | Firebase Storage |
| Voice messages + transcription | S-COM-041 | High | Whisper |
| Quick reactions | S-COM-048 | Medium | Comms |
| Translation | S-COM-044 | High | Gemini |
| Chat lock (father-only) | S-COM-052 | Medium | Comms |
| Family calendar (Hijri+Gregorian) | S-COM-030/031 | High | Comms |
| Task list | S-COM-032 | Medium | Comms |
| Shopping list | S-COM-033 | Medium | Firestore |
| Live location broadcast | S-COM-035 | High | FusedLocation |
| Arrival/exit alerts | S-COM-036 | Medium | Geofence |
| Notifications + preferences | S-ADM-020/022/023 | High | FCM |
| Mother permissions | S-ADM-028/029 | High | Family |
| Privacy settings | S-ADM-028 | High | Family |
| Data export + deletion | S-ADM-029 | Medium | Cloud SQL |

**Exit criteria:** Family can communicate, share calendar/tasks, share location, receive notifications, manage privacy.

---

## Phase 3: Safety Layer (Weeks 11–18)

| Item | Services | Priority | Dependency |
|------|----------|----------|------------|
| Screen time limits | S-PAR-001/002/003 | Critical | UsageStats bridge |
| Device lock | S-PAR-005 | Critical | Accessibility bridge |
| Bedtime schedule | S-PAR-006 | High | Screen time |
| Extra time request | S-PAR-009 | High | Permission requests |
| GPS tracking | S-PAR-011/012 | Critical | FusedLocation |
| Safe zones (Geofences) | S-PAR-014 | Critical | Geofencing bridge |
| App blocking | S-PAR-015/016 | Critical | Accessibility bridge |
| Web filtering | S-PAR-017/018 | High | Accessibility bridge |
| Content alerts (29 categories) | S-PAR-021/045 | Critical | Accessibility + Gemini |
| SOS | S-COM-039 + S-PAR-032 | Critical | FusedLocation + FCM |
| Kill Switch | S-PAR-041 | Critical | VPN + Accessibility |
| Anti-bypass | S-PAR-038 | Critical | Accessibility + DPM |
| School Time | S-PAR-052 + S-ADM-035 | High | WorkManager + Accessibility |
| School schedule (Hijri) | S-ADM-035 | High | Calendar |
| Focus Mode display | S-PAR-034 | Medium | Education (Phase 4) |
| Device activity report | S-PAR-034 | Medium | Cloud Function |

**Exit criteria:** Father can monitor and control child's device: screen time, apps, web, location, content, Kill Switch, School Time, Anti-bypass. SOS works end-to-end.

---

## Phase 4: Education Layer (Weeks 15–22)

> Overlaps with Phase 3 (Focus Mode depends on Safety app_rules).

| Item | Services | Priority | Dependency |
|------|----------|----------|------------|
| Subject management | S-EDU-001/002 | Critical | Phase 1 |
| Lesson management | S-EDU-003/004 | Critical | Subjects |
| Assignment creation/submission | S-EDU-009/010/011/014 | Critical | Lessons |
| Quiz system | S-EDU-017/019/020 | High | Lessons |
| Progress tracking | S-EDU-024 | High | All education |
| Points + badges | S-EDU-028/029 | High | Progress |
| Focus Mode | S-EDU-034/035 | High | Safety app_rules |
| Quran memorization | S-EDU-038/039 | High | MediaRecorder |
| AI Tutor (basic) | S-EDU-046 | Medium | AI (Phase 5) |
| Placement test | S-EDU-052 | High | Gemini |
| Adaptive learning path | S-EDU-047 | High | Placement |
| Adaptive exercises | S-EDU-051 | High | Adaptive state |
| XP + levels | S-EDU-058 | High | Points |

**Exit criteria:** Child can learn: subjects, lessons, assignments, quizzes, points, badges, Focus Mode, Quran, adaptive learning, XP.

---

## Phase 5: Intelligence Layer (Weeks 19–26)

> Overlaps with Phases 3–4 (AI-002, AI-004, AI-008 serve those layers).

| Item | Services | Priority | Dependency |
|------|----------|----------|------------|
| AI Orchestrator (rate limit + RAG + safety + log) | (infra) | Critical | Gemini + Pinecone + Redis |
| AI Assistant | AI-001 | High | Orchestrator |
| Sentiment analysis | AI-002 | High | Orchestrator + Comms |
| AI Private Tutor | AI-003 | High | Orchestrator |
| Auto assignment grading | AI-004 | High | Orchestrator + Education |
| Educational recommendations | AI-007/020 | High | Orchestrator + Pinecone |
| Quran recitation analysis | AI-008 | High | Whisper + Gemini |
| AI cost tracking | (infra) | High | Cloud SQL |

**Exit criteria:** All 7 P0 AI capabilities functional. Cost tracking active. Rate limiting per plan.

---

## Phase 6: Integration & Polish (Weeks 23–30)

> Overlaps with Phase 5.

| Item | Services | Priority | Dependency |
|------|----------|----------|------------|
| Today Dashboard | S-ADM-033 | Critical | All systems |
| Unified Family Event Model | (infra) | Critical | All systems |
| Cross-system event wiring | (infra) | Critical | Event model |
| Needs-me (alerts, time requests, install approvals) | (UI) | High | Today Dashboard |
| Child profile switcher | (UI) | High | Today Dashboard |
| Live header chips (location, battery, online) | (UI) | High | Today Dashboard |
| Permission denial recovery flow | (UI) | Critical | All bridges |
| Empty/loading/error/denied/locked/trial-expired states | (UI) | High | All screens |
| Shneiderman checklist validation | (QA) | High | All screens |
| RTL/LTR validation | (QA) | High | All screens |
| Real-device testing | (QA) | Critical | Critical devices |

**Exit criteria:** All systems integrated. Today Dashboard aggregates everything. All states implemented. Real-device tests pass.

---

## Phase 7: Commercialization (Weeks 27–32)

> Overlaps with Phase 6.

| Item | Services | Priority | Dependency |
|------|----------|----------|------------|
| 14-day trial auto-start | S-ADM-038 | Critical | Subscription |
| Google Play Billing integration | S-ADM-014/016 | Critical | Play Billing plugin |
| Paywall screen | S-ADM-016 | Critical | Billing |
| Trial expiry → feature gating | (infra) | Critical | Subscription events |
| Trial reminder (Day 11 FCM) | (infra) | High | Scheduled function |
| Grace period (payment failure) | (infra) | High | Billing |
| Feature flag system | (infra) | Medium | All systems |

**Exit criteria:** Trial works. Billing works. Paywall works. Feature gating works. Revenue path is live.

---

## Phase 8: Scale Preparation (Weeks 31–36)

> Overlaps with Phase 7.

| Item | Priority | Dependency |
|------|----------|------------|
| Firebase Crashlytics | Critical | Flutter |
| Firebase Performance Monitoring | High | Flutter |
| Feature flags for safe rollout | High | All |
| Load testing (Cloud Functions) | High | Backend |
| Database partitioning verification | High | Cloud SQL |
| CDN setup (Firebase Storage) | Medium | Storage |
| Monitoring + alerting (backend) | High | Cloud Functions |
| Security audit | Critical | All |
| COPPA/PDPL compliance review | Critical | All |
| Google Play submission + review | Critical | All |
| Beta testing program | High | Real devices |
| App Store Optimization (ASO) | Medium | Marketing |

**Exit criteria:** App is production-ready: monitored, tested, audited, compliant, submitted to Play Store.

---

## Timeline Summary

> ### ⚠️ Re-baselined 2026-09-14 — the 36-week plan was invalid
>
> The 36-week schedule was built when the screen inventory was believed to be **62 screens**. The
> reconciled inventory is **274 distinct surfaces** (`05_user_experience/02_SCREEN_CATALOG_EXPANDED.md`),
> and the owner has confirmed 274 as the official scope. **A 4.4× increase in UI surface cannot be
> absorbed inside an unchanged schedule.** Per the owner's standing rule — *scope and quality are fixed,
> the date moves* — the timeline below is re-baselined rather than compressed.

#### Old baseline (superseded — retained for audit)

| Phase | Weeks | Focus | P0 Services |
|-------|-------|-------|-------------|
| 1. Foundation | 1–4 | Auth, family, DB, offline | 8 |
| 2. Core Family Services | 5–10 | Comms, admin, notifications | 20+8 |
| 3. Safety Layer | 11–18 | Monitoring, native bridges | 20 |
| 4. Education Layer | 15–22 | Learning, gamification, Quran | 24 |
| 5. Intelligence Layer | 19–26 | AI capabilities | 7 |
| 6. Integration & Polish | 23–30 | Today Dashboard, events, states | — |
| 7. Commercialization | 27–32 | Trial, billing, paywall | — |
| 8. Scale Preparation | 31–36 | Testing, audit, launch prep | — |
| ~~Total~~ | ~~36 weeks~~ | **invalid — assumed 62 screens** | 91 |

#### New baseline (binding)

| Phase | Weeks | Screens | Focus | P0 Services |
|-------|-------|:-------:|-------|-------------|
| 1. Foundation | 1–6 | 22 | Auth (email+password), family, DB, RLS, offline, onboarding + permission screens | 8 |
| 2. Core Family Services | 7–16 | 52 | Comms, calls (LiveKit), calendar, tasks, admin, notifications | 20+8 |
| 3. Safety Layer | 17–28 | 49 | Monitoring, native bridges, Kill Switch, SOS, Anti-bypass | 20 |
| 4. Education Layer | 23–36 | 57 | Learning, gamification, Quran, adaptive paths | 24 |
| 5. Intelligence Layer | 31–40 | 19 | AI capabilities + **AI safety guardrails (GAP-AI-01)** | 7 |
| 6. Integration & Polish | 37–46 | 61 | Today Dashboard, shared/state templates, cross-system events, all 8 states | — |
| 7. Commercialization | 43–48 | 14 | Trial, billing, paywall, free-tier gating | — |
| 8. Scale Preparation | 47–52 | — | Testing (565 cases), audit, Play Store review buffer | — |
| **Total** | **52 weeks** | **274** | | **91** |

> Overlaps remain intentional — later phases start before earlier ones fully complete, based on dependencies.

#### How the 52 weeks were derived (so it can be challenged, not just believed)

| Input | Value |
|---|---|
| Distinct surfaces | 274 |
| Less reusable templates/components (SHR-055→061 + shared) | −14 → **260 build items** |
| Blended throughput, Arabic/RTL + 8 mandatory states per screen, 4–5 Flutter devs | **6–7 screens / week** |
| Raw UI build | ≈ 40 weeks |
| Native Android bridges (Accessibility, VPN, Device Admin, overlay) — not screen-bound | +6 weeks, parallel |
| Testing, audit, Play Store review cycles | +6 weeks |
| **Sequenced total with overlap** | **48–56 weeks → plan at 52** |

**Confidence: ±4 weeks**, with two named risks that can move it further:
1. **Google Play Accessibility review (OD-001)** — a rejection blocks **7 P0 services**. Historically 2–6 weeks of appeal per attempt. This is the single largest schedule risk in the project and it is *outside* the team's control.
2. **Kill Switch legality (OD-004)** — unresolved in 5 of 12 target markets. A negative finding removes a headline premium feature and forces repricing.

**Do not re-compress this plan by cutting the 8 mandatory UI states or Arabic/RTL testing.** Those are the two places teams instinctively cut, and both are load-bearing for this product's core promise.

---

## Priority Scoring Model

For each feature within a phase:

| Factor | Weight |
|--------|--------|
| Business Value | 30% |
| User Value | 25% |
| Dependency (blocks others) | 20% |
| Technical Complexity (inverse) | 15% |
| Risk (inverse) | 10% |

**Priority = (Business × 0.3) + (User × 0.25) + (Dependency × 0.2) + (1/Complexity × 0.15) + (1/Risk × 0.1)**
