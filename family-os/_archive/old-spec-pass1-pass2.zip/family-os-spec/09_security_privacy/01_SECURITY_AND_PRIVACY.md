---
title: "Security & Privacy Architecture"
tags: [security, privacy, compliance, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification
---

# Security & Privacy Architecture

---

## 1. Security vs Privacy vs Safety vs Compliance vs Trust

| Concept | Definition | Example in Platform |
|---------|-----------|---------------------|
| **Safety** | Protecting the child from external harm | Content alerts, geofences, Kill Switch, SOS |
| **Security** | Protecting the system from unauthorized access | Auth, encryption, RLS, anti-bypass |
| **Privacy** | Protecting the child's personal data from over-exposure | Father sees sentiment result, not raw messages |
| **Compliance** | Meeting legal requirements | GDPR/PDPL data export + deletion, COPPA child data |
| **Trust** | The family's confidence that the platform acts in their interest | Transparency, human override, audit log |

---

## 2. Authentication

| Aspect | Value |
|--------|-------|
| Method | Firebase Auth Email/Password |
| Biometric | Optional, after first login (local_auth) |
| Phone | NOT for authentication — communication only |
| Session | JWT token via Firebase; refresh automatic |
| Child device | Independent account via email; recovery via email link |
| MFA | Not in MVP (P1 consideration) |
| Password reset | Email link (SCR-SHR-03) |

---

## 3. Authorization

### 3.1 RBAC + mother_permissions

```
User.role → base permissions
  ├─ admin: ALL
  ├─ limited_admin: base + mother_permissions overlay
  └─ child: restricted set
```

### 3.2 Enforcement Layers

| Layer | Technology | Scope |
|-------|-----------|-------|
| App-level | Riverpod providers + GoRouter redirects | Screen visibility, action buttons |
| API-level | Cloud Functions auth check | Every endpoint validates role + family membership |
| Database-level | PostgreSQL RLS policies | Row-level: family_id, user_id scoping |
| Firestore-level | Security Rules | Document-level: family_id scoping |

### 3.3 RLS Policy Pattern

```sql
-- Every family-scoped table has this pattern
CREATE POLICY family_isolation ON messages
  USING (family_id IN (
    SELECT family_id FROM family_members
    WHERE user_id = current_user_id()
    AND status = 'active'
  ));
```

---

## 4. Encryption

| Layer | Technology |
|-------|-----------|
| Transit | TLS 1.3 (all API calls, Firestore, Firebase Storage) |
| At rest | AES-256 (Cloud SQL, Firebase Storage) |
| Calls | E2E via LiveKit (WebRTC DTLS-SRTP) |
| Local | Drift SQLCipher encryption (AES-256) |
| Secrets | Google Secret Manager (API keys, service account) |

---

## 5. Privacy Boundaries

### 5.1 Child Data Protection Rules

| Rule | Implementation |
|------|---------------|
| No raw message text to AI logs | Sentiment logs store only: sentiment, intensity, bullying_risk — NOT the message |
| No raw message text to parent | Parent sees: alert category + severity + recommendation — NOT the message |
| No child photos to parent | Parent sees: "sensitive image detected" — NOT the image |
| Audio deleted after processing | Quran recitation: audio deleted after Whisper analysis |
| Sensitive images: hash + thumbnail only | Store hash + blurred thumbnail — never full image |
| Screen viewer always notifies child | Child sees notification when parent watches |
| Child sees what reaches parent | Transparency screen shows simplified version |

### 5.2 Data Retention

| Data Type | Retention |
|-----------|-----------|
| Messages | Soft delete; hard delete 90 days after |
| Usage logs | 90 days |
| Web history | 60 days |
| Location history | 30 days live; BigQuery archive 1 year |
| Geofence events | 30 days |
| Content alerts | 90 days |
| Sentiment logs | 90 days (no text) |
| Audit logs | 1 year |
| AI conversations | 90 days |
| Emergency events | 1 year |

### 5.3 Data Rights (GDPR/PDPL)

| Right | Implementation |
|-------|---------------|
| Access | Data export (JSON+ZIP) within 24h — S-ADM-029 |
| Rectification | Profile editing per role |
| Erasure | Account deletion with 30-day grace period — S-ADM-029 |
| Portability | JSON export format |
| Object | Child can see what's shared; father can adjust privacy settings |

---

## 6. Anti-Bypass Architecture

| Layer | Mechanism |
|-------|-----------|
| App uninstall prevention | AccessibilityService + DevicePolicyManager |
| Force-stop prevention | Foreground Service (persistent notification) |
| Date/time change detection | AccessibilityService monitors Settings |
| VPN usage detection | Network capability check |
| Safe Mode detection | Boot receiver + check |
| Factory reset detection | DevicePolicyManager wipe callback |
| Accessibility disable attempt | Auto re-enable via Device Admin; FCM urgent to father if fails |

---

## 7. Audit Log

| Event | Logged Fields |
|-------|---------------|
| `family.created` | actor_id, family_id, timestamp |
| `member.invited` | actor_id, invitee_email, role, timestamp |
| `member.joined` | actor_id, user_id, timestamp |
| `role.changed` | actor_id, target_id, old_role, new_role, timestamp |
| `permission.changed` | actor_id, target_id, permission_key, old_value, new_value |
| `device.linked` | actor_id, device_id, user_id, timestamp |
| `device.unlinked` | actor_id, device_id, timestamp |
| `screentime.rule_changed` | actor_id, user_id, old_limit, new_limit |
| `app.blocked` | actor_id, user_id, package_name |
| `web.blocked` | actor_id, user_id, url |
| `killswitch.activated` | actor_id, user_id, duration |
| `content.alert_triggered` | system, user_id, category, severity |
| `sos.activated` | user_id, lat, lng, timestamp |
| `sos.resolved` | actor_id, event_id, resolution |
| `data.exported` | actor_id, family_id, timestamp |
| `data.deleted` | actor_id, family_id, timestamp |

---

## 8. Emergency Access (Break-Glass)

| Scenario | Mechanism |
|----------|-----------|
| Father forgets password | Email recovery link (SCR-SHR-03) |
| Father loses device | Re-auth on new device; old device session revoked |
| Father account deleted | 30-day grace period; mother can be promoted to admin by system |
| Child locked out | Father can unlock remotely; child can request via SCR-PAR-04 |
| SOS override | SOS always works for child regardless of lock state |

---

## 9. Rate Limiting & Abuse Prevention

| Resource | Limit |
|----------|-------|
| AI Assistant | 30/day free; 50/day family; unlimited premium |
| AI Tutor | 20/day free; 30/day family; unlimited premium |
| AI Grading | 5/day free; 20/day family; unlimited premium |
| Translation | Unlimited (cached in Redis) |
| Lesson generation | ❌ free; 3/day family; 10/day premium |
| API calls | 100/min per user |
| SOS | 10/hour (prevent abuse) |
| Login attempts | 5/minute then 15-min lockout |

---

## 10. Compliance Checklist

| Regulation | Status | Notes |
|------------|--------|-------|
| COPPA (US, <13) | ✅ Designed | Parent consent required; no personal data without permission; no raw text storage |
| PDPL (Saudi Arabia) | ✅ Designed | Explicit consent; right of access; deletion; Arabic language |
| GDPR (Europe, future) | ✅ Ready | Export + deletion designed; right to be forgotten; data minimization |
| Google Play Policies | ⚠️ Risk | AccessibilityService + SMS require justification; needs promo video |
| Apple App Store (future) | N/A | iOS deferred |
