---
title: "Observability & Operations"
tags: [operations, observability, devops, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification
---

# Observability & Operations

---

## 1. Observability Stack

| Layer | Tool | Purpose |
|-------|------|---------|
| Crash reporting | Firebase Crashlytics | App crashes, non-fatal errors |
| Performance | Firebase Performance Monitoring | API latency, screen render time |
| Custom metrics | Cloud Functions logging + Google Cloud Monitoring | API health, error rates, queue depth |
| AI cost | Custom `ai_cost_tracking` table + dashboard | Per-family AI spend |
| Business metrics | Custom analytics (privacy-respecting) | DAU, retention, conversion |
| Alerting | Google Cloud Alerting + Slack/email | Critical errors, downtime |

---

## 2. Key Metrics to Monitor

### Application Health

| Metric | Target | Alert Threshold |
|--------|--------|-----------------|
| Crash-free sessions | > 99.5% | < 99% |
| API response P95 | < 500ms | > 1000ms |
| Firestore sync success | > 99.5% | < 98% |
| Offline sync success | > 99% | < 95% |
| App launch time | < 2s | > 4s |
| ANR (App Not Responding) | < 0.1% | > 0.5% |

### AI Operations

| Metric | Target | Alert |
|--------|--------|-------|
| Gemini error rate | < 1% | > 5% |
| Gemini latency P95 | < 5s | > 10s |
| Whisper error rate | < 2% | > 10% |
| AI cost per family/day | < $0.15 | > $0.50 |
| Rate limit hits | < 5% of requests | > 20% |

### Business Metrics

| Metric | Target |
|--------|--------|
| DAU | Growing |
| DAU/MAU ratio | > 0.6 |
| Trial → Paid conversion | > 15% |
| Monthly churn | < 5% |
| SOS response time | < 30s median |

---

## 3. Operations

### 3.1 Deployment Pipeline

```
Developer → Git Push → CI (lint + test + build)
    ↓
Staging (auto-deploy from main)
    ↓
Manual QA + real-device testing
    ↓
Production deploy (Cloud Functions + Firestore rules + SQL migrations)
    ↓
Play Store release (phased rollout: 10% → 50% → 100%)
```

### 3.2 Database Operations

| Operation | Strategy |
|-----------|----------|
| Migrations | Forward-only; versioned; tested on staging |
| Backups | Automated daily Cloud SQL backups + PITR |
| Partitioning | Monthly partitions for high-volume tables |
| Archival | BigQuery for location history > 30 days |
| Indexing | GIN indexes for jsonb; B-tree for FKs; composite for common queries |

### 3.3 Incident Response

| Severity | Definition | Response Time | Actions |
|----------|-----------|---------------|---------|
| P0 (Critical) | App unusable, data loss, SOS broken | < 15 min | Rollback, fix, deploy hotfix |
| P1 (High) | Major feature broken, monitoring fails | < 1 hour | Investigate, fix, deploy |
| P2 (Medium) | Minor feature broken, degraded | < 4 hours | Triage, schedule fix |
| P3 (Low) | Cosmetic, non-blocking | Next sprint | Backlog |

### 3.4 Feature Flags

| Flag | Purpose |
|------|---------|
| `ai_assistant_enabled` | Enable/disable AI assistant per family |
| `kill_switch_enabled` | Enable/disable per market (legal) |
| `sms_monitoring_enabled` | Enable/disable per market (policy) |
| `multi_tier_pricing` | Enable multi-tier when ready |
| `new_feature_*` | Safe rollout of new features |

---

## 4. Compliance Operations

| Requirement | Frequency | Owner |
|-------------|-----------|-------|
| COPPA review | Annual | Legal + Product |
| PDPL review | Annual | Legal + Product |
| Google Play policy review | Per release | Product |
| Security audit | Pre-launch + annual | External |
| Data retention enforcement | Automated daily | System |
| Audit log review | Monthly | Product |
