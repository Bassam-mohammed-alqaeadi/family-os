---
title: "Product Vision & Source of Truth"
tags: [product, vision, mission, source-of-truth, binding]
created: 2026-09-13
updated: 2026-09-13
phase: Unified World-Class Family Platform Specification
authority: product-level — governs all product decisions
---

# Product Vision & Source of Truth

---

## 1. Product Vision

> **أن تصبح المنصة العائلية الذكية المرجع الأول للأسرة العربية في تنظيم حياتها الرقمية وحمایتها وتعليم أبنائها — منصة واحدة بدل ثمانية.**

### Vision Statement (EN)

> To become the reference Family Operating System for the Arab household — unifying communication, protection, education, and intelligence into one coherent platform that grows with the family.

---

## 2. Product Mission

> **تمكين كل أسرة عربية من إدارة تواصلها ومراقبتها الأبوية وتعليم أبنائها في مكان واحد آمن ذكي — بدعم عربي أصيل، تقويم هجري، وأدوار هرمية تحترم الثقافة العائلية.**

---

## 3. Product Principles (Non-negotiable)

| # | المبدأ | المعنى |
|---|--------|--------|
| ١ | **Family First** | كل قرار تصميمي يبدأ من سؤال: هل هذا يخدم الأسرة كوحدة؟ |
| ٢ | **One Platform, Not Many Apps** | لا تُبنى ميزة كجزيرة منفصلة — تتكامل مع السياق العائلي |
| ٣ | **Arabic-First** | العربية أولًا في كل شيء: UI، محتوى، AI، تقويم هجري |
| ٤ | **Safety Over Surveillance** | المراقبة تحمي — لا تتلصص. شفافية الابن منخفضة لكن ليست معدومة |
| ٥ | **Offline-Resilient** | التطبيق يعمل بلا إنترنت. كل Domain يدعم offline mode |
| ٦ | **AI Serves, Not Decides** | AI يوصي ويساعد؛ القرارات الحساسة للإنسان |
| ٧ | **Privacy by Design** | خصوصية الطفل محمية. COPPA/PDPL من اليوم الأول |
| ٨ | **Buildable, Not Theoretical** | كل ميزة قابلة للتنفيذ بالتقنيات المختارة |
| ٩ | **No Orphan Anything** | لا ميزة/بيانات/شاشة/حدث بدون ربط كامل |
| ١٠ | **Commercially Viable** | نموذج إيراد واضح دون تخريب ثقة الأسرة |

---

## 4. Core Problems

| # | المشكلة | الأثر |
|---|---------|------|
| ١ | التفكك التطبيقي | ٥–٨ تطبيقات، ٥–٨ اشتراكات، إرهاق تبديل |
| ٢ | غياب العربية | لا منافس مراقبة عربي أول، لا محتوى تعليمي عربي أصيل |
| ٣ | غياب الأدوار الهرمية | لا منافس يدعم أب/أم/ابن بصلاحيات متدرجة |
| ٤ | غياب التقويم الهجري | لا منافس يقدم هجري+ميلادي متزامن |
| ٥ | غياب القرآن + AI | لا منافس يدمج تحفيظ قرآن + تلاوة بـAI |
| ٦ | غياب التكامل | لا منافس يربط تنبيه محتوى بموقع بمكالمة طوارئ |
| ٧ | غياب AI العائلي | لا منافس يستخدم AI في مشاعر + توصيات + تصحيح + تحليل سلوك |

---

## 5. Value Proposition

| للأسرة | القيمة |
|--------|--------|
| **تواصل** | محادثات + مكالمات + تقويم + مهام في مكان واحد |
| **حماية** | مراقبة شاملة: وقت شاشة + محتوى + موقع + مناطق + Kill Switch |
| **تعليم** | منهج عربي + قرآن + تقييم تكيفي + نقاط + شارات |
| **ذكاء** | AI: مساعد + معلم + تحليل مشاعر + توصيات + تحليل تلاوة |
| **تنظيم** | لوحة اليوم + تقويم هجري + مهام + قوائم |
| **ثقة** | أدوار هرمية + شفافية محدودة + خصوصية + تصدير/حذف |

---

## 6. Product Boundaries

### In Scope (MVP — P0)

- ٩١ خدمة P0 عبر ٥ أنظمة
- ٦٢ شاشة تصميم
- أندرويد أولًا · Flutter + Drift
- AR + EN · هجري + ميلادي
- Premium ٤٩ ر.س/شهر + ١٤ يوم تجريبي
- عائلة: ٦ أفراد / ٤ أطفال / جهاز واحد لكل طفل

### Out of Scope (MVP — مؤجّل P1–P3)

- PickMeUp، مخطط وجبات، محادثة صوتية AI، قصص عائلية، ألبوم
- Contact Watchlist، Sexting prevention، YouTube محسّن، Gaming alerts
- App approval، Slang detection، تقارير أسبوعية موسّعة
- أوردو + هندي

### Non-Goals (هذه الدورة)

- عارض الشاشة · قراءة SMS · سجل المكالمات · صوت باتجاه واحد
- شاشة شفافية الابن العالية (`SCR-SHR-07`)
- iOS · Jetpack Compose كـUI · راوتر/PC · VPN كمنتج مستقل
- marketplace مدرسين · بث عام

### Future Boundaries (بعد MVP)

- iOS support
- Web dashboard for parents
- Multi-device per child
- Extended family / grandparent roles
- School integration API
- Smart home integration
- Wearable support

---

## 7. Target Users (deep)

### Persona 1: أبو خالد (الأب — `admin`)

| البند | التفاصيل |
|-------|---------|
| العمر | ٣٥–٤٥ |
| الدور | مالك العائلة — كل الصلاحيات |
| الوظيفة | موظف / رجل أعمال |
| الهدف | حماية أبنائه رقميًا + ضمان دراستهم + تواصل عائلي منظم |
| الإحباط | ٥ تطبيقات لمراقبة ابن واحد؛ لا يرى الصورة كاملة؛ تنبيهات متأخرة |
| Key JTBD | "عندما يحدث شيء خطير لابني، أريد أن أعرف فورًا مع السياق الكامل، دون فحص ٥ تطبيقات." |

### Persona 2: أم خالد (الأم — `limited_admin`)

| البند | التفاصيل |
|-------|---------|
| العمر | ٣٠–٤٠ |
| الدور | شريك — صلاحيات يفتحها الأب |
| الهدف | متابعة أبنائها + تنظيم حياة العائلة |
| الإحباط | لا تريد المراقبة الثقيلة لكن تريد رؤية الموقع + الدراسة |
| Key JTBD | "أريد تنظيم حياة عائلتي في مكان واحد — وجبات، تقويم، مهام، ومتابعة أبنائي." |

### Persona 3: خالد (الابن — `child`)

| البند | التفاصيل |
|-------|---------|
| العمر | ٨–١٦ |
| الدور | خاضع للمراقبة — لا يمكن إيقاف مشاركة الموقع/النشاط |
| الهدف | ألعاب + تواصل مع العائلة + دراسة بدون ملل |
| الإحباط | لا يفهم لماذا حُظر تيك توك؛ يشعر بأن والديه يتجسسون |
| Key JTBD | "أريد أن أذاكر بطريقة ممتعة وأكافأ، وأن أفهم ما يصل لوالديّ." |

---

## 8. Success Metrics

| Metric | Target |
|--------|--------|
| DAU/MAU ratio | > ٠٫٦ (الاستخدام اليومي ضروري للمراقبة) |
| Trial → Paid conversion | > ١٥٪ |
| Churn (monthly) | < ٥٪ |
| NPS | > ٤٠ |
| SOS response time | < ٣٠ ثانية من إطلاق الابن لاستلام الأب |
| Crash-free sessions | > ٩٩٫٥٪ |
| Offline sync success | > ٩٩٪ عند عودة الاتصال |
| Time to onboard family | < ٥ دقائق |
| Screen time compliance | > ٩٠٪ (الابن لا يتجاوز الحد) |
| Market share (Arab family apps) | ١٠٪ بحلول ٢٠٢٨ |

---

## 9. Strategic Target

> **$٩٠٠ مليون دولار تقييم بحلول ٢٠٢٨** — عبر نموذج اشتراك + توسع إقليمي + طبقات AI قابلة للتفعيل.

---

## 10. Authority Chain

```
Product Vision & Source of Truth (this file)
    ↓
Domain Model + Capability Map
    ↓
Requirements (extracted + audited)
    ↓
Architecture + Data + Security + AI
    ↓
UX Architecture + Screen Contracts
    ↓
Traceability + Quality + Roadmap
```

> لا اختراع صاعدًا. لا إعادة فتح القرارات المسجّلة هنا.
