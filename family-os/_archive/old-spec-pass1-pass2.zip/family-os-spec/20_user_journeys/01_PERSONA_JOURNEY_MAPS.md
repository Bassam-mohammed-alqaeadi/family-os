# Persona Journey Maps — World-Class Family OS

> **Document type:** User Journey Maps  
> **Platform:** World-Class Family OS (Arabic-first family platform)  
> **Roles:** Father (admin) · Mother (limited_admin) · Child (child)  
> **Date:** 2026-09-13  
> **Status:** Specification — Comprehensive  

---

## Table of Contents

1. [Overview & Methodology](#1-overview--methodology)
2. [Persona Profiles](#2-persona-profiles)
   - 2.1 Abu Khalid (Father — admin)
   - 2.2 Umm Khalid (Mother — limited_admin)
   - 2.3 Khalid (Child — child)
3. [Father Journey Maps](#3-father-journey-maps)
   - 3.1 J-F01: First-Time Onboarding
   - 3.2 J-F02: Daily Monitoring Routine
   - 3.3 J-F03: Emergency Response (SOS)
   - 3.4 J-F04: Educational Management
   - 3.5 J-F05: Subscription Management
4. [Mother Journey Maps](#4-mother-journey-maps)
   - 4.1 J-M01: Joining the Family
   - 4.2 J-M02: Daily Family Management
   - 4.3 J-M03: Educational Support
5. [Child Journey Maps](#5-child-journey-maps)
   - 5.1 J-C01: First-Time Setup
   - 5.2 J-C02: Daily Learning Routine
   - 5.3 J-C03: Communication
   - 5.4 J-C04: Screen Time Management
6. [Cross-Persona Interaction Patterns](#6-cross-persona-interaction-patterns)
7. [Journey Emotion Heatmap Summary](#7-journey-emotion-heatmap-summary)

---

## 1. Overview & Methodology

This document maps the end-to-end journeys of three personas across the **World-Class Family OS** — an Arabic-first family platform serving Saudi and Gulf-region families. Each journey is traced from trigger to resolution, capturing user actions, system responses, emotional states, touchpoints, pain points, and design opportunities.

### Methodology

- **Journey mapping approach:** Stage-based mapping with emotional arc tracking
- **Emotion scale:** 😊 Happy · 😐 Neutral · 😣 Frustrated · 😰 Anxious · 😌 Relieved · 🤩 Delighted
- **Touchpoint notation:** `SCR-XXX-XX` = screen ID reference from the product specification
- **Cultural context:** Saudi family structure, Hijri calendar integration, Arabic-first design, Islamic educational priorities (Quran memorization, prayer times)

### Journey Inventory

| Persona | Journey ID | Journey Name | Priority | Flow Doc |
|---------|-----------|-------------|----------|----------|
| Father | J-F01 | First-Time Onboarding | P0 | `flows/01` |
| Father | J-F02 | Daily Monitoring Routine | P1 | `flows/03` |
| Father | J-F03 | Emergency Response (SOS) | P0-CRITICAL | `flows/02` |
| Father | J-F04 | Educational Management | P1 | — |
| Father | J-F05 | Subscription Management | P1 | — |
| Mother | J-M01 | Joining the Family | P0 | `flows/01` |
| Mother | J-M02 | Daily Family Management | P1 | `flows/03` |
| Mother | J-M03 | Educational Support | P1 | — |
| Child | J-C01 | First-Time Setup | P0 | `flows/01` |
| Child | J-C02 | Daily Learning Routine | P1 | `flows/03` |
| Child | J-C03 | Communication | P1 | `flows/03` |
| Child | J-C04 | Screen Time Management | P1 | `flows/03` |

---

## 2. Persona Profiles

### 2.1 Abu Khalid (Father — admin)

| Attribute | Detail |
|-----------|--------|
| **Name** | Abu Khalid (أبو خالد) |
| **Real name** | Khalid Al-Otaibi (خالد العتيبي) |
| **Role** | Father — `admin` |
| **Age** | 38 |
| **Location** | Riyadh, Saudi Arabia |
| **Occupation** | Project manager at a construction company |
| **Family** | Wife (Umm Khalid), two sons (Khalid 12, Saud 9), one daughter (Layla 7) |
| **Tech comfort** | Moderate — uses WhatsApp, banking apps, but finds monitoring tools confusing |
| **Device** | iPhone 15 Pro (primary), iPad (occasional) |

**Goals:**
- Protect children digitally — know what apps they use, what content reaches them
- Ensure education — verify homework completion, track Quran memorization
- Organized family communication — one place for calendar, tasks, messages
- Immediate awareness when something dangerous happens

**Frustrations:**
- 5 separate apps to monitor one child — location app, screen time app, content filter app, school app, family chat app
- No complete picture — each app shows a fragment, no unified view
- Late alerts — discovers problems hours or days after they happen
- Setup complexity — giving up on configuration halfway through

**JTBD:**
> "When something dangerous happens to my son, I want to know immediately with full context, without checking 5 apps."

**Navigation:** Father bottom nav → `Today · Communicate · Monitor · Learn · More`  
**Home screen:** Today Dashboard (SCR-ADM-09) — unified status of all children

### 2.2 Umm Khalid (Mother — limited_admin)

| Attribute | Detail |
|-----------|--------|
| **Name** | Umm Khalid (أم خالد) |
| **Real name** | Nora Al-Harbi (نورة الحربي) |
| **Role** | Mother — `limited_admin` |
| **Age** | 34 |
| **Location** | Riyadh, Saudi Arabia |
| **Occupation** | Homemaker, part-time Quran teacher at neighborhood halaqa |
| **Family** | Same as Abu Khalid |
| **Tech comfort** | Moderate-high — active on social media, manages household digitally |
| **Device** | Samsung Galaxy S24 (primary) |

**Goals:**
- Follow children — know they arrived at school, know they're safe
- Organize family life — meals, calendar, tasks, shopping in one place
- Support education — especially Quran memorization, Arabic, Islamic studies
- Light monitoring — not heavy surveillance, but awareness

**Frustrations:**
- Doesn't want heavy monitoring tools — feels like spying on her own children
- Wants location visibility but not app-by-app breakdown
- Study visibility without micromanaging — wants to see progress, not control every minute
- Fragmented household management — WhatsApp group for family, paper for grocery list, separate calendar app

**JTBD:**
> "I want to organize my family's life in one place — meals, calendar, tasks, and follow my children."

**Navigation:** Mother bottom nav → `Today · Communicate · Monitor · Learn · More`  
**Home screen:** Today Dashboard (SCR-ADM-09) — with limited_admin permissions (monitoring subset visible, admin controls hidden)

### 2.3 Khalid (Child — child)

| Attribute | Detail |
|-----------|--------|
| **Name** | Khalid (خالد) |
| **Role** | Child — `child` |
| **Age** | 12 (oldest child) |
| **Location** | Riyadh, Saudi Arabia |
| **School** | Middle school — 1st year (الصف الأول متوسط) |
| **Tech comfort** | High — gamer, TikTok user, knows his way around phones |
| **Device** | Samsung Galaxy A25 (family-owned, managed by father) |

**Goals:**
- Games + entertainment — wants fun, not just studying
- Family communication — talk to mom, dad, siblings without restrictions
- Studying without boredom — wants it to feel like a game, not a chore
- Earning rewards — points, badges, leveling up feels good

**Frustrations:**
- Doesn't understand why TikTok is blocked — "all my friends have it"
- Feels spied on — knows dad can see everything, doesn't like it
- Screen time limits feel arbitrary — "why only 2 hours?"
- Homework is boring — traditional assignments feel like school at home

**JTBD:**
> "I want to study in a fun way and be rewarded, and understand what reaches my parents."

**Navigation:** Child bottom nav → `Learn · Communicate · My Time · AI · More`  
**Home screen:** Learning Home (SCR-EDU-01) — gamified dashboard with XP, badges, daily quests  
**SOS access:** Floating Action Button (FAB) on every child screen — hold 3 seconds to trigger

---

## 3. Father Journey Maps

### 3.1 J-F01: First-Time Onboarding

**Persona:** Abu Khalid (Father, admin)  
**Trigger:** Discovers the app through a friend's recommendation or an ad; installs from App Store/Google Play  
**Goal:** Get the whole family set up with monitoring active and first alert received  
**Duration:** ~25-40 minutes over 1-2 sessions  
**Priority:** P0

#### ASCII Flow

```
INSTALL ──> REGISTER ──> CREATE FAMILY ──> INVITE MEMBERS ──> LINK CHILD DEVICE
                                                                    │
                                                                    ▼
          FIRST ALERT <── CONFIGURE MONITORING <── SET RULES <── GRANT PERMISSIONS
```

#### Journey Stages

| Stage | User Action | System Response | Emotion | Touchpoint | Pain Point | Opportunity |
|-------|------------|----------------|---------|------------|------------|-------------|
| 1. App Install | Searches "family protection" or "حماية العائلة" in store, taps Install | Downloads app, shows Arabic-first splash screen on launch | 😐 Neutral | App store, splash | App store search results show many competitors — hard to distinguish | Arabic-first store listing with "منصة عائلية متكاملة" positioning |
| 2. Registration | Enters email + password, taps the verification link in his inbox | Creates the account, asks for name "الاسم", family name "اسم العائلة", optional contact phone | 😐 Neutral | SCR-SHR-02 → SCR-SHR-02b | Verification email may land in spam; father may not check email often on mobile | Explicit spam-folder hint, in-app resend, and auto-advance the moment verification lands |
| 3. Family Creation | Enters family name "عائلة العتيبي", selects his role as "الأب" (Father) | Creates family entity, assigns admin role, shows celebratory "مرحباً بك في نظام عائلتك" | 😊 Happy | Family setup wizard | Family name is public-facing — needs guidance on privacy | Auto-suggest "عائلة [اسم العائلة]" from registration data |
| 4. Invite Members | Taps "إضافة أفراد العائلة", sees QR code + link sharing + SMS invite options | Generates invite QR code and shareable link with family token | 😐 Neutral | Member invitation screen | Doesn't know wife needs to install separately — expects instant add | Clear visual: "كل فرد يحتاج تثبيت التطبيق على جواله" with step-by-step |
| 5. Invite Mother | Shares QR code with Umm Khalid via WhatsApp, she scans and starts her own onboarding | Tracks invite status: "بانتظار الانضمام" (pending), shows avatar with pending badge | 😣 Frustrated | Invite status display | No way to remind or re-send invite from father's side without going deep | "تذكير" (remind) button next to pending invite; push notification to invitee |
| 6. Link Child Device | Takes Khalid's phone, opens child invite, enters pairing code shown on father's screen | Pairing flow: father shows 6-digit code → child app enters it → devices paired | 😰 Anxious | Device pairing screen (both phones) | This is the critical step — if it fails, monitoring never starts; anxiety about getting it right | Visual pairing animation on both screens, progress indicator, "تم الربط بنجاح" celebration |
| 7. Grant Permissions | On child's phone, approves location access, accessibility service, notification access, device admin | Shows permission list with Arabic explanations of WHY each is needed ("نحتاج الموقع لمعرفة وصول ابنك للمدرسة") | 😣 Frustrated | Permission grant screens on child device | Android permission screens are in English/system language — breaks the Arabic-first promise; too many permissions at once | Pre-permission explanation cards in Arabic BEFORE each system dialog; batch permissions logically |
| 8. Configure Monitoring — Screen Time | Sets daily screen time limit: 2 hours on weekdays, 3 on weekends | Shows time allocation interface with sliders, preview of schedule | 😊 Happy | Screen time config (SCR-MON-02) | Doesn't know what "reasonable" limits are — guesses | Pre-set age-based recommended limits with "ننصح بـ 2 ساعة للأعمار 8-13" |
| 9. Configure Monitoring — App Rules | Reviews installed apps on Khalid's phone, sees TikTok flagged as "غير مناسب" (inappropriate) | App categorization: green (allowed), yellow (conditional), red (blocked), with age-based recommendations | 😰 Anxious | App rules screen (SCR-MON-05) | First time seeing all apps son has installed — may discover unexpected apps; emotional moment | Gentle framing: "هذه التطبيقات على جوال خالد" with one-tap block/allow and recommended defaults |
| 10. Configure Monitoring — Web Filter | Enables web filter with "فلتر المحتوى — مستوى متوسط" (medium content filter) | Shows 29 content categories with toggles, default medium preset selected | 😐 Neutral | Web filter config (SCR-MON-07) | 29 categories is overwhelming — doesn't understand "محتوى عنيف" vs "أسلحة" distinction | Preset levels (خفيف/متوسط/صارم) with plain-language descriptions, expandable detail |
| 11. Configure — Safe Zones | Adds safe zones: home (البيت), school (المدرسة), mosque (الجامع), grandfather's house | Map interface with draggable radius circles, auto-detects home from current location | 😊 Happy | Safe zone setup (SCR-MON-04) | Drawing zones on map is fiddly on phone; radius default unclear | Auto-suggest home address, school from calendar, named presets; default 200m radius |
| 12. Educational Setup | Selects Khalid's grade (أول متوسط), subjects auto-populate: Math, Science, Arabic, Islamic Studies, English, Social Studies | Grade-based curriculum appears, Quran memorization section highlighted | 😊 Happy | Education setup (SCR-EDU-01) | Subject list may not match school exactly — Saudi curriculum varies by track | Confirm "هل هذه المواد تطابق مواد خالد في المدرسة؟" with edit/add option |
| 13. First Alert | Next day, Khalid tries to open TikTok at 3 PM — blocked alert fires | Push notification: "🚨 خالد حاول فتح تيك توك (محظور)" → opens Today Dashboard with details | 😌 Relieved | Today Dashboard (SCR-ADM-09), push notification | Alert may come at work — needs enough context to decide if action needed | Alert includes: time, app, action taken (blocked), child's current location, one-tap "تواصل مع خالد" |

#### Emotional Arc

```
Emotion:  😐 ──> 😐 ──> 😊 ──> 😐 ──> 😣 ──> 😰 ──> 😣 ──> 😊 ──> 😰 ──> 😐 ──> 😊 ──> 😊 ──> 😌
          Install Reg  Family Invite Mother Link   Perms  Screen  Apps   Filter  Zones   Edu    Alert
```

### 3.2 J-F02: Daily Monitoring Routine

**Persona:** Abu Khalid (Father, admin)  
**Trigger:** Daily habit — morning check, evening review  
**Goal:** Verify children are safe and on-track without spending more than 5 minutes  
**Duration:** 2-5 minutes per session, 2-3 sessions per day  
**Priority:** P1

#### ASCII Flow

```
OPEN APP ──> TODAY DASHBOARD ──> SCAN STATUS CARDS ──> DRILL INTO ALERTS?
    │                                    │                     │
    │                                    ▼                     ▼
    │                             ALL GREEN? ──YES──> DONE (relief)
    │                                    │
    │                                    NO
    │                                    ▼
    └──────────────────────────> REVIEW ALERT ──> ADJUST RULES ──> CLOSE
```

#### Journey Stages

| Stage | User Action | System Response | Emotion | Touchpoint | Pain Point | Opportunity |
|-------|------------|----------------|---------|------------|------------|-------------|
| 1. Morning Check | Opens app at 7:30 AM after Fajr prayer | Today Dashboard (SCR-ADM-09) loads: 3 child cards showing location (البيت), screen time used (0), status (نشط/ساكن), last activity | 😐 Neutral | Today Dashboard | If a child hasn't picked up their device, card shows "لا يوجد نشاط" — ambiguous: sleeping or device off? | Distinguish "جهاز مغلق" (device off) vs "لا نشاط" (no activity) with different icons |
| 2. Scan Status Cards | Scans all 3 children: Khalid (green), Saud (green), Layla (green) | Color-coded cards: green = all clear, yellow = attention needed, red = alert | 😌 Relieved | Status cards on dashboard | Three children = three cards to read — quick glance but still 3 separate items | Summary banner at top: "كل الأطفال بخير ✓" when all green — single glance confirmation |
| 3. Evening Review | Opens app at 8:00 PM, sees Khalid's card is yellow | Yellow indicator: "خالد استخدم وقت الشاشة الكامل" (screen time exhausted) | 😐 Neutral | Dashboard, drill-down | Yellow without context — is this bad? He used his allowed time, that's normal | Differentiate "used all time" (informational yellow) from "tried to exceed" (action yellow) |
| 4. Drill into alerts | Taps Khalid's card → sees timeline: school 7:30-2:00, home 2:15, games 4:00-6:00, homework 6:30-7:30 | Day timeline with location changes, app usage breakdown, study sessions | 😊 Happy | Child detail (SCR-MON-01) | Timeline is detailed but long — scrolling needed for full picture | "ملخص اليوم" (day summary) card at top: 3 lines max, then expandable detail |
| 5. Review content alerts | Sees 1 content alert: "محتوى تم حجبه: موقع ألعاب عنيفة" at 4:15 PM during game time | Alert card with category (عنف), action taken (blocked), site name (masked), time | 😰 Anxious | Content alert detail (SCR-MON-08) | "موقع ألعاب عنيفة" — is this a real threat or false positive from a legitimate gaming site? | Show blocked URL domain (not full URL), reason for classification, one-tap "السماح لهذا الموقع" override |
| 6. Adjust rules | Decides to reduce Khalid's weekend game time from 3h to 2h30m | Opens app rules, adjusts, confirmation "تم تحديث القاعدة" | 😐 Neutral | App rules (SCR-MON-05) | Change applies immediately — child may notice mid-game and get upset | Option to "طبق غداً" (apply tomorrow) vs "طبق الآن" (apply now); explain impact to child |

#### Emotional Arc

```
Emotion:  😐 ──> 😌 ──> 😐 ──> 😊 ──> 😰 ──> 😐
          Open  Scan  Evening Drill  Alert  Adjust
```

### 3.3 J-F03: Emergency Response (SOS)

**Persona:** Abu Khalid (Father, admin)  
**Trigger:** Receives SOS push notification from child's device  
**Goal:** Understand the emergency, locate child, make contact, resolve situation  
**Duration:** Seconds to minutes — every second counts  
**Priority:** P0-CRITICAL  
**Full flow documented in:** `flows/02_SOS_EMERGENCY_JOURNEY.md`

#### ASCII Flow

```
SOS PUSH NOTIFICATION (high-priority, sound + vibration)
    │
    ▼
TAP NOTIFICATION ──> SOS FULL-SCREEN OVERLAY
    │                        │
    │                        ├─ Child name + photo
    │                        ├─ Live GPS location + map
    │                        ├─ Battery level
    │                        ├─ Time since trigger
    │                        └─ Device status
    │                                    │
    ▼                                    ▼
CALL CHILD <────────── ONE TAP ─── QUICK ACTIONS PANEL
    │                                    │
    │                                    ├─ اتصال مباشر (call)
    │                                    ├─ إرسال رسالة (message)
    │                                    ├─ طلب موقع محدث (request location)
    │                                    └─ إنهاء حالة الطوارئ (resolve)
    │
    ▼
CHILD ANSWERS? ──YES──> ASSESS ──> RESOLVE ──> LOG SOS EVENT
    │
    NO
    │
    ▼
CALL MOTHER / DRIVE TO LOCATION / CONTACT AUTHORITIES
```

#### Journey Stages (Summary — full detail in flows/02)

| Stage | User Action | System Response | Emotion | Touchpoint | Pain Point | Opportunity |
|-------|------------|----------------|---------|------------|------------|-------------|
| 1. Alert Received | Phone buzzes aggressively, special SOS sound plays (distinct from all other notifications) | Critical push notification overrides Do Not Disturb, full-screen banner on lock screen | 😰 Anxious | Push notification, lock screen | If phone is in pocket at a meeting, the sound must be unmistakable — not just another notification | Unique SOS sound profile + vibration pattern + visual; override DND/silent mode |
| 2. Open SOS View | Taps notification, app opens directly to SOS full-screen overlay | Full-screen red-themed overlay: child name "خالد", photo, live GPS map, battery 73%, "قبل 30 ثانية" | 😰 Anxious | SOS overlay (SCR-SOS-02) | Seconds feel like minutes — loading time of map is critical | Pre-cache map tiles; show text location immediately ("حي النرجس، الرياض") while map loads |
| 3. Assess Context | Reads location: near school, not a safe zone — 800m from school at a location he doesn't recognize | Shows location relative to safe zones, street name, nearby landmarks | 😰 Anxious | SOS map view | Doesn't know what's near that location — is it a shop? a park? a stranger's house? | Show nearby places (POI overlay): "بالقرب من: محل بقالة، متنزه" |
| 4. Call Child | Taps "اتصال مباشر" (direct call) — phone dialer opens with Khalid's number | Initiates call, SOS overlay stays in background; if child doesn't answer, returns to SOS | 😰 Anxious | Dialer + SOS overlay | If child can't answer (danger, phone taken), the call fails and father panics more | Auto-retry 3 times, then auto-call mother, then show "انتقل إلى الموقع" drive directions |
| 5. Child Answers | Khalid answers — "يا بابا، صار مشكلة مع واحد من الشباب" (dad, had a problem with a kid) | Call active, SOS overlay shows "في اتصال" status, location continues updating | 😌 Relieved | Active call screen | Audio quality may be poor; father is stressed and may miss details | After call ends, prompt: "هل تم حل الموقف؟" with quick resolution logging |
| 6. Resolve SOS | Taps "تم حل الموقف" (situation resolved) | SOS event logged with: trigger time, location history, call recording metadata, resolution notes; returns to dashboard | 😌 Relieved | Resolution screen (SCR-SOS-04) | No way to add notes about what happened — loses context for future reference | Optional "ماذا حدث؟" free-text or voice note; auto-generate incident timeline |
| 7. Follow-up | Later that evening, reviews SOS incident in Monitor > SOS History | Shows incident card with timeline, map, call log; sentiment analysis flags emotional state | 😐 Neutral | SOS history (SCR-MON-06) | History is buried in Monitor tab — hard to find after the fact | "حوادث SOS" shortcut on Today Dashboard for 48 hours after an event |

#### Emotional Arc

```
Emotion:  😰 ──> 😰 ──> 😰 ──> 😰 ──> 😌 ──> 😌 ──> 😐
          Alert  Open  Assess  Call  Answer Resolve Follow-up
```

### 3.4 J-F04: Educational Management

**Persona:** Abu Khalid (Father, admin)  
**Trigger:** Weekly — Sunday after Maghrib prayer (start of Saudi school week)  
**Goal:** Assign homework, track completion, review AI grading, adjust learning path  
**Duration:** 10-15 minutes weekly + 3-5 minutes daily check  
**Priority:** P1

#### ASCII Flow

```
SUNDAY EVENING
    │
    ▼
OPEN LEARN TAB ──> SELECT CHILD (KHALID) ──> REVIEW LAST WEEK
    │                                            │
    │                                            ├─ Completed assignments?
    │                                            ├─ AI grades & flags
    │                                            ├─ Quran progress
    │                                            └─ Time spent studying
    │                                                    │
    ▼                                                    ▼
ASSIGN NEW HOMEWORK ──> SELECT SUBJECT ──> SELECT LESSON/UNIT
    │                                            │
    │                                            ▼
    │                                    SET DEADLINE (Hijri date)
    │                                            │
    ▼                                            ▼
CONFIRM ASSIGNMENT ──> NOTIFICATION TO CHILD ──> TRACK THROUGH WEEK
    │                                                    │
    ▼                                                    ▼
WEEKEND REVIEW ──> AI GRADING REPORT ──> ADJUST DIFFICULTY / PATH
```

#### Journey Stages

| Stage | User Action | System Response | Emotion | Touchpoint | Pain Point | Opportunity |
|-------|------------|----------------|---------|------------|------------|-------------|
| 1. Open Learn Tab | Taps "التعليم" (Learn) in bottom nav | Learn dashboard: per-child cards with XP, completion %, badges earned, Quran progress bar | 😐 Neutral | Learn tab (SCR-EDU-01) | Shows all children but father wants to focus on one — needs extra tap | Tab remembers last viewed child; show "استمرار" (continue) card for that child |
| 2. Review Last Week | Taps Khalid's card → weekly summary: Math 85%, Science 72%, Arabic 90%, Quran 3 new verses memorized | Weekly report with subject breakdown, AI-flagged weak areas, time-on-task, streak | 😊 Happy | Weekly report (SCR-EDU-12) | Science at 72% — is this concerning or normal? No benchmark | Show class average or "النطاق الطبيعي: 70-90%" contextual band; flag only if below threshold |
| 3. Review AI Grading | Taps into Science → sees AI-graded quiz: 3 wrong answers on photosynthesis questions | Detailed breakdown: question, child's answer, correct answer, AI explanation, recommended review topics | 😐 Neutral | AI grading detail (SCR-EDU-08) | AI explanation may be too technical; father isn't a science teacher | Plain-language summary: "خالد يحتاج مراجعة عملية التمثيل الضوئي" + link to recommend lesson |
| 4. Assign Homework | Taps "تكليف واجب جديد" (assign new homework), selects Science, picks unit "النباتات" (Plants) | Assignment builder: select subject → unit → lesson → type (quiz/reading/exercise) → deadline | 😊 Happy | Assignment builder (SCR-EDU-06) | Father doesn't know exactly which lesson maps to school curriculum this week | "مزامنة مع المنهج" option: auto-suggest next lesson based on Saudi curriculum pacing |
| 5. Set Deadline | Picks deadline: Thursday 15 Safar 1448 H (Hijri date) — shows as Thursday 25 Sep 2026 Gregorian | Hijri calendar picker with Gregorian conversion displayed alongside | 😊 Happy | Hijri date picker (SCR-COM-04) | Hijri-Gregorian conversion is helpful but father may not think in Hijri for school deadlines | Default to Hijri with Gregorian subtitle; remember preference per user |
| 6. Confirm & Send | Reviews assignment: Science > Plants > Quiz (10 questions), due Thursday, points: 50 XP | Confirmation screen with summary, "إرسال" button, notification preview to child | 😊 Happy | Assignment confirm (SCR-EDU-07) | No way to preview what child will see — father worries if it's too hard | "معاينة كطالب" (preview as student) toggle showing the child's view |
| 7. Daily Track | Monday evening, checks: Khalid hasn't started the Science assignment | Assignment status: "لم يبدأ" (not started) with gentle nudge option | 😣 Frustrated | Assignment tracking (SCR-EDU-10) | Father worries son is ignoring work, but it's only Monday — deadline is Thursday | Show "متبقي 3 أيام" context; only flag if not started by Wednesday |
| 8. Mid-week Check | Wednesday: Khalid completed the quiz, scored 80% | Status: "اكتمل — 80%" with AI feedback; 40 XP earned (out of 50) | 😌 Relieved | Assignment result (SCR-EDU-11) | 80% is good but not perfect — father may not know if intervention needed | Contextual note: "نتيجة جيدة، أعلى من متوسط المستوى" if data supports |
| 9. Adjust Learning Path | Based on week's data, taps "تعديل مسار التعلم" → AI recommends: increase Science difficulty slightly, add Quran review session | Adaptive learning recommendation card with rationale and one-tap apply | 🤩 Delighted | Learning path adjustment (SCR-EDU-13) | Father trusts AI recommendation but doesn't understand the rationale fully | Show 1-sentence "لماذا؟" explanation: "خالد يتقن العلوم بنسبة 80%، يمكن زيادة التحدي تدريجياً" |

#### Emotional Arc

```
Emotion:  😐 ──> 😊 ──> 😐 ──> 😊 ──> 😊 ──> 😊 ──> 😣 ──> 😌 ──> 🤩
          Open  Review Grade  Assign Deadline Confirm Track  Check  Adjust
```

### 3.5 J-F05: Subscription Management

**Persona:** Abu Khalid (Father, admin)  
**Trigger:** Day 11 of 14-day trial — reminder notification  
**Goal:** Decide whether to subscribe, complete payment, manage billing  
**Duration:** 3-5 minutes decision + payment  
**Priority:** P1

#### ASCII Flow

```
TRIAL DAY 11 ──> PUSH: "باقي 3 أيام على انتهاء الفترة التجريبية"
    │
    ▼
OPEN APP ──> BANNER ON DASHBOARD: "3 أيام متبقية"
    │
    ├──> VIEW WHAT'S INCLUDED ──> COMPARISON TABLE
    │                                    │
    │                                    ▼
    │                            DECIDE
    │                           /        \
    │                         /            \
    │                    SUBSCRIBE        SKIP
    │                        │               │
    │                        ▼               ▼
    │              SELECT PLAN         TRIAL EXPIRES
    │              (49 SAR/mo)         FEATURES LOCKED
    │                        │               │
    │                        ▼               ▼
    │              APPLE PAY /      RE-ENGAGE LATER
    │              MADDA / STC PAY
    │                        │
    │                        ▼
    │              PAYMENT CONFIRMED
    │              🎉 "شكراً! عضويتك مفعّلة"
    │                        │
    │                        ▼
    │              MANAGE BILLING (More > Settings)
    │              ├─ Change plan
    │              ├─ Cancel
    │              ├─ Download invoice
    │              └─ Payment method
```

#### Journey Stages

| Stage | User Action | System Response | Emotion | Touchpoint | Pain Point | Opportunity |
|-------|------------|----------------|---------|------------|------------|-------------|
| 1. Trial Reminder | Day 11: receives push at 10 AM — "باقي 3 أيام على انتهاء فترتك التجريبية — اشترك الآن للاستمرار في حماية عائلتك" | Scheduled push notification with value reminder + CTA | 😐 Neutral | Push notification | If father dismisses it, he may forget and lose all monitoring on day 14 | Escalating reminders: day 11 (gentle), day 13 (urgent), day 14 morning (final) |
| 2. Dashboard Banner | Opens app, sees banner on Today Dashboard: "⏰ 3 أيام متبقية في الفترة التجريبية" with "اشترك" button | Non-intrusive banner, dismissible but reappears daily until resolved | 😐 Neutral | Today Dashboard banner | Banner is small and may be scrolled past — urgency not conveyed | Sticky banner at top of dashboard; cannot be fully dismissed during trial's last 3 days |
| 3. View Plans | Taps "اشترك" → subscription page: one plan shown — "العضوية المميزة — 49 ريال/شهرياً" | Clean pricing page: 49 SAR/month, features list, trial benefits carried over, no contracts | 😐 Neutral | Subscription page (SCR-ADM-12) | Only one tier — may wonder if there's a cheaper or annual option | Show monthly 49 SAR + annual option (e.g., 490 SAR — 2 months free) for value perception |
| 4. Compare Features | Scrolls to see what's included: full monitoring, education, AI tutor, SOS, family chat, unlimited members | Feature checklist with checkmarks; "ماذا ستفقد" (what you'll lose) section if trial expires | 😰 Anxious | Feature comparison | "ماذا ستفقد" is a fear-based approach — may feel manipulated | Frame positively: "استمر في الحصول على..." with focus on value, not loss |
| 5. Decide to Subscribe | Taps "اشترك الآن" | Payment method selection: Apple Pay, mada (مدى), STC Pay, Visa/Mastercard | 😊 Happy | Payment method selector | Saudi users prefer mada and Apple Pay; if their card isn't supported, they abandon | Lead with mada and Apple Pay (most common in KSA); STC Pay prominent |
| 6. Payment — Apple Pay | Selects Apple Pay, authenticates with Face ID | Processes payment, shows success animation "🎉 تم تفعيل عضويتك بنجاح" | 🤩 Delighted | Payment confirmation | If payment fails (insufficient funds, card declined), no clear recovery | Show specific error: "تم رفض البطاقة — جرب طريقة دفع أخرى" with one-tap retry |
| 7. Confirmation | Sees confirmation: "العضوية المميزة — مفعّلة" with next billing date "15 أكتوبر 2026 — 49 ريال" | Dashboard banner changes to "✓ عضوية مفعّلة" then disappears after 3 seconds | 🤩 Delighted | Confirmation + dashboard | Receipt/invoice not immediately available — may need for employer reimbursement | "تحميل الفاتورة" button on confirmation; auto-save to More > Settings > Billing |
| 8. Manage Billing | Two months later, wants to change to annual plan: More > Settings > العضوية والفوترة | Billing page: current plan, next billing date, payment method, change/cancel options, invoice history | 😐 Neutral | Billing settings (SCR-ADM-13) | Cancel option may be hidden in sub-menu — feels like dark pattern | Clear, honest layout: change plan and cancel at same visual level; no confirmation maze |
| 9. Cancel Consideration | Reads cancel flow: "هل أنت متأكد؟ ستفقد..." with two buttons: "استمرار الإلغاء" and "البقاء مشترك" | Cancellation flow with retention offer: "احصل على شهر مجاني بدلاً من الإلغاء" | 😐 Neutral | Cancel flow | Retention offer is good UX but must be honest — not a trap | Offer one free month as genuine option; honor cancel immediately if user proceeds |

#### Emotional Arc

```
Emotion:  😐 ──> 😐 ──> 😐 ──> 😰 ──> 😊 ──> 🤩 ──> 🤩 ──> 😐 ──> 😐
          Remind Banner Plans  Compare Decide Payment Confirm Manage Cancel
```

---

## 4. Mother Journey Maps

### 4.1 J-M01: Joining the Family

**Persona:** Umm Khalid (Mother, limited_admin)  
**Trigger:** Receives WhatsApp message from Abu Khalid with invite link/QR code  
**Goal:** Install app, join family, configure permissions with father, start using  
**Duration:** ~15-20 minutes  
**Priority:** P0

#### ASCII Flow

```
RECEIVE INVITE (WhatsApp) ──> SCAN QR / TAP LINK ──> APP STORE REDIRECT
    │                                                    │
    │                                                    ▼
    │                                              INSTALL APP
    │                                                    │
    ▼                                                    ▼
REGISTER (phone + name) <────────────────────────── LAUNCH APP
    │
    ▼
DETECT FAMILY INVITE ──> AUTO-LINK TO FAMILY
    │
    ▼
SELECT ROLE: "الأم" (Mother)
    │
    ▼
PERMISSION CONFIGURATION (with father)
    │
    ├─ Father opens: limited_admin settings for Umm Khalid
    ├─ Toggles ON: location view, study progress, calendar, tasks, shopping
    ├─ Toggles OFF: Kill Switch, Anti-bypass, web filter config, billing
    │
    ▼
CONFIRM ──> DASHBOARD LOADS (limited view) ──> START USING
```

#### Journey Stages

| Stage | User Action | System Response | Emotion | Touchpoint | Pain Point | Opportunity |
|-------|------------|----------------|---------|------------|------------|-------------|
| 1. Receive Invite | Gets WhatsApp message from Abu Khalid: "نزلي التطبيق وامسحي الكود" with QR image | Father's app generates QR + link; mother receives it in WhatsApp | 😐 Neutral | WhatsApp, QR code | QR code in WhatsApp image may not scan well — screenshot needed | Link-based invite as primary, QR as secondary; link opens app store if app not installed |
| 2. Install App | Taps link → redirected to Google Play → installs | App installs, launches with Arabic-first splash | 😐 Neutral | Google Play | Download size may be large for her data plan — Saudi mobile data is not unlimited | Show app size upfront; offer "تثبيت لاحقاً على Wi-Fi" reminder option |
| 3. Register | Enters her phone number (+966), receives SMS code, enters name "نورة", role auto-detected from invite as "الأم" | Registration pre-fills family token from invite link; role pre-selected as Mother | 😊 Happy | Registration screen | Simpler than father's — she doesn't create family, just joins; but if link expired, confusion | Show "أنت تنضم لعائلة العتيبي" banner during registration — confirms context |
| 4. Auto-Link to Family | Completes registration → app shows "تم انضمامك إلى عائلة العتيبي ✓" with family member avatars | Family entity auto-linked via invite token; her avatar appears on father's app as "انضمت" | 🤩 Delighted | Family join confirmation | If father hasn't configured her permissions yet, she sees empty dashboard — confusing | Show "بانتظار إعداد الصلاحيات من الأب" placeholder with estimated wait, not a blank screen |
| 5. Permission Configuration | Abu Khalid opens his app, sees notification "نورة انضمت — اضبط صلاحياتها", configures her access | Father's admin panel: permission toggles for mother role — grouped by category | 😐 Neutral | Father's permission config (SCR-ADM-04) | Father must do this manually — if he delays, mother is stuck with no access | Auto-suggest default mother permissions: location + education + communications ON, advanced monitoring OFF |
| 6. Configure Together | Father and mother sit together: he explains what he enabled, she asks for study visibility | Permission toggles applied; mother's app refreshes to show enabled features | 😊 Happy | Permission config (both devices) | This is a trust conversation — the tool should facilitate, not dictate | Provide a "مشاركة الصلاحيات" screen both can see — maybe father's screen mirrors to hers |
| 7. Dashboard Loads | Mother's app shows Today Dashboard: children's location (visible), calendar (visible), tasks (visible), monitoring controls (hidden) | limited_admin dashboard: shows subset of admin features; monitoring tab shows location + study, not web filter or Kill Switch | 😊 Happy | Today Dashboard (limited) | Hidden features may look like missing features — she might think the app is broken | Subtle "متاح للأب فقط" (admin only) labels on restricted features, not just hidden |
| 8. First Action | Opens calendar, adds event: "موعد الطبيب — خالد، الثلاثاء 4 مساءً" | Calendar entry created, syncs to all family members, Hijri date displayed | 😊 Happy | Calendar (SCR-COM-03) | Calendar may already have events father added — she needs to see them | Show existing events prominently; don't let her create duplicates |

#### Emotional Arc

```
Emotion:  😐 ──> 😐 ──> 😊 ──> 🤩 ──> 😐 ──> 😊 ──> 😊 ──> 😊
          Invite Install Reg  Join  Perms Config Dashboard First action
```

### 4.2 J-M02: Daily Family Management

**Persona:** Umm Khalid (Mother, limited_admin)  
**Trigger:** Daily — morning planning, throughout day for tasks/shopping  
**Goal:** Keep family organized: meals, calendar, tasks, shopping, children's location  
**Duration:** Ongoing throughout the day — micro-interactions  
**Priority:** P1

#### ASCII Flow

```
MORNING (6:30 AM, after Fajr)
    │
    ├─> Open app → Today Dashboard
    │      ├─ Children's status (home, sleeping)
    │      ├─ Today's calendar: "خالد - مدرسة 7:00", "سعود - مدرسة 7:30"
    │      └─ Today's tasks: "تحضير الغداء", "شراء خضار"
    │
    ▼
AFTERNOON (2:00 PM)
    │
    ├─ Push: "خالد وصل إلى منطقة آمنة: المنزل ✓"
    ├─ Open Communicate tab
    │      ├─ Family chat: "وينكم؟ تعالوا غداكم جاهز"
    │      └─ Shopping list: add "حليب، خبز، بيض"
    │
    ▼
EVENING (7:00 PM)
    │
    ├─ Open Communicate > Calendar
    │      ├─ Add: "زيارة الجدة - الجمعة بعد العصر"
    │      └─ Check: "خالد - واجب العلوم - الخميس"
    │
    ├─ Open Monitor > Location
    │      └─ Khalid at mosque (safe zone) ✓
    │
    ▼
NIGHT (9:30 PM)
    │
    └─ Quick check: all children home, screen time ending, tomorrow's calendar
```

#### Journey Stages

| Stage | User Action | System Response | Emotion | Touchpoint | Pain Point | Opportunity |
|-------|------------|----------------|---------|------------|------------|-------------|
| 1. Morning Planning | Opens app at 6:30 AM, sees Today Dashboard: calendar shows school times, tasks for the day, meal planner empty | Dashboard with: today's events, tasks list, shopping list status, meal planner prompt | 😐 Neutral | Today Dashboard (SCR-ADM-09) | Meal planner is empty — she forgot to plan yesterday | Pre-fill meal planner with suggestions based on past entries: "اقتراح: مقلوبة بالدجاج" |
| 2. Add Meal Plan | Taps meal planner, enters "كبسة دجاج للغداء، فطور: بيض وخبز، عشاء: شوربة" | Meal planner saves entries, syncs to shopping list if ingredients are missing | 😊 Happy | Meal planner (SCR-COM-08) | No auto-generate shopping items from meal plan — must manually add ingredients | "أضف مكونات لقائمة التسوق" button that parses meal plan and suggests items |
| 3. Check Children's Location | Before school run, checks all 3 children — Saud and Layla still home, Khalid already left (location shows moving toward school) | Location map with child markers, movement direction, ETA to destination | 😊 Happy | Location view (SCR-MON-03) | Khalid's marker on the road — is he walking or in a car? Movement speed unclear | Show movement mode: "مشي" / "في سيارة" based on speed; ETA to school |
| 4. Add Shopping Items | During the day, remembers items: opens Communicate > Shopping, adds "حليب، خبز، بيض، طماطم، بصل" | Shopping list with categories (ألبان، مخبوزات، خضار), checkboxes, share with family | 😊 Happy | Shopping list (SCR-COM-07) | Items are uncategorized — list is just text; no quantities | Auto-categorize items on add; quantity field; "شاركي مع أبو خالد" share button |
| 5. Afternoon Location Alert | 2:00 PM: push notification "خالد وصل إلى المنزل ✓" — auto-check from safe zone | Geofence-triggered push: child entered safe zone, with timestamp | 😌 Relieved | Push notification | Good notification, but if it DOESN'T come (child went elsewhere), she may not notice absence | If no arrival notification by expected time + 15 min, send "خالد لم يصل بعد — تحقق من موقعه" |
| 6. Family Chat | Opens Communicate > Family Chat, sends voice message: "خلصتوا مدرسة؟ تعالوا البيت، الغدا جاهز" | Voice message recorded (15 sec), transcribed automatically, sent to family group | 😊 Happy | Family chat (SCR-COM-01) | Voice message transcription is Arabic — accuracy varies with dialect | Najdi/Saudi dialect-aware transcription; show transcription with "تحقق من النص" option |
| 7. Translation Needed | Khalid replies in English (school assignment practice): "I'm on my way mom" | In-app translation: shows original + Arabic translation "أنا في طريقي يا أمي" below | 🤩 Delighted | Chat translation (SCR-COM-01b) | Translation is one-way (to Arabic); if she wants to reply in Arabic for him to practice English, no reverse | Bidirectional toggle: "ترجمة تلقائية" for both directions; language learning context |
| 8. Evening Calendar Check | Opens Communicate > Calendar, Hijri view: today is 14 Safar 1448 H, adds event for Friday 16 Safar: "زيارة الجدة بعد العصر" | Hijri calendar with Gregorian subtitle, event added, notified to all family members | 😊 Happy | Calendar (SCR-COM-04) | Prayer time overlay missing — "بعد العصر" is relative, needs prayer time reference | Show prayer times on calendar; auto-convert "بعد العصر" to actual time based on location |
| 9. Evening Location Check | Opens Monitor > Location at 7 PM: Khalid at الجامع (mosque, safe zone), Saud at home, Layla at home | Map with all 3 children, safe zone indicators | 😌 Relieved | Location map (SCR-MON-03) | Must manually open to check — no passive awareness | Scheduled location summary push at key times: after school, after Maghrib, after Isha |
| 10. Night Wrap-up | 9:30 PM: quick dashboard glance — all children home, screen time for Khalid 1h45m used (15 min remaining), tomorrow's events visible | Dashboard evening view: all-green status, screen time summary, tomorrow preview | 😌 Relieved | Today Dashboard | Screen time running out for Khalid — will he be cut off mid-game? | Show "خالد: 15 دقيقة متبقية" with option to extend by 15 min for tonight |

#### Emotional Arc

```
Emotion:  😐 ──> 😊 ──> 😊 ──> 😊 ──> 😌 ──> 😊 ──> 🤩 ──> 😊 ──> 😌 ──> 😌
          Plan  Meal  Loc   Shop  Alert Chat  Trans Calendar Check Wrap-up
```

### 4.3 J-M03: Educational Support

**Persona:** Umm Khalid (Mother, limited_admin, part-time Quran teacher)  
**Trigger:** Daily — homework support, Quran memorization follow-up  
**Goal:** Assign homework, monitor progress, communicate with child about studies  
**Duration:** 5-10 minutes daily + 15 min Quran session  
**Priority:** P1

#### ASCII Flow

```
OPEN LEARN TAB ──> SELECT CHILD (KHALID)
    │
    ├─ Check: Today's assignments (from father + school)
    ├─ Check: Quran memorization progress
    ├─ Check: AI tutor recommendations
    │
    ▼
ASSIGN QURAN TASK ──> SELECT SURAH/VERSES ──> SET MEMORIZATION DEADLINE
    │
    ▼
MONITOR PROGRESS ──> KHALID OPENS APP ──> RECITES QURAN ──> AI ANALYSIS
    │                                                    │
    │                                                    ├─ Tajweed accuracy
    │                                                    ├─ Pronunciation score
    │                                                    └─ Memorization retention
    │
    ▼
REVIEW AI REPORT ──> COMMUNICATE WITH KHALID (encouragement / correction)
    │
    ▼
ADJUST LEARNING PATH (with father's approval if needed)
```

#### Journey Stages

| Stage | User Action | System Response | Emotion | Touchpoint | Pain Point | Opportunity |
|-------|------------|----------------|---------|------------|------------|-------------|
| 1. Open Learn Tab | Taps "التعليم" → sees children's cards: Khalid (Math 85%, Science 72%, Quran: Surah Al-Kahf in progress) | Learn dashboard with per-child progress, focus on Quran memorization section | 😐 Neutral | Learn tab (SCR-EDU-01) | Quran section is mixed with regular subjects — she wants it prominent | Quran memorization as a featured card at top for mother role (based on her Quran teaching background) |
| 2. Review Progress | Taps Khalid's Quran progress: "سورة الكهف — 5 آيات محفوظة، 3 آيات جديدة هذا الأسبوع" | Quran tracker: surah name, verses memorized, verses remaining, last review date, retention score | 😊 Happy | Quran progress (SCR-EDU-04) | Retention score — what does "85% retention" mean for a 12-year-old? | Plain language: "خالد يتذكر 5 من 6 آيات بشكل صحيح — ممتاز لعمره" |
| 3. Assign Quran Task | Taps "تكليف حفظ جديد", selects Surah Al-Mulk verses 1-5, deadline: Friday before Jumu'ah | Assignment builder with Quran-specific options: surah selector, verse range, memorization vs. review mode | 😊 Happy | Quran assignment (SCR-EDU-05) | Selecting verse ranges is manual — must know surah structure | Auto-suggest next verses based on progress; "الآيات التالية: 6-10" recommendation |
| 4. Khalid Recites | Khalid opens app, taps "مراجعة القرآن", recites verses into microphone | AI Quran recitation analysis: records audio, analyzes tajweed rules, compares to reference recitation, scores pronunciation | 😐 Neutral (child) | Quran recitation (SCR-EDU-03) | Khalid may feel self-conscious recording his voice; if AI scores low, he may get discouraged | Positive framing: "أحسنت! 3 آيات صحيحة" before showing corrections; gamify with "نقاط الحفظ" |
| 5. AI Analysis Results | Mother receives notification: "خالد أكمل مراجعة الكهف — نتيجة التجويد: 88%" | Push notification with score, link to detailed analysis: verse-by-verse breakdown, specific tajweed errors highlighted | 😊 Happy | Quran AI report (SCR-EDU-09) | Tajweed errors are technical (إقلاب، إخفاء) — mother may not know all rules | Explain in simple terms: "في كلمة 'يجعل'، يجب إظهار اللام بشكل أوضح" with audio example |
| 6. Listen to Recording | Taps "استماع لتسجيل خالد" — hears his recitation, notes one verse where he hesitated | Audio playback with waveform, verse timestamps, AI-flagged sections marked | 😊 Happy | Audio playback (SCR-EDU-09b) | Audio quality depends on child's microphone — may be noisy | Show AI confidence level: "جودة التسجيل: متوسطة — قد تؤثر على الدقة" |
| 7. Communicate with Khalid | Opens 1:1 chat with Khalid, sends voice message: "ما شاء الله، حلوة المراجعة. بس آية 12 يحتاج تكرارها شوي" | Voice message sent to child's 1:1 chat, transcribed, child receives notification | 😊 Happy | 1:1 chat (SCR-COM-02) | Voice message + Quran feedback in same chat — context gets lost if other messages interleave | "تعليق تعليمي" special message type that pins to the assignment for context |
| 8. Check Other Subjects | Switches to Science: sees Khalid's quiz result 80%, AI-flagged weak area: photosynthesis | Subject overview with recent grades, time-on-task, AI recommendations | 😐 Neutral | Subject detail (SCR-EDU-12) | Science is not her strong area — she can't help with photosynthesis | AI tutor link: "اطلب من المساعد الذكي شرح هذا الدرس لخالد" with one tap |
| 9. Request Father Action | Some monitoring changes require admin — she taps "طلب من الأب" next to a setting she can't change | Sends a request notification to Abu Khalid: "نورة تطلب: زيادة وقت خالد التعليمي 30 دقيقة" | 😣 Frustrated | Permission-gated action | limited_admin means she hits walls — feels like second-class user | Show "اطلب من الأب" instead of hiding; make request frictionless; father approves with one tap |

#### Emotional Arc

```
Emotion:  😐 ──> 😊 ──> 😊 ──> 😐 ──> 😊 ──> 😊 ──> 😊 ──> 😐 ──> 😣
          Open  Review Assign Recite Results Listen  Chat   Check  Request
```

---

## 5. Child Journey Maps

### 5.1 J-C01: First-Time Setup

**Persona:** Khalid (Child, 12)  
**Trigger:** Father hands him the phone with app installed, says "نزل التطبيق وحط رقمك"  
**Goal:** Get through setup so he can play — wants the fun parts, not the monitoring  
**Duration:** ~10-15 minutes (shorter than father's setup — child's is simpler)  
**Priority:** P0

#### ASCII Flow

```
FATHER SAYS "INSTALL APP" ──> CHILD OPENS APP
    │
    ▼
SPLASH SCREEN (fun, colorful) ──> "أهلاً خالد! 🎮"
    │
    ▼
REGISTER (phone number, simple) ──> ENTER PAIRING CODE (6 digits from father)
    │
    ▼
GRANT PERMISSIONS ──> (location, notifications, accessibility)
    │                    │
    │                    ├─ System dialogs (boring, confusing)
    │                    └─ "ليش يحتون الموقع؟" (why do they need location?)
    │
    ▼
WELCOME VIDEO / TUTORIAL ──> "شوف كيف تستخدم التطبيق"
    │
    ▼
LEARNING HOME LOADS ──> SEES XP: 0, LEVEL 1, DAILY QUESTS
    │
    ▼
FIRST LESSON PROMPT ──> "ابدأ أول درس واربح 50 نقطة!"
    │
    ▼
COMPLETE FIRST LESSON ──> 🎉 +50 XP ──> LEVEL UP ANIMATION ──> "أحسنت!"
```

#### Journey Stages

| Stage | User Action | System Response | Emotion | Touchpoint | Pain Point | Opportunity |
|-------|------------|----------------|---------|------------|------------|-------------|
| 1. App Launch | Opens app — sees colorful, game-like splash with Arabic "أهلاً!" | Child-themed splash: bright colors, mascot character, playful animation | 😊 Happy | Splash screen | Doesn't know what this app is — is it a game? school? spying? | Show 3-icon intro: "🎮 تعلم · 💬 تواصل · 🏆 اربح نقاط" — tells him it's fun, not just monitoring |
| 2. Registration | Enters phone number, receives SMS, types code — simple, 30 seconds | Child registration: phone + SMS only (no email needed), name pre-filled from invite | 😊 Happy | Registration (child) | Entering phone number is easy but SMS code may be slow to arrive | Auto-detect SMS code (Android SMS Retriever API); no manual typing |
| 3. Pairing Code | Enters 6-digit code that father shows on his phone | Pairing animation: two phones "connecting" with progress bar; father's screen shows same animation | 😰 Anxious | Pairing screen | Doesn't understand pairing — "ليش جوال أبوي؟" (why dad's phone?) | Simple explanation: "هذا يربط جوالك بعائلتك — حتى أمك وأبوك يقدرون يوصلونك" |
| 4. Grant Permissions | Series of permission dialogs: location, notifications, accessibility, device admin | System permission dialogs (Android) with pre-permission cards in Arabic explaining each | 😣 Frustrated | Permission screens | "ليش يحتون موقعي؟" — feels invasive; system dialogs are technical and scary | Pre-card: "نحتاج موقعك حتى لو ضعت، يقدر أبوك يدل عليك ويساعدك" — safety framing, not surveillance framing |
| 5. Permission Fatigue | 4th permission request — child is getting impatient, taps through without reading | Each permission explained but child skips; system shows "هل أنت متأكد؟" if skipped | 😣 Frustrated | Permission fatigue | Too many permissions in a row — child will approve blindly or refuse | Group permissions: "صلاحيات الأمان" (safety) batch first, delay non-critical ones to later |
| 6. Welcome Tutorial | Short interactive tutorial: 3 screens showing Learn, Communicate, SOS features | Swipeable tutorial with mascot: "هنا تتعلم وتكسب نقاط! وهنا تتكلم مع عائلتك! وهذا زر الطوارئ 🆘" | 😊 Happy | Tutorial screens | Tutorial is skippable — if skipped, child misses SOS explanation | Make SOS tutorial non-skippable (first time only): "اضغط مطوّل على هذا الزر لو صار خطر" |
| 7. Learning Home | Dashboard loads: XP 0, Level 1, avatar (customizable), daily quests, subject cards | Gamified home: big XP counter, progress ring, "مهام اليوم" (daily quests), first subject highlighted | 🤩 Delighted | Learning Home (SCR-EDU-01) | Level 1 with 0 XP feels like starting from nothing — no sense of progress yet | "ابدأ رحلتك" (start your journey) banner with first-lesson CTA prominently displayed |
| 8. Customize Avatar | Taps avatar, picks from character options: boy with ghutra, boy with cap, robot, astronaut | Avatar customizer with unlockable skins (some require XP) | 🤩 Delighted | Avatar selector | Only default avatars available at Level 1 — cool ones locked | Show locked avatars with "افتح عند المستوى 5" — creates motivation to earn XP |
| 9. First Lesson | Taps "ابدأ أول درس" → Science lesson on Plants, interactive with animations | Lesson loads: interactive content with mini-games, progress bar, checkpoint questions | 😊 Happy | Lesson player (SCR-EDU-02) | If lesson is too long, child loses interest before completing | Keep first lesson under 5 minutes; immediate feedback; "أحسنت!" at each checkpoint |
| 10. Earn First Points | Completes lesson, earns 50 XP, level-up animation plays with sound and confetti | XP awarded, level-up celebration, new badge "الخطوة الأولى" (First Step), progress ring animates | 🤩 Delighted | XP/Badge screen (SCR-EDU-14) | After the high of leveling up, what's next? Could feel anticlimactic | "مهمة جديدة متاحة!" immediately after level-up to maintain momentum |
| 11. Discover SOS | Notices red FAB on screen — taps it (short tap) → tooltip: "اضغط مطولاً 3 ثواني في حالة الطوارئ فقط" | Short tap shows tooltip, not SOS trigger; explains the hold-to-trigger safety | 😐 Neutral | SOS FAB tooltip | Child may experiment with it — accidental 3-second hold during exploration | First 24 hours: 3-second hold shows confirmation "هل أنت في خطر؟ نعم/لا" before triggering |

#### Emotional Arc

```
Emotion:  😊 ──> 😊 ──> 😰 ──> 😣 ──> 😣 ──> 😊 ──> 🤩 ──> 🤩 ──> 😊 ──> 🤩 ──> 😐
          Open  Reg   Pair  Perm1 Perm2 Tutor Home  Avatar Lesson Points SOS
```

### 5.2 J-C02: Daily Learning Routine

**Persona:** Khalid (Child, 12)  
**Trigger:** Daily — after school, opens app to do assignments and earn XP  
**Goal:** Study in a fun way, earn points, level up, do Quran  
**Duration:** 30-60 minutes per session  
**Priority:** P1

#### ASCII Flow

```
OPEN LEARN TAB ──> LEARNING HOME
    │
    ├─ XP counter: 1,250 / Level 4
    ├─ Daily quests: 3 of 5 completed
    ├─ Streak: 7 days 🔥
    │
    ▼
CHECK ASSIGNMENTS
    │
    ├─ Science quiz (due Thursday) ──> START
    │      ├─ 10 questions, interactive
    │      ├─ AI grading instant
    │      └─ Score: 80% ──> +40 XP
    │
    ▼
EARN BADGE ──> "عالم النباتات 🌱" ──> LEVEL UP? (check XP bar)
    │
    ▼
QURAN REVIEW
    │
    ├─ Select Surah Al-Kahf verses 1-5
    ├─ Recite into microphone
    ├─ AI analysis: 88% tajweed accuracy
    ├─ Correction suggestions
    └─ +30 XP + "حافظ مميز" badge
    │
    ▼
FOCUS MODE
    │
    ├─ Enable Focus Mode (blocks games for 25 min)
    ├─ Deep work on Math assignment
    └─ Focus Mode ends ──> +20 XP + "متركّز" badge
    │
    ▼
DASHBOARD ──> CHECK LEADERBOARD (family ranking)
    │
    └─ "أنت الأول بين إخوانك! 👑"
```

#### Journey Stages

| Stage | User Action | System Response | Emotion | Touchpoint | Pain Point | Opportunity |
|-------|------------|----------------|---------|------------|------------|-------------|
| 1. Open Learn | Opens app, taps Learn tab → Learning Home: XP 1,250, Level 4, streak 7 days, 3/5 daily quests done | Gamified dashboard with XP ring, streak flame, quest checklist, subject cards | 🤩 Delighted | Learning Home (SCR-EDU-01) | If streak is broken (didn't study yesterday), demotivating to see "0 days" | Streak shield: "استخدم درع المتتالية" (streak shield) earned weekly to protect one missed day |
| 2. Check Assignments | Sees pending: Science quiz (due Thu), Math exercises (due Sun), Quran review (due Fri) | Assignment list with deadlines (Hijri + Gregorian), XP rewards, estimated time | 😐 Neutral | Assignment list (SCR-EDU-10) | Multiple assignments with different deadlines — hard to prioritize | Auto-sort by deadline urgency; show "ابدأ بهذا" recommendation for most urgent |
| 3. Start Science Quiz | Taps Science quiz → 10 questions on Plants unit, interactive format with images | Quiz player: question, multiple choice, immediate feedback, progress bar, timer (optional) | 😊 Happy | Quiz player (SCR-EDU-03) | Some questions are hard — wrong answers feel punishing | After wrong answer: show explanation with "لا بأس، تعلمت شيئاً جديداً" + still earn partial XP |
| 4. AI Grading | Completes quiz — instant grading: 8/10 correct, 80%, AI feedback on 2 wrong answers | Instant AI grade: score, correct/incorrect breakdown, explanation per wrong answer, XP awarded | 😊 Happy | AI grading result (SCR-EDU-08) | AI explanation may be complex; child may not read it | Gamified feedback: "🌟 8 من 10! تعلمت 2 حقيقة جديدة" + simple 1-line explanation per error |
| 5. Earn XP & Badge | +40 XP awarded, progress ring animates toward Level 5, new badge: "عالم النباتات 🌱" | Badge unlock animation, XP counter increment, progress ring fills, level-up check | 🤩 Delighted | XP/Badge animation (SCR-EDU-14) | If not enough to level up, slight disappointment | Show "متبقي 60 نقطة للمستوى 5 — درس واحد آخر!" to maintain motivation |
| 6. Quran Review | Taps Quran tab → selects Surah Al-Kahf verses 1-5 → taps "ابدأ المراجعة" → recites aloud | Recording interface: simple mic button, verse-by-verse prompts, waveform visualization | 😐 Neutral | Quran recitation (SCR-EDU-03b) | Speaking into phone is awkward if siblings are around | Privacy note: "تسجيلك خاص بك وبوالديك فقط" + option to use headphones with mic |
| 7. AI Quran Analysis | Finishes recitation → AI analysis: 88% accuracy, 2 tajweed corrections, verse 3 needs review | Quran AI report: overall score, verse-by-verse breakdown, audio comparison to reference, specific corrections | 😐 Neutral | Quran AI (SCR-EDU-09) | Corrections feel like criticism — "أخطائي أكثر من نجاحاتي" if framed wrong | Lead with strengths: "3 آيات ممتازة! ✨" then "آية 3: لنراجعها معاً" — growth framing |
| 8. Quran XP & Badge | +30 XP, badge "حافظ مميز" (Distinguished Memorizer), streak: Quran 5 days | XP animation, Quran-specific streak counter, badge unlock | 🤩 Delighted | Quran XP screen | Quran badges may be less exciting than game-like badges to some children | Special Quran badge designs with Islamic art motifs — culturally meaningful, not generic |
| 9. Focus Mode | Taps "وضع التركيز" → enables 25-minute focus session → games and non-educational apps blocked | Focus Mode: countdown timer, gentle blocking of entertainment apps, study session tracking, ambient option (nature sounds) | 😐 Neutral | Focus Mode (SCR-EDU-15) | If Focus Mode blocks the app he needs for homework (e.g., browser for research), frustration | Smart Focus: allow whitelisted educational apps; block only entertainment; child can request temporary access |
| 10. Math Assignment | During Focus Mode, works on Math exercises: 5 problems, scratchpad, step-by-step solver hints | Math exercise player: problem display, input area, hint system, AI step-by-step guidance on request | 😣 Frustrated | Math exercises (SCR-EDU-02b) | Math is hard; without help, child may give up; AI hint may not explain in a way he understands | AI Tutor "المساعد الذكي" chat button: "أسأل المساعد" for natural-language help on current problem |
| 11. Focus Mode Ends | Timer ends, Focus Mode lifts, +20 XP, "متركّز" badge, games available again | Focus completion: XP award, badge, screen time for games restored, summary of what was accomplished | 😌 Relieved | Focus completion (SCR-EDU-15b) | Transition from focus to free time — does he immediately jump to games? | "أحسنت! أنجزت 5 مسائل رياضيات. وقت اللعب متاح الآن 🎮" — clear transition |
| 12. Check Leaderboard | Opens "ترتيب العائلة" — sees himself ranked #1 among siblings (Khalid 1,250 XP > Saud 800 XP > Layla 400 XP) | Family leaderboard: ranked list with XP, level, badges, friendly competition framing | 🤩 Delighted | Leaderboard (SCR-EDU-16) | If he's NOT first, may feel demotivated; if always first, no challenge | Show personal best: "أفضل أسبوع لك: 500 نقطة" alongside family ranking; celebrate improvement, not just rank |

#### Emotional Arc

```
Emotion:  🤩 ──> 😐 ──> 😊 ──> 😊 ──> 🤩 ──> 😐 ──> 😐 ──> 🤩 ──> 😐 ──> 😣 ──> 😌 ──> 🤩
          Home  Assign Quiz  Grade XP/Badge Quran AI   QuranXP Focus Math  FocusEnd Leader
```

### 5.3 J-C03: Communication

**Persona:** Khalid (Child, 12)  
**Trigger:** Wants to talk to mom about pickup, message family, or use SOS  
**Goal:** Communicate with family easily, send voice messages, translate if needed  
**Duration:** Micro-interactions — 30 seconds to 2 minutes  
**Priority:** P1 (SOS portion is P0-CRITICAL)

#### ASCII Flow

```
OPEN COMMUNICATE TAB
    │
    ├─ FAMILY CHAT ──────────────────────────────────────────┐
    │      ├─ Text message: "متى تجون؟"                        │
    │      ├─ Voice message (tap-hold record)                 │
    │      ├─ See mom's reply with auto-translate              │
    │      └─ Send emoji / sticker                             │
    │                                                         │
    ├─ 1:1 CHAT (with mom) <──────────────────────────────────┤
    │      ├─ Private conversation                             │
    │      └─ Translation toggle                               │
    │                                                         │
    └─ SOS (EMERGENCY) ──────────────────────────────────────┘
           └─ Hold FAB 3 seconds ──> CONFIRMATION ──> SOS SENT
                                                     │
                                                     ▼
                                              Waiting for response...
                                              (see flows/02 for full flow)
```

#### Journey Stages

| Stage | User Action | System Response | Emotion | Touchpoint | Pain Point | Opportunity |
|-------|------------|----------------|---------|------------|------------|-------------|
| 1. Open Communicate | Taps "تواصل" in bottom nav → family chat opens, shows recent messages | Communicate tab: family chat as default view, contact list for 1:1, recent conversations | 😊 Happy | Communicate tab (SCR-COM-01) | Family chat is default — but he may want 1:1 with mom first | Show both: family chat stream + quick-access mom/dad/sibling avatars at top |
| 2. Send Text Message | Types "متى تجون البيت؟" → sends to family group | Message sent, delivered checkmarks, read receipts show who saw it | 😊 Happy | Family chat (SCR-COM-01) | Read receipts can cause anxiety ("شافها أبوي وما رد") | Standard checkmarks for delivery; read receipts optional per family |
| 3. Send Voice Message | Taps-hold mic icon → speaks "أمي، وينك؟ تعالي خذني من المدرسة" → releases to send | Voice message recorded (8 sec), waveform displayed, auto-transcribed in chat, sent to group | 😊 Happy | Voice message (SCR-COM-01c) | If he releases too early or accidentally, message sends incomplete | "إلغاء" (cancel) swipe option before send; preview before confirm |
| 4. Receive Reply with Translation | Mom replies in Arabic: "أنا في طريقي، 10 دقايق" — but if she sends in English for his practice: "Coming in 10 minutes" | Auto-translation: shows original + Arabic translation below; tap to toggle which is primary | 🤩 Delighted | Chat translation (SCR-COM-01b) | If translation is off, he sees English he can't fully read | Auto-detect foreign language and auto-translate with toggle to see original |
| 5. 1:1 Chat with Mom | Taps mom's avatar → opens private chat → sends "أمي، أبغى ألعب بعد الواجب، كم ساعة عندي؟" | 1:1 chat opens, message sent privately, mom receives notification | 😊 Happy | 1:1 chat (SCR-COM-02) | Can't delete sent messages — said something impulsive, can't take back | Time-limited delete: "حذف الرسالة (خلال دقيقة)" option after sending |
| 6. Stickers & Emoji | Taps sticker icon → browses Arabic/Islamic-themed stickers → sends "بارك الله فيك" sticker | Sticker picker with categories: emotions, Islamic greetings, family-themed, animated | 🤩 Delighted | Sticker picker (SCR-COM-01d) | Limited sticker set at start; cool ones may require XP or purchase | Unlockable sticker packs tied to learning achievements: "افتح حزمة عند المستوى 5" |
| 7. SOS — Trigger (Emergency) | In a stressful situation (confronted by older kids at park), holds red FAB for 3 seconds | 3-second hold triggers haptic escalation: vibration increases at 1s, 2s, 3s; confirmation screen "إرسال طوارئ؟" | 😰 Anxious | SOS FAB, confirmation (SCR-SOS-01) | In real panic, 3 seconds feels long; confirmation screen may slow him down | Make confirmation instant (0.5s auto-confirm) if child has been in same location >5 min and triggers SOS |
| 8. SOS — Waiting | SOS sent — screen shows "تم إرسال الطوارئ ✅ أبوك توصل" with live status | SOS active screen: "تم إبلاغ والدك" + pulsing animation + "انتظر، أبوك راح يتصل فيك" + call button | 😰 Anxious | SOS active (SCR-SOS-03) | Waiting for response is agonizing — no feedback if notification was seen | Show real-time status: "تم الإرسال ✓" → "شافه أبوك ✓" → "يتصل بك..." → "في اتصال" |
| 9. SOS — Father Calls | Father calls → Khalid answers → explains situation → father says "أنا جاي الحين" | Call connects, SOS overlay shows call status, location continues streaming to father | 😌 Relieved | Call screen (SCR-SOS-02b) | If call drops (weak signal), panic returns | Auto-redial on drop; "أبوك يعاود الاتصال" message; fallback to SMS with location link |
| 10. SOS — Resolved | Father arrives, situation handled, father taps "تم الحل" on his app → Khalid's app shows "تم إنهاء حالة الطوارئ ✓" | Resolution notification on child's app; SOS mode exits, normal UI returns; incident logged | 😌 Relieved | SOS resolution (SCR-SOS-04) | No debrief for child — was that scary? Does he need to talk? | Post-SOS check-in (1 hour later): "كيف حالك الآن؟" with mood selector; triggers notification to parents if "زعلان/خايف" |

#### Emotional Arc

```
Emotion:  😊 ──> 😊 ──> 😊 ──> 🤩 ──> 😊 ──> 🤩 ──> 😰 ──> 😰 ──> 😌 ──> 😌
          Open  Text  Voice Trans  1:1   Sticker SOS   Wait  Call  Resolve
```

### 5.4 J-C04: Screen Time Management

**Persona:** Khalid (Child, 12)  
**Trigger:** Wants to play games but screen time is running out or exhausted  
**Goal**: Play games, understand limits, request more time if needed  
**Duration:** Micro-interactions — 30 seconds to 2 minutes  
**Priority:** P1

#### ASCII Flow

```
OPEN "MY TIME" TAB
    │
    ▼
SCREEN TIME DASHBOARD
    ├─ Today: 1h 45m used / 2h 00m limit
    ├─ Breakdown: Games 1h, Educational 30m, Chat 15m
    ├─ 15 minutes remaining ⏱️
    └─ Time resets at 4:00 AM tomorrow
    │
    ▼
15 MIN REMAINING <── NOTIFICATION: "باقي 15 دقيقة"
    │
    ├─ Option 1: Accept and use remaining time wisely
    │      └─ Use 15 min for games ──> Time's up ──> "انتهى وقتك اليوم"
    │
    ├─ Option 2: Request more time
    │      ├─ Tap "اطلب وقت إضافي"
    │      ├─ Select: +15 min / +30 min / +1 hour
    │      ├─ Add reason: "أبغى أكمل مباراة" / "أبغى أخلص واجب"
    │      └─ Send request to parent(s)
    │           │
    │           ▼
    │      PARENT RECEIVES REQUEST
    │           ├─ APPROVE ──> Time extended ──> "تمت الموافقة! +30 دقيقة 🎉"
    │           ├─ DENY ──> "لم تتم الموافقة هذه المرة" + reason
    │           └─ ADJUST ──> "أمك وافقت على 15 دقيقة فقط"
    │
    └─ Option 3: Switch to educational (unlimited)
           ├─ Educational apps don't count against screen time
           └─ Opens Learn tab ──> earns XP ──> might earn bonus game time
```

#### Journey Stages

| Stage | User Action | System Response | Emotion | Touchpoint | Pain Point | Opportunity |
|-------|------------|----------------|---------|------------|------------|-------------|
| 1. Open My Time | Taps "وقتي" (My Time) in bottom nav → screen time dashboard | My Time dashboard: circular progress (used/limit), category breakdown, time remaining, reset time | 😐 Neutral | My Time (SCR-CHD-01) | Seeing "1h 45m of 2h used" — only 15 min left, feels restrictive | Show how much was EARNED through learning: "ربحت 30 دقيقة إضافية بالدراسة!" |
| 2. Category Breakdown | Taps breakdown: Games 1h, Educational 30m (doesn't count), Chat 15m | Bar chart: app categories with time, color-coded (games=blue, edu=green, chat=gray) | 😐 Neutral | Time breakdown (SCR-CHD-01b) | Educational time doesn't count against limit — but he may not realize this | Prominent callout: "⭐ وقت التعليم لا يحسب من وقت اللعب!" to motivate learning |
| 3. 15-Min Warning | Push notification: "⏱️ باقي 15 دقيقة من وقت الشاشة" | Warning push at 15-min and 5-min marks before screen time expires | 😣 Frustrated | Push notification | Interrupts his game — feels like the app is ruining his fun | Warning is necessary, but tone it: "استمتع بآخر 15 دقيقة 👋" not alarming |
| 4. Request More Time | Taps "اطلب وقت إضافي" → selects +30 min → adds reason: "أبغى أكمل مباراة مع ربعاي" | Time request form: duration selector, reason text/voice, send to parent(s) | 😐 Neutral | Time request (SCR-CHD-02) | Has to justify play time — feels like begging | Preset reasons: "أكمل مباراة" / "أخلص واجب" / "عندي ضيوف" to reduce friction |
| 5. Waiting for Response | Request sent — shows "بانتظار رد أمك..." with pulsing animation | Pending request status: sent to mother's app, waiting indicator, auto-notify after 2 min if no response | 😰 Anxious | Request pending (SCR-CHD-02b) | If parent doesn't respond quickly, child is stuck — can't play, can't extend | Auto-approve +15 min if no response in 5 minutes (configurable by parent); prevents stalling |
| 6. Parent Approves | Mother approves +30 min → Khalid sees "🎉 تمت الموافقة! +30 دقيقة إضافية" with celebration | Approval notification, time extended, countdown resets with new total | 🤩 Delighted | Approval notification | May come to expect approvals — entitlement risk | Track approval rate; if >80% approved, suggest parent tighten limits |
| 7. Parent Denies | Mother denies → Khalid sees "لم تتم الموافقة هذه المرة" with reason "خلصت وقتك اليوم، بكرة" | Denial notification with parent's reason (if provided), gentle tone | 😣 Frustrated | Denial notification | No denial reason = child feels arbitrary; "why not?" with no answer | Parent must provide reason (preset options: "وقت متأخر" / "لم تذاكر" / "بكرة يوم مدرسة") |
| 8. Parent Adjusts | Mother approves only +15 min instead of requested 30 → "أمك وافقت على 15 دقيقة فقط" | Adjusted approval with new amount, parent's counter-offer shown | 😐 Neutral | Adjusted approval | Getting less than requested — mildly disappointing but fair | Show parent's reasoning: "أمك: 15 دقيقة كافية اليوم، وقت العشاء قريب" |
| 9. Screen Time Exhausted | Time runs out completely → games lock, screen shows "انتهى وقتك اليوم ⏰ بكرة تبدأ من جديد الساعة 4 صباحاً" | Device lock for entertainment apps; educational apps remain accessible; lock screen with reset time | 😣 Frustrated | Screen time lock (SCR-CHD-03) | Hard lock feels punishing — no explanation of how to earn more | "اكسب وقت إضافي بالتعلم! +15 دقيقة لكل درس تخلصه" — redirect to learning |
| 10. Earn Bonus Time | Opens Learn tab, completes a lesson → earns +15 min bonus game time → games unlock | Educational completion grants bonus entertainment time; notification "أحسنت! +15 دقيقة وقت لعب" | 🤩 Delighted | Bonus time notification | If bonus time ratio is too low (e.g., 30 min study for 5 min play), not motivating | Fair ratio: 15-20 min study = 15 min bonus play; clearly communicated so child sees the deal |
| 11. School Time Lock | At 7:00 AM, School Time activates → all non-educational apps locked during school hours | School Time profile: games locked, location tracking active, only educational + communication apps available | 😐 Neutral | School Time (SCR-MON-09) | If School Time starts too early or runs too late, child can't use phone after school | Configurable by parent: School Time 6:45 AM - 2:30 PM (aligned with actual school hours) |

#### Emotional Arc

```
Emotion:  😐 ──> 😐 ──> 😣 ──> 😐 ──> 😰 ──> 🤩 ──> 😣 ──> 😐 ──> 😣 ──> 🤩 ──> 😐
          Open  Break  Warn  Request Wait  Approve Deny  Adjust Lock   Earn  School
```

---

## 6. Cross-Persona Interaction Patterns

The platform is not three separate experiences — it is one family system where each persona's actions ripple to the others. Below are the key interaction patterns.

### 6.1 Father ↔ Mother: Permission Gate

```
Father (admin)                           Mother (limited_admin)
    │                                          │
    │  ── grants permissions ──────────────>   │
    │     (location, education, comms)         │
    │                                          │
    │  <── requests admin action ──────────    │
    │     (increase screen time, change rules)  │
    │                                          │
    │  ── approves/denies ─────────────────>   │
    │                                          │
```

| Interaction | Trigger | Direction | Emotion Impact |
|------------|---------|-----------|----------------|
| Permission grant | Father configures mother's access | F → M | Mother: 😐→😊 if smooth, 😣 if delayed |
| Admin request | Mother needs a change she can't make | M → F | Mother: 😣 (hits a wall); Father: 😐 (another task) |
| Joint monitoring decision | Both parents discuss a child's alert | F+M | Both: 😰→😌 if aligned, 😣→😣 if they disagree |
| Shared calendar event | Either adds an event | F↔M | Both: 😊 (collaboration working) |

### 6.2 Father ↔ Child: Monitoring & Authority

```
Father (admin)                           Child (child)
    │                                          │
    │  ── sets rules (screen time, apps) ──>   │
    │                                          │
    │  <── screen time request ────────────    │
    │                                          │
    │  ── approves/denies ─────────────────>   │
    │                                          │
    │  <── SOS alert ───────────────────────   │
    │                                          │
    │  ── calls / responds ────────────────>   │
    │                                          │
    │  ── assigns homework ────────────────>   │
    │                                          │
    │  <── homework completed ─────────────    │
    │                                          │
```

| Interaction | Trigger | Direction | Emotion Impact |
|------------|---------|-----------|----------------|
| Rule enforcement | Child tries blocked app | System (F's rules) → C | Child: 😣; Father: 😐 (if alerted) or unaware |
| Screen time request | Child asks for more time | C → F | Child: 😰→🤩/😣; Father: 😐 |
| SOS | Child triggers emergency | C → F | Child: 😰; Father: 😰→😌 |
| Homework assignment | Father creates assignment | F → C | Child: 😐→😣; Father: 😊 |
| Homework completion | Child finishes work | C → F | Child: 🤩; Father: 😌 |
| Content alert | Child accesses flagged content | System → F → (C aware?) | Father: 😰; Child: 😣 if confronted |

### 6.3 Mother ↔ Child: Nurturing & Education

```
Mother (limited_admin)                   Child (child)
    │                                          │
    │  ── assigns Quran task ──────────────>   │
    │                                          │
    │  <── recitation completed ───────────    │
    │                                          │
    │  ── reviews AI report ───────────────>   │
    │                                          │
    │  ── sends voice message (feedback) ──>   │
    │                                          │
    │  <── location arrival notification ──    │
    │     ("خالد وصل للبيت ✓")                  │
    │                                          │
    │  ── approves screen time request ────>   │
    │                                          │
```

| Interaction | Trigger | Direction | Emotion Impact |
|------------|---------|-----------|----------------|
| Quran assignment | Mother assigns memorization | M → C | Child: 😐; Mother: 😊 |
| Recitation feedback | AI report + mother's voice note | M → C | Child: 😊; Mother: 😊 |
| Safe arrival | Geofence trigger | System → M (about C) | Mother: 😌 |
| Screen time approval | Child requests more time | C → M → C | Child: 🤩/😣; Mother: 😐 |
| Daily chat | "تعال غداك جاهز" | M → C | Both: 😊 |

### 6.4 Child ↔ Child (Sibling): Gamified Competition

```
Khalid (12, Level 4)                    Saud (9, Level 2)
    │                                          │
    │  <── leaderboard ranking ────────────>   │
    │     (Khalid #1, Saud #2)                  │
    │                                          │
    │  ── family chat banter ──────────────>   │
    │  <────────────────────────────────────   │
    │                                          │
```

| Interaction | Trigger | Direction | Emotion Impact |
|------------|---------|-----------|----------------|
| Leaderboard | Weekly XP comparison | System → both | Higher rank: 🤩; Lower rank: 😣→motivated or discouraged |
| Family chat | Group conversation | C ↔ C | 😊 (social bonding) |
| Badge envy | One sibling earns cool badge | System → other | 😣 (want it too) → 🤩 (motivation to earn) |

---

## 7. Journey Emotion Heatmap Summary

### Father Journey Heatmap

```
Journey     Stage:  1    2    3    4    5    6    7    8    9    10   11   12   13
J-F01 Onb:        😐   😐   😊   😐   😣   😰   😣   😊   😰   😐   😊   😊   😌
J-F02 Daily:      😐   😌   😐   😊   😰   😐
J-F03 SOS:        😰   😰   😰   😰   😌   😌   😐
J-F04 Edu:        😐   😊   😐   😊   😊   😊   😣   😌   🤩
J-F05 Sub:        😐   😐   😐   😰   😊   🤩   🤩   😐   😐

Color key:  😊 Happy  😐 Neutral  😣 Frustrated  😰 Anxious  😌 Relieved  🤩 Delighted
```

**Father pain clusters:** Stages 5-7 of onboarding (inviting, pairing, permissions) — the highest frustration zone. SOS stages 1-4 (alert through call) — highest anxiety zone.

### Mother Journey Heatmap

```
Journey     Stage:  1    2    3    4    5    6    7    8    9    10
J-M01 Join:       😐   😐   😊   🤩   😐   😊   😊   😊
J-M02 Daily:      😐   😊   😊   😊   😌   😊   🤩   😊   😌   😌
J-M03 Edu:        😐   😊   😊   😐   😊   😊   😊   😐   😣

Color key:  😊 Happy  😐 Neutral  😣 Frustrated  😰 Anxious  😌 Relieved  🤩 Delighted
```

**Mother pain clusters:** J-M03 stage 9 (permission wall — needs father for admin action). J-M01 stages 1-2 (install friction). Overall, mother journeys are more positive — she uses the platform for organization, not surveillance.

### Child Journey Heatmap

```
Journey     Stage:  1    2    3    4    5    6    7    8    9    10   11   12
J-C01 Setup:      😊   😊   😰   😣   😣   😊   🤩   🤩   😊   🤩   😐
J-C02 Learn:      🤩   😐   😊   😊   🤩   😐   😐   🤩   😐   😣   😌   🤩
J-C03 Comm:       😊   😊   😊   🤩   😊   🤩   😰   😰   😌   😌
J-C04 Screen:     😐   😐   😣   😐   😰   🤩   😣   😐   😣   🤩   😐

Color key:  😊 Happy  😐 Neutral  😣 Frustrated  😰 Anxious  😌 Relieved  🤩 Delighted
```

**Child pain clusters:** J-C01 stages 4-5 (permission fatigue), J-C02 stage 10 (math frustration), J-C04 stages 3/7/9 (time warnings, denial, hard lock). The child's experience oscillates between delight (gamification) and frustration (restrictions) — the platform must balance these carefully.

### Overall Emotion Distribution

| Emotion | Father (across all stages) | Mother | Child |
|---------|---------------------------|--------|-------|
| 🤩 Delighted | 11% | 13% | 20% |
| 😊 Happy | 28% | 52% | 28% |
| 😐 Neutral | 30% | 22% | 24% |
| 😣 Frustrated | 17% | 7% | 17% |
| 😰 Anxious | 11% | 4% | 7% |
| 😌 Relieved | 6% | 4% | 4% |

**Key insight:** The child has the most delight (gamification works) but also tied with father for most frustration (restrictions). The mother has the most consistently positive experience — she uses the platform for connection and organization, not control. The father's anxiety spikes are concentrated in SOS and onboarding — these are the flows that need the most design attention.

---

*Related documents:*
- [Onboarding Journey — Full Flow](flows/01_ONBOARDING_JOURNEY.md)
- [SOS Emergency Journey — Full Flow](flows/02_SOS_EMERGENCY_JOURNEY.md)
- [Daily Life Journeys — Full Flow](flows/03_DAILY_LIFE_JOURNEYS.md)
