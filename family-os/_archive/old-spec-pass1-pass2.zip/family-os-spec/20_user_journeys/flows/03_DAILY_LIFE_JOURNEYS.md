# Daily Life Journeys — How the Platform Weaves into Family Life

> **Flow ID:** FLOW-03  
> **Journey IDs covered:** J-F02 (Father daily monitoring), J-M02 (Mother daily management), J-C02 (Child daily learning), J-C03 (Child communication), J-C04 (Child screen time)  
> **Criticality:** P1 — Retention and daily habit formation  
> **Date:** 2026-09-13  

---

## Table of Contents

1. [Journey Overview](#1-journey-overview)
2. [Father: Daily Monitoring Routine](#2-father-daily-monitoring-routine)
3. [Mother: Daily Family Management](#3-mother-daily-family-management)
4. [Child: Daily Learning Routine](#4-child-daily-learning-routine)
5. [Child: Communication Flow](#5-child-communication-flow)
6. [Child: Screen Time Management](#6-child-screen-time-management)
7. [Family Day Timeline — Synchronized View](#7-family-day-timeline--synchronized-view)
8. [Complete ASCII Flow Diagrams](#8-complete-ascii-flow-diagrams)
9. [Critical Pain Points & Design Opportunities](#9-critical-pain-points--design-opportunities)
10. [Edge Cases & Fallback Flows](#10-edge-cases--fallback-flows)
11. [Daily Engagement Metrics](#11-daily-engagement-metrics)

---

## 1. Journey Overview

This document maps how the World-Class Family OS weaves into the daily life of a Saudi family across a typical weekday. Rather than isolated feature flows, these journeys show the **rhythm of a day** — how the platform becomes a natural part of morning routines, school hours, afternoon activities, evening family time, and bedtime.

### The Family — Daily Context

| Member | Role | Device | School/Work | Daily Platform Usage |
|--------|------|--------|-------------|---------------------|
| Abu Khalid (38) | Father (admin) | iPhone 15 Pro | Construction PM, office 7AM-5PM | ~5 min morning, ~5 min evening + alerts |
| Umm Khalid (34) | Mother (limited_admin) | Samsung S24 | Homemaker + Quran halaqa | ~15 min morning, micro-checks through day |
| Khalid (12) | Child (child) | Samsung A25 | Middle school, 7AM-2PM | 30-60 min after school (learning + games) |
| Saud (9) | Child (child) | Samsung A15 | Elementary, 7:30AM-1:30PM | 20-30 min after school (learning + games) |
| Layla (7) | Child (child, manual) | No phone (under 8) | Elementary, 7:30AM-1:30PM | Manual tracking only; borrows mom's phone for lessons |

### A Typical Saudi School Day

```
4:30 AM  Fajr prayer
5:00 AM  Family waking up, morning routine
6:30 AM  Breakfast, children prepare for school
7:00 AM  Khalid leaves for school (walk/bus)
7:30 AM  Saud & Layla leave for school
8:00 AM  Father leaves for work; mother home
         ─── SCHOOL HOURS ───
12:00 PM Dhuhr prayer
1:30 PM  Saud & Layla return from school
2:00 PM  Khalid returns from school
2:30 PM  Lunch (غداء) — family meal
3:00 PM  Asr prayer — quiet time
3:30 PM  Study time / homework / app learning
5:00 PM  Free time / play / screen time
6:00 PM  Maghrib prayer
6:30 PM  Family time / dinner prep
7:30 PM  Isha prayer
8:00 PM  Dinner (عشاء) — family meal
9:00 PM  Children bedtime routine
10:00 PM Children asleep; screen time lock
10:30 PM Parents wind down
```

### Navigation Reference

| Persona | Bottom Nav | Home Screen |
|---------|-----------|-------------|
| Father | Today · Communicate · Monitor · Learn · More | Today Dashboard (SCR-ADM-09) |
| Mother | Today · Communicate · Monitor · Learn · More | Today Dashboard (SCR-ADM-09) — limited view |
| Child | Learn · Communicate · My Time · AI · More | Learning Home (SCR-EDU-01) |
| Child | SOS FAB on every screen (hold 3s to trigger) | — |

## 2. Father: Daily Monitoring Routine

**Persona:** Abu Khalid (Father, admin)  
**Day:** Sunday (first day of Saudi school week) — 14 Safar 1448 H / 22 September 2026  
**Pattern:** Quick morning check → workday with alerts → evening review

### Morning Check (6:45 AM, after Fajr)

| Time | Action | System Response | Screen ID | Emotion | Error / Edge | Success Criteria |
|------|--------|----------------|-----------|---------|-------------|------------------|
| 6:45 | Opens app, taps Today | Dashboard loads: 3 child cards — Khalid (home, sleeping/no activity), Saud (home), Layla (home, manual) | SCR-ADM-09 | 😐 Neutral | Khalid's card: "لا يوجد نشاط" — ambiguous (sleeping vs device off) | Distinguish device-off from no-activity (icon difference) |
| 6:46 | Scans summary banner | "كل الأطفال في البيت ✓" (all children at home) | SCR-ADM-09 (banner) | 😌 Relieved | — | One-glance confirmation that all is well |
| 6:47 | Checks today's calendar | Calendar widget: "خالد — مدرسة ٧:٠٠", "سعود — مدرسة ٧:٣٠", "لاية — مدرسة ٧:٣٠" | SCR-COM-04 (widget) | 😐 Neutral | — | Morning schedule confirmed |
| 6:48 | Closes app, prepares for work | — | — | 😊 Happy | — | Morning check complete in <3 minutes |

### During Workday (8 AM – 5 PM)

| Time | Trigger | System Response | Screen ID | Emotion | Error / Edge | Success Criteria |
|------|---------|----------------|-----------|---------|-------------|------------------|
| 7:05 | Khalid exits home zone → push: "خالد خرج من البيت 🚶" | Departure notification with direction (toward school) | Push | 😐 Neutral | If no departure by 7:15 → "خالد لم يخرج بعد — تأكد أنه استيقظ" | Child en route to school confirmed |
| 7:20 | Khalid enters school zone → push: "خالد وصل للمدرسة ✓" | Arrival notification at safe zone, school time auto-activates | Push | 😌 Relieved | If no arrival by 7:40 → "خالد لم يصل للمدرسة — تحقق" | School arrival confirmed |
| 7:35 | Saud enters school zone → push: "سعود وصل للمدرسة ✓" | Same pattern for Saud | Push | 😌 Relieved | — | Both boys at school |
| 10:30 | Content alert: "خالد حاول فتح موقع محظور (ألعاب) — تم الحجب" | Push with: site category, action, time, child location (school) | SCR-MON-08 (push) | 😰 Anxious | False positive (legitimate site blocked) → "السماح لهذا الموقع" one-tap | Father aware of attempt; blocked automatically |
| 10:32 | Taps alert → sees context: "موقع ألعاب — تم الحجب في المدرسة" | Alert detail: site domain (masked), category (ألعاب), time, action taken | SCR-MON-08 (detail) | 😐 Neutral | — | Father assesses: "he tried to play games at school, blocked — OK" |
| 2:05 | Khalid leaves school → push: "خالد خرج من المدرسة" | Departure notification, heading toward home | Push | 😐 Neutral | If heading wrong direction → "خالد يبتعد عن البيت — تحقق" | School departure confirmed |
| 2:15 | Khalid arrives home → push: "خالد وصل للبيت ✓" | Arrival at home safe zone | Push | 😌 Relieved | — | Child home safe |

### Evening Review (8:30 PM, after Isha)

| Time | Action | System Response | Screen ID | Emotion | Error / Edge | Success Criteria |
|------|--------|----------------|-----------|---------|-------------|------------------|
| 8:30 | Opens app → Today Dashboard | Dashboard: all children home (green), screen time used, study completed | SCR-ADM-09 | 😌 Relieved | — | Evening status check |
| 8:31 | Taps Khalid's card → day detail | Day timeline: school 7:20-2:00, home 2:15, study 3:30-4:15 (45 min), games 5:00-6:45 (1h45m), chat with friends 7:00-7:15, Quran 7:30-7:50 | SCR-MON-01 | 😊 Happy | If study time <15 min → flag "قليل الوقت الدراسي اليوم" | Full day picture for Khalid |
| 8:33 | Reviews content alerts: 1 today (games site at school, already blocked) | Alert log with all content alerts, all auto-blocked | SCR-MON-08 (log) | 😐 Neutral | Multiple alerts → "3 محاولات حجب اليوم — راجع الإعدادات" | All alerts reviewed |
| 8:34 | Checks Saud: screen time 1h30m used (of 1h30m limit — exhausted) | Saud's card: yellow, "استخدم وقت الشاشة الكامل" | SCR-ADM-09 (card) | 😐 Neutral | Saud's screen time was only 1h30m (age 9, lower limit) — normal | Saud's usage confirmed within limits |
| 8:35 | Reviews Khalid's learning: Science quiz 80%, Math exercises completed, Quran: 3 verses reviewed (88% accuracy) | Learn summary: grades, time-on-task, Quran progress, badges earned | SCR-EDU-12 | 😊 Happy | If any subject <60% → flag "يحتاج مراجعة" | Educational progress reviewed |
| 8:36 | Closes app | — | — | 😌 Relieved | — | Evening review complete in <6 minutes |

### Father Daily Flow Diagram

```
6:45 AM                    WORKDAY                        8:30 PM
   │           ┌──────────────────────────────┐             │
   ▼           │                              │             ▼
[Morning]      │  7:05 ─ Khalid left home     │        [Evening]
[Check]        │  7:20 ─ Khalid at school ✓   │        [Review]
 <3min>        │  7:35 ─ Saud at school ✓     │         <6min>
   │           │ 10:30 ─ Content alert (game) │             │
   │           │       → blocked, reviewed    │             │
   │           │  2:05 ─ Khalid left school   │             │
   │           │  2:15 ─ Khalid home ✓        │             │
   │           │                              │             │
   │           └──────────────────────────────┘             │
   ▼                                                         ▼
 😌 All at home                                    😌 Day reviewed
    ✓                                                  ✓
```

## 3. Mother: Daily Family Management

**Persona:** Umm Khalid (Mother, limited_admin)  
**Day:** Sunday — 14 Safar 1448 H / 22 September 2026  
**Pattern:** Morning planning → micro-checks through day → evening organization

### Morning Planning (6:00 AM, after Fajr)

| Time | Action | System Response | Screen ID | Emotion | Error / Edge | Success Criteria |
|------|--------|----------------|-----------|---------|-------------|------------------|
| 6:00 | Opens app → Today Dashboard | Dashboard: children's status (all home), today's calendar, task list, meal planner | SCR-ADM-09 | 😐 Neutral | — | Dashboard loaded with morning context |
| 6:02 | Opens Communicate > Calendar | Calendar (Hijri view): 14 صفر ١٤٤٨ — Sunday; events: school times for all 3 children, "خالد — واجب علوم (خميس)", "زيارة الجدة (الجمعة)" | SCR-COM-04 | 😊 Happy | — | Week's events visible at a glance |
| 6:05 | Adds calendar event: "موعد الطبيب — سعود — الأربعاء ٤ عصراً" | Event created: Wed 16 Safar, 4:00 PM; Hijri + Gregorian displayed; all family members notified | SCR-COM-04 (add) | 😊 Happy | Time conflict with Saud's school → "تنبيه: سعود في المدرسة وقتها" | Event added with conflict detection |
| 6:08 | Opens Meal Planner → enters today's meals: "فطور: عجة وخبز، غداء: كبسة دجاج، عشاء: شوربة عدس" | Meal plan saved for today; auto-suggests shopping items needed | SCR-COM-08 | 😊 Happy | — | Meals planned for the day |
| 6:10 | Opens Shopping List → reviews auto-suggested items from meal plan: "دجاج، رز، بهار، عدس" → adds "حليب، خبز، بيض" manually | Shopping list updated, categorized: ألبان (حليب), مخبوزات (خبز), بقالة (بيض, رز, بهار), لحوم (دجاج) | SCR-COM-07 | 😊 Happy | — | Shopping list ready for the day |
| 6:12 | Opens Tasks → adds: "غسل ملابس الأولاد", "تنظيف الصالة", "تحضير غداء قبل ١:٠٠" | Task list with 3 items, time-sorted; "تحضير الغداء" flagged with 1:00 PM deadline | SCR-COM-05 | 😐 Neutral | — | Tasks organized for the day |
| 6:15 | Sends family chat message: "صباح الخير جميعاً — لا تنسون واجباتكم 🌸" | Message sent to family group; children will see it when they wake | SCR-COM-01 | 😊 Happy | — | Morning message delivered |

### Mid-Morning (9:00 AM, after children at school)

| Time | Action | System Response | Screen ID | Emotion | Error / Edge | Success Criteria |
|------|--------|----------------|-----------|---------|-------------|------------------|
| 9:00 | Checks: all 3 children at school (safe zones green) | Location map: Khalid at school ✓, Saud at school ✓, Layla (manual: marked "at school" by mother) | SCR-MON-03 | 😌 Relieved | Layla has no device — manual check; "تأكيد: لاية في المدرسة ✓" button | All children confirmed at school |
| 9:05 | Opens Learn tab → Khalid's progress: sees Science quiz from last week (80%), Quran progress (5 verses) | Education overview per child; AI tutor recommendations | SCR-EDU-01 (mother view) | 😊 Happy | — | Academic progress reviewed |
| 9:10 | Assigns Quran task to Khalid: "مراجعة سورة الكهف — الآيات ١-٥ — موعد: الجمعة" | Assignment created, sent to Khalid's app; notification: "أمك كلفتك مراجعة قرآن" | SCR-EDU-05 | 😊 Happy | — | Quran task assigned for the week |
| 9:15 | Opens Communicate > 1:1 chat with Khalid → sends: "لا تنسى واجب العلوم يا حبيبي 📚" | Private message to Khalid; he'll see it at school (if notifications allowed during school time) | SCR-COM-02 | 😊 Happy | School Time blocks notifications → message arrives at 2:00 PM when school time ends | Message queued for after school |

### Afternoon (2:00 PM – 5:00 PM)

| Time | Action | System Response | Screen ID | Emotion | Error / Edge | Success Criteria |
|------|--------|----------------|-----------|---------|-------------|------------------|
| 2:00 | Push: "خالد وصل للبيت ✓" | Geofence notification; child home safe | Push | 😌 Relieved | — | Khalid home confirmed |
| 2:05 | Opens Communicate > Family Chat → Khalid sent: "وصلت! جوعان 🍽️" | Family chat shows Khalid's message; mother replies: "الغدى جاهز، تعال كُل" | SCR-COM-01 | 😊 Happy | — | Child communication established |
| 2:30 | After lunch, opens Tasks → marks "تحضير الغداء" as complete ✓ | Task completed; progress bar updates | SCR-COM-05 (check) | 😌 Relieved | — | Task management working |
| 3:00 | Asr prayer — app shows prayer time reminder | Prayer time notification: "حان وقت صلاة العصر" | SCR-MORE-01 (prayer) | 😐 Neutral | If prayer time DND enabled, monitoring alerts still come through | Prayer time awareness integrated |
| 3:30 | Checks children's screen time: Khalid has 1h55m remaining, Saud has 1h remaining | Screen time overview per child (visible to limited_admin) | SCR-CHD-01 (mother view) | 😐 Neutral | — | Screen time status known |
| 3:35 | Saud requests +15 min screen time → push: "سعود يطلب وقت إضافي (١٥ دقيقة)" | Time request notification with reason: "أبغى أكمل لعبة" | SCR-CHD-02 (push) | 😐 Neutral | — | Screen time request received |
| 3:36 | Approves +15 min → Saud gets "🎉 تمت الموافقة!" | Approval sent; Saud's screen time extended | SCR-CHD-02 (approve) | 😊 Happy | — | Request handled in real-time |

### Evening (6:30 PM – 9:30 PM)

| Time | Action | System Response | Screen ID | Emotion | Error / Edge | Success Criteria |
|------|--------|----------------|-----------|---------|-------------|------------------|
| 6:30 | Family chat: sends voice message "تعالوا للعشاء، الجدة موجودة" | Voice message (12s) recorded, transcribed: "تعالوا للعشاء، الجدة موجودة", sent to family group | SCR-COM-01c | 😊 Happy | Transcription accuracy: Najdi dialect may cause errors → "تحقق من النص" option | Family communication via voice |
| 7:00 | Opens Calendar → adds: "زيارة الجدة — الجمعة بعد العصر — جميع الأفراد" | Event created for Friday 16 Safar, after Asr; all family members notified | SCR-COM-04 | 😊 Happy | Prayer time integration: "بعد العصر" auto-converts to ~3:30 PM based on Riyadh prayer times | Event with prayer-time reference |
| 7:30 | Checks Khalid's learning: he completed Science quiz (80%) and Quran review (88%) | Learn summary for Khalid: quiz grades, Quran accuracy, XP earned, badges | SCR-EDU-12 | 😊 Happy | — | Evening education check |
| 7:35 | Sends 1:1 to Khalid: "ما شاء الله، درست زين اليوم 👏" | Praise message to child; positive reinforcement | SCR-COM-02 | 😊 Happy | — | Positive reinforcement loop |
| 8:00 | Opens Shopping List → checks items, marks "دجاج ✓, رز ✓, حليب ✓" as purchased | Shopping list checkboxes update; remaining: "خبز, بيض, عدس, بهار" | SCR-COM-07 (check) | 😐 Neutral | — | Shopping progress tracked |
| 9:00 | Bedtime check: opens dashboard, all children home, screen times ending | Dashboard: Khalid 15 min remaining (auto-locks at 10 PM), Saud exhausted, Layla (no device) | SCR-ADM-09 | 😌 Relieved | — | Evening wind-down confirmed |
| 9:30 | Closes app, children going to bed | — | — | 😌 Relieved | — | Day's organization complete |

### Mother Daily Flow Diagram

```
6:00 AM         9:00 AM         2:00 PM              6:30 PM         9:30 PM
   │               │                │                    │               │
   ▼               ▼                ▼                    ▼               ▼
[Morning]      [Mid-Morning]    [Afternoon]          [Evening]       [Night]
   │               │                │                    │               │
   ├─ Calendar      ├─ Location ✓    ├─ Khalid home ✓    ├─ Voice msg     ├─ All home ✓
   ├─ Meal plan     ├─ Edu progress  ├─ Family chat      ├─ Calendar add  ├─ Screen time
   ├─ Shopping      ├─ Quran assign  ├─ Task complete    ├─ Edu review    │   ending
   ├─ Tasks         ├─ 1:1 Khalid    ├─ Screen time      ├─ Praise Khalid ├─ Day done
   └─ Family msg    └─ (school)      │   request (Saud)  ├─ Shopping chk
                                     └─ Approve +15 min  └─ Bedtime chk
   
   😊 ────────────── 😊 ────────────── 😌 ────────────────── 😊 ────────────── 😌
```

## 4. Child: Daily Learning Routine

**Persona:** Khalid (Child, 12)  
**Day:** Sunday — 14 Safar 1448 H / 22 September 2026  
**Pattern:** After-school learning session — gamified, XP-driven, with Quran and Focus Mode

### After School (2:30 PM – 6:00 PM)

| Time | Action | System Response | Screen ID | Emotion | Error / Edge | Success Criteria |
|------|--------|----------------|-----------|---------|-------------|------------------|
| 2:30 | Opens app after lunch → Learning Home | Learning Home: XP 1,250, Level 4, streak 7 days 🔥, daily quests: 0/5, "ابدأ رحلتك!" | SCR-EDU-01 | 🤩 Delighted | Streak intact from yesterday — motivating | Dashboard loaded, motivation established |
| 2:32 | Checks daily quests: "اكمل درس علوم (50 XP)", "حفظ قرآن 3 آيات (30 XP)", "حل 5 مسائل رياضيات (40 XP)", "اقرأ درس لغة عربية (30 XP)", "كمل اختبار (50 XP)" | Quest checklist with XP rewards and estimated time per quest | SCR-EDU-01 (quests) | 😐 Neutral | 5 quests feels like a lot → "اختر ما تريد البدء به" | Quests visible and prioritized |
| 2:35 | Taps "اكمل درس علوم" → Science: Plants unit, lesson 3 "التركيب الضوئي" (Photosynthesis) | Lesson player: interactive content with animations, 5-minute duration, checkpoint questions | SCR-EDU-02 | 😊 Happy | If lesson already completed → "أكملت هذا الدرس بالفعل ✓" | Science lesson started |
| 2:40 | Completes lesson checkpoint: "ما هو التركيب الضوئي?" → answers correctly | Correct answer animation: "أحسنت! 🌟" + mini-explanation | SCR-EDU-02 (checkpoint) | 🤩 Delighted | Wrong answer → "لا بأس، تعلمت شيئاً جديداً" + still partial XP | Checkpoint passed |
| 2:42 | Lesson complete → +50 XP, progress ring animates, Level 4 → still Level 4 (needs 1,400 for Level 5) | XP award animation; "متبقي ١٠٠ نقطة للمستوى ٥" displayed | SCR-EDU-14 | 🤩 Delighted | — | Quest 1 complete, XP earned, motivation to continue |
| 2:43 | Quest 1 checked off → 1/5 daily quests done | Quest checklist updates with checkmark | SCR-EDU-01 (updated) | 😊 Happy | — | Progress visible |
| 2:45 | Taps "حل 5 مسائل رياضيات" → Math: Algebra, 5 problems | Math exercise player: problem display, input area, hint system, AI tutor button | SCR-EDU-02b | 😐 Neutral | First problem is hard → "أسأل المساعد الذكي" button visible | Math exercises started |
| 2:50 | Stuck on problem 2: "حل المعادلة ٣س + ٧ = ٢٢" → taps AI Tutor | AI Tutor chat: "أهلاً خالد! أسألني عن أي مسألة" → Khalid types "كيف أحل ٣س + ٧ = ٢٢؟" | SCR-EDU-02c (AI) | 😣 Frustrated | AI gives full answer too easily → no learning | AI gives STEP-BY-STEP hint, not answer: "اطرح ٧ من الطرفين أولاً" |
| 2:53 | Follows hint: 3x = 15 → x = 5 → enters answer → correct! | Correct! +10 XP (partial), "أحسنت! استخدمت المساعد بحكمة" | SCR-EDU-02b (result) | 😌 Relieved | — | AI tutor helped without giving away answer |
| 3:00 | Completes all 5 Math problems: 4/5 correct, 1 wrong → +35 XP (of 40) | Math summary: 4 correct, 1 wrong, AI explanation for wrong answer, +35 XP | SCR-EDU-02b (summary) | 😊 Happy | — | Quest 2 complete (4/5 correct), XP earned |
| 3:02 | 2/5 quests done → checks leaderboard: "أنت الأول! 👑 1,335 XP — Saud: 850 XP" | Family leaderboard with XP, levels, badges | SCR-EDU-16 | 🤩 Delighted | If NOT first → "أفضل أسبوع لك: ٥٠٠ نقطة" personal best shown | Motivation maintained through competition |
| 3:05 | Asr prayer reminder → "حان وقت صلاة العصر" → Khalid leaves app to pray | Prayer time notification; app pauses session | SCR-MORE-01 (prayer) | 😐 Neutral | — | Prayer time respected |
| 3:20 | Returns from prayer → taps "حفظ قرآن 3 آيات" → Quran module | Quran recitation: Surah Al-Kahf, verses 1-5, recite button, verse display | SCR-EDU-03b | 😐 Neutral | Doesn't feel like "studying" — more like spiritual practice | Quran review started |
| 3:25 | Recites verses 1-3 into microphone → AI analysis: 90% tajweed accuracy | AI Quran report: verse-by-verse, accuracy, corrections, audio comparison | SCR-EDU-09 | 😊 Happy | Corrections feel like criticism → lead with "3 آيات ممتازة! ✨" | Quran recitation completed |
| 3:28 | Recites verses 4-5 → AI: 85% accuracy, 1 correction on verse 4 | Quran report updated; +30 XP, badge "حافظ مميز" | SCR-EDU-09b | 🤩 Delighted | — | Quest 3 complete, Quran XP earned |
| 3:30 | 3/5 quests done → taps "اقرأ درس لغة عربية" → Arabic: grammar lesson | Arabic lesson: interactive reading, 10 minutes, comprehension questions | SCR-EDU-02 | 😐 Neutral | — | Arabic lesson started |
| 3:40 | Completes Arabic lesson → +30 XP → 4/5 quests done | XP award, quest checklist: 4/5 | SCR-EDU-14 | 😊 Happy | — | Quest 4 complete |
| 3:42 | Taps "كمل اختبار" → Science quiz (assigned by father): Plants unit, 10 questions | Quiz player: 10 questions, multiple choice, instant feedback, progress bar | SCR-EDU-03 | 😐 Neutral | Quiz is harder than lesson → some wrong answers | Science quiz started |
| 4:00 | Quiz complete: 8/10 correct (80%) → AI grading instant → +40 XP (of 50) | AI grade: score, per-question breakdown, explanation for 2 wrong, +40 XP | SCR-EDU-08 | 😊 Happy | 2 wrong → "راجع هذه النقاط" suggestion with lesson link | Quest 5 complete, all daily quests done! |
| 4:02 | All 5 quests complete → "🎉 أكملت كل مهام اليوم! +١٨٥ XP" celebration | Completion celebration: total XP today, level progress, new badge if earned | SCR-EDU-01 (celebration) | 🤩 Delighted | — | Daily learning routine complete — all quests done |
| 4:05 | XP total: 1,435 → Level up! Level 4 → Level 5 → confetti animation, new avatar unlocked | Level-up celebration: full-screen animation, "وصلت للمستوى ٥! 🎉", unlock notification for avatar | SCR-EDU-14 (level up) | 🤩 Delighted | — | Level up achieved — dopamine peak |
| 4:10 | Taps avatar → unlocks new avatar: "رائد فضاء" (Astronaut) → changes avatar | Avatar customization: new skin unlocked and applied | SCR-EDU-01 (avatar) | 🤩 Delighted | — | Reward for consistent learning |
| 4:15 | Opens Focus Mode → "وضع التركيز — ٢٥ دقيقة" → entertainment apps blocked | Focus Mode: countdown timer, gentle block on games, ambient sounds option (nature) | SCR-EDU-15 | 😐 Neutral | If Focus Mode blocks an app he needs → "طلب استثناء" option | Focus Mode active for free study |
| 4:20 | During Focus Mode, reviews Science notes for upcoming test → reads lesson again | Focus Mode tracks study time; +20 XP at completion | SCR-EDU-02 (review) | 😐 Neutral | — | Self-directed study during Focus Mode |
| 4:40 | Focus Mode ends → +20 XP, "متركّز" badge, games unlocked | Focus completion: XP, badge, transition message | SCR-EDU-15b | 😌 Relieved | — | Focus session productive |
| 4:45 | Free time! → opens games (Roblox) — screen time has 1h15m remaining | Screen time countdown visible in notification; games accessible | — | 🤩 Delighted | — | Earned play time begins |
| 5:55 | Screen time: 15 min remaining → push: "⏱️ باقي ١٥ دقيقة" | Warning notification | Push | 😣 Frustrated | — | Screen time warning received |
| 6:00 | Maghrib prayer reminder → leaves game → goes to pray | Prayer time notification | SCR-MORE-01 | 😐 Neutral | — | Prayer time interrupts naturally |
| 6:05 | Returns → 10 min screen time left → decides to save it → opens family chat instead | Family chat: sees mom's message about dinner, grandma visiting | SCR-COM-01 | 😊 Happy | — | Child chooses communication over last 10 min of games |

### Child Daily Learning Flow Diagram

```
2:30 PM                           6:00 PM
   │                                 │
   ▼                                 ▼
[Learning Home] ──────────────────────────────────────> [Free Time → Chat]
   │
   ├─ Quest 1: Science lesson (Photosynthesis) ──> +50 XP
   ├─ Quest 2: Math 5 problems (4/5 correct) ────> +35 XP
   │      └─ AI Tutor helped on problem 2 (step-by-step hint)
   ├─ Quest 3: Quran recitation (verses 1-5) ────> +30 XP + badge
   ├─ Quest 4: Arabic reading ──────────────────> +30 XP
   ├─ Quest 5: Science quiz (8/10, 80%) ────────> +40 XP
   │
   ├─ ALL QUESTS DONE: +185 XP total ──> LEVEL UP! 4 → 5 🎉
   ├─ New avatar unlocked: رائد فضاء
   │
   ├─ Focus Mode (25 min): Science review ──> +20 XP + badge
   │
   ├─ Free time: Roblox (1h10m of screen time)
   ├─ Screen time warning at 15 min
   ├─ Maghrib prayer → natural break
   └─ Chooses family chat over remaining 10 min

   🤩 🤩 🤩 😐 😣 🤩 😐 😌 🤩
```

## 5. Child: Communication Flow

**Persona:** Khalid (Child, 12)  
**Day:** Sunday — 14 Safar 1448 H / 22 September 2026  
**Pattern:** Micro-interactions throughout the day — family chat, 1:1, voice messages, translation

### Daily Communication Touchpoints

| Time | Action | System Response | Screen ID | Emotion | Error / Edge | Success Criteria |
|------|--------|----------------|-----------|---------|-------------|------------------|
| 7:00 | At breakfast, opens family chat → sees mom's morning message: "صباح الخير جميعاً — لا تنسون واجباتكم 🌸" → replies with thumbs up emoji 👍 | Emoji sent to family group; mom sees it | SCR-COM-01 | 😊 Happy | — | Morning family connection established |
| 7:15 | Walking to school → sends 1:1 to mom: "أمي، وين فلوسي للوجبة المدرسية؟ 😅" → mom replies: "في جيبك يا غبي 😂 بس شوف زين" | 1:1 chat with mom; quick exchange; mom uses humor | SCR-COM-02 | 😊 Happy | — | Practical communication (school lunch money) |
| 10:15 | During break at school → School Time restricts most apps, but Communicate is allowed → opens family chat → sends "الفرصة حلوة 🔥" | Message sent during school break; School Time allows Communicate | SCR-COM-01 | 😊 Happy | If School Time blocks chat → "غير متاح وقت الدرس" | Communication maintained during school |
| 2:05 | Arrives home → sees mom's chat: "خلصتوا مدرسة؟ تعالوا غداكم جاهز" → replies: "وصلت! جوعان 🍽️" | Family chat exchange; voice transcription of any voice messages | SCR-COM-01 | 😊 Happy | — | Afternoon check-in with family |
| 2:10 | Saud (brother, 9) sends Khalid a 1:1 message: "خلصت واجب علوم؟ ابغى أسألك سؤال" | 1:1 chat with sibling; Khalid replies: "إيه بس لحقه، أنا بسأل المساعد الذكي وأرجع لك" | SCR-COM-02 | 😊 Happy | — | Sibling communication and collaboration |
| 4:45 | After study session, opens family chat → sends voice message: "خلصت كل مهامي اليوم! ١٨٥ نقطة! 🎉" | Voice message (8s) recorded, transcribed: "خلصت كل مهامي اليوم ١٨٥ نقطة", sent to family group | SCR-COM-01c | 🤩 Delighted | Transcription drops the number "١٨٥" → "تحقق من النص" shown | Achievement shared with family via voice |
| 4:48 | Mom replies with voice message: "ما شاء الله يا بطل! 👏 تعال لك هدية" | Voice message from mom; auto-played (if setting on); transcribed | SCR-COM-01c | 🤩 Delighted | — | Positive reinforcement from parent |
| 5:30 | Playing Roblox with cousin → sends family chat: "ألعب مع راكان بالروبلوكس 🎮" → dad replies: "لا تنسى وقت الصلاة" | Family chat exchange; father's reminder about prayer | SCR-COM-01 | 😐 Neutral | — | Parental guidance via chat (light-touch monitoring) |
| 6:05 | After Maghrib, opens Communicate → sees dad's 1:1 message: "خالد، وينك؟ تعال للعشاء، جدتك وصلت" → replies: "أنا جاي 🏃" | 1:1 chat with father; quick reply | SCR-COM-02 | 😊 Happy | — | Father-child communication |
| 7:15 | At dinner with grandma → sends a photo to family chat (if photo sharing enabled) → "الجدة سويت كنافة! 😋" | Photo + caption sent to family group; family members who aren't present see it | SCR-COM-01d | 🤩 Delighted | Photo sharing not enabled → "المشاركة غير مفعّلة" | Shared family moment via photo |
| 8:00 | Saud sends a message in English (practicing): "Brother, can you help me with math?" → Khalid sees Arabic translation: "أخي، تقدر تساعدني بالرياضيات؟" → Khalid replies in Arabic: "إيه، أي مسألة؟" | Bidirectional translation: English → Arabic for Khalid; his Arabic reply → English for Saud (if Saud has translation on) | SCR-COM-01b | 🤩 Delighted | Translation imperfect with dialect → "الترجمة تقريبية" note | Cross-language sibling communication |
| 8:30 | Before bed, sends 1:1 to mom: "تصبحين على خير يا أمي ❤️" → mom replies: "وأنت بخير يا قلبي 🌙" | Goodnight exchange; warm close to the day | SCR-COM-02 | 😊 Happy | — | Day ends with family warmth |

### Communication Flow Diagram

```
7:00 AM              SCHOOL               2:00 PM              EVENING              8:30 PM
   │                   │                    │                    │                    │
   ▼                   ▼                    ▼                    ▼                    ▼
Family chat        1:1 Mom              Family chat         1:1 Dad              1:1 Mom
(morning msg)      (lunch money)        ("وصلت!")           (dinner w/           (goodnight)
   │                   │                    │              grandma)                 │
   ▼                   ▼                    ▼                    ▼                    ▼
👍 emoji           Quick reply          Voice msg:          Photo:               ❤️ msg
                   from mom             "١٨٥ نقطة!"          "كنافة!"             "تصبحين
                                        🎉                  😋                    على خير"
   │                   │                    │                    │                    │
   ▼                   ▼                    ▼                    ▼                    ▼
😊 Happy           😊 Happy              🤩 Delighted         🤩 Delighted          😊 Happy
   
   ┌──────────────────────────────────────────────────────────────────────────────┐
   │  TRANSLATION LAYER: Saud ↔ Khalid English/Arabic auto-translation (8:00 PM)   │
   │  "Brother, can you help me?" → "أخي، تقدر تساعدني بالرياضيات؟"                  │
   └──────────────────────────────────────────────────────────────────────────────┘
   
   ┌──────────────────────────────────────────────────────────────────────────────┐
   │  SCHOOL TIME: Communicate tab remains accessible during breaks                │
   │  All other apps blocked during class hours                                    │
   └──────────────────────────────────────────────────────────────────────────────┘
```

## 6. Child: Screen Time Management

**Persona:** Khalid (Child, 12)  
**Day:** Sunday — 14 Safar 1448 H / 22 September 2026  
**Pattern:** Awareness → usage → warnings → requests → earning bonus time

### Screen Time Journey Through the Day

| Time | Action | System Response | Screen ID | Emotion | Error / Edge | Success Criteria |
|------|--------|----------------|-----------|---------|-------------|------------------|
| 2:30 | Opens "وقتي" (My Time) tab → sees today's screen time: 0h used / 2h limit | My Time dashboard: circular progress (0%), category breakdown empty, "يبدأ من جديد ٤ صباحاً" | SCR-CHD-01 | 😐 Neutral | — | Screen time status known |
| 2:35 | Reviews screen time rules: "الحد اليومي: ساعتين (أيام الأسبوع)، ٣ ساعات (عطلة). وقت التعليم لا يحسب" | Rules display: daily limit, weekend limit, educational exclusion, bedtime lock (10 PM) | SCR-CHD-01 (rules) | 😐 Neutral | — | Child understands the rules |
| 4:45 | After completing all learning quests (which didn't count against screen time), opens Roblox → screen time starts counting | Game session begins; screen time counter starts; notification: "بدأ وقت اللعب — ٢:٠٠ متبقية" | — | 🤩 Delighted | — | Earned entertainment time begins |
| 5:45 | Playing for 1 hour → screen time: 1h used / 2h limit → 1h remaining | Counter updates in background; no notification (no warning yet) | — | 😊 Happy | — | Usage tracking in progress |
| 5:55 | Screen time: 1h10m used → 50 min remaining → first warning at 15 min before limit? No — warning at 15 min remaining = at 1h45m mark | — | — | — | — | — |
| 5:55 | Push notification: "⏱️ باقي ١٥ دقيقة من وقت الشاشة" | 15-minute warning; subtle, not alarming | Push | 😣 Frustrated | Right in the middle of a Roblox game → annoying timing | Warning received; child aware time is limited |
| 6:00 | Maghrib prayer → leaves game (natural break) → prays → returns | Screen time paused during prayer (app in background = not counted if configured) | — | 😐 Neutral | If screen time continues counting during prayer → unfair; configure: prayer time pauses counter | Prayer time respected |
| 6:10 | Returns to game → 10 min remaining → decides to save time → closes game → opens family chat instead | Switches from entertainment to communication; remaining 10 min preserved | SCR-COM-01 | 😊 Happy | — | Child self-regulates screen time |
| 6:30 | At dinner → not using phone → screen time not counting | Natural pause; no action needed | — | — | — | — |
| 7:15 | Wants to play more → 10 min remaining → opens Roblox for 10 min | Screen time resumes; counter at 1h50m → 10 min left | — | 😐 Neutral | — | Final 10 minutes of screen time used |
| 7:25 | Screen time: 2h used → exhausted → game locks → "انتهى وقتك اليوم ⏰ بكرة تبدأ من جديد الساعة ٤ صباحاً" | Hard lock on entertainment apps; educational apps remain accessible; motivational message: "اكسب وقت إضافي بالتعلم! +١٥ دقيقة لكل درس" | SCR-CHD-03 | 😣 Frustrated | Mid-game lock → lost progress in Roblox → very frustrating | Lock applied; educational redirect shown |
| 7:26 | Taps "اطلب وقت إضافي" → selects +30 min → reason: "أبغى أكمل مباراة مع ربعي" | Time request form: duration, reason, send to parent(s) | SCR-CHD-02 | 😐 Neutral | — | Request submitted |
| 7:27 | Request sent to mother → "بانتظار رد أمك..." pulsing animation | Pending request status; mother receives push: "خالد يطلب ٣٠ دقيقة إضافية" | SCR-CHD-02b | 😰 Anxious | Mother doesn't respond for 2 min → child waits anxiously | Request pending, waiting for response |
| 7:30 | Mother approves only +15 min (not 30) → Khalid sees: "أمك وافقت على ١٥ دقيقة فقط. سبب: وقت العشاء قريب" | Adjusted approval with reason; games unlock for 15 min | SCR-CHD-02c | 😐 Neutral | Got less than asked — mildly disappointed but understands | Partial approval with clear reasoning |
| 7:31 | Plays Roblox for 15 min → time expires again → locked | Second lock; "انتهى الوقت الإضافي ⏰" | SCR-CHD-03 | 😣 Frustrated | Double frustration: locked twice in one evening | Second lock applied |
| 7:35 | Sees "اكسب وقت إضافي بالتعلم" → opens Learn tab → does a quick Arabic reading quest (10 min) → +15 min bonus | Bonus time granted; notification: "أحسنت! +١٥ دقيقة وقت لعب 🎮" | SCR-EDU-01 → SCR-CHD-01 | 🤩 Delighted | Learning to earn play time = positive behavior loop | Bonus time earned through learning |
| 7:50 | Uses 15 min bonus time for Roblox → then closes → ready for dinner | Bonus time used; screen time fully exhausted + bonus | — | 😊 Happy | — | Earned-play cycle complete |
| 9:30 | Bedtime → screen time already exhausted → phone enters bedtime mode at 10 PM | Bedtime lock: all entertainment locked; only alarm + emergency calls + SOS active | SCR-CHD-04 | 😐 Neutral | — | Bedtime mode enforced |

### Screen Time Decision Tree

```
CHILD OPENS ENTERTAINMENT APP
    │
    ├── Screen time remaining > 0? 
    │     ├── YES → App opens, time counts down
    │     └── NO → App locked
    │              │
    │              ├── Child accepts lock → redirect to Learn tab
    │              │
    │              ├── Child requests more time → parent approves/denies/adjusts
    │              │      ├── Approved → time extended, app opens
    │              │      ├── Denied → "خلصت وقتك اليوم، بكرة"
    │              │      └── Adjusted → partial extension with reason
    │              │
    │              └── Child earns bonus → completes lesson → +15 min
    │                     └── App unlocks for bonus duration
    │
    └── Is app educational? 
          ├── YES → No screen time counted (unlimited)
          └── NO → Counts against limit

SPECIAL STATES:
    ├─ School Time (7AM-2PM) → Entertainment locked, Learn + Communicate open
    ├─ Bedtime (10PM-4AM) → All entertainment locked, SOS + alarm only
    └─ Focus Mode (user-activated) → Entertainment blocked for set duration
```

## 7. Family Day Timeline — Synchronized View

This section shows how all three personas' daily journeys interconnect in a single synchronized timeline. The platform's value is not in any single journey — it's in how these journeys create a shared family awareness.

### Synchronized Timeline — Sunday, 14 Safar 1448 H

```
TIME     FATHER (Abu Khalid)        MOTHER (Umm Khalid)       CHILD (Khalid, 12)
═══════════════════════════════════════════════════════════════════════════════
04:30    Fajr prayer               Fajr prayer               Sleeping
         │                         │
05:00    Wakes up, morning         Wakes up, morning         Sleeping
         routine                   routine
         │                         │
06:00    —                         Opens app:                Sleeping
                                   Today Dashboard
                                   ├─ Calendar check
                                   ├─ Meal planner
                                   ├─ Shopping list
                                   ├─ Tasks
                                   └─ Family chat: "صباح الخير"
         │                         │
06:30    Breakfast with            Breakfast with            Wakes up, breakfast
         family                    family                    ├─ Sees mom's msg 👍
         │                         │                         │
06:45    Opens app:                —                         —
         Morning check (<3min)
         ├─ All children home ✓
         ├─ Calendar confirmed
         └─ Closes app
         │                         │                         │
07:00    Leaves for work           —                         Leaves for school
                                                            └─ 1:1 mom: "فلوس الوجبة?"
         │                         │                         │
07:05    Push: "خالد خرج           —                         Walking to school
         من البيت"                 │
         │                         │                         │
07:20    Push: "خالد وصل           —                         At school
         للمدرسة ✓"                │                         └─ School Time activates
         │                         │                         │
07:30    —                         Saud & Layla              Saud & Layla leave
                                   leave for school          for school
         │                         │                         │
07:35    Push: "سعود وصل           —                         In class
         للمدرسة ✓"                │
         │                         │                         │
08:00    At work                   Home:                     In class
                                   Quran halaqa prep
         │                         │                         │
09:00    Working                   Opens app:                In class (School Time)
                                   ├─ All at school ✓
                                   ├─ Edu progress check
                                   ├─ Assigns Quran task
                                   └─ 1:1 Khalid: "لا تنسى
                                      واجب العلوم"
         │                         │                         │
10:15    —                         —                         School break:
                                                            family chat: "الفرصة حلوة 🔥"
         │                         │                         │
10:30    Push: "خالد حاول          —                         In class (blocked
         فتح موقع محظور            │                         site attempt)
         (ألعاب) — تم الحجب"
         → reviews, OK
         │                         │                         │
12:00    Dhuhr prayer              Dhuhr prayer              Dhuhr prayer at school
         │                         │                         │
13:30    —                         Saud & Layla              Saud & Layla home
                                   arrive home               │
         │                         │                         │
14:00    Working                   —                         School ends
         │                         │                         │
14:05    Push: "خالد خرج           —                         Walking home
         من المدرسة"               │
         │                         │                         │
14:15    Push: "خالد وصل           Push: "خالد وصل          Arrives home
         للبيت ✓"                  للبيت ✓"                  ├─ Family chat:
         │                         │                         │  "وصلت! جوعان 🍽️"
         │                         │                         │  Mom: "الغدى جاهز"
         │                         │                         │
14:30    —                         Lunch with                Lunch with family
                                   children                  │
         │                         │                         │
15:00    —                         Asr prayer                Asr prayer
                                   ├─ Task: "تحضير الغداء ✓"│
         │                         │                         │
15:20    —                         —                         Opens app: Learn
                                                            ├─ Quest 1: Science
                                                            │  lesson +50 XP
                                                            ├─ Quest 2: Math 5
                                                            │  problems +35 XP
                                                            │  └─ AI Tutor help
                                                            ├─ Quest 3: Quran
                                                            │  recitation +30 XP
                                                            ├─ Quest 4: Arabic
                                                            │  reading +30 XP
                                                            ├─ Quest 5: Science
                                                            │  quiz 80% +40 XP
                                                            ├─ ALL DONE: +185 XP
                                                            └─ LEVEL UP! 4→5 🎉
         │                         │                         │
15:30    —                         Saud requests +15 min     —
                                   screen time
                                   → Approves ✓
         │                         │                         │
16:00    —                         —                         Opens Focus Mode
                                                            (25 min study)
         │                         │                         │
16:25    —                         —                         Focus ends: +20 XP
         │                         │                         │
16:45    —                         —                         Free time:
                                                            Roblox (cousin)
                                                            ├─ 1h10m screen time
         │                         │                         │
17:55    —                         —                         Screen warning:
                                                            "باقي ١٥ دقيقة"
         │                         │                         │
18:00    —                         Maghrib prayer            Maghrib prayer
                                   │                         ├─ Leaves game
         │                         │                         │
18:05    —                         —                         Returns: 10 min left
                                                            → Chooses family
                                                            chat instead
         │                         │                         │
18:30    —                         Dinner prep               —
                                   ├─ Voice msg: "تعالوا     │
                                   للعشاء، الجدة موجودة"    │
         │                         │                         │
18:30    Push from family          —                         Hears mom's voice
         chat: voice msg           │                         msg
         │                         │                         │
19:00    Leaves work               —                         —
         │                         │                         │
19:15    Arrives home              Family dinner             Family dinner
         ├─ 1:1 Khalid:            with grandma              ├─ Sends photo:
         "تعال للعشاء،              │                         │  "كنافة! 😋"
         جدتك وصلت"                │                         │
         │                         │                         │
19:30    Isha prayer               Isha prayer               Isha prayer
         │                         │                         │
20:00    —                         —                         Saud asks for math
                                                            help (in English,
                                                            auto-translated)
         │                         │                         │
20:30    Opens app:                —                         —
         Evening review (<6min)
         ├─ All children home ✓
         ├─ Khalid day timeline
         ├─ Content alert reviewed
         ├─ Saud screen time done
         ├─ Khalid learning: 80%
         └─ Closes app
         │                         │                         │
20:35    —                         —                         1:1 mom:
                                                            "تصبحين على خير ❤️"
                                                            Mom: "وأنت بخير 🌙"
         │                         │                         │
21:00    —                         —                         Bedtime routine
         │                         │                         │
22:00    —                         —                         Bedtime lock:
                                                            screen time off
         │                         │                         │
22:30    Parents wind down         Parents wind down         Sleeping
═══════════════════════════════════════════════════════════════════════════════
```

### Daily Interaction Points (Cross-Persona)

| Time | Interaction | Type | Value Created |
|------|------------|------|---------------|
| 6:00 | Mother sends morning message → child sees at 6:30 | Family chat | Connection, routine |
| 7:05 | Child leaves home → father receives push | Location alert | Safety awareness |
| 9:10 | Mother assigns Quran task → child sees after school | Educational assignment | Learning direction |
| 10:30 | Content alert → father reviews | Monitoring alert | Protection |
| 14:15 | Child arrives home → both parents notified | Location alert | Safety confirmation |
| 15:30 | Mother approves Saud's screen time request | Screen time | Real-time parenting |
| 16:00 | Child earns 185 XP → mother checks progress | Educational achievement | Pride, motivation |
| 18:30 | Mother sends voice message → family gathers | Family communication | Organization |
| 20:00 | Sibling communication with translation | Cross-language chat | Bonding + language practice |
| 20:30 | Father reviews day → child's data informs understanding | Monitoring review | Informed parenting |
| 20:35 | Goodnight message exchange | 1:1 chat | Emotional connection |

## 8. Complete ASCII Flow Diagrams

### 8.1 Father Daily Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    FATHER DAILY FLOW                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  06:45 ── [Today Dashboard] ──> Scan all children ──> All ✓    │
│              │                                    │              │
│              │                               😌 Relieved         │
│              │ <3 min                                │           │
│              ▼                                       ▼           │
│         [Calendar check]                         [Close app]     │
│         [Close app]                                               │
│              │                                                   │
│  ────────────┼──────── WORKDAY (7AM-5PM) ──────────────────     │
│              │                                                   │
│              ▼                                                   │
│  07:05 ── Push: Khalid left home ──> 😐                          │
│  07:20 ── Push: Khalid at school ✓ ──> 😌                        │
│  07:35 ── Push: Saud at school ✓ ──> 😌                          │
│  10:30 ── Push: Content alert (games) ──> 😰                     │
│         └─ Review: blocked, OK ──> 😐                            │
│  14:05 ── Push: Khalid left school ──> 😐                        │
│  14:15 ── Push: Khalid home ✓ ──> 😌                             │
│                                                                 │
│  ────────────────────────────────────────────────────────────   │
│                                                                 │
│  20:30 ── [Today Dashboard] ──> Evening Review                  │
│              │                                                   │
│              ├─ Khalid card: day timeline (school, study,       │
│              │              games, chat, Quran)                  │
│              ├─ Content alerts: 1 (reviewed)                    │
│              ├─ Saud card: screen time exhausted (normal)       │
│              ├─ Khalid learning: Science 80%, Quran 88%         │
│              └─ All children home ✓                             │
│                   │                                             │
│              😌 Relieved                                        │
│              <6 min                                             │
│                   │                                             │
│                   ▼                                             │
│              [Close app]                                        │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 8.2 Mother Daily Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    MOTHER DAILY FLOW                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  06:00 ── [Today Dashboard]                                     │
│              │                                                   │
│              ├─ Calendar: school times, appointments            │
│              ├─ Add event: dentist for Saud (Wednesday)          │
│              ├─ Meal planner: فطور/غداء/عشاء                     │
│              ├─ Shopping list: auto-suggest + manual items      │
│              ├─ Tasks: 3 items for the day                      │
│              └─ Family chat: "صباح الخير 🌸"                      │
│                   │                                             │
│              😊 Happy                                           │
│                   │                                             │
│  09:00 ── [Location check: all at school ✓]                     │
│  09:05 ── [Learn: progress review + assign Quran task]           │
│  09:15 ── [1:1 Khalid: "لا تنسى واجب العلوم"]                    │
│                                                                 │
│  14:00 ── Push: Khalid home ✓                                   │
│  14:05 ── [Family chat: "وصلت! جوعان"] → reply                  │
│  15:00 ── Asr prayer                                            │
│  15:30 ── [Approve Saud screen time +15 min]                     │
│                                                                 │
│  18:30 ── [Voice msg: "تعالوا للعشاء"]                           │
│  19:00 ── [Calendar: add "زيارة الجدة الجمعة"]                    │
│  19:35 ── [Khalid learning: 80% quiz, 88% Quran → praise]       │
│  20:35 ── [1:1 Khalid goodnight ❤️]                              │
│  21:00 ── [Dashboard: all home, screen time ending]              │
│                   │                                             │
│              😌 Relieved                                        │
│                   │                                             │
│                   ▼                                             │
│              [Close app — day organized]                        │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 8.3 Child Daily Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    CHILD (KHALID) DAILY FLOW                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  06:30 ── [Family chat: morning msg → 👍]                        │
│  07:00 ── [1:1 Mom: lunch money] → school                       │
│  07:20 ── [School Time activates: entertainment locked]          │
│  10:15 ── [Family chat: "الفرصة حلوة" (break)]                   │
│                                                                 │
│  ─────────── SCHOOL (7:20-14:00) ───────────────────────────    │
│                                                                 │
│  14:15 ── [Home: family chat "وصلت! جوعان"]                      │
│  14:30 ── Lunch                                                 │
│                                                                 │
│  15:20 ── [LEARN TAB: Learning Home]                            │
│              │                                                   │
│              ├─ Quest 1: Science (Photosynthesis) +50 XP        │
│              ├─ Quest 2: Math 5 problems (4/5) +35 XP           │
│              │      └─ AI Tutor: step-by-step hint               │
│              ├─ Quest 3: Quran recitation (1-5) +30 XP          │
│              │      └─ AI: 88% tajweed accuracy                  │
│              ├─ Quest 4: Arabic reading +30 XP                  │
│              ├─ Quest 5: Science quiz 80% +40 XP                │
│              │                                                   │
│              └─ ALL QUESTS DONE: +185 XP                        │
│                  └─ LEVEL UP! 4 → 5 🎉                          │
│                  └─ New avatar: رائد فضاء                        │
│                   │                                             │
│              🤩 Delighted                                       │
│                   │                                             │
│  16:00 ── [Focus Mode: 25 min study] → +20 XP                   │
│  16:45 ── [Free time: Roblox with cousin]                       │
│  17:55 ── [Screen warning: 15 min left]                         │
│  18:00 ── [Maghrib prayer: natural break]                       │
│  18:10 ── [Chooses family chat over remaining game time]         │
│                                                                 │
│  19:15 ── [Dinner with grandma: photo to family chat]           │
│  20:00 ── [Saud asks for math help (English→Arabic translation)]│
│                                                                 │
│  21:00 ── [Screen time exhausted → lock]                        │
│              │                                                   │
│              ├─ Request +30 min → mom approves +15 min          │
│              ├─ Use 15 min → exhausted again                    │
│              └─ Earn bonus: Arabic quest → +15 min              │
│                   │                                             │
│  20:35 ── [1:1 Mom: "تصبحين على خير ❤️"]                         │
│  21:30 ── [Bedtime routine]                                     │
│  22:00 ── [Bedtime lock: all entertainment off]                 │
│                   │                                             │
│              😊 Happy (productive, fun, connected day)           │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## 9. Critical Pain Points & Design Opportunities

### Daily Life Pain Points

| # | Pain Point | Persona | Severity | Impact | Root Cause |
|---|-----------|---------|----------|--------|------------|
| D1 | Notification fatigue — too many pushes through the day | Father | 🟡 HIGH | Father starts ignoring alerts; might miss a real one | Every geofence, every content block, every departure generates a push |
| D2 | Mother hits permission walls repeatedly | Mother | 🟡 HIGH | Feels like second-class user; friction in daily flow | limited_admin restricts actions she expects to be able to do |
| D3 | Child frustrated by screen time locks mid-game | Child | 🟡 HIGH | Frustration, resentment, "I hate this app" feeling | Hard lock interrupts without grace period |
| D4 | Educational content too easy or too hard | Child | 🟠 MEDIUM | Child either breezes through (boring) or struggles (demotivating) | Difficulty not perfectly calibrated to individual |
| D5 | Prayer time conflicts with app usage | All | 🟠 MEDIUM | App usage during prayer time is culturally inappropriate | No prayer-time awareness in screen time or notification system |
| D6 | Voice message transcription errors (Najdi dialect) | Mother, Child | 🟠 MEDIUM | Misunderstanding within family chat | Arabic dialects differ from MSA; speech-to-text trained on MSA |
| D7 | Sibling leaderboard demotivates lower-ranked child | Child (Saud) | 🟠 MEDIUM | Saud always lower than Khalid → gives up trying | Age/level gap makes competition unfair |
| D8 | Meal planner doesn't auto-generate shopping list | Mother | 🟠 MEDIUM | Manual duplicate work between meal plan and shopping | No integration between the two modules |
| D9 | School Time blocks communication during emergencies | Child | 🔴 CRITICAL | Child can't send SOS during School Time (if FAB is blocked) | School Time restrictions too aggressive |
| D10 | Evening review requires too many taps | Father | 🟠 MEDIUM | Father skips review because it's tedious → loses awareness | No single-page "day summary" — must drill into each child |

### Design Opportunities

#### OPD1: Smart Notification Bundling (addresses D1)

Instead of sending every geofence and content alert as a separate push, bundle them:

```
Instead of:
  7:05 ── Push: "خالد خرج من البيت"
  7:20 ── Push: "خالد وصل للمدرسة ✓"
  7:35 ── Push: "سعود وصل للمدرسة ✓"
  10:30 ── Push: "خالد: موقع محظور — تم الحجب"

Offer (configurable):
  Morning summary (8:00 AM): 
  "☀️ صباح الخير — خالد وسعود في المدرسة ✓، لاية في البيت. 
   تنبيه واحد: خالد حاول فتح موقع ألعاب (تم الحجب)"
  
  Real-time alerts ONLY for: SOS, unsafe zone departure, 
  repeated content violations, device offline >30min
```

**Settings:** Father can choose: "كل التنبيهات" (all) / "ملخصات دورية" (periodic summaries) / "الطارئ فقط" (emergencies only). SOS always real-time regardless of setting.

#### OPD2: Permission Request System (addresses D2)

When mother hits a permission wall, instead of "غير مسموح" (not allowed):

```
┌──────────────────────────────────────┐
│  هذه الميزة متاحة للأب فقط           │
│                                      │
│  هل تطلب من أبوك:                    │
│  "زيادة وقت خالد التعليمي ٣٠ دقيقة"   │
│                                      │
│  [ نعم، أرسل الطلب ]  [ لاحقاً ]      │
└──────────────────────────────────────┘
```

Father receives: "نورة تطلب: زيادة وقت خالد التعليمي" with one-tap approve/deny. No friction, no feeling of second-class.

#### OPD3: Grace Period for Screen Time Lock (addresses D3)

When screen time is about to expire, offer a 2-minute grace period:

```
Screen time: 2:00 used
    ↓ (at 1:55)
Warning: "باقي ٥ دقائق — احفظ تقدمك"
    ↓ (at 2:00)
Grace period: "دقيقتان إضافيتان لحفظ تقدمك" (games continue for 2 min)
    ↓ (at 2:02)
Lock: "انتهى الوقت — تم حفظ تقدمك"
```

This prevents the "lost my Roblox progress" frustration that makes children hate the app.

#### OPD4: Adaptive Difficulty Engine (addresses D4)

AI continuously adjusts lesson difficulty based on performance:
- 3 correct answers in a row → increase difficulty slightly
- 2 wrong answers in a row → decrease difficulty and offer review
- Maintain "flow state" — challenging but achievable

Show to child as: "مستوى التحدي: متكيف معك" (adaptive to you).

#### OPD5: Prayer Time Integration (addresses D5)

```
Prayer Time Behavior:
├─ 5 minutes before prayer: notification "اقترب وقت الصلاة"
├─ At prayer time: 
│    ├─ Screen time PAUSES (not counting against limit)
│    ├─ All notifications silenced (except SOS)
│    └─ Show "وقت الصلاة — توقف وأدِ الصلاة" gentle reminder
├─ 15 minutes after prayer: normal operation resumes
└─ Friday 11:30-12:30: Jumu'ah prayer special silence

Settings: "احترام أوقات الصلاة" toggle (default ON for Saudi users)
```

#### OPD6: Dialect-Aware Speech Recognition (addresses D6)

Train the speech-to-text on Saudi/Najdi dialect specifically:
- Recognize "أبغى" (Najdi for "أريد")
- Recognize "اللحين" (Najdi for "الآن")
- Recognize "ربع" (Najdi for "أصدقاء")

Show transcription with confidence indicator: high confidence = clean text; low confidence = "تحقق من النص" prompt.

#### OPD7: Fair Sibling Competition (addresses D7)

Instead of a single family leaderboard, offer:
- **Personal growth leaderboard:** "أفضل أسبوع لك" (your best week) — compete against self
- **Age-adjusted ranking:** Saud's XP is adjusted for age (9 vs 12) — shows relative effort
- **Team challenges:** "تعاونوا أنتم وإخوانكم: اكملوا ٥٠٠ نقطة هذا الأسبوع" — cooperative, not competitive
- **Different categories:** Saud might be #1 in Quran, Khalid #1 in Science — celebrate individual strengths

#### OPD8: Meal-to-Shopping Integration (addresses D8)

When mother saves a meal plan, system auto-generates shopping items:

```
Meal: كبسة دجاج
Auto-suggest to shopping:
  ├─ دجاج (1 كيلو)
  ├─ رز بسمتي (2 كوب)
  ├─ بهار كبسة (1 ملعقة)
  ├─ بصل (2 حبة)
  ├─ زبيب (للتزيين)
  └─ لوز (للتزيين)

Mother can: [إضافة الكل] [اختيار] [تعديل الكميات]
```

#### OPD9: SOS Bypasses School Time (addresses D9)

**CRITICAL:** SOS FAB and SOS functionality must NEVER be blocked by School Time, bedtime, screen time lock, or Focus Mode. The FAB overlay must be active at ALL times on the child's device.

School Time blocks entertainment apps only — communication and SOS are always accessible. This is a hard system requirement, not a configuration option.

#### OPD10: One-Page Day Summary (addresses D10)

Father's evening review should be a single scrollable page, not drill-downs:

```
┌──────────────────────────────────────────────────────┐
│  📊 ملخص اليوم — ١٤ صفر ١٤٤٨ هـ                       │
│                                                      │
│  ✅ جميع الأطفال في البيت                              │
│  ⏱️  ٣ تنبيهات اليوم (١ محتوى، ٢ موقع)                 │
│                                                      │
│  ── خالد (١٢) ──                                     │
│  📍 مدرسة → بيت ✓                                     │
│  📚 تعليم: ١٨٥ نقطة، اختبار علوم ٨٠٪                  │
│  🕌 قرآن: ٥ آيات (٨٨٪ دقة)                            │
│  🎮 وقت الشاشة: ٢س + ١٥ دقيقة مكافأة                   │
│  🚨 ١ تنبيه محتوى (موقع ألعاب — تم الحجب)              │
│                                                      │
│  ── سعود (٩) ──                                      │
│  📍 مدرسة → بيت ✓                                     │
│  📚 تعليم: ٦٠ نقطة                                    │
│  🎮 وقت الشاشة: ١س٣٠د (مكتمل)                          │
│  ✅ لا تنبيهات                                        │
│                                                      │
│  ── لاية (٧) ──                                      │
│  📍 مدرسة → بيت ✓ (يدوي)                              │
│  📚 تعليم: ٢٠ نقطة (عبر جوال الأم)                     │
│  ✅ لا تنبيهات                                        │
│                                                      │
│  [مراجعة التفاصيل]  [تعديل القواعد]  [تم]               │
└──────────────────────────────────────────────────────┘
```

## 10. Edge Cases & Fallback Flows

### Edge Case 1: Child Forgets Phone at Home (School Day)

**Scenario:** Khalid leaves for school but forgets his phone. Father gets no departure or arrival notification.

```
7:15 AM — no departure notification received
    ↓
7:30 AM — system detects: Khalid's device still at home; battery 85%; no activity
    ↓
Push to father: "خالد لم يخرج من البيت بعد — أو قد يكون نسي جواله. الجوال في البيت."
    ↓
Father knows: either Khalid overslept (unlikely — he was at breakfast) 
or forgot his phone → calls home to confirm
    ↓
Resolution: Khalid is at school without phone → no monitoring today
    → Dashboard shows: "خالد — الجوال في البيت (غير نشط)" all day
    → School Time rules don't apply (no phone to enforce them)
    → At pickup, Khalid gets phone back → monitoring resumes
```

### Edge Case 2: Internet Outage at Home

**Scenario:** WiFi goes down during Khalid's learning session. Cellular data may or may not be available.

```
WiFi drops → app switches to cellular (if available)
    ↓
If cellular available:
    └─ Seamless; lesson continues; slightly slower
    ↓
If no internet at all:
    └─ Pre-cached lessons still work (if downloaded)
    └─ Live features disabled: chat, live quizzes, AI Tutor
    └─ Child sees: "لا يوجد اتصال — الدروس المحفوظة متاحة"
    └─ Monitoring: location updates pause
    └─ Father sees: "خالد — الجوال غير متصل بالإنترنت"
    └─ SOS: attempts cellular → SMS fallback → works if any signal
```

### Edge Case 3: Weekend vs. Weekday Screen Time Rules

**Scenario:** It's Friday (weekend in Saudi). Different rules apply.

```
Weekday (Sunday–Thursday):
    ├─ Screen time: 2 hours
    ├─ School Time: 7 AM – 2 PM (entertainment locked)
    └─ Bedtime: 10 PM

Weekend (Friday–Saturday):
    ├─ Screen time: 3 hours
    ├─ School Time: OFF (no school)
    ├─ Bedtime: 11 PM (or configurable by parent)
    └─ Jumu'ah prayer (Friday): 11:30 AM – 12:30 PM (special silence period)
```

### Edge Case 4: School Holiday / National Day

**Scenario:** It's Saudi National Day (September 23) — school is off. Children are home all day.

```
System detects: Saudi National Day (built-in calendar)
    ↓
Auto-adjusts:
    ├─ School Time: DISABLED for the day
    ├─ Screen time: Weekend rules apply (3 hours)
    ├─ Safe zones: school zone doesn't generate departure/arrival alerts
    └─ Notification to father: "اليوم إجازة — قواعد العطلة مطبّقة"

Father can override: "تطبيق قواعد يوم الأسبوع" if he wants stricter control
```

### Edge Case 5: Child Uses a Second Device (Friend's Phone, School Tablet)

**Scenario:** Khalid borrows his friend's phone to watch TikTok (bypassing the block on his own phone).

```
Monitoring only covers Khalid's registered device
    ↓
Friend's device: no monitoring, no blocking, no tracking
    ↓
Platform cannot prevent this — physical limitation
    ↓
Mitigation:
    ├─ If Khalid's device shows low usage but GPS shows "home" →
    │  AI infers: may be using another device
    ├─ Weekly AI insight: "خالد استخدم جواله ٤٥ دقيقة فقط هذا الأسبوع — أقل من المعتاد"
    └─ Father can discuss with Khalid based on pattern changes
```

### Edge Case 6: Child in Two-Household Family (Divorced Parents)

**Scenario:** Future consideration — child splits time between father's house and mother's house.

```
Current system: single family entity with admin (father) + limited_admin (mother)
    ↓
Divorced scenario:
    ├─ Father's house: full monitoring, father is admin
    ├─ Mother's house: mother needs different safe zones, different rules
    └─ Rules may conflict between households
    
Fallback for now:
    ├─ Father remains admin; mother is limited_admin
    ├─ Father can add mother's house as a safe zone
    ├─ Screen time rules apply regardless of location
    └─ Monitoring continues across both households

Future enhancement: "ملفات تعريف المنزل" (household profiles) — 
different rules auto-activate based on which household the child is in
```

### Edge Case 7: Multiple Devices Per Child (Phone + Tablet)

**Scenario:** Khalid has a phone (Samsung A25) and a school tablet (iPad). Both need monitoring.

```
Current system: one device per child
    ↓
Multi-device scenario:
    ├─ Primary device (phone): full monitoring
    ├─ Secondary device (tablet): needs separate pairing
    └─ Screen time: combined across both devices (2h total, not 2h each)

Design consideration:
    ├─ During pairing: "هل يملك خالد أجهزة أخرى؟" with "إضافة جهاز" option
    ├─ Screen time aggregation: "خالد — جميع الأجهزة: ٢:١٥ استخدام"
    └─ Location: primary device only (child carries phone, not tablet)
```

## 11. Daily Engagement Metrics

### Retention & Habit Formation

| Metric | Target | Measurement | Benchmark |
|--------|--------|-------------|-----------|
| Daily Active Users (DAU) — Father | >60% of registered | App opened at least once per day | 40% typical for utility apps |
| Daily Active Users (DAU) — Mother | >70% of registered | App opened at least once per day | 50% (more daily utility) |
| Daily Active Users (DAU) — Child | >50% of registered | Learning Home opened + at least 1 quest started | 30% for education apps |
| Weekly Active Users (WAU) — All | >80% of registered | At least 3 active days per week | 60% for family apps |
| Daily session count — Father | 2-3 sessions | Morning check + alerts + evening review | — |
| Daily session count — Mother | 5-8 micro-sessions | Morning planning + throughout day + evening | — |
| Daily session count — Child | 1-2 sessions | After-school learning + free time | — |
| Average session duration — Father | <5 min | Per session | — |
| Average session duration — Mother | <3 min (micro) | Per session | — |
| Average session duration — Child | 30-45 min | Learning session; free time separate | — |

### Feature Engagement

| Feature | Metric | Target | Persona |
|---------|--------|--------|---------|
| Today Dashboard | Daily views | >90% of DAU | Father |
| Family Chat | Messages sent per day | >3 per family | All |
| Location Check | Views per day | >2 per parent | Father, Mother |
| Calendar | Events added per week | >2 per family | Mother (primary) |
| Shopping List | Items added per week | >5 per family | Mother (primary) |
| Learning Quests | Quests completed per day | >3 per child | Child |
| Quran Module | Sessions per week | >3 per child | Child, Mother |
| AI Tutor | Questions asked per week | >2 per child | Child |
| Focus Mode | Sessions per week | >2 per child | Child |
| Screen Time Request | Requests per week | <5 per child | Child |
| Screen Time Earned (via learning) | Bonus time earned per week | >30 min per child | Child |

### Gamification Metrics (Child)

| Metric | Target | Measurement |
|--------|--------|-------------|
| XP earned per day | >100 | Sum of all XP from quests, quizzes, Focus Mode |
| Streak maintenance | 5+ day average | Consecutive days with at least 1 quest completed |
| Level-up frequency | Every 1-2 weeks | Time between level-ups for engaged users |
| Badge collection | 1-2 new badges per week | Badges earned from achievements |
| Leaderboard engagement | 3+ views per week | Family leaderboard opens per week |
| Learning-to-play conversion | >50% of bonus time | Bonus screen time earned via learning / total bonus time |

### Notification Quality Metrics

| Metric | Target | Measurement |
|--------|--------|-------------|
| Push notification open rate | >35% | Opened / delivered (excluding SOS which should be >95%) |
| Notification-to-action rate | >20% | Opened → took action (viewed alert, responded to request) |
| Notification dismissal rate | <40% | Dismissed without opening |
| Notification fatigue signal | <3% | User turns off notification category |
| SOS notification open rate | >95% | SOS opened within 30 seconds of delivery |
| False trigger rate (SOS) | <5% per month | False SOS events / total SOS events |

### Saudi-Specific Engagement Metrics

| Metric | Target | Notes |
|--------|--------|-------|
| Hijri calendar usage | >70% | Users with Hijri as primary calendar view |
| Quran module weekly engagement | >60% of families | At least 1 Quran session per child per week |
| Prayer time awareness response | >80% | Users who respect prayer time nudges (pause usage) |
| Voice message usage | >40% of messages | Saudi culture prefers voice notes over typing |
| Arabic NLP accuracy | >90% | Transcription, translation, and AI Tutor accuracy in MSA + Najdi |
| Family chat activity (vs WhatsApp) | >30% of family communication | Platform chat share vs WhatsApp (measured indirectly) |

### Day-Part Engagement Heatmap

```
TIME    FATHER            MOTHER            CHILD (KHALID)
═══════════════════════════════════════════════════════════
04:30   ░░░░░░░░░░        ░░░░░░░░░░        ░░░░░░░░░░
05:00   ░░░░░░░░░░        ▓░░░░░░░░░        ░░░░░░░░░░
06:00   ░░░░░░░░░░        ██████████  ← Morning planning peak
06:45   █████░░░░░  ← Morning check  
07:00   ░░░░░░░░░░        ░░░░░░░░░░        ▓░░░░░░░░░  ← Chat only
08:00   ░░░░░░░░░░        ▓░░░░░░░░░        ░░░░░░░░░░
09:00   ░░░░░░░░░░        █████░░░░░  ← Mid-morning check
10:30   ▓░░░░░░░░░  ← Content alert
14:00   ▓░░░░░░░░░  ← Arrival push     ▓░░░░░░░░░        ░░░░░░░░░░
14:15   ░░░░░░░░░░        ▓░░░░░░░░░        ▓░░░░░░░░░  ← Home chat
15:00   ░░░░░░░░░░        ░░░░░░░░░░        ██████████
15:30   ░░░░░░░░░░        ▓░░░░░░░░░  ← Screen time req
16:00   ░░░░░░░░░░        ░░░░░░░░░░        ██████████  ← PEAK: Learning
17:00   ░░░░░░░░░░        ░░░░░░░░░░        █████░░░░░  ← Free time
18:00   ░░░░░░░░░░        ▓░░░░░░░░░        ▓░░░░░░░░░
18:30   ░░░░░░░░░░        ▓░░░░░░░░░  ← Dinner prep chat
19:00   ░░░░░░░░░░        ▓░░░░░░░░░        ▓░░░░░░░░░
19:30   ░░░░░░░░░░        ░░░░░░░░░░        ░░░░░░░░░░
20:30   █████░░░░░  ← Evening review  ░░░░░░░░░░        ░░░░░░░░░░
21:00   ░░░░░░░░░░        ▓░░░░░░░░░  ← Bedtime check    ▓░░░░░░░░░  ← Goodnight
22:00   ░░░░░░░░░░        ░░░░░░░░░░        ░░░░░░░░░░

█ = High activity    ▓ = Moderate activity    ░ = Low/no activity
```

---

*Related documents:*
- [Persona Journey Maps](../01_PERSONA_JOURNEY_MAPS.md)
- [Onboarding Journey](01_ONBOARDING_JOURNEY.md)
- [SOS Emergency Journey](02_SOS_EMERGENCY_JOURNEY.md)
