# SOS Emergency Journey — From Child Trigger to Parent Response

> **Flow ID:** FLOW-02  
> **Journey IDs covered:** J-F03 (Father emergency response), J-C03 (Child SOS trigger)  
> **Criticality:** P0-CRITICAL — The most important safety flow in the platform  
> **SLA Target:** Trigger → Parent notification < 5 seconds  
> **Date:** 2026-09-13  

---

## Table of Contents

1. [Journey Overview](#1-journey-overview)
2. [Phase 1: Child Triggers SOS](#2-phase-1-child-triggers-sos)
3. [Phase 2: System Processing & Alert Dispatch](#3-phase-2-system-processing--alert-dispatch)
4. [Phase 3: Parent Receives & Acknowledges Alert](#4-phase-3-parent-receives--acknowledges-alert)
5. [Phase 4: Parent Assesses Situation](#5-phase-4-parent-assesses-situation)
6. [Phase 5: Parent Responds](#6-phase-5-parent-responds)
7. [Phase 6: Resolution & Follow-up](#7-phase-6-resolution--follow-up)
8. [Complete ASCII Flow Diagram](#8-complete-ascii-flow-diagram)
9. [Critical Pain Points & Design Opportunities](#9-critical-pain-points--design-opportunities)
10. [Edge Cases & Fallback Flows](#10-edge-cases--fallback-flows)
11. [SOS Technical Requirements Summary](#11-sos-technical-requirements-summary)
12. [SOS Success Metrics & SLAs](#12-sos-success-metrics--slas)

---

## 1. Journey Overview

The SOS Emergency Journey is the **most critical safety flow** in the World-Class Family OS. It is the feature that directly fulfills the father's primary JTBD: *"When something dangerous happens to my son, I want to know immediately with full context."* Every second between the child's trigger and the parent's response matters — this flow is designed for a **sub-5-second trigger-to-notification SLA**.

### Journey Architecture

```
CHILD TRIGGERS                    SYSTEM PROCESSES                  PARENT RESPONDS
═══════════════                   ═════════════════                 ═══════════════
Hold FAB 3 seconds                Capture GPS + device state        Push notification (critical)
→ Confirmation                    → Dispatch alert to parents       → Open SOS overlay
→ SOS active                      → Start live tracking              → View location + context
                                  → Open communication channel       → Call child
                                                                     → Resolve or escalate
```

### Realistic Scenario

**Context:** Khalid (12) is at a park near his school in Riyadh, playing with friends after Maghrib prayer. An older teenager from another neighborhood starts harassing his group. Khalid feels threatened but is not in immediate physical danger — he wants his father to know and come.

**Timeline target:**
- T+0s: Khalid presses and holds SOS FAB
- T+3s: Confirmation screen → Khalid confirms
- T+3.5s: SOS dispatched (GPS, device state, alert)
- T+4s: Abu Khalid's phone receives critical push notification (overrides DND)
- T+5s: Abu Khalid opens notification → SOS overlay loads
- T+8s: Abu Khalid sees Khalid's location, taps "Call"
- T+15s: Call connects
- T+2-5min: Abu Khalid arrives or guides Khalid to safety
- T+10min: SOS resolved

### Key Design Principles

1. **Speed over everything** — the flow is optimized for the fastest possible notification
2. **Fail-safe, not fail-dead** — if any step fails, the system retries and falls back, never silently drops
3. **Context-rich** — the parent should know WHO, WHERE, WHAT, and HOW to respond in one glance
4. **Child-safe triggering** — 3-second hold prevents accidental triggers; confirmation prevents pocket-presses
5. **Multi-channel redundancy** — push notification + SMS fallback + in-app alert + sound override
6. **Privacy-preserving** — SOS data is emergency-only; not used for routine monitoring
7. **Cultural sensitivity** — in Saudi culture, family safety is paramount; the SOS feature is the platform's most important trust signal

### SLA Targets

| Stage | SLA | Hard Requirement |
|-------|-----|-----------------|
| Trigger → Confirmation | ≤3s (hold time) | 3-second hold with haptic escalation |
| Confirmation → Dispatch | ≤0.5s | GPS + device state captured and sent |
| Dispatch → Parent notification received | ≤5s | Push + SMS fallback if push undelivered in 3s |
| Notification → Parent opens SOS view | ≤3s | One tap from notification → full overlay |
| SOS view → Call button visible | ≤1s | Call button is immediately visible without scrolling |
| Location update frequency during active SOS | Every 10s | Live tracking until resolved |
| Battery optimization | SOS must work <30% battery | Disable battery optimization for SOS |

## 2. Phase 1: Child Triggers SOS

**Actor:** Khalid (Child, 12)  
**Goal:** Signal danger to parents as quickly and safely as possible  
**Duration:** 3-5 seconds (hold time + confirmation)  

### Step-by-Step Flow

| Step | Actor | Action | System Response | Screen ID | Emotion | Error / Edge Case | Success Criteria |
|------|-------|--------|----------------|-----------|---------|-------------------|------------------|
| 1.1 | Child | On any screen (in app or another app — SOS FAB is an overlay), child sees red circular FAB in bottom-right corner | FAB is always visible on child's screen: red circle with 🆘 icon, subtle pulse animation to indicate it's interactive but not alarming | SCR-SOS-FAB | 😐 Neutral | FAB not visible — overlay permission not granted (Phase 4 issue) | FAB visible on every child screen across all apps |
| 1.2 | Child | Presses and holds the FAB | Haptic feedback begins: gentle vibration at 0s, medium at 1s, strong at 2s, very strong at 3s. Visual: FAB grows, ring fills around it (progress indicator) | SCR-SOS-01a | 😰 Anxious | Child releases before 3s → trigger cancels, ring resets, no alert sent | Hold registered; haptic escalation progressing |
| 1.3 | Child | Holds through 3 seconds — ring completes | Confirmation overlay slides up: "🆘 إرسال طوارئ؟" with two buttons: "نعم، أرسل" (Yes, send) and "إلغاء" (Cancel) | SCR-SOS-01 | 😰 Anxious | Child accidentally triggered (pocket press) — can cancel now | 3-second hold complete; confirmation dialog shown |
| 1.4 | Child | Taps "نعم، أرسل" (Yes, send) | SOS DISPATCHED: system immediately captures GPS coordinates, device battery, device status, timestamp, child profile → sends to backend → backend pushes to all parent devices | SCR-SOS-01b | 😰 Anxious | Child taps "إلغاء" — SOS cancelled, no alert sent; logged as "false trigger" for analytics | SOS confirmed and dispatched within 0.5s of tap |
| 1.5 | Child | Screen transitions to SOS Active view | SOS Active screen: red theme, pulsing animation, "تم إرسال الطوارئ ✅" + "أبوك توصل" + live status indicator + "اتصل بأبوك" quick button + "إنهاء" (end) button | SCR-SOS-03 | 😰 Anxious (but reassured) | Screen must stay on SOS view — child cannot navigate away during active SOS (unless phone is taken) | SOS Active screen displayed; child knows alert was sent |

### Hold-to-Trigger Mechanism Detail

```
Time:   0s      1s      2s      3s
        │       │       │       │
Hold:   █───────█───────█───────█──> TRIGGER
        │       │       │       │
Haptic: gentle  medium  strong  VERY strong
        │       │       │       │
Visual: 25%     50%     75%     100% ring filled
        │       │       │       │
        ▼       ▼       ▼       ▼
        If released here → CANCEL (no alert)
                            │
                            ▼
                    Confirmation: "🆘 إرسال طوارئ؟"
                       [نعم، أرسل]    [إلغاء]
                            │              │
                            ▼              ▼
                       DISPATCH       CANCEL (logged)
```

### Safety Considerations

- **Accidental trigger prevention:** 3-second hold + confirmation dialog = two-step safety. Pocket presses won't trigger (hold is too long for accidental).
- **Duress consideration:** If child is being forced to cancel, the 3-second hold already dispatched a "soft trigger" — **consider stealth mode**: after 2s hold, a "silent SOS" could be sent without confirmation, logging but not displaying anything to the child's screen. (Future enhancement — needs careful design to avoid false triggers.)
- **First 24 hours protection:** During the first 24 hours after onboarding, the 3-second hold shows a confirmation "هل أنت في خطر حقيقي؟" with larger buttons, to prevent testing-based false triggers.
- **Cooldown:** After a cancelled SOS, a 10-second cooldown prevents rapid re-triggering (prevents spam), but a genuine second trigger within cooldown gets a "هل أنت متأكد؟ هذا تنبيه متكرر" warning, not a block.

## 3. Phase 2: System Processing & Alert Dispatch

**Actor:** System (backend + child device + parent device)  
**Goal:** Capture all emergency data and deliver alert to parent(s) in <5 seconds  
**Duration:** 0.5-5 seconds (from confirmation to parent notification received)  
**Criticality:** This is the technical core — if dispatch fails, the entire safety promise breaks.

### Step-by-Step Flow

| Step | Actor | Action | System Response | Screen ID | Emotion | Error / Edge Case | Success Criteria |
|------|-------|--------|----------------|-----------|---------|-------------------|------------------|
| 2.1 | System (child device) | On confirmation, device captures: GPS (lat/long), battery level, network type (WiFi/cellular), device model, screen state (on/off), timestamp (Hijri + Gregorian) | Data packet assembled in <200ms; sent to backend via HTTPS POST | — | — | GPS unavailable (indoor, no signal) → use last known location + cell tower triangulation | All available location + device data captured |
| 2.2 | System (backend) | Receives SOS packet → creates SOS event record → identifies parent(s) to notify → dispatches push notifications (APNs for iOS, FCM for Android) | Backend processes in <100ms; pushes sent to all parent devices (father + mother if connected) | — | — | Backend down → retry with exponential backoff; child device also sends SMS fallback directly | Push notification dispatched to all parent devices |
| 2.3 | System (push) | Push notification delivered to parent device(s) | **Critical push:** overrides Do Not Disturb, silent mode, and focus modes. Unique sound (distinct from all other notifications). Full-screen banner on lock screen. | Push notification | — | Push not delivered (no internet on parent device) → SMS fallback after 3s timeout | Push notification received on at least one parent device |
| 2.4 | System (SMS fallback) | If push undelivered after 3 seconds → SMS sent to parent phone number(s) with: "🆘 تنبيه طوارئ من خالد — موقعه: [Google Maps link]. تتبع: [app link]" | SMS dispatched via Saudi telecom gateway (STC/Mobily/Zain); includes location link that opens in browser | SMS | — | SMS also fails (parent phone off) → email fallback (if email provided); log "delivery failure" | At least one channel delivers the alert |
| 2.5 | System (child device) | Starts live tracking: GPS updates every 10 seconds, sent to backend → relayed to parent's SOS overlay in real-time | Live location stream active; child device enters high-priority mode (GPS polling at 1Hz, upload at 0.1Hz) | — | — | GPS drift in urban canyon (Riyadh high-rises) → use fused location (GPS + WiFi + cell) | Live tracking stream active and updating |
| 2.6 | System (child device) | Starts recording ambient audio (optional, privacy-gated) | If enabled by parent during setup: records 30-second audio clip, encrypts, uploads to backend for parent access | — | — | Microphone blocked by another app → skip audio; log "audio unavailable" | Audio recording available if enabled (opt-in only) |
| 2.7 | System (backend) | Logs SOS event: trigger time, location, device data, audio (if available), notification delivery status, parent response tracking | SOS event record created with unique ID; all subsequent actions (parent views, calls, resolution) are appended to this record | — | — | — | Complete SOS event record created for audit trail |

### Alert Dispatch Architecture

```
CHILD DEVICE (Khalid's phone)
    │
    ├─ GPS Capture (<200ms)
    ├─ Battery + Device State
    ├─ Timestamp (Hijri + Gregorian)
    ├─ Network type
    │
    ▼ (HTTPS POST, <100ms)
BACKEND SERVER
    │
    ├─ Create SOS Event Record
    ├─ Identify Parents (father + mother)
    ├─ Dispatch Push (APNs/FCM) ─────────────────────┐
    │                                                  │
    ├─ Timer: 3 seconds ──── (no delivery) ───> SMS Fallback
    │                                                  │
    │                                                  ▼
    │                                    PARENT DEVICE (Father's iPhone)
    │                                    ├─ Critical Push Received
    │                                    ├─ Overrides DND / Silent
    │                                    ├─ Unique SOS Sound
    │                                    └─ Full-Screen Banner
    │
    ├─ Start Live Tracking (GPS every 10s)
    ├─ Start Audio Recording (if enabled)
    │
    └─ Log Event + Delivery Status

REDUNDANCY LAYERS:
    Layer 1: Push notification (primary)
    Layer 2: SMS fallback (3s timeout)
    Layer 3: Email fallback (5s timeout, if email on file)
    Layer 4: In-app alert (next time parent opens app)
    Layer 5: Mother receives parallel notification (if connected)
```

### Notification Payload (Parent Device)

```
┌────────────────────────────────────────────────────┐
│  🆘 تنبيه طوارئ — خالد                              │
│                                                    │
│  📍 حي النرجس، الرياض                              │
│  ⏰ قبل لحظات — ٢٠:٤٥ مساءً                          │
│  🔋 بطارية: ٧٣٪                                    │
│                                                    │
│  [فتح تفاصيل الطوارئ]                               │
└────────────────────────────────────────────────────┘
        ↑
  Full-screen banner on lock screen
  Overrides Do Not Disturb
  Unique SOS sound (distinct from all other notifications)
  Vibration pattern: long-long-long (SOS Morse code)
```

## 4. Phase 3: Parent Receives & Acknowledges Alert

**Actor:** Abu Khalid (Father)  
**Goal:** Become aware of the emergency and open the SOS response view  
**Duration:** 2-5 seconds (from notification to SOS overlay loaded)  
**Criticality:** Every second of delay here reduces the child's safety. The notification must be impossible to miss.

### Step-by-Step Flow

| Step | Actor | Action | System Response | Screen ID | Emotion | Error / Edge Case | Success Criteria |
|------|-------|--------|----------------|-----------|---------|-------------------|------------------|
| 3.1 | Father | Phone is in pocket (at a work meeting) — receives critical push | Phone vibrates with SOS pattern (long-long-long); unique alarm sound plays even though phone is on silent/DND; screen lights up with full-screen banner | Lock screen banner | 😰 Anxious | Phone is truly off (battery dead) → SMS fallback hits; next time phone powers on, in-app alert shows | Father becomes aware of SOS within 5s of dispatch |
| 3.2 | Father | Pulls phone out, sees full-screen banner: "🆘 تنبيه طوارئ — خالد — حي النرجس، الرياض" | Banner shows: child name, location (street-level), time, battery, "فتح تفاصيل الطوارئ" button | SCR-SOS-PUSH | 😰 Anxious | Father accidentally dismisses banner (swipe) → notification stays in notification shade with same urgency | Father sees the notification with enough context to act |
| 3.3 | Father | Taps "فتح تفاصيل الطوارئ" or taps notification in shade | App opens DIRECTLY to SOS full-screen overlay — no dashboard, no auth wall, no loading spinner (pre-cached data) | SCR-SOS-02 | 😰 Anxious | App not installed on this phone (father using secondary device) → SMS link opens web-based SOS view in browser | SOS overlay loads within 1s of tap |
| 3.4 | Father | Sees SOS overlay — full-screen red-themed emergency view | SOS Overlay contents (see layout below): child photo + name, live GPS map, location address, battery, time since trigger, quick action buttons | SCR-SOS-02 | 😰 Anxious | Map tiles slow to load (poor connection) → text address shows immediately, map loads progressively | Father has all critical info visible without scrolling |

### SOS Overlay Layout

```
╔══════════════════════════════════════════════════╗
║  🆘 حالة طوارئ — نشطة              [إنهاء] ║
╠══════════════════════════════════════════════════╣
║                                                  ║
║  ┌──────┐  خالد العتيبي                           ║
║  │ PHOTO│  ١٢ سنة                                ║
│  └──────┘  بطارية: ٧٣٪ 🔋                        ║
║                                                  ║
║  📍 حي النرجس — شارع الأمير سلطان                  ║
║     الرياض                                       ║
║     قبل ٣٠ ثانية                                 ║
║                                                  ║
║  ┌──────────────────────────────────────────────┐║
║  │                                              │║
║  │           [ LIVE GPS MAP ]                   │║
║  │                                              │║
║  │     📍 Khalid's position                     │║
║  │     🏠 Home (1.2 km)                         │║
║  │     🕌 Mosque (400 m)                        │║
║  │     🏫 School (800 m)                        │║
║  │                                              │║
║  └──────────────────────────────────────────────┘║
║                                                  ║
║  ┌─────────────┐  ┌─────────────┐  ┌──────────┐ ║
║  │ 📞 اتصال    │  │ 💬 رسالة    │  │ 🗺️ اذهب  │ ║
║  │  مباشر      │  │  سريعة      │  │  للموقع   │ ║
║  └─────────────┘  └─────────────┘  └──────────┘ ║
║                                                  ║
║  ┌──────────────────────────────────────────────┐║
║  │  حالة الجوال: متصل · WiFi: لا · GPS: دقيق     │║
║  └──────────────────────────────────────────────┘║
║                                                  ║
║  [ إنهاء حالة الطوارئ ]                           ║
╚══════════════════════════════════════════════════╝

QUICK ACTIONS (visible without scrolling):
  📞 اتصال مباشر  — one-tap call to child
  💬 رسالة سريعة  — pre-set messages: "أنا جاي", "وين أنت بالضبط؟", "اتصل بالشرطة؟"
  🗺️ اذهب للموقع  — opens Google Maps/Apple Maps with directions to child's location
```

### Emotional State Tracking

```
Father's emotional journey during notification:

Notification arrives:  😰😰😰  (peak anxiety — "what happened?")
Opens overlay:         😰😰    (still anxious but now has information)
Sees location:         😰😐    (can assess — "he's at the park, not far")
Sees battery:          😐      (73% — phone isn't dying, communication possible)
Sees quick actions:    😐😊    (knows exactly what to do next)
```

## 5. Phase 4: Parent Assesses Situation

**Actor:** Abu Khalid (Father)  
**Goal:** Understand what is happening to the child and decide how to respond  
**Duration:** 5-30 seconds (assessment phase — depends on context available)  

### Step-by-Step Flow

| Step | Actor | Action | System Response | Screen ID | Emotion | Error / Edge Case | Success Criteria |
|------|-------|--------|----------------|-----------|---------|-------------------|------------------|
| 4.1 | Father | Looks at map — sees Khalid is at a park near school, 1.2 km from home | Map shows: child's position (red dot), safe zones (home, school, mosque), distance indicators, movement trail (if moving) | SCR-SOS-02 (map) | 😐 Neutral → 😰 | Map not loading (connection issue) → text address "حي النرجس، شارع الأمير سلطان" already displayed | Father can identify child's general location |
| 4.2 | Father | Checks nearby landmarks — is this a known place? | POI overlay shows nearby: "متنزه النرجس" (park), "محل بقالة" (grocery), "مسجد الرحمن" (mosque) | SCR-SOS-02 (POI) | 😐 Neutral | POI data unavailable → show only street name | Father recognizes the location or gets enough context |
| 4.3 | Father | Checks time since trigger — "قبل ٣٠ ثانية" — this just happened | Timer counts up: "قبل ٣٠ ثانية" → "قبل ٤٥ ثانية" → "قبل ١ دقيقة" — increasing urgency | SCR-SOS-02 (timer) | 😰 Anxious | Timer is reassuring if short; alarming if long (>5 min) before parent saw it | Father knows how fresh the emergency is |
| 4.4 | Father | Checks if Khalid is moving — map shows red dot stationary | Movement indicator: "ساكن" (stationary) or "يتحرك" (moving) with direction arrow; if moving, speed shown | SCR-SOS-02 (movement) | 😐 Neutral | GPS jitter may show false movement → use movement threshold (ignore <3 m/s) | Father knows if child is moving (fleeing? walking? in a vehicle?) |
| 4.5 | Father | Checks device status — battery 73%, GPS active, no WiFi (on cellular) | Device status bar: battery, connectivity, GPS accuracy, screen state | SCR-SOS-02 (status) | 😐 Neutral | If battery <10%, show "⚠️ بطارية منخفضة — قد ينقطع الاتصال" | Father can assess communication viability |
| 4.6 | Father | If audio recording enabled, taps "استماع للتسجيل" | Audio player: 30-second ambient recording from child's phone; waveform display; play/pause | SCR-SOS-02c (audio) | 😰 Anxious | Audio not available (not enabled or mic blocked) → "التسجيل الصوتي غير متاح" | Father gets audio context if available |
| 4.7 | Father | Reviews location history — where was Khalid before this? | Location trail: last 30 minutes of movement, showing path from home to park to current location | SCR-SOS-02d (trail) | 😐 Neutral | Location history sparse (GPS was off before SOS) → "لا يوجد مسار سابق" | Father understands child's movement pattern leading to emergency |
| 4.8 | Father | Mental assessment: "He's at the park near school. He was at home 30 min ago. He walked to the park. Battery is fine. He's not moving." → Decides to call | — | — | 😐 Neutral → 😰 | Father may panic and act irrationally; system should provide calm guidance | Father has enough context to choose a response action |

### Assessment Decision Tree

```
FATHER ASSESSES:
    │
    ├── Is child in a known safe zone? 
    │     ├── YES → Lower urgency; child may have triggered accidentally → call to verify
    │     └── NO  → Higher urgency; child is somewhere unexpected → call immediately
    │
    ├── Is child moving?
    │     ├── YES, fast → may be fleeing or in a vehicle → call immediately + drive to location
    │     ├── YES, slow → walking, likely conscious → call to assess
    │     └── NO, stationary → could be hiding, cornered, or safe → call immediately
    │
    ├── Battery level?
    │     ├── >50% → communication viable → call
    │     ├── 10-50% → call now before battery dies
    │     └── <10% → URGENT: call NOW; prepare to drive; "⚠️ بطارية منخفضة"
    │
    └── Audio available?
          ├── YES → listen for signs of danger (voices, distress, silence)
          └── NO  → proceed without audio context

DECISION: Call child first. If no answer in 30s, call mother. 
          If no answer from either, drive to location / contact authorities.
```

## 6. Phase 5: Parent Responds

**Actor:** Abu Khalid (Father)  
**Goal:** Make contact with child and take appropriate action  
**Duration:** 15 seconds to 5 minutes (call + decision)  

### Step-by-Step Flow

| Step | Actor | Action | System Response | Screen ID | Emotion | Error / Edge Case | Success Criteria |
|------|-------|--------|----------------|-----------|---------|-------------------|------------------|
| 5.1 | Father | Taps "📞 اتصال مباشر" (Direct Call) | Phone dialer opens with Khalid's number pre-loaded; SOS overlay minimizes to picture-in-picture (PiP) so father sees live location while on call | SCR-SOS-02b + dialer | 😰 Anxious | Call fails (network issue) → auto-retry 3 times with 2s interval; then "تعذر الاتصال — حاول مرة أخرى أو أرسل رسالة" | Call initiated within 1s of tap |
| 5.2 | Father | Hears ringing — waiting for Khalid to answer | Ringing tone; PiP shows child's location updating; if child's phone rings, child sees "أبوك يتصل 📞" on SOS screen | Dialer + SCR-SOS-03 (child) | 😰 Anxious | No answer after 30s → "لم يرد خالد — [الاتصال مرة أخرى] [إرسال رسالة] [الاتصال بأمه] [الذهاب للموقع]" | Call connects or father has clear fallback options |
| 5.3 | Child | Khalid sees "أبوك يتصل 📞" on his SOS screen → answers | Call connected; father hears Khalid's voice: "يا بابا، صار مشكلة مع واحد من الشباب الكبار" | SCR-SOS-03 (call active) | 😰→😌 (child) 😰 (father) | Call drops (weak signal) → auto-redial after 3s; "أبوك يعاود الاتصال" shown on child's screen | Call connected; voice communication established |
| 5.4 | Father | Talks to Khalid: "وين أنت بالضبط؟ وش صار؟" — assesses situation through conversation | Call continues; PiP shows live location; father can switch to speaker; SOS event records call duration | Active call + PiP | 😐 Neutral (assessing) | Background noise makes it hard to hear → "يمكنك تفعيل مكبر الصوت" prompt | Father gets verbal context of the emergency |
| 5.5 | Father | Decides response: "أنا جاي الحين، ابقى مع ربعك ما تروح. ٥ دايق وأوصل" | Father ends call; taps "🗺️ اذهب للموقع" → opens Google Maps/Apple Maps with turn-by-turn directions to Khalid's location | SCR-SOS-02 (Maps redirect) | 😐 Neutral (has a plan) | — | Father has clear action plan and is en route |
| 5.6 | Father | While driving, mother receives parallel notification | Mother's phone: "🆨 خالد أرسل طوارئ — أبوك تواصل معه" with location link; she can call Khalid too | SCR-SOS-PUSH (mother) | 😰 Anxious (mother) | Mother not connected (limited_admin not set up yet) → only father notified | Both parents are aware; mother can provide secondary support |
| 5.7 | Father | Arrives at location — finds Khalid with friends, older teenager has left | Father physically present; assesses situation; confirms Khalid is safe | — | 😌 Relieved | Father can't find Khalid at GPS point (GPS offset) → call again for landmarks | Father reaches child; situation assessed in person |
| 5.8 | Alternative: Quick Message | If father can't call (in a meeting, quiet space), taps "💬 رسالة سريعة" | Pre-set messages: "أنا جاي" / "وين أنت؟" / "اتصل فيني بسرعة" / custom text → sent to child's SOS screen | SCR-SOS-02e (quick msg) | 😐 Neutral | Child doesn't see message (phone in pocket) → delivery confirmation: "تم التسليم ✓" or "بانتظار التسليم" | Father communicates without calling; child receives message on SOS screen |

### Response Decision Matrix

```
SITUATION                    →  BEST RESPONSE
═════════════════════════════════════════════════════
Child answers call,          →  Talk, assess, guide verbally
not in danger                    
                                    │
Child answers call,          →  Talk, calm child, drive to location
in danger, can talk                OR contact authorities (911/999)
                                    │
Child doesn't answer         →  Auto-retry 3x → call mother →
                                    drive to location → 
                                    if >5 min no contact: authorities
                                    │
Child answers, can't talk    →  Send quick message "أرسل موقعك"
(danger nearby, can't            OR drive immediately
speak freely)                      │
                                    │
Child's phone is off/        →  Last known location → drive there
dead battery                     → contact mother → authorities
                                    │
Child is moving fast         →  Track live → call → if vehicle,
(in a vehicle?)                   note direction → report to
                                    authorities if non-family vehicle
```

### Call Fallback Chain

```
Call Child (Khalid)
    │
    ├── No answer (30s) → Auto-retry x3
    │       │
    │       └── Still no answer → Call Mother (Umm Khalid)
    │               │
    │               ├── Mother answers → coordinate response
    │               │
    │               └── Mother doesn't answer → 
    │                       ├─ Send quick message to child
    │                       ├─ Drive to location (GPS)
    │                       └─ If >5 min total: contact 999 (Saudi emergency)
    │
    ├── Call connects → assess → respond
    │
    └── Call drops → Auto-redial
            │
            └── 3 drops → switch to SMS + drive
```

## 7. Phase 6: Resolution & Follow-up

**Actor:** Abu Khalid (Father) + Khalid (Child)  
**Goal:** Formally end the SOS event, log what happened, follow up on child's wellbeing  
**Duration:** 1-5 minutes for resolution; follow-up extends over hours/days  

### Step-by-Step Flow

| Step | Actor | Action | System Response | Screen ID | Emotion | Error / Edge Case | Success Criteria |
|------|-------|--------|----------------|-----------|---------|-------------------|------------------|
| 7.1 | Father | At the scene, confirms Khalid is safe → taps "إنهاء حالة الطوارئ" on SOS overlay | Resolution screen appears: "هل تم حل الموقف؟" with options: "نعم، خالد بأمان" / "لا، المشكلة ما زالت" / "اتصل بالجهات المختصة" | SCR-SOS-04 | 😌 Relieved | Father doesn't end SOS (forgets) → system auto-prompt after 30 min: "هل انتهت حالة الطوارئ؟" | Resolution initiated |
| 7.2 | Father | Taps "نعم، خالد بأمان" | SOS event ends: live tracking stops, child's SOS screen returns to normal, incident logged with full timeline | SCR-SOS-04a | 😌 Relieved | — | SOS formally resolved; tracking stops; normal operation resumes |
| 7.3 | Father | Optional: prompted "ماذا حدث؟" — can add notes | Free-text or voice note: "خالد تعرض لمضايقة من مراهق أكبر في الحديقة. وصلت وأخذته. لا يوجد إصابات." | SCR-SOS-04b | 😐 Neutral | Father skips notes → log defaults to "تم الحل — لا ملاحظات" | Incident notes recorded for future reference |
| 7.4 | System | Generates SOS incident report: trigger time, location history, call log, resolution notes, sentiment analysis of call audio (if enabled) | Complete incident timeline: chronological events, map trail, call metadata, father's notes; saved to Monitor > SOS History | — | — | — | Full incident record created and archived |
| 7.5 | Child | Khalid's SOS screen exits → sees "تم إنهاء حالة الطوارئ ✓ — أبوك وصل" → normal app returns | Child returns to normal app state; SOS mode deactivated; gentle message: "أبوك حضر. أنت بأمان الآن." | SCR-SOS-04c (child) | 😌 Relieved | Child's phone died during SOS → when recharged and reconnected, shows "تم حل حالة الطوارئ" notification | Child knows the emergency is over and is safe |
| 7.6 | System | 1 hour later: post-SOS check-in push to child | "كيف حالك الآن؟" with mood selector: 😊 بخير / 😐 تعبان / 😣 زعلان / 😰 خايف | SCR-SOS-05 (child) | 😐 Neutral | Child ignores check-in → no follow-up needed; logged as "no response" | Post-SOS emotional check-in delivered |
| 7.7 | System | If child selects 😣 زعلان or 😰 خايف → notification to father: "خالد يشعر بالضيق بعد حادثة الطوارئ — يفضل التحدث معه" | Parent alert with recommendation to talk; not an emergency, but a wellbeing prompt | SCR-SOS-05a (parent) | 😐 Neutral | Father dismisses → logged; can review in SOS history | Parent is proactively informed of child's emotional state post-incident |
| 7.8 | Father | Evening: reviews SOS incident in Monitor > SOS History | SOS History card: date (Hijri + Gregorian), location, duration, call log, notes, sentiment analysis flag, child's post-check-in mood | SCR-MON-06 | 😐 Neutral | History buried in Monitor tab → "حوادث SOS" shortcut on Today Dashboard for 48h | Father can review and reflect on the incident |
| 7.9 | System | AI sentiment analysis (behind the scenes) flags: call audio showed elevated stress; child's mood was 😐; recommends "مراقبة حالة خالد النفسية للأيام القادمة" | Sentiment analysis card in SOS history with recommendations; NOT shown to child — only to father in private | SCR-MON-06b | — | Sentiment analysis unavailable (no audio) → skip; note "تحليل المشاعر غير متاح" | Father has AI-assisted post-incident insight |
| 7.10 | Father | Optional: adjusts rules based on incident — e.g., adds the park as a monitored zone, or restricts after-Maghrib outings | Father opens monitoring settings, makes adjustments; changes applied to child's device | SCR-MON-04 / SCR-MON-05 | 😐 Neutral | — | Father takes preventive action based on incident learnings |

### Resolution Screen Layout

```
╔══════════════════════════════════════════════════╗
║  إنهاء حالة الطوارئ                               ║
╠══════════════════════════════════════════════════╣
║                                                  ║
║  هل تم حل الموقف؟                                 ║
║                                                  ║
║  ┌──────────────────────────────────────────────┐║
║  │  ✓  نعم، خالد بأمان                          │║
║  └──────────────────────────────────────────────┘║
║  ┌──────────────────────────────────────────────┐║
║  │  ⚠️  لا، المشكلة ما زالت                     │║
║  └──────────────────────────────────────────────┘║
║  ┌──────────────────────────────────────────────┐║
║  │  📞  اتصل بالجهات المختصة (999)               │║
║  └──────────────────────────────────────────────┘║
║                                                  ║
║  ملاحظات (اختياري):                               ║
║  ┌──────────────────────────────────────────────┐║
║  │  ماذا حدث؟ (اكتب أو سجّل صوتياً)              │║
║  │                                              │║
║  │                                              │║
║  └──────────────────────────────────────────────┘║
║                                                  ║
║  [ حفظ وإنهاء ]                                   ║
╚══════════════════════════════════════════════════╝
```

## 8. Complete ASCII Flow Diagram

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                    SOS EMERGENCY JOURNEY — COMPLETE FLOW                      ║
║                  Target SLA: Trigger → Notification < 5 seconds               ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  ┌─ PHASE 1: CHILD TRIGGERS SOS                                              ║
║  │                                                                          ║
║  │  [Any screen — SOS FAB visible] SCR-SOS-FAB                              ║
║  │       │                                                                  ║
║  │       ▼                                                                  ║
║  │  [Child presses + holds FAB]                                             ║
║  │       │  0s ── 1s ── 2s ── 3s                                            ║
║  │       │  gentle → medium → strong → VERY strong (haptic)                 ║
║  │       │  25% → 50% → 75% → 100% ring fill                               ║
║  │       │                                                                  ║
║  │       ▼ (hold complete at 3s)                                            ║
║  │  [Confirmation: "🆘 إرسال طوارئ؟"] SCR-SOS-01                            ║
║  │       │                                                                  ║
║  │       ├── [إلغاء] ──> CANCEL (logged as false trigger)                   ║
║  │       │                                                                  ║
║  │       └── [نعم، أرسل] ──> DISPATCH (0.5s)                                ║
║  │                                  │                                       ║
║  │                                  ▼                                       ║
║  │  [SOS Active screen] SCR-SOS-03                                          ║
║  │  "تم إرسال الطوارئ ✅ أبوك توصل"                                          ║
║  │  Live status: waiting → seen → calling...                                ║
║  │                                                                          ║
║  ├─ PHASE 2: SYSTEM PROCESSING & DISPATCH                                    ║
║  │                                                                          ║
║  │  Child Device                    Backend                      Parent Device ║
║  │  ┌──────────┐               ┌──────────┐               ┌──────────────┐  ║
║  │  │GPS capture│──HTTPS POST──>│Create SOS │──Push (APNs/  │Notification  │  ║
║  │  │Battery    │   (<100ms)    │Event      │   FCM)──────> │received     │  ║
║  │  │Device state│              │           │               │(overrides DND)│ ║
║  │  │Timestamp  │              │           │               └──────────────┘  ║
║  │  └──────────┘               │           │                         │       ║
║  │       │                      │           │    if no delivery        │       ║
║  │       ▼                      │           │    in 3s:                │       ║
║  │  Live tracking                │           ├──SMS Fallback──> ┌──────────┐ │ ║
║  │  (GPS/10s)                   │           │                   │SMS with  │ │ ║
║  │       │                      │           │                   │map link  │ │ ║
║  │       ▼                      │           │                   └──────────┘ │ ║
║  │  Audio recording              │           │                         │      │ ║
║  │  (if enabled, 30s)            └──────────┘                         │      │ ║
║  │                                                                      │      │ ║
║  │                                                                      ▼      │ ║
║  ├─ PHASE 3: PARENT RECEIVES ALERT                                          │ ║
║  │                                                                      │ ║
║  │  [Lock screen: full-screen banner]                                       │ ║
║  │  "🆘 تنبيه طوارئ — خالد                                                    │ ║
║  │   📍 حي النرجس، الرياض · قبل لحظات · 🔋 ٧٣٪"                                │ ║
║  │                                                                          │ ║
║  │       │                                                                  │ ║
║  │       ▼ (tap notification)                                               │ ║
║  │  [SOS Full-Screen Overlay] SCR-SOS-02                                    │ ║
║  │  ┌──────────────────────────────────────────────────┐                    │ ║
║  │  │ 🆘 خالد · ١٢ سنة · 🔋 ٧٣٪                        │                    │ ║
║  │  │ 📍 حي النرجس — شارع الأمير سلطان                   │                    │ ║
║  │  │ ┌────────────────────────────────────────┐       │                    │ ║
║  │  │ │       [ LIVE GPS MAP ]                  │       │                    │ ║
║  │  │ │  📍 Khalid · 🏠 Home · 🕌 Mosque        │       │                    │ ║
║  │  │ └────────────────────────────────────────┘       │                    │ ║
║  │  │ [📞 اتصال] [💬 رسالة] [🗺️ اذهب للموقع]           │                    │ ║
║  │  └──────────────────────────────────────────────────┘                    │ ║
║  │                                                                          │ ║
║  │       │                                                                  │ ║
║  │       ▼                                                                  │ ║
║  ├─ PHASE 4: PARENT ASSESSES                                                │ ║
║  │                                                                          │ ║
║  │  Father reviews:                                                         │ ║
║  │  ├─ Map: child at park, 1.2km from home                                  │ ║
║  │  ├─ Time: "before 30 seconds" — fresh                                    │ ║
║  │  ├─ Movement: stationary                                                 │ ║
║  │  ├─ Battery: 73% — communication viable                                  │ ║
║  │  ├─ POI: near النرجس park, grocery, mosque                                │ ║
║  │  └─ Audio (if enabled): ambient recording playback                       │ ║
║  │                                                                          │ ║
║  │  Assessment: "He's at the park. Not moving. Battery fine.                │ ║
║  │  Something happened but he's not fleeing. → CALL"                        │ ║
║  │                                                                          │ ║
║  │       │                                                                  │ ║
║  │       ▼                                                                  │ ║
║  ├─ PHASE 5: PARENT RESPONDS                                                │ ║
║  │                                                                          │ ║
║  │  [Tap: 📞 اتصال مباشر]                                                    │ ║
║  │       │  SOS overlay → PiP (picture-in-picture)                          │ ║
║  │       ▼  Dialer opens with Khalid's number                                │ ║
║  │  [Ringing... Khalid sees "أبوك يتصل 📞"]                                  │ ║
║  │       │                                                                  │ ║
║  │       ├── No answer (30s) → retry x3 → call mother → drive → authorities │ ║
║  │       │                                                                  │ ║
║  │       └── Khalid answers                                                 │ ║
║  │              "يا بابا، صار مشكلة مع واحد من الشباب الكبار"                  │ ║
║  │              Father: "أنا جاي الحين، ابقى مع ربعك. ٥ دايق وأوصل"            │ ║
║  │              │                                                           │ ║
║  │              ▼                                                           │ ║
║  │  [Tap: 🗺️ اذهب للموقع] → Google Maps directions → Drive to Khalid        │ ║
║  │                                                                          │ ║
║  │  [Father arrives at park — finds Khalid safe]                            │ ║
║  │                                                                          │ ║
║  │       │                                                                  │ ║
║  │       ▼                                                                  │ ║
║  ├─ PHASE 6: RESOLUTION & FOLLOW-UP                                         │ ║
║  │                                                                          │ ║
║  │  [Tap: إنهاء حالة الطوارئ] SCR-SOS-04                                     │ ║
║  │       │                                                                  │ ║
║  │       ▼                                                                  │ ║
║  │  [Resolution: "نعم، خالد بأمان"] SCR-SOS-04a                              │ ║
║  │       │  SOS ends; live tracking stops; child's screen normalizes        │ ║
║  │       ▼                                                                  │ ║
║  │  [Optional notes: "ماذا حدث؟"] SCR-SOS-04b                               │ ║
║  │       │  "تعرض لمضايقة من مراهق أكبر في الحديقة. لا إصابات."              │ ║
║  │       ▼                                                                  │ ║
║  │  [Incident report generated + archived]                                  │ ║
║  │       │                                                                  │ ║
║  │       ▼ (1 hour later)                                                   │ ║
║  │  [Post-SOS check-in to child: "كيف حالك؟"] SCR-SOS-05                    │ ║
║  │       │                                                                  │ ║
║  │       ├── 😊 بخير → logged, no parent alert                              │ ║
║  │       ├── 😐 تعبان → logged, gentle parent note                          │ ║
║  │       ├── 😣 زعالان → parent notified: "خالد يشعر بالضيق"                 │ ║
║  │       └── 😰 خايف → parent notified urgently                              │ ║
║  │                                                                          │ ║
║  │  [SOS History available in Monitor tab] SCR-MON-06                       │ ║
║  │  [Sentiment analysis + recommendations] SCR-MON-06b                      │ ║
║  │                                                                          │ ║
║  └──────────────────────────────────────────────────────────────────────────┘ ║
║                                                                              ║
║                    SOS JOURNEY COMPLETE ✓                                    ║
╚══════════════════════════════════════════════════════════════════════════════╝
```

## 9. Critical Pain Points & Design Opportunities

### SOS Pain Point Severity Matrix

| # | Pain Point | Phase | Severity | Impact | Root Cause |
|---|-----------|-------|----------|--------|------------|
| S1 | Parent phone on silent/DND — misses notification | 3 | 🔴 CRITICAL | Child in danger, parent unaware | iOS/Android DND blocks standard notifications |
| S2 | Parent phone is off or dead battery | 3 | 🔴 CRITICAL | No notification received at all | Phone power management |
| S3 | GPS unavailable (indoor, weak signal) | 2 | 🔴 CRITICAL | Location unknown — can't find child | GPS limitations indoors/urban canyons |
| S4 | Child's phone dies during SOS (low battery) | 2-5 | 🔴 CRITICAL | Communication + tracking cut off | Battery depletion during high-GPS-usage SOS mode |
| S5 | Call doesn't connect (network congestion) | 5 | 🟡 HIGH | No voice communication | Cellular network issues |
| S6 | Child can't answer (danger, phone taken, hiding) | 5 | 🟡 HIGH | Father panics with no feedback | Physical danger preventing phone use |
| S7 | Accidental false triggers (pocket, testing) | 1 | 🟠 MEDIUM | Parent anxiety, trust erosion in system | FAB accessibility vs. safety tradeoff |
| S8 | Map tiles slow to load on parent's phone | 3 | 🟠 MEDIUM | Delays assessment, increases anxiety | Map API performance under stress |
| S9 | Audio recording not enabled (privacy opt-in) | 2 | 🟠 MEDIUM | Lost context — father can't hear what's happening | Privacy default vs. safety tradeoff |
| S10 | Mother not connected — single point of failure | 5 | 🟠 MEDIUM | Only one parent receives alert | Mother hasn't completed onboarding |

### Design Opportunities

#### OPSOS1: Critical Push Channel (addresses S1)

The platform must use **critical alerts** (APNs Critical Notifications for iOS, FCM High Priority for Android) that bypass Do Not Disturb and silent mode. This requires:
- iOS: Apple Critical Alert Entitlement (requires Apple approval — justified by safety app)
- Android: FCM with `priority: "high"` + `channel_id: "sos_critical"` with full-screen intent

Additionally: **unique SOS sound** — a distinct, attention-grabbing tone that the brain immediately associates with emergency. Not a standard notification chime. Test with Saudi users for cultural appropriateness.

```
SOS Notification Sound Design:
- Pattern: long-long-long (SOS Morse code: ··· ─── ···)
- Frequency: 800-1200 Hz (carries through pockets/bags)
- Duration: 5 seconds, repeat 3x with 1s gap
- Volume: override system volume to 80% minimum
- Vibration: long-long-long pattern synced with sound
```

#### OPSOS2: Multi-Channel Redundancy (addresses S1, S2)

```
Layer 1: Critical Push (APNs/FCM) — 0s
    ↓ (no delivery in 3s)
Layer 2: SMS with location link — 3s
    ↓ (no delivery in 5s)
Layer 3: Email (if on file) — 5s
    ↓
Layer 4: In-app alert on next app open — persistent
    ↓
Layer 5: Mother's device (parallel, not sequential) — 0s
```

If ALL layers fail, the system logs a "delivery failure" critical event and retries every 30 seconds for 10 minutes.

#### OPSOS3: Fused Location + Fallback (addresses S3)

GPS alone is insufficient in Riyadh's urban environment (high-rises, indoor spaces). The platform must use:
1. **GPS** (primary, 3m accuracy outdoors)
2. **WiFi positioning** (indoor, 10-15m accuracy)
3. **Cell tower triangulation** (fallback, 50-500m accuracy)
4. **Last known location + movement prediction** (if all live methods fail)

Display accuracy to parent: "📍 الموقع دقيق (٣م)" or "📍 الموقع تقريبي (٥٠م)" so parent knows reliability.

#### OPSOS4: Battery Preservation Mode (addresses S4)

When SOS is active, the child's device enters **SOS Power Mode**:
- Screen brightness reduced to 30%
- Non-essential background processes killed
- GPS polling optimized: 10s interval (not 1s) to save battery
- Cellular data limited to SOS stream + call capability
- Other apps frozen (except communication)

Target: extend a 10% battery to last 30+ minutes during SOS.

Alert parent if child battery <15% during active SOS: "⚠️ بطارية خالد منخفضة (١٢٪) — قد ينقطع الاتصال"

#### OPSOS5: No-Answer Escalation Protocol (addresses S5, S6)

```
Call child → no answer (30s)
    ↓
Auto-retry x3 (2s intervals)
    ↓
Still no answer → 
    ├─ Send SMS: "أبوك يحاول يتصل فيك — ارد بسرعة 🆘"
    ├─ Send in-app message to SOS screen
    ├─ Call mother (if connected)
    └─ Show father: "خالد لم يرد" + options:
            [الاتصال مرة أخرى] [إرسال رسالة] [الاتصال بأمه] 
            [الذهاب للموقع] [اتصل بالشرطة 999]
    ↓
If >5 minutes with no contact:
    └─ Auto-suggest: "لم تتمكن من التواصل مع خالد منذ ٥ دقائق. 
                       هل تريد الاتصال بالجهات المختصة؟"
            [اتصل 999]  [متابعة المحاولة]
```

#### OPSOS6: False Trigger Prevention (addresses S7)

- 3-second hold with haptic escalation (already designed)
- Confirmation dialog (already designed)
- **First 24h protection:** extra confirmation "هل أنت في خطر حقيقي؟"
- **Cooldown:** 10-second cooldown after cancelled trigger
- **Pattern detection:** 3+ false triggers in a week → father gets "خالد أرسل ٣ تنبيهات كاذبة هذا الأسبوع — تحقق من الإعدادات"
- **Accidental vs. intentional:** if FAB pressed while phone is in pocket (proximity sensor covered, screen off) → require 5-second hold instead of 3

#### OPSOS7: Pre-Cached Map Tiles (addresses S8)

On child's device: cache map tiles for a 5km radius around each safe zone. On parent's device: cache tiles around all child safe zones. When SOS fires, the map renders instantly from cache while live tiles update.

Text address shows immediately: "حي النرجس، شارع الأمير سلطان، الرياض" — no waiting for map.

#### OPSOS8: Audio Recording Opt-In Design (addresses S9)

During onboarding, father is asked: "هل تريد تفعيل التسجيل الصوتي الطارئ؟ سيتم تسجيل ٣٠ ثانية من المحيط عند إرسال طوارئ."

- Default: OFF (privacy-preserving)
- If enabled: recording only during active SOS, encrypted, deleted after 30 days, accessible only to admin parent
- If disabled: SOS still fully functional — audio is a bonus context layer

#### OPSOS9: Dual-Parent Alert (addresses S10)

SOS always alerts ALL connected parents simultaneously — not sequentially. If mother is connected (limited_admin with SOS alert permission), she receives the same critical notification. This eliminates single-point-of-failure risk.

If mother is NOT yet connected, father's onboarding dashboard should show: "⚠️ أم خالد غير متصلة — تنبيهات الطوارئ تذهب لك فقط. أوصي بتوصيلها."

## 10. Edge Cases & Fallback Flows

### Edge Case 1: Child's Phone Dies During Active SOS

**Scenario:** Khalid triggers SOS with 8% battery. 5 minutes later, phone dies.

```
SOS active, battery 8%
    ↓ (5 min: GPS streaming, screen on)
Battery 0% → phone dies
    ↓
System detects: child device offline (no GPS updates for 60s)
    ↓
Parent's SOS overlay: "⚠️ جوال خالد انطفأ — آخر موقع: [map pin]
    قبل ٢ دقيقة · 🔋 كان ٣٪"
    ↓
Father's options:
    ├─ Last known location is still shown (frozen on map)
    ├─ "اذهب للموقع" → directions to last known GPS
    ├─ Call → goes to voicemail (phone is off)
    └─ If >10 min since last update → suggest calling 999
    ↓
When child's phone recharges and reconnects:
    └─ App opens → "تم حل حالة الطوارئ" if father resolved
       OR "حالة الطوارئ ما زالت نشطة — أبوك ينتظر" if not
```

**Mitigation:** SOS Power Mode (OPSOS4) extends battery life. Parent is warned at <15% battery. Last known location remains pinned on map.

### Edge Case 2: No GPS Available (Indoor / Underground)

**Scenario:** Khalid is in a basement game center with no GPS signal.

```
SOS triggered → GPS unavailable
    ↓
System: WiFi positioning → approximate location (15m accuracy)
    ↓
If WiFi also unavailable:
    ↓
Cell tower triangulation → "تقريبي (٢٠٠م)" — neighborhood level
    ↓
If ALL location methods fail:
    ↓
Parent sees: "⚠️ تعذر تحديد موقع خالد بدقة — آخر موقع معروف:
    حي النرجس (قبل ٢٠ دقيقة)"
    ↓
Fallback: "أرسل رسالة لخالد: أرسل موقعك" → child can manually
share location via Google Maps share link from within the app
```

### Edge Case 3: Child Triggers SOS but Is Not in Danger (False Alarm)

**Scenario:** Khalid is testing the FAB, holds 3 seconds, confirms "نعم، أرسل" to see what happens.

```
SOS dispatched → father panics, calls immediately
    ↓
Khalid: "لا لا، أبوك، كنت أجرب بس!"
    ↓
Father: "لا تجرب هذا! هذا للطارئ بس!"
    ↓
Father resolves: "نعم، خالد بأمان" + notes: "تجريب — تنبيه كاذب"
    ↓
System: logs as false trigger; if 3+ false triggers in a week:
    ↓
Father gets: "خالد أرسل ٣ تنبيهات كاذبة — يفضل الشرح له
    أن الزر للطارئ فقط"
```

**Prevention:** First 24h: extra confirmation dialog. Tutorial requires SOS demo (non-functional). Educational content: "زر الطوارئ للخطر الحقيقي فقط" shown after false trigger.

### Edge Case 4: Both Parents' Phones Unreachable

**Scenario:** Father is on a flight (phone off). Mother's phone is dead. Khalid triggers SOS.

```
SOS dispatched → push to father (undelivered) → push to mother (undelivered)
    ↓
3s timeout → SMS to father (phone off, SMS queued) → SMS to mother (phone off)
    ↓
5s timeout → email (if on file)
    ↓
ALL channels fail → system logs "delivery failure"
    ↓
Child's SOS screen shows: "تم الإرسال — بانتظار الرد..."
    ↓ (no response for 5 min)
Child's screen: "لم يرد أحد بعد. هل تريد الاتصال بأحد آخر؟"
    Options: [اتصل بأبوك] [اتصل بأمك] [اتصل بالجهات المختصة 999]
    ↓
If child calls 999 directly from app → SOS event flags as "authorities contacted"
```

**Design note:** The child's SOS screen should include a "call 999" option after 5 minutes of no parent response — but this must be carefully designed to avoid replacing parent contact as the default.

### Edge Case 5: SOS Triggered While Already on a Call

**Scenario:** Khalid is on the phone with his mother. He triggers SOS while the call is active.

```
Active call with mother → Khalid holds SOS FAB → confirms
    ↓
SOS dispatched → father receives critical notification
    ↓
Mother (on call with Khalid) receives parallel notification on HER screen:
    "🆘 خالد أرسل طوارئ — أنت في مكالمة معه الآن"
    ↓
Mother: "خالد! شو صار؟!" — she's already on the phone, can assess immediately
    ↓
Father calls Khalid → call waiting (Khalid is with mother)
    ↓
Khalid can switch to father's call or mother can relay info to father
```

**Design note:** If a parent is already in a call with the child during SOS, they should receive a visual in-call banner, not just a push notification.

### Edge Case 6: Child Is Moving Rapidly (In a Vehicle)

**Scenario:** Khalid is in a car with someone other than family — moving fast on a highway.

```
SOS triggered → GPS shows rapid movement (80 km/h on طريق الملك فهد)
    ↓
Parent's SOS overlay: "⚠️ خالد يتحرك بسرعة (٨٠ كم/س) — اتجاه: الجنوب
    على طريق الملك فهد"
    ↓
Movement indicator: "🚗 في مركبة" (detected by speed)
    ↓
Father calls → Khalid answers → "أنا مع عمي، رايحين الدمام"
    ↓
Father: OK — resolved. OR Father: "من معك؟!" → concerning
    ↓
If father can't reach child and child is moving away from safe zones:
    └─ System suggests: "خالد يبتعد عن مناطق الآمان — هل تعرف
        من ينقله؟" + option to contact authorities
```

**Design note:** Speed detection should distinguish walking (<6 km/h), running (<15 km/h), and vehicle (>20 km/h). Show movement mode to parent.

### Edge Case 7: SOS Triggered from a Safe Zone

**Scenario:** Khalid is at home (safe zone) and triggers SOS — maybe a home emergency (fire, intruder, medical).

```
SOS triggered → location = Home (safe zone)
    ↓
Parent's notification: "🆘 تنبيه طوارئ — خالد
    📍 في البيت (منطقة آمنة)"
    ↓
Context: child is at a KNOWN location — father knows exactly where
    ↓
If father is NOT home: "خالد في البيت — هل هناك خطر داخل المنزل؟"
    ↓
Father calls → assesses → if home emergency: contact 999 or rush home
    ↓
If father IS home: he can go to Khalid immediately
```

**Design note:** Safe zone SOS should NOT be treated as lower priority — emergencies at home are just as critical. The "safe zone" label provides context, not de-escalation.

### Edge Case 8: Multiple Children Trigger SOS Simultaneously

**Scenario:** Khalid and Saud are together and both trigger SOS (e.g., a fire at school).

```
Khalid SOS → father receives "🆘 خالد — المدرسة"
Saud SOS → father receives "🆘 سعود — المدرسة"
    ↓
Father's phone: two critical notifications within seconds
    ↓
SOS overlay shows BOTH children:
    ┌────────────────────────────────┐
    │ 🆘 طوارئ نشط — طفلان           │
    │                                │
    │ 📍 خالد — المدرسة (٨٠٠م)       │
    │ 📍 سعود — المدرسة (٨٠٠م)       │
    │                                │
    │ [📞 اتصال بخالد]               │
    │ [📞 اتصال بسعود]               │
    │ [🗺️ اذهب للموقع]                │
    └────────────────────────────────┘
    ↓
Single map view shows both children's positions
Father can call either or both
```

**Design note:** The system must handle concurrent SOS events from multiple children without degrading performance.

## 11. SOS Technical Requirements Summary

### Performance Requirements

| Requirement | Target | Hard Limit | Measurement |
|------------|--------|------------|-------------|
| Hold-to-trigger time | 3s | ±0.2s | Timer from touch start to confirmation |
| Confirmation to dispatch | <0.5s | <1s | From tap "نعم" to backend receipt |
| Dispatch to parent notification | <5s | <10s | From dispatch to push received |
| SMS fallback trigger | 3s after push | — | Timer from push dispatch |
| SOS overlay load time | <1s | <3s | From notification tap to overlay rendered |
| GPS update frequency (active SOS) | 10s | 15s max | Interval between location updates |
| Call initiation latency | <1s | <2s | From tap "اتصال" to dialer open |
| Location accuracy (outdoor) | <5m | <15m | GPS accuracy with clear sky |
| Location accuracy (indoor) | <15m | <50m | WiFi + cell fused |

### Platform-Specific Requirements

#### iOS (Parent Device)

| Feature | Requirement |
|---------|------------|
| Critical Alert Entitlement | Required — Apple approval needed for safety app. Justification: "Family safety application for child protection in Saudi Arabia" |
| Push Priority | `interruptive: true`, `sound: sos_critical.wav` (custom), `badge: 🆘` |
| Full-Screen Intent | `UserNotificationType.alert` + `UserNotificationType.sound` |
| DND Override | Requires Critical Alert entitlement — standard notifications will NOT override DND on iOS |
| Background Location | App must have `always` authorization for live tracking during SOS |

#### Android (Child + Parent Device)

| Feature | Requirement |
|---------|------------|
| FCM Priority | `priority: "high"` + `notification_channel_id: "sos_critical"` |
| Full-Screen Intent | `setFullScreenIntent()` — shows over lock screen |
| DND Override | Channel must have `setBypassDnd(true)` + `IMPORTANCE_HIGH` |
| Overlay Permission | `SYSTEM_ALERT_WINDOW` — required for SOS FAB overlay on child device |
| Foreground Service | SOS tracking runs as foreground service with persistent notification |
| Battery Optimization | App must be exempted from battery optimization (prompt user during setup) |
| Device Admin | Required for Kill Switch and preventing SOS app uninstall |

### Data Requirements

| Data Point | Source | When Captured | Privacy |
|-----------|--------|---------------|---------|
| GPS coordinates | Child device | At trigger + every 10s during active SOS | Emergency-only; deleted after 30 days post-resolution |
| Battery level | Child device | At trigger + every 60s | Emergency-only |
| Device status | Child device | At trigger | Emergency-only |
| Ambient audio | Child device (if enabled) | 30s from trigger | Encrypted; opt-in only; deleted after 30 days |
| Call metadata | Phone system | During call | Duration + timestamp only; NO call recording |
| Location history trail | Backend | During active SOS | Deleted after 90 days |
| Incident notes | Father input | At resolution | Retained in SOS history (admin only) |
| Post-SOS mood | Child input | 1h post-resolution | Retained in SOS history |
| Sentiment analysis | AI (backend) | Post-call | Derived data; admin only; not shown to child |

### Saudi-Specific Technical Considerations

| Consideration | Detail |
|--------------|--------|
| SMS Gateway | Must support STC, Mobily, Zain for SMS fallback |
| Emergency Number | 999 (Saudi police); 997 (ambulance); 998 (fire) — app should offer all three |
| Arabic Address Resolution | Reverse geocoding must return Arabic street/neighborhood names: "حي النرجس، شارع الأمير سلطان" |
| Hijri Timestamp | SOS events logged in both Hijri and Gregorian |
| Prayer Time Awareness | SOS notifications override prayer time "do not disturb" settings (if app has prayer-time DND) |
| Map Provider | Google Maps primary (best Saudi coverage); Apple Maps fallback on iOS |
| Network Resilience | Must work on 3G/4G/5G and WiFi; Saudi mobile networks generally reliable but underground/indoor gaps exist |

## 12. SOS Success Metrics & SLAs

### Primary SLA Dashboard

| SLA | Target | Measurement | Alert If |
|-----|--------|-------------|---------|
| Trigger → Notification received | <5s | P50: time from child confirmation to parent device receipt | P50 > 8s |
| Notification → SOS overlay loaded | <3s | P50: time from notification tap to overlay rendered | P50 > 5s |
| GPS accuracy at trigger | <5m outdoor | P90 accuracy in meters with clear sky | P90 > 15m |
| Live tracking uptime during SOS | 100% | Percentage of expected 10s updates actually received | Any missed update |
| Call initiation | <1s | Time from "اتصال" tap to dialer open | > 2s |
| Push delivery rate | >99% | Percentage of SOS pushes delivered to at least one parent device | < 95% |
| SMS fallback delivery rate | >95% | Percentage of SMS fallbacks delivered within 10s | < 90% |

### Operational Metrics

| Metric | Target | Measurement Period |
|--------|--------|-------------------|
| False trigger rate | <5% of all SOS events | Monthly |
| Average SOS resolution time | <10 min | Monthly median |
| SOS → call answered rate | >80% | Monthly |
| SOS → parent responds within 30s | >90% | Monthly |
| Post-SOS child wellbeing check-in response rate | >60% | Monthly |
| Concurrent SOS handling (multiple children) | 100% success | Per event |
| Audio recording availability (when enabled) | >95% | Per event |
| Dual-parent delivery rate (when both connected) | >99% | Per event |

### Trust & Satisfaction Metrics

| Metric | Target | Measurement |
|--------|--------|-------------|
| Parent confidence in SOS ("I trust the SOS will reach me") | >4.5/5 | Quarterly survey |
| Child understanding of SOS ("I know how to use the emergency button") | >4.0/5 | Post-onboarding survey |
| Parent response satisfaction ("I had enough context to act") | >4.5/5 | Post-SOS micro-survey |
| False trigger annoyance ("I get too many false alarms") | <2.0/5 (lower is better) | Monthly |
| SOS feature usage awareness (% of parents who know how SOS works) | >90% | Quarterly |

### Incident Review Metrics

| Metric | Target | Notes |
|--------|--------|-------|
| Real emergencies successfully resolved | 100% | Every genuine SOS must result in child safety |
| Incidents requiring authority contact (999) | Tracked, no target | Contextual — some situations need police |
| Incidents where parent couldn't reach child | Tracked | Investigate root cause (network, battery, location) |
| Time from SOS to physical parent arrival | <15 min (urban) | Riyadh-specific; rural areas may differ |
| Repeat SOS from same child within 30 days | Tracked | May indicate ongoing situation needing intervention |

### SLA Monitoring Architecture

```
SOS EVENT TRIGGERED
    │
    ▼
┌──────────────────────────────────────────────┐
│         SOS SLA MONITORING DASHBOARD          │
├──────────────────────────────────────────────┤
│                                              │
│  Real-time:                                  │
│  ├─ Trigger → Dispatch latency:    0.3s ✓   │
│  ├─ Dispatch → Push received:      2.1s ✓   │
│  ├─ Push → Overlay loaded:         1.4s ✓   │
│  ├─ GPS accuracy:                  4m ✓     │
│  ├─ Live tracking:                 active   │
│  └─ Call status:                   ringing  │
│                                              │
│  If ANY metric exceeds SLA:                  │
│  └─ Alert engineering team (PagerDuty)       │
│     "SOS SLA breach: push delivery 12s"      │
│                                              │
│  Post-event:                                 │
│  └─ Full timeline recorded for audit         │
│     and SLA compliance reporting             │
└──────────────────────────────────────────────┘
```

---

*Related documents:*
- [Persona Journey Maps](../01_PERSONA_JOURNEY_MAPS.md)
- [Onboarding Journey](01_ONBOARDING_JOURNEY.md)
- [Daily Life Journeys](03_DAILY_LIFE_JOURNEYS.md)
