---
title: "User/Role Architecture"
tags: [roles, permissions, architecture, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification
---

# User/Role Architecture

---

## 1. Roles

| Role | ID | Description | Cannot |
|------|----|-------------|--------|
| Father | `admin` | Family owner — all permissions | Be removed or demoted |
| Mother | `limited_admin` | Partner — permissions opened by father | Access father-only operations regardless of permissions |
| Child | `child` | Subject to monitoring | Stop location/activity sharing; delete app; logout from family |

---

## 2. Permission Model

### 2.1 Permission Layers

```
Role (RBAC) → mother_permissions (ABAC override) → Screen visibility → Action authorization
```

- **RBAC**: Role determines base permission set
- **mother_permissions**: Father can open/close specific capabilities for mother
- **Screen visibility**: IA hides/shows screens based on role + permissions
- **Action authorization**: Backend RLS + Firestore Security Rules enforce at data level

### 2.2 Father-Only Operations (hard-hidden from Mother)

| Screen | Operation |
|--------|-----------|
| SCR-PAR-06 | Manage safe zones |
| SCR-PAR-07 | Manage app rules |
| SCR-PAR-08 | Manage web filter |
| SCR-PAR-11 | Kill Switch |
| SCR-PAR-12 | Anti-bypass |
| SCR-ADM-02 | Manage members |
| SCR-ADM-03 | Manage devices + sensitive permissions |
| SCR-ADM-04 | Subscription + billing |
| SCR-ADM-07 | Child privacy management |
| SCR-COM-11 | Lock conversation |

### 2.3 Mother Permissions Gates (`mother_permissions`)

| Permission Key | Default | When Closed |
|----------------|---------|-------------|
| `monitoring` | Open | PAR-01 hub + deep monitor links hidden |
| `sos_receive` | Open | COM-07 receive mode hidden |
| `content_alerts` | Open | PAR-09 + Needs-me alert cards hidden |
| `school_time_control` | Open | PAR-10 toggles hidden |
| `location_view` | Open | PAR-05 hidden |

> Mother **never** gains PAR-06/07/08/11/12 or ADM-02/03/04/07 by permission — those stay father-only.

### 2.4 Child Restrictions

| Action | Status |
|--------|--------|
| Stop location sharing | Blocked (system-level enforcement via FusedLocationProvider) |
| Stop activity monitoring | Blocked |
| Delete app | Prevented by Anti-bypass |
| Logout from family | Blocked while parents active |
| Change monitoring settings | Blocked |
| See parent dashboard | Blocked |
| See content alerts (29 categories) | Blocked |
| See siblings' data | Blocked (privacy) |
| Create sub-groups | Blocked |
| Lock conversations | Blocked |

---

## 3. Permission Matrix (P0 — Key Operations)

### Communications

| Operation | Father | Mother | Child |
|-----------|--------|--------|-------|
| Create family chat | ✅ | ✅ (participate) | ✅ (participate, mandatory) |
| Create 1:1 chat | ✅ | ✅ | ✅ |
| Create sub-group | ✅ | ❌ | ❌ |
| Send message | ✅ | ✅ | ✅ |
| Voice message + transcription | ✅ | ✅ | ✅ |
| Translation | ✅ | ✅ | ✅ |
| Lock chat | ✅ | ❌ | ❌ (subject) |
| Read receipts | ✅ | ✅ | ✅ |
| Calendar event | ✅ | ✅ | ❌ (view only) |
| Task list | ✅ | ✅ | ✅ (check off only) |
| Shopping list | ✅ | ✅ | ✅ (add items) |
| Live location | ✅ (receive) | ✅ (receive) | 🔄 (mandatory broadcast) |
| SOS | ✅ (receive) | ✅ (receive **P**) | ✅ (launch) |

### Monitoring

| Operation | Father | Mother | Child |
|-----------|--------|--------|-------|
| Set screen time limit | ✅ | ⚠️ (if opened) | ❌ |
| Instant device lock | ✅ | ⚠️ (if opened) | ❌ (subject) |
| Block/allow apps | ✅ | ❌ | ❌ |
| Kill Switch | ✅ | ❌ | ❌ (subject) |
| School Time | ✅ | ⚠️ (if opened) | ❌ (subject) |
| GPS tracking | ✅ | ✅ (view) | ❌ (mandatory) |
| Safe zones | ✅ | ❌ | ❌ |
| Web filter | ✅ | ❌ | ❌ |
| Content alerts (29) | ✅ | ✅ (if opened) | ❌ |
| Anti-bypass | ✅ | ❌ | ❌ (subject) |
| Request extra time | ❌ | ❌ | ✅ |

### Education

| Operation | Father | Mother | Child |
|-----------|--------|--------|-------|
| Add subject/lesson | ✅ | ✅ | ❌ |
| Create assignment/quiz | ✅ | ✅ | ❌ |
| Submit assignment | ❌ | ❌ | ✅ |
| Take quiz | ❌ | ❌ | ✅ |
| AI grading | 👁️ (results) | 👁️ (results) | ✅ (sees own) |
| Points/badges | 🔄 (auto-grant) | 🔄 (auto-grant) | ✅ (earns) |
| Focus Mode | ✅ (activate) | ✅ (activate) | ✅ (request) |
| Quran recitation | ❌ | ❌ | ✅ |
| AI Tutor | ✅ | ✅ | ✅ |
| Placement test | ✅ (request + view) | ✅ (request + view) | ✅ (takes) |
| Adaptive learning | 👁️ (progress) | 👁️ (progress) | ✅ (performs) |
| XP + levels | 👁️ | 👁️ | ✅ (earns) |

### AI

| Operation | Father | Mother | Child |
|-----------|--------|--------|-------|
| AI Assistant | ✅ | ✅ | ✅ |
| Sentiment analysis | ✅ (family) | ✅ | ❌ |
| AI Tutor | ✅ | ✅ | ✅ |
| Auto-grading | ✅ (results) | ✅ (results) | ✅ (own) |
| Recommendations | ✅ (children's) | ✅ | ✅ (own) |
| Quran recitation AI | ❌ | ❌ | ✅ |

### Administration

| Operation | Father | Mother | Child |
|-----------|--------|--------|-------|
| Create family | ✅ | ❌ | ❌ |
| Invite members | ✅ | ❌ | ❌ |
| Manage roles | ✅ | ❌ | ❌ |
| Manage devices | ✅ | ❌ | ❌ |
| Subscription + billing | ✅ | ❌ | ❌ |
| Mother permissions | ✅ (manages) | ❌ (subject) | ❌ |
| Notifications | ✅ (family) | ✅ (self) | ✅ (self) |
| Settings | ✅ | ✅ | ✅ (limited) |
| Privacy | ✅ (sets child) | ⚠️ | ✅ (sees what's shared) |
| Export + delete | ✅ | ✅ (self) | ❌ |
| Today Dashboard | ✅ | ✅ | ❌ |

---

## 4. For Each Operation: Authorization Map

| Question | Answer |
|----------|--------|
| Who can initiate? | See matrix above |
| Who can see? | Screen visibility per role + permissions |
| Who can approve? | Father for all sensitive operations; Mother if opened |
| Who can modify? | Father for all rules; Mother for assignments/tasks/calendar; Child for own profile |
| Who can revoke? | Father only (members, permissions, rules) |
| Who can override? | Father can override any action except own role change |
| Who can audit? | Father (audit log); system (all sensitive actions logged) |
