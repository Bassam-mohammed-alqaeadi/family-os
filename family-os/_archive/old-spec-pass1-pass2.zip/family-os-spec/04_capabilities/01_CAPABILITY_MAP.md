---
title: "Family Platform Capability Map"
tags: [capabilities, map, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification
---

# Family Platform Capability Map

> All capabilities of the platform, organized by layer. Each capability maps to one or more Domains and services.

---

## Capability Layers

```
┌─────────────────────────────────────────────────────────┐
│                    AI Intelligence                        │
├─────────────────────────────────────────────────────────┤
│          Education & Growth │ Safety & Monitoring        │
├─────────────────────────────────────────────────────────┤
│                    Communications                        │
├─────────────────────────────────────────────────────────┤
│    Family & Identity │ Administration & Commerce        │
├─────────────────────────────────────────────────────────┤
│    Family Context (cross-cutting projection)             │
├─────────────────────────────────────────────────────────┤
│    Security & Trust (cross-cutting foundation)           │
└─────────────────────────────────────────────────────────┘
```

---

## 1. Family & Identity Capabilities

| Capability | Domain | P0 Services | Status |
|-----------|--------|-------------|--------|
| Family creation | Family & Identity | S-ADM-001 | Essential |
| Member invitation | Family & Identity | S-ADM-002/003 | Essential |
| Role management | Family & Identity | S-ADM-004 | Essential |
| Profile management | Family & Identity | S-ADM-006 | Essential |
| Device registration | Family & Identity | S-ADM-009/010/013 | Essential |
| Member limits (6/4/1) | Family & Identity | S-ADM-006 | Essential |
| Mother permissions | Family & Identity | S-ADM-029→S-ADM-028 | Essential |
| Transfer ownership | Family & Identity | — | P1 |
| Remove member | Family & Identity | — | P1 |
| Leave family | Family & Identity | — | P1 |

---

## 2. Communications Capabilities

| Capability | Domain | P0 Services | Status |
|-----------|--------|-------------|--------|
| Family group chat | Communications | S-COM-001 | Essential |
| 1:1 private chat | Communications | S-COM-002 | Essential |
| Sub-group chat | Communications | S-COM-003 | Essential |
| Message reply | Communications | S-COM-004 | Essential |
| Voice messages + transcription | Communications | S-COM-041 | Essential |
| Read receipts | Communications | S-COM-011 | Essential |
| Media sharing (images/files/audio) | Communications | S-COM-010/025/029 | Essential |
| Quick reactions | Communications | S-COM-048 | Essential |
| Real-time translation | Communications | S-COM-044 | Essential |
| Chat lock (father-only) | Communications | S-COM-052 | Essential |
| Voice/Video calls (LiveKit) | Communications | S-COM-006 | **P0** ¹ |
| Family calendar (Hijri+Gregorian) | Communications | S-COM-030/031 | Essential |
| Task list | Communications | S-COM-032 | Essential |
| Shopping list | Communications | S-COM-033 | Essential |
| Live location broadcast | Communications | S-COM-035 | Essential |
| Arrival/exit alerts | Communications | S-COM-036 | Essential |
| SOS | Communications | S-COM-039 | Essential |
| Polls | Communications | — | P1 |
| Scheduled messages | Communications | — | P1 |
| Meal planning | Communications | — | P1 |
| Family stories | Communications | — | P1 |
| ChoreAI | Communications | — | P1 |
| Temporary messages | Communications | — | P1 |
| Chat folders | Communications | — | P2 |
| Group calls | Communications | — | P2 |

---

## 3. Safety & Monitoring Capabilities

| Capability | Domain | P0 Services | Status |
|-----------|--------|-------------|--------|
| Screen time limits | Safety | S-PAR-001/002/003 | Essential |
| Instant device lock | Safety | S-PAR-005 | Essential |
| Bedtime schedule | Safety | S-PAR-006 | Essential |
| Extra time request | Safety | S-PAR-009 | Essential |
| Live GPS tracking | Safety | S-PAR-011/012 | Essential |
| Safe zones (Geofences) | Safety | S-PAR-014 | Essential |
| App blocking/rules | Safety | S-PAR-015/016 | Essential |
| Web filtering | Safety | S-PAR-017/018 | Essential |
| Content alerts (29 categories) | Safety | S-PAR-021/045 | Essential |
| Arrival/exit alerts | Safety | S-PAR-032 | Essential |
| Focus Mode display | Safety | S-PAR-034 | Essential |
| Anti-bypass protection | Safety | S-PAR-038 | Essential |
| Kill Switch (internet off) | Safety | S-PAR-041 | Essential |
| School Time | Safety | S-PAR-052 | Essential |
| Contact Watchlist | Safety | — | P1 |
| Sexting prevention | Safety | — | P1 |
| YouTube enhanced | Safety | — | P1 |
| Gaming alerts | Safety | — | P1 |
| App approval workflow | Safety | — | P1 |
| Slang detection | Safety | — | P1 |
| Driving report | Safety | — | P1 |
| Frequent places | Safety | — | P1 |
| Stealth browsing | Safety | — | P1 |
| Advanced analytics | Safety | — | P1 |
| Screen viewer | Safety | — | P2 |
| Remote photos | Safety | — | P2 |
| One-way audio | Safety | — | P2 |
| Sensitive photo detection | Safety | — | P2 |
| Router filtering | Safety | — | P2 |
| Peer benchmark | Safety | — | P3 |

---

## 4. Education & Growth Capabilities

| Capability | Domain | P0 Services | Status |
|-----------|--------|-------------|--------|
| Subject management | Education | S-EDU-001/002 | Essential |
| Lesson management | Education | S-EDU-003/004 | Essential |
| Assignment creation/submission | Education | S-EDU-009/010/011 | Essential |
| AI auto-grading | Education | S-EDU-013 | Essential |
| Manual grading | Education | S-EDU-014 | Essential |
| Quiz system | Education | S-EDU-017/019/020 | Essential |
| Progress tracking | Education | S-EDU-024 | Essential |
| Points + badges | Education | S-EDU-028/029 | Essential |
| Focus Mode | Education | S-EDU-034/035 | Essential |
| Quran memorization | Education | S-EDU-038/039 | Essential |
| AI Tutor | Education | S-EDU-046 | Essential |
| Adaptive learning path | Education | S-EDU-047 | Essential |
| Graded adaptive exercises | Education | S-EDU-051 | Essential |
| Placement test | Education | S-EDU-052 | Essential |
| XP + levels | Education | S-EDU-058 | Essential |
| Daily challenges | Education | — | P1 |
| Visual learning paths | Education | — | P1 |
| Skill recommendations | Education | — | P1 |
| Creative writing | Education | — | P1 |
| Video library | Education | — | P1 |
| Skill gap reports | Education | — | P1 |
| Interactive stories | Education | — | P2 |
| Leaderboards | Education | — | P2 |

---

## 5. AI Intelligence Capabilities

| Capability | Domain | P0 Services | Status |
|-----------|--------|-------------|--------|
| AI Orchestrator (rate limit + RAG + safety) | AI | (infrastructure) | Essential |
| Family assistant chat | AI | AI-001 | Essential |
| Sentiment analysis (messages) | AI | AI-002 | Essential |
| Private tutor | AI | AI-003 | Essential |
| Auto assignment grading | AI | AI-004 | Essential |
| Educational recommendations | AI | AI-007/020 | Essential |
| Quran recitation analysis | AI | AI-008 | Essential |
| Image analysis | AI | — | P1 |
| Voice conversation with AI | AI | — | P1 |
| Behavior analysis + reports | AI | — | P1 |
| Sensitive content detection | AI | — | P1 |
| AI lesson generation | AI | — | P1 |
| Chat summarization | AI | — | P1 |
| Flashcard generation | AI | — | P1 |
| Family-context RAG | AI | — | P2 |

---

## 6. Administration & Commerce Capabilities

| Capability | Domain | P0 Services | Status |
|-----------|--------|-------------|--------|
| Premium subscription (49 SAR) | Administration | S-ADM-014/016 | Essential |
| 14-day trial | Administration | S-ADM-038 | Essential |
| Paywall | Administration | S-ADM-016 | Essential |
| Notification preferences | Administration | S-ADM-020/022/023 | Essential |
| Family settings | Administration | S-ADM-026 | Essential |
| User settings | Administration | S-ADM-027 | Essential |
| Privacy settings | Administration | S-ADM-028 | Essential |
| Data export + deletion | Administration | S-ADM-029 | Essential |
| Today Dashboard | Administration | S-ADM-033 | Essential |
| School schedule (Hijri) | Administration | S-ADM-035 | Essential |
| Language (AR/EN + RTL/LTR) | Administration | S-ADM-027 | Essential |
| Quiet hours | Administration | — | P1 |
| Weekly reports | Administration | — | P1 |
| Meal plan management | Administration | — | P1 |
| Family album | Administration | — | P1 |
| Billing history | Administration | — | P1 |

---

## 7. Cross-Cutting Capabilities

### Family Context

| Capability | Status |
|-----------|--------|
| Real-time family state projection | Essential |
| Member status aggregation | Essential |
| Policy aggregation | Essential |
| Event stream aggregation | Essential |
| Alert aggregation | Essential |

### Security & Trust

| Capability | Status |
|-----------|--------|
| Authentication (email/password + biometric) | Essential |
| Authorization (RBAC + mother_permissions) | Essential |
| Data encryption (TLS 1.3 + AES-256) | Essential |
| Audit logging | Essential |
| Anti-bypass (tamper resistance) | Essential |
| Rate limiting | Essential |
| Data retention + deletion | Essential |
| Data export | Essential |
| Emergency access (break-glass) | Essential |
| Permission denial recovery | Essential |
| Session management | Essential |
| Device trust | Essential |

### Offline & Resilience

| Capability | Status |
|-----------|--------|
| Offline-first local database (Drift) | Essential |
| Sync queue + conflict resolution | Essential |
| Degraded mode (feature unavailable offline) | Essential |
| Retry with exponential backoff | Essential |
| Event ordering guarantees | Essential |
| Duplicate prevention (idempotency) | Essential |

### Observability & Operations

| Capability | Status |
|-----------|--------|
| Crash reporting | Strongly Recommended |
| Performance monitoring | Strongly Recommended |
| Feature flags | Strongly Recommended |
| A/B testing | Strongly Recommended |
| Push notification analytics | Strongly Recommended |
| AI cost tracking | Essential |

---

## 8. Capability Coverage Summary

| Layer | Essential (P0) | P1 | P2 | P3 | Total |
|-------|----------------|----|----|----|-------|
| Family & Identity | 8 | 3 | — | — | 11 |
| Communications | 20 | 7 | 2 | 1 | 30 |
| Safety & Monitoring | 20 | 11 | 5 | 1 | 37 |
| Education & Growth | 24 | 7 | 2 | — | 33 |
| AI Intelligence | 7 | 7 | 1 | — | 15 |
| Administration & Commerce | 12 | 5 | — | — | 17 |
| Security & Trust | 12 | — | — | — | 12 |
| Offline & Resilience | 6 | — | — | — | 6 |
| Observability | 1 | 4 | — | — | 5 |
| **Total** | **91** | **44** | **10** | **2** | **166** |

---

¹ **Corrected 2026-09-14 (reconciliation).** This row previously read **P1**, contradicting `02_requirements/01_REQUIREMENTS_EXTRACTION.md:38` (`S-COM-006 | P0 | LiveKit`). The frozen requirement governs, and the owner reconfirmed full LiveKit VoIP inside P0. The SOS workflow depends on it directly (`07_behavioral_architecture/01_WORKFLOWS_AND_EVENTS.md:234` — auto-call the father after 5s), so a P1 classification would have deferred a dependency of a P0 safety path.
