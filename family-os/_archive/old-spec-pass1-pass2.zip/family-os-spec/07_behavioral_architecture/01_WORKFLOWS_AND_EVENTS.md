---
title: "Behavioral Architecture — Workflows, State Machines & Events"
tags: [behavioral, workflows, events, state, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification
---

# Behavioral Architecture

---

## 1. Unified Family Event Model

Every significant action in the platform produces an event. Events flow through the system enabling cross-domain reactivity.

### 1.1 Event Structure

```
Event {
  event_id: UUID
  event_name: string
  producer: string (domain)
  timestamp: ISO8601
  family_id: UUID
  actor_id: UUID
  payload: jsonb
  security_classification: public|internal|confidential|restricted
  offline_behavior: queue|drop|local_only
  retry_behavior: exponential_backoff|max_3
  idempotency_key: UUID
  audit_required: boolean
}
```

### 1.2 Event Catalog (P0)

#### Family & Identity Events

| Event | Producer | Consumers | Offline | Audit |
|-------|---------|-----------|---------|-------|
| `family.created` | Family & Identity | Comms (auto chat), Admin (subscription), Notifications | Queue | ✅ |
| `member.invited` | Family & Identity | Notifications (FCM) | Queue | ✅ |
| `member.joined` | Family & Identity | Comms (add to chat), Safety (start monitoring), Notifications | Queue | ✅ |
| `member.role_changed` | Family & Identity | All domains (re-evaluate permissions) | Queue | ✅ |
| `device.registered` | Family & Identity | Safety (link monitoring) | Queue | ✅ |
| `device.linked` | Family & Identity | Safety (activate monitoring), Notifications | Queue | ✅ |

#### Communications Events

| Event | Producer | Consumers | Offline | Audit |
|-------|---------|-----------|---------|-------|
| `message.sent` | Comms | AI (sentiment), Notifications (FCM) | Queue | ❌ |
| `message.read` | Comms | — | Queue | ❌ |
| `voice.transcribed` | Comms (via AI) | — | Drop | ❌ |
| `message.translated` | Comms (via AI) | — | Drop | ❌ |
| `event.created` | Comms | Notifications (reminder) | Queue | ❌ |
| `task.created` | Comms | Notifications (assignee) | Queue | ❌ |
| `task.completed` | Comms | Notifications (creator) | Queue | ❌ |
| `sos.activated` | Comms | Safety (live location), Notifications (urgent FCM), All (system message) | Queue (urgent priority) | ✅ |
| `sos.resolved` | Comms | Safety (stop location), Notifications | Queue | ✅ |
| `location.broadcast` | Comms | Safety (geofence check) | Queue (batched) | ❌ |

#### Safety & Monitoring Events

| Event | Producer | Consumers | Offline | Audit |
|-------|---------|-----------|---------|-------|
| `screentime.limit_reached` | Safety | Comms (system message), Notifications | Local | ✅ |
| `device.locked` | Safety | Education (pause learning), Notifications | Local | ✅ |
| `device.unlocked` | Safety | Education (resume), Notifications | Queue | ✅ |
| `app.blocked` | Safety | Notifications | Local | ✅ |
| `web.blocked` | Safety | — | Local | ❌ |
| `geofence.entered` | Safety | Comms (system message), Notifications | Queue | ❌ |
| `geofence.exited` | Safety | Comms (system message), Notifications | Queue | ❌ |
| `content.alert_triggered` | Safety (via AI) | Notifications (parent), Admin (Today Dashboard) | Queue | ✅ |
| `killswitch.activated` | Safety | Notifications, Comms (system message) | Queue | ✅ |
| `killswitch.deactivated` | Safety | Notifications | Queue | ✅ |
| `antibypass.attempt_detected` | Safety | Notifications (urgent FCM to father) | Queue (urgent) | ✅ |
| `schooltime.activated` | Safety | Notifications, Comms (system message) | Local | ✅ |
| `schooltime.deactivated` | Safety | Notifications | Local | ✅ |
| `permission.requested` | Safety | Notifications (parent), Admin (Needs-me) | Queue | ✅ |
| `permission.approved` | Safety | Notifications (child), Comms (system message) | Queue | ✅ |
| `permission.denied` | Safety | Notifications (child) | Queue | ✅ |

#### Education Events

| Event | Producer | Consumers | Offline | Audit |
|-------|---------|-----------|---------|-------|
| `lesson.completed` | Education | AI (recommendations), Notifications | Queue | ❌ |
| `assignment.submitted` | Education | AI (auto-grading), Notifications (parent) | Queue | ❌ |
| `assignment.graded` | Education (via AI) | Notifications (child + parent), Comms (system message) | Queue | ❌ |
| `quiz.completed` | Education | Notifications, AI (recommendations) | Queue | ❌ |
| `points.earned` | Education | Notifications (child) | Local | ❌ |
| `badge.earned` | Education | Notifications (child + parent) | Local | ❌ |
| `focus.activated` | Education | Safety (block apps via app_rules) | Local | ❌ |
| `focus.deactivated` | Education | Safety (unblock apps) | Local | ❌ |
| `quran.recited` | Education | AI (recitation analysis) | Queue | ❌ |
| `quran.verified` | Education (via AI) | Notifications (parent) | Queue | ❌ |
| `placement.completed` | Education | AI (learning path), Notifications | Queue | ❌ |
| `level.up` | Education | Notifications (child + parent), Comms (system message) | Local | ❌ |
| `xp.earned` | Education | — | Local | ❌ |

#### AI Events

| Event | Producer | Consumers | Offline | Audit |
|-------|---------|-----------|---------|-------|
| `ai.response_generated` | AI | — | Drop | ❌ |
| `ai.sentiment_analyzed` | AI | Safety (if bullying_risk), Notifications | Queue | ❌ |
| `ai.recommendation_generated` | AI | Education (display) | Drop | ❌ |
| `ai.recitation_analyzed` | AI | Education (update progress) | Queue | ❌ |
| `ai.cost_incurred` | AI | Admin (cost tracking) | Drop | ✅ |
| `ai.safety_triggered` | AI | Notifications (if critical) | Queue | ✅ |

#### Administration Events

| Event | Producer | Consumers | Offline | Audit |
|-------|---------|-----------|---------|-------|
| `subscription.activated` | Admin | All (enable features) | Queue | ✅ |
| `subscription.canceled` | Admin | All (restrict features), Notifications | Queue | ✅ |
| `subscription.expired` | Admin | All (revert to free), Notifications | Queue | ✅ |
| `trial.started` | Admin | Notifications, All (enable all features) | Queue | ✅ |
| `trial.expiring` | Admin | Notifications (3-day warning) | Queue | ✅ |
| `trial.expired` | Admin | All (restrict), Notifications | Queue | ✅ |
| `notification.sent` | Admin | FCM | Queue | ❌ |
| `settings.changed` | Admin | All (apply settings) | Local | ❌ |
| `language.changed` | Admin | All (reload i18n) | Local | ❌ |
| `data.exported` | Admin | — | Requires online | ✅ |
| `data.deleted` | Admin | All (cleanup) | Requires online | ✅ |

---

## 2. State Machines (P0)

### 2.1 Message Lifecycle

```
[*] → Scheduled (if scheduled_at set)
[*] → Sent (if immediate)
Scheduled → Sent (cron trigger) | Cancelled (user cancels)
Sent → Delivered (Firestore listener)
Delivered → Read (POST /messages/{id}/read)
Read/Sent/Delivered → Deleted (soft delete)
```

### 2.2 Device Lock

```
Unlocked → Locked (father locks | screen time exceeded | bedtime)
Locked → Unlocked (father unlocks | extra time approved)
Locked → PermissionRequested (child requests time)
PermissionRequested → Unlocked (father approves) | Locked (deny | 1hr timeout)
```

### 2.3 Assignment

```
NotStarted → InProgress (child starts)
InProgress → Submitted (child submits)
Submitted → Graded (AI or father) | Returned (father returns)
Returned → InProgress (child resubmits)
```

### 2.4 Permission Request

```
Pending → Approved (father) | Denied (father) | Expired (1hr timeout)
```

### 2.5 Invitation

```
Pending → Accepted | Declined | Expired (7 days)
```

### 2.6 Subscription

```
Free → Trialing (POST /subscriptions)
Trialing → Active (trial ends + charge) | Expired (cancelled before end)
Active → Canceled (POST cancel) | PastDue (charge fails)
Canceled → Expired (end of billing cycle)
PastDue → Active (payment updated) | Expired (7-day grace)
Expired → Free (revert to free tier)
```

### 2.7 Free Trial

```
[*] → تجربة_نشطة (14 days, all features)
تجربة_نشطة → تجربة_قاربت_الانتهاء (Day 11 — reminder)
تجربة_قاربت_الانتهاء → مدفوع (subscribe) | تجربة_منتهية (Day 14)
تجربة_منتهية → مدفوع (subscribe) | مجاني (free plan, limited)
```

### 2.8 XP & Level

| Level | Name | XP Range |
|-------|------|----------|
| 1 | مبتدئ | 0–499 |
| 2 | متعلم | 500–1,999 |
| 3 | مجتهد | 2,000–4,999 |
| 4 | متفوق | 5,000–9,999 |
| 5 | خبير | 10,000–24,999 |
| 6 | ماجستير | 25,000+ |

### 2.9 AI Recommendation

```
مُولّدة → معروضة (displayed)
معروضة → مقبولة (accepted) | مرفوضة (dismissed) | منتهية_الصلاحية (7 days)
مقبولة → مكتملة (completed, +XP) | متروكة (abandoned)
متروكة → re-recommended later
```

### 2.10 SOS Emergency

```
Idle → Activated (child hold 3s)
Activated → Calling (auto-call after 5s)
Calling → Connected (father answers) | Missed (no answer → retry)
Connected → Resolved (father marks "arrived safely")
Missed → Calling (retry) | Resolved (father cancels)
```

---

## 3. Key Workflows (P0)

### 3.1 SOS Flow

1. Child holds SOS button 3s → vibration + confirmation
2. GPS acquired → `POST /api/emergency/sos`
3. `INSERT emergency_events` → FCM urgent to parents
4. System message in family chat
5. Wait 5s → auto-call father (LiveKit)
6. Father sees live location on map (`SCR-COM-07` receive mode)
7. Father answers or retries
8. Father marks "arrived safely" → event resolved

### 3.2 Content Alert Flow (29 Categories)

1. Child types text in WhatsApp/TikTok/etc.
2. AccessibilityService captures text → `POST /api/content-scan`
3. Gemini classifies against 29 categories
4. If dangerous: `INSERT content_alerts` → FCM to parent
5. Parent sees: category + severity + recommendation (**NOT full text**)
6. Parent acts: talk to child / block app / dismiss

### 3.3 Focus Mode Flow

1. Child activates Focus Mode (`SCR-EDU-09`)
2. Education → Safety: trigger `app_rules` blocking
3. Safety blocks entertainment/social/games, allows education + parent calls
4. Timer runs → child studies
5. Timer ends → +10 XP (if ≥80% duration) → Safety unblocks apps
6. Child can emergency pause (10 min max)

### 3.4 Assignment + AI Grading Flow

1. Parent creates assignment (`SCR-EDU-05`)
2. Child sees assignment on `SCR-EDU-01`
3. Child completes and submits
4. `INSERT assignment_submissions` → FCM to parent
5. AI-004 grades: Gemini analyzes answers → grade + feedback (<10s)
6. `UPDATE grade + feedback` → calculate points → update streak → check badges
7. FCM to child + parent → display result

### 3.5 Onboarding Flow

1. `SCR-SHR-01` Splash → `SCR-SHR-02` Login (email/password)
2. First login → `SCR-SHR-04` Create family (father) or accept invitation
3. Permission flow: UsageStats → Location → Accessibility → Notifications → Overlay
4. Each denial → `UX-PERM-DENIED` (explanation + "Open Settings")
5. Father: → `SCR-ADM-09` (Today Dashboard)
6. Child: → `SCR-EDU-01` (Learning Home)

### 3.6 Subscription + Trial Flow

1. New family → auto-start 14-day trial (all features)
2. Day 11 → FCM reminder "3 days left"
3. Day 14 → trial expires → features locked
4. Father opens `SCR-ADM-04` Paywall → sees 49 SAR/month
5. Google Play Billing → payment → subscription active
6. If payment fails → 7-day grace → revert to free

### 3.7 Kill Switch Flow

1. Father presses "Pause Internet" (`SCR-PAR-11`)
2. Select duration (15/30/45/60 min or manual)
3. `POST /api/internet/pause` → `INSERT internet_pause_events`
4. FCM to child → AccessibilityService blocks internet apps
5. Child sees "Internet paused" screen
6. Duration ends → auto-resume OR father presses "Resume"

### 3.8 Anti-Bypass Flow

1. AccessibilityService + DevicePolicyManager monitor continuously
2. Child tries to disable Accessibility → detected immediately
3. Auto re-enable via Device Admin
4. If re-enable fails → FCM urgent to father: "Monitoring disabled — intervention needed"
5. Also detects: date/time changes, VPN usage, Safe Mode, factory reset
