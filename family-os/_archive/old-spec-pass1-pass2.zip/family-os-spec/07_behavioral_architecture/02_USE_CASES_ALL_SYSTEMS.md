---
title: "Use Cases — All Systems (91 P0)"
tags: [use-cases, behavioral, all-systems, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification (Pass 2)
---

# Use Cases — All Five Systems

> وثيقة حالات الاستخدام الكاملة لـ 91 خدمة P0 عبر الأنظمة الخمسة.
> كل حالة استخدام مكتوبة بصيغة موحّدة: الهدف، الفاعلون، الشروط المسبقة، التدفق الأساسي، التدفقات البديلة، شروط النجاح، والاستثناءات.

---

## Format Reference

```
UC-XXX: Title
  Actor(s):       Who triggers it
  Preconditions:  What must be true before
  Trigger:        What starts it
  Main Flow:      Numbered steps (happy path)
  Alt Flows:      Named deviations
  Postconditions: What is true after success
  Exceptions:     Error / edge handling
  Services:       P0 service IDs covered
  Screen(s):      Screen IDs involved
```

---

# System 1: Communications (S-COM) — 20 P0

## UC-COM-01: Send Message in Family Group Chat

| Field | Value |
|-------|-------|
| **Actor(s)** | Father, Mother, Child |
| **Preconditions** | User authenticated; member of family; family group conversation exists (auto-created on family creation) |
| **Trigger** | User opens family chat and types/records a message |
| **Services** | S-COM-001, S-COM-004, S-COM-011, S-COM-048 |
| **Screen(s)** | SCR-COM-01, SCR-COM-02 |

**Main Flow:**
1. User navigates to Communicate tab → SCR-COM-01 (Chat list)
2. User taps family group chat row
3. System displays SCR-COM-02 (Conversation detail) with message history
4. User types message in input field
5. User taps Send button
6. System saves message to local Drift DB (optimistic)
7. System displays message in chat with ✓ (sent) indicator
8. System queues message for Cloud sync
9. Cloud Function `messageSender` processes message → saves to Cloud SQL → sends FCM to all family members
10. Other members' devices receive FCM → display message
11. System updates sender's indicator to ✓✓ (delivered)
12. When recipient opens conversation, system records `message_read` → sender sees blue ✓✓

**Alt Flow A — Reply to Message:**
1. User long-presses on existing message
2. Context menu shows: رد (Reply), نسخ (Copy), تفاعل (React)
3. User taps رد → quoted message appears above input field
4. User types reply → sends with `reply_to_id` set
5. System displays reply with quoted original above it

**Alt Flow B — Quick Reaction:**
1. User long-presses on message → reaction picker appears
2. User taps emoji reaction (❤️, 👍, 😂, 😢, 🤲)
3. System saves `message_reaction` and displays reaction badge under message
4. Original sender receives notification

**Postconditions:** Message stored in Cloud SQL + Drift; FCM delivered; read receipts tracked
**Exceptions:**
- Offline: message queued in Drift `pending_operations`; sent on reconnect; user sees ⏳ indicator
- Chat locked by father (S-COM-052): non-father members see "المحادثة مقفلة" and cannot send
- Rate limit exceeded: "طلبات كثيرة، حاول لاحقًا"

---

## UC-COM-02: Send Private 1:1 Message

| Field | Value |
|-------|-------|
| **Actor(s)** | Father, Mother, Child |
| **Preconditions** | Both users are family members |
| **Trigger** | User opens existing 1:1 chat or creates new one |
| **Services** | S-COM-002, S-COM-004, S-COM-011 |
| **Screen(s)** | SCR-COM-01, SCR-COM-02 |

**Main Flow:**
1. User navigates to SCR-COM-01 → taps existing 1:1 chat OR taps "محادثة جديدة" → selects family member
2. System opens/creates 1:1 conversation (type=`direct`)
3. User types and sends message (same flow as UC-COM-01 steps 4-12)

**Alt Flow — New 1:1 with Child:**
1. Father/Mother taps child's profile from Today Dashboard → "مراسلة"
2. System opens 1:1 with child

**Postconditions:** Private conversation created/used; message delivered to single recipient
**Exceptions:** Child cannot initiate 1:1 with non-family members (system blocks)

---

## UC-COM-03: Create Sub-Group Chat

| Field | Value |
|-------|-------|
| **Actor(s)** | Father only |
| **Preconditions** | Family has ≥3 members |
| **Trigger** | Father wants a chat with subset of family |
| **Services** | S-COM-003 |
| **Screen(s)** | SCR-COM-01, SCR-COM-02 |

**Main Flow:**
1. Father navigates to SCR-COM-01 → taps "مجموعة جديدة"
2. System shows member picker (family members only)
3. Father selects 2+ members, enters group name
4. Father taps "إنشاء"
5. System creates conversation (type=`subgroup`) with selected members
6. Group appears in all selected members' chat lists

**Postconditions:** Sub-group conversation created; all selected members can see and use it
**Exceptions:**
- Mother/Child attempts to create → system blocks: "إنشاء المجموعات متاح للأب فقط"
- Only 1 member selected → system shows: "اختر عضوين على الأقل"

---

## UC-COM-04: Make Voice Call (P2P)

| Field | Value |
|-------|-------|
| **Actor(s)** | Father, Mother, Child |
| **Preconditions** | Both users online; RECORD_AUDIO permission granted |
| **Trigger** | User taps call icon in conversation or contact |
| **Services** | S-COM-006 |
| **Screen(s)** | SCR-COM-02, SCR-COM-10 |

**Main Flow:**
1. User taps 📞 icon in conversation header
2. System checks: recipient online? audio permission granted?
3. System initiates LiveKit WebRTC session
4. Callee's device rings (FCM + in-app sound)
5. Callee accepts → audio stream established (E2E encrypted via DTLS-SRTP)
6. Both users see call-in-progress screen (timer, mute, speaker, end)
7. Either user taps "إنهاء المكالمة" → call ends
8. System logs call duration in `messages` (type=`call`)

**Alt Flow — Call Declined:**
1. Callee taps "رفض" → caller sees "لم يتم الرد"
2. System logs missed call as system message

**Alt Flow — Callee Offline:**
1. System detects callee offline → shows "المستخدم غير متصل"
2. Sends FCM "مكالمة فائتة من [caller]"

**Postconditions:** Call completed; duration logged; both parties notified
**Exceptions:**
- RECORD_AUDIO denied → permission recovery dialog → "Open Settings"
- Network too poor → "جودة الاتصال ضعيفة" warning → auto-disconnect after 10s silence

---

## UC-COM-05: Share Media (Images/Files/Audio)

| Field | Value |
|-------|-------|
| **Actor(s)** | Father, Mother, Child |
| **Preconditions** | Relevant media permissions granted |
| **Trigger** | User taps attachment icon in conversation |
| **Services** | S-COM-010, S-COM-025, S-COM-029 |
| **Screen(s)** | SCR-COM-02 |

**Main Flow:**
1. User taps 📎 icon in input bar
2. System shows attachment menu: صورة (image), ملف (file), صوت (audio)
3. User selects type → system opens picker (gallery / file system / audio recorder)
4. User selects/captures media
5. System compresses image (if applicable), shows preview with caption field
6. User taps Send
7. System uploads to Firebase Storage (shows progress bar)
8. On upload complete, creates message with `message_attachment` record
9. Recipients see thumbnail/file icon with download option

**Alt Flow — Voice Message (S-COM-029 + S-COM-041):**
1. User holds microphone button in input bar
2. System starts recording (MediaRecorder)
3. User releases → recording stops → waveform preview shown
4. User taps Send → audio uploaded → message sent
5. System triggers `voiceTranscriber` Cloud Function (Whisper)
6. Transcribed text appears below voice waveform for recipient

**Postconditions:** Media stored in Firebase Storage; message with attachment delivered; voice transcribed
**Exceptions:**
- Upload fails (network) → retry with exponential backoff; show ⚠️ on message
- File too large (>25MB) → "حجم الملف كبير جدًا"
- Voice too short (<1s) → "الرسالة الصوتية قصيرة جدًا"
- Whisper transcription fails → show voice only, log error; no transcription text

---

## UC-COM-06: Create Calendar Event (Hijri)

| Field | Value |
|-------|-------|
| **Actor(s)** | Father, Mother |
| **Preconditions** | User is parent role |
| **Trigger** | User opens calendar and taps "+" |
| **Services** | S-COM-030 |
| **Screen(s)** | SCR-COM-03, SCR-COM-05 |

**Main Flow:**
1. User navigates to Communicate → التقويم (SCR-COM-03)
2. System displays calendar view (month) with Hijri dates primary, Gregorian secondary
3. User taps "+" or taps a date
4. System opens SCR-COM-05 (Event form)
5. User enters: title, Hijri date (auto-calculated Gregorian), time, attendees (family members), reminder (15min/1hr/1day)
6. User taps "حفظ"
7. System saves `family_event` with both Hijri and Gregorian dates
8. System sends notification to attendees

**Postconditions:** Event created; visible in family calendar for all attendees; reminders scheduled
**Exceptions:**
- Child attempts to create → "إنشاء الأحداث متاح للوالدين فقط"
- Past date selected → warning "هذا تاريخ ماضي — هل تريد المتابعة؟"

---

## UC-COM-07: Edit/Delete Calendar Event

| Field | Value |
|-------|-------|
| **Actor(s)** | Father, Mother (creator or father can edit any) |
| **Preconditions** | Event exists |
| **Trigger** | User taps event in calendar |
| **Services** | S-COM-031 |
| **Screen(s)** | SCR-COM-03, SCR-COM-05 |

**Main Flow:**
1. User taps event → SCR-COM-05 opens in view mode
2. User taps "تعديل" → form becomes editable
3. User modifies fields → taps "حفظ"
4. System updates `family_event`; sends updated notification to attendees

**Alt Flow — Delete:**
1. User taps "حذف" → confirmation dialog: "هل تريد حذف هذا الحدث؟"
2. User confirms → system soft-deletes event; notifies attendees

**Postconditions:** Event updated/deleted; all attendees notified of change

---

## UC-COM-08: Manage Tasks and Reminders

| Field | Value |
|-------|-------|
| **Actor(s)** | Father, Mother, Child (assigned tasks) |
| **Preconditions** | Family exists |
| **Trigger** | User opens Tasks tab |
| **Services** | S-COM-032 |
| **Screen(s)** | SCR-COM-04 |

**Main Flow:**
1. User navigates to SCR-COM-04 → Tasks tab
2. System shows task list grouped by: مهامي (My Tasks), مهام العائلة (Family Tasks)
3. Parent taps "+" → enters: title, assignee (family member), due date (Hijri), priority
4. System saves `family_task`; sends notification to assignee
5. Assignee sees task in their list → taps checkbox to complete
6. System marks `completed=true`, `completed_at=now`; sends notification to creator

**Postconditions:** Task created, assigned, tracked, completed; notifications sent at each state change

---

## UC-COM-09: Shared Shopping List

| Field | Value |
|-------|-------|
| **Actor(s)** | Father, Mother, Child |
| **Preconditions** | Family exists |
| **Trigger** | User opens Shopping tab |
| **Services** | S-COM-033 |
| **Screen(s)** | SCR-COM-04 |

**Main Flow:**
1. User navigates to SCR-COM-04 → Shopping tab
2. System shows shopping list from Firestore (real-time sync)
3. User taps "+" → enters item name, selects category (فواكه، خضار، لحوم، منظفات، أخرى)
4. Item appears immediately for all family members (Firestore real-time)
5. Any member taps checkbox → item marked as purchased
6. Checked items move to "تم الشراء" section

**Postconditions:** Shopping list updated in real-time for all family members
**Exceptions:** Offline: changes queued in Drift, synced when online

---

## UC-COM-10: Live Location Broadcast

| Field | Value |
|-------|-------|
| **Actor(s)** | Father, Mother, Child |
| **Preconditions** | ACCESS_FINE_LOCATION + ACCESS_BACKGROUND_LOCATION granted |
| **Trigger** | User taps "مشاركة موقعي" or automatic for monitored child |
| **Services** | S-COM-035 |
| **Screen(s)** | SCR-COM-06, SCR-PAR-05 |

**Main Flow:**
1. Child: location auto-broadcast (always on for monitored children)
2. Parent: taps "مشاركة موقعي" in SCR-COM-06 for temporary sharing
3. System writes location to Firestore `families/{id}/locations/{uid}` every 30 seconds
4. Other family members see live pin on map (SCR-COM-06 or SCR-PAR-05)
5. Location includes: lat, lng, accuracy, battery %, last update timestamp

**Postconditions:** Location visible to family members in real-time
**Exceptions:**
- GPS denied → show permission recovery dialog
- Indoor/poor GPS → show accuracy circle + "دقة منخفضة" badge
- Child cannot stop location sharing (enforced by system)

---

## UC-COM-11: Create Poll

| Field | Value |
|-------|-------|
| **Actor(s)** | Father, Mother |
| **Preconditions** | Conversation exists |
| **Trigger** | User taps poll icon in conversation |
| **Services** | S-COM-036 |
| **Screen(s)** | SCR-COM-02 |

**Main Flow:**
1. User taps ☐ poll icon in conversation action bar
2. System shows poll creation sheet: question + 2-6 options + expiry (optional)
3. User fills fields → taps "إرسال"
4. System saves `poll` record; sends as special message type
5. All members see poll card in chat → tap to vote
6. System records `poll_vote`; updates live results bar chart
7. On expiry (or all voted), poll closes → final results shown

**Postconditions:** Poll created, votes collected, results visible to all
**Exceptions:** Child can vote but not create polls

---

## UC-COM-12: Trigger SOS Emergency

| Field | Value |
|-------|-------|
| **Actor(s)** | Child (trigger), Father/Mother (receive) |
| **Preconditions** | Child logged in; SOS FAB visible on every child screen |
| **Trigger** | Child holds SOS FAB for 3 seconds |
| **Services** | S-COM-039 |
| **Screen(s)** | SCR-COM-07 |

**Main Flow:**
1. Child holds SOS FAB (red pulsing button) for 3 seconds
2. System shows countdown: ٣...٢...١
3. At zero: system activates SOS mode
4. System starts live location broadcast (highest accuracy, every 5 seconds)
5. System sends FCM to Father + Mother (CRITICAL priority — bypasses DND)
6. System creates `emergency_event` record
7. System initiates auto-call to Father
8. Child sees SCR-COM-07 (launch mode): "جاري الاتصال بوالديك" + live location
9. Father/Mother receive full-screen SOS alert with child's location
10. Parent opens SCR-COM-07 (receive mode): map + call + navigate + resolve buttons
11. Parent taps "تم الحل" → emergency resolved → audit logged

**Alt Flow — SOS Cancel:**
1. Child releases FAB before 3 seconds → nothing happens

**Alt Flow — No Parent Responds (60s):**
1. System sends SMS fallback to parent phone numbers
2. Child device activates loud alarm + screen flash
3. System re-sends FCM every 30 seconds for 5 minutes

**Postconditions:** Emergency event logged; parents notified; child located; resolution recorded in audit
**Exceptions:**
- Offline: SOS queued at highest priority; sent on any connectivity; local alarm activates
- Battery critical: SOS still functions; includes battery % in alert
- Both parents offline: SMS fallback + local alarm + log for later review
- SOS bypasses: device lock, screen time limit, Kill Switch, bedtime mode

---

## UC-COM-13: Send Voice Message with Transcription

| Field | Value |
|-------|-------|
| **Actor(s)** | Father, Mother, Child |
| **Preconditions** | RECORD_AUDIO granted |
| **Trigger** | User holds microphone button |
| **Services** | S-COM-041 |
| **Screen(s)** | SCR-COM-02, SCR-COM-10 |

**Main Flow:**
1. User holds microphone button in chat input
2. System starts recording; shows timer + waveform
3. User releases → recording stops
4. Preview shown with playback + cancel + send
5. User taps Send → audio uploaded to Firebase Storage
6. Message sent with `message_attachment` (type=voice)
7. Cloud Function `voiceTranscriber` processes audio via Whisper
8. Transcribed text appears below waveform for all participants

**Postconditions:** Voice message delivered; transcription available
**Exceptions:**
- Audio <1 second → "الرسالة قصيرة جدًا"
- Whisper fails → voice message delivered without transcription; log error

---

## UC-COM-14: Real-Time Message Translation

| Field | Value |
|-------|-------|
| **Actor(s)** | Father, Mother, Child |
| **Preconditions** | Translation enabled in settings (S-COM-044) |
| **Trigger** | User receives message in different language OR taps "ترجم" |
| **Services** | S-COM-044 |
| **Screen(s)** | SCR-COM-02, SCR-COM-09 |

**Main Flow:**
1. User receives message in different language
2. If auto-translate enabled: system checks Redis cache for translation
3. Cache miss → Cloud Function `translator` sends to Gemini → caches result (1hr TTL)
4. Translated text appears below original message with "🌐 مترجم" indicator
5. User can tap translation to see original

**Alt Flow — Manual Translation:**
1. User long-presses message → taps "ترجم"
2. System translates on-demand

**Postconditions:** Translation stored in `message_translations`; cached in Redis
**Exceptions:**
- Premium feature: trial-expired users see "اشترك لتفعيل الترجمة"
- Translation fails → "تعذرت الترجمة" with retry option

---

## UC-COM-15: Lock Conversation (Father Only)

| Field | Value |
|-------|-------|
| **Actor(s)** | Father |
| **Preconditions** | Conversation exists; user is father |
| **Trigger** | Father opens conversation settings |
| **Services** | S-COM-052 |
| **Screen(s)** | SCR-COM-11 |

**Main Flow:**
1. Father opens conversation → taps settings → "قفل المحادثة"
2. SCR-COM-11: Father sets PIN (4-6 digits)
3. Father confirms PIN → conversation locked
4. Other members see "المحادثة مقفلة" — cannot send or read new messages
5. Father can unlock by entering PIN

**Postconditions:** Conversation locked; only father can unlock; existing messages preserved
**Exceptions:** Mother/Child attempt to lock → action hidden from their UI

---
---

# System 2: Monitoring (S-PAR) — 20 P0

## UC-PAR-01: Set Daily Screen Time Limit

| Field | Value |
|-------|-------|
| **Actor(s)** | Father |
| **Preconditions** | Child device linked; UsageStatsManager permission granted on child device |
| **Trigger** | Father opens screen time settings for a child |
| **Services** | S-PAR-001 |
| **Screen(s)** | SCR-PAR-02 |

**Main Flow:**
1. Father navigates to Monitor → Screen Time (SCR-PAR-02)
2. Father selects child (if multiple)
3. System shows current daily limit, usage chart, app breakdown
4. Father adjusts daily limit slider (30min–8hr in 15min steps)
5. Father can set per-day limits (أحد–سبت / Sunday–Saturday)
6. Father taps "حفظ"
7. System saves `screen_time_rule` → syncs to child device via Firestore
8. Child device enforces new limit immediately

**Postconditions:** Screen time rule active; child device enforces; usage tracked
**Exceptions:**
- UsageStats permission revoked on child → father sees ⚠️ warning; child prompted to re-grant

---

## UC-PAR-02: View Usage Reports

| Field | Value |
|-------|-------|
| **Actor(s)** | Father (full), Mother (if granted), Child (remaining time only) |
| **Preconditions** | Screen time tracking active |
| **Trigger** | User opens screen time screen |
| **Services** | S-PAR-002 |
| **Screen(s)** | SCR-PAR-02 |

**Main Flow:**
1. Father opens SCR-PAR-02 → sees daily/weekly charts
2. Bar chart shows: used vs. limit per day
3. App breakdown list shows: app icon, name, minutes used, category
4. Father can filter by: اليوم (today), الأسبوع (week), الشهر (month)

**Child View:**
1. Child opens "وقتي" tab → sees remaining time only (not detailed breakdown)
2. Shows: ⏱ ٤٥ دقيقة متبقية | الحد اليومي: ساعتان

**Postconditions:** Reports displayed from `screen_time_usage` data

---

## UC-PAR-03: Configure Smart Schedules

| Field | Value |
|-------|-------|
| **Actor(s)** | Father |
| **Preconditions** | Child linked |
| **Trigger** | Father wants different rules per time period |
| **Services** | S-PAR-003, S-PAR-006 |
| **Screen(s)** | SCR-PAR-02 |

**Main Flow:**
1. Father opens Screen Time → "جداول ذكية"
2. System shows schedule builder: weekday vs. weekend rules
3. Father configures:
   - وقت المدرسة (school hours): 0 minutes allowed
   - بعد المدرسة: 2 hours
   - عطلة نهاية الأسبوع: 3 hours
4. Father sets bedtime: ٩:٣٠ م → ٦:٠٠ ص (device locks at bedtime)
5. System saves rules → child device enforces per schedule

**Postconditions:** Smart schedule active; device auto-locks at bedtime; usage adjusted by day type

---

## UC-PAR-04: Instant Device Lock

| Field | Value |
|-------|-------|
| **Actor(s)** | Father (trigger), Child (experiences lock) |
| **Preconditions** | Child device linked; Accessibility/Overlay permission on child device |
| **Trigger** | Father taps "قفل الجهاز" |
| **Services** | S-PAR-005 |
| **Screen(s)** | SCR-PAR-01, SCR-PAR-03 |

**Main Flow:**
1. Father taps "قفل فوري" on child's card in Today Dashboard or Monitoring Hub
2. System sends FCM to child device (CRITICAL priority)
3. Child device receives → Accessibility/Overlay shows full-screen lock (SCR-PAR-03)
4. Child sees: "تم قفل جهازك بواسطة والدك" + remaining lock time (if timed) + "طلب فتح" button
5. Father sees confirmation: "تم قفل جهاز خالد"

**Alt Flow — Child Requests Unlock:**
1. Child taps "طلب فتح" → enters reason
2. Father receives notification → approves or denies
3. Approved → lock removed; Denied → lock continues

**Postconditions:** Device locked; child sees lock overlay; SOS still accessible
**Exceptions:** SOS bypasses device lock — child can always trigger SOS even when locked

---

## UC-PAR-05: Request Extra Time (Child)

| Field | Value |
|-------|-------|
| **Actor(s)** | Child (request), Father/Mother (approve) |
| **Preconditions** | Screen time limit reached or close to limit |
| **Trigger** | Child taps "طلب وقت إضافي" |
| **Services** | S-PAR-009 |
| **Screen(s)** | SCR-PAR-04 |

**Main Flow:**
1. Child's screen time reaches limit → lock screen appears
2. Child taps "طلب وقت إضافي" (SCR-PAR-04)
3. Child selects: amount (15/30/60 min), enters reason ("أحتاج لإنهاء واجب الرياضيات")
4. System creates `permission_request` → sends FCM to Father
5. Father receives notification with request details
6. Father taps approve → system extends `screen_time_rule` by requested amount
7. Child device unlocks; child sees "تمت الموافقة — ٣٠ دقيقة إضافية"

**Alt Flow — Denied:**
1. Father taps deny → child sees "لم تتم الموافقة — حاول غدًا"

**Postconditions:** Request logged in `permission_requests`; time extended if approved

---

## UC-PAR-06: Track Child Location (Live GPS)

| Field | Value |
|-------|-------|
| **Actor(s)** | Father, Mother |
| **Preconditions** | Child device linked; Location permissions granted |
| **Trigger** | Parent opens map |
| **Services** | S-PAR-011, S-PAR-012 |
| **Screen(s)** | SCR-PAR-05 |

**Main Flow:**
1. Parent opens Monitor → الخريطة (SCR-PAR-05)
2. System reads child location from Firestore `families/{id}/locations/{uid}`
3. Map shows child's pin with: name, battery %, last update time, accuracy circle
4. If multiple children: switcher at top → parent selects child
5. Parent can tap "تنقل" → opens Google Maps navigation to child's location
6. Location history: parent taps "السجل" → see movement trail for today

**Postconditions:** Parent sees child's current and historical location
**Exceptions:**
- Location permission revoked → "تتبع الموقع متوقف" warning + guide to re-grant
- GPS off → last known location shown with "آخر تحديث: منذ ١٥ دقيقة"

---

## UC-PAR-07: Configure Safe Zones (Geofences)

| Field | Value |
|-------|-------|
| **Actor(s)** | Father only |
| **Preconditions** | Child linked; location active |
| **Trigger** | Father opens safe zones |
| **Services** | S-PAR-014, S-PAR-032 |
| **Screen(s)** | SCR-PAR-06 |

**Main Flow:**
1. Father opens Monitor → المناطق الآمنة (SCR-PAR-06)
2. Map shows existing geofences as circles
3. Father taps "+" → taps map center → adjusts radius (100m–2km)
4. Father enters: name ("المنزل"/"المدرسة"), notification on enter/exit
5. Father taps "حفظ" → system creates `geofence` → registers with Android GeofencingClient
6. When child enters/exits zone: system creates `geofence_event` → sends FCM to father: "خالد وصل إلى المنزل"
7. System also creates system message in family chat

**Postconditions:** Geofence active; events trigger notifications and chat messages
**Exceptions:** Mother cannot access this screen (father-exclusive)

---

## UC-PAR-08: Block/Allow Apps

| Field | Value |
|-------|-------|
| **Actor(s)** | Father only |
| **Preconditions** | Child device linked; Accessibility permission on child |
| **Trigger** | Father opens app rules |
| **Services** | S-PAR-015, S-PAR-016 |
| **Screen(s)** | SCR-PAR-07 |

**Main Flow:**
1. Father opens Monitor → قواعد التطبيقات (SCR-PAR-07)
2. System shows all apps installed on child's device with status: ✅ مسموح / ❌ محظور / ⏱ محدد
3. Father taps app → toggles between: allowed, blocked, time-limited
4. Father can also set rules by category: ألعاب (games) → 1hr/day, تواصل اجتماعي → blocked
5. System saves `app_rule` → syncs to child device
6. AccessibilityService on child enforces: blocked app opens → overlay "هذا التطبيق محظور بواسطة والدك"

**Postconditions:** App rules enforced; child sees block overlay on restricted apps

---

## UC-PAR-09: Configure Web Filtering

| Field | Value |
|-------|-------|
| **Actor(s)** | Father only |
| **Preconditions** | AccessibilityService on child device |
| **Trigger** | Father opens web filter settings |
| **Services** | S-PAR-017, S-PAR-018 |
| **Screen(s)** | SCR-PAR-08 |

**Main Flow:**
1. Father opens Monitor → فلترة الويب (SCR-PAR-08)
2. System shows category toggles: محتوى بالغين (adult) ❌, ألعاب قمار (gambling) ❌, عنف ❌, etc.
3. Father toggles categories on/off
4. Father can add exceptions: allow specific URL despite category block, OR block specific URL despite category allow
5. System saves `web_filter_exception` → syncs to child
6. Browser on child device checks URL against rules → blocked sites show "هذا الموقع محظور"

**Postconditions:** Web filter active; blocked sites logged in `web_history`

---

## UC-PAR-10: Detect Suspicious Content (29 Categories)

| Field | Value |
|-------|-------|
| **Actor(s)** | System (automatic), Father/Mother (review) |
| **Preconditions** | AccessibilityService active; AI content classification available |
| **Trigger** | AccessibilityService detects text/activity matching alert pattern |
| **Services** | S-PAR-021, S-PAR-045, AI-002 |
| **Screen(s)** | SCR-PAR-09 |

**Main Flow:**
1. AccessibilityService monitors visible text on child's screen
2. Text sent to Cloud Function `contentScanner` (no raw text stored in logs)
3. AI classifies content against 29 categories (bullying, self-harm, drugs, violence, sexual, etc.)
4. If match found → creates `content_alert` with: category, severity (low/medium/high/critical), recommendation
5. System sends FCM to Father (and Mother if permission granted)
6. Parent opens SCR-PAR-09 → sees alert feed with filters by category/severity
7. Parent reviews → taps alert → sees: app name, category, severity, recommendation (NO raw text)
8. Parent can: dismiss, block app, talk to child

**Postconditions:** Alert logged; parent notified; child's raw text NOT stored
**Exceptions:**
- AI unavailable → text queued; processed when online
- False positive → parent dismisses; system logs dismissal for accuracy tuning

---

## UC-PAR-11: Anti-Bypass Protection

| Field | Value |
|-------|-------|
| **Actor(s)** | System (automatic), Father (notification) |
| **Preconditions** | Child device linked with Device Admin + Accessibility + VPN |
| **Trigger** | Child attempts to circumvent monitoring |
| **Services** | S-PAR-038 |
| **Screen(s)** | SCR-PAR-12 |

**Main Flow:**
1. System continuously monitors for bypass attempts:
   - App uninstall attempt → DevicePolicyManager blocks
   - Force stop attempt → Foreground Service restarts
   - Date/time change → AccessibilityService detects
   - Third-party VPN → network check detects
   - Safe Mode → boot receiver detects
   - Accessibility disabled → auto re-enable attempt + FCM to father
2. On detection → creates `anti_bypass_event`
3. System sends FCM to Father: "محاولة تجاوز الحماية من جهاز خالد"
4. Father opens SCR-PAR-12 → sees: protection status (VPN ✅, Accessibility ✅, DPM ✅), bypass attempt log

**Postconditions:** Bypass attempt logged; father notified; protection maintained

---

## UC-PAR-12: Activate Kill Switch

| Field | Value |
|-------|-------|
| **Actor(s)** | Father only |
| **Preconditions** | VPN_SERVICE permission on child device |
| **Trigger** | Father toggles Kill Switch |
| **Services** | S-PAR-041 |
| **Screen(s)** | SCR-PAR-11 |

**Main Flow:**
1. Father opens Monitor → Kill Switch (SCR-PAR-11)
2. Father sees large toggle + child selector
3. Father activates → optional: set duration (30min/1hr/2hr/until-I-turn-off)
4. System sends command to child device via Cloud Function `killSwitchHandler`
5. Child device activates local VPN → all internet traffic blocked
6. Child sees notification: "تم إيقاف الإنترنت بواسطة والدك"
7. Phone calls still work; SOS still works (bypasses VPN)

**Alt Flow — Scheduled Deactivation:**
1. Duration expires → VPN deactivates → internet resumes
2. Father notified: "تم استعادة الإنترنت لجهاز خالد"

**Postconditions:** Internet paused/resumed; `internet_pause_event` logged with duration
**Exceptions:** Mother cannot access Kill Switch (father-exclusive)

---

## UC-PAR-13: Activate School Time Mode

| Field | Value |
|-------|-------|
| **Actor(s)** | Father (configure), System (auto-activate) |
| **Preconditions** | School schedule configured (S-ADM-035) |
| **Trigger** | School time schedule triggers |
| **Services** | S-PAR-052, S-ADM-035 |
| **Screen(s)** | SCR-PAR-10, SCR-ADM-10 |

**Main Flow:**
1. Father configures school schedule in SCR-ADM-10: days (Hijri week), start/end times per day
2. System creates `school_time_schedule` records
3. When schedule triggers (WorkManager + Accessibility):
   - Block all non-educational apps
   - Allow only: المنصة العائلية, apps father whitelisted
   - Enable GPS school zone verification (if configured)
4. Child sees "وضع المدرسة" badge → restricted app access
5. Parent sees "في المدرسة" status on Today Dashboard
6. When school time ends → normal rules resume

**Postconditions:** School Time enforced during scheduled hours; apps restricted; parent aware

---

## UC-PAR-14: Focus Mode Display in Monitoring

| Field | Value |
|-------|-------|
| **Actor(s)** | Father, Mother (view) |
| **Preconditions** | Child is in Focus Mode (triggered from Education) |
| **Trigger** | Child activates Focus Mode |
| **Services** | S-PAR-034 |
| **Screen(s)** | SCR-PAR-01 |

**Main Flow:**
1. Child activates Focus Mode from Education → triggers event `focus.activated`
2. Safety domain receives event → updates monitoring display
3. Parent sees on SCR-PAR-01 (Monitoring Hub): "🎯 خالد في وضع التركيز — الرياضيات — ١٨ دقيقة متبقية"
4. When Focus Mode ends → display updates to normal

**Postconditions:** Parent can see child's focus status in monitoring view

---
---

# System 3: Education (S-EDU) — 24 P0

## UC-EDU-01: Add Subject

| Field | Value |
|-------|-------|
| **Actor(s)** | Father, Mother |
| **Preconditions** | Family exists; at least one child linked |
| **Trigger** | Parent opens subjects management |
| **Services** | S-EDU-001, S-EDU-002 |
| **Screen(s)** | SCR-EDU-02 |

**Main Flow:**
1. Parent navigates to Learn → المواد (SCR-EDU-02)
2. Parent taps "+" → enters: subject name (e.g. الرياضيات), icon, color, grade level, assigned child
3. System saves `subject` record → appears in child's learning home
4. Child sees new subject card in SCR-EDU-01

**Postconditions:** Subject created and visible to child and parents

---

## UC-EDU-02: Add and View Lessons

| Field | Value |
|-------|-------|
| **Actor(s)** | Father/Mother (create), Child (view/complete) |
| **Preconditions** | Subject exists |
| **Trigger** | Parent adds lesson; child opens subject |
| **Services** | S-EDU-003, S-EDU-004 |
| **Screen(s)** | SCR-EDU-03, SCR-EDU-04 |

**Main Flow (Create):**
1. Parent opens subject → taps "درس جديد"
2. Parent enters: title, content (text + images), order in sequence
3. System saves `lesson` → appears in child's lesson list

**Main Flow (Complete):**
1. Child opens subject → SCR-EDU-03 (lesson list)
2. Child taps lesson → SCR-EDU-04 (interactive content)
3. Child reads/interacts with content → taps "أكملت الدرس"
4. System creates `lesson_completion` → awards points → progress updated
5. Next lesson unlocks

**Postconditions:** Lesson completed; progress tracked; points earned

---

## UC-EDU-03: Create and Submit Assignment

| Field | Value |
|-------|-------|
| **Actor(s)** | Father/Mother (create), Child (submit) |
| **Preconditions** | Subject exists |
| **Trigger** | Parent creates assignment; child submits |
| **Services** | S-EDU-009, S-EDU-010, S-EDU-011, S-EDU-014 |
| **Screen(s)** | SCR-EDU-05 |

**Main Flow (Create):**
1. Parent opens subject → "واجب جديد"
2. Parent enters: title, description, questions (MCQ / short answer / essay), due date (Hijri), total points
3. System saves `assignment` with `questions` JSONB → sends notification to child

**Main Flow (Submit):**
1. Child opens SCR-EDU-05 → sees assignment with Hijri due date
2. Child answers each question
3. Child can attach file (photo of handwritten work)
4. Child taps "إرسال" → system creates `assignment_submission` (status=`submitted`)
5. System triggers AI grading (UC-AI-04)

**Postconditions:** Assignment created with due date; submission received; AI grading triggered

---

## UC-EDU-04: AI Auto-Grading

| Field | Value |
|-------|-------|
| **Actor(s)** | System (AI-004), Father/Mother (override) |
| **Preconditions** | Assignment submitted |
| **Trigger** | `assignment.submitted` event |
| **Services** | S-EDU-013, S-EDU-014, AI-004 |
| **Screen(s)** | SCR-EDU-05 |

**Main Flow:**
1. System receives submission → triggers `aiGrader` Cloud Function
2. Gemini 2.5 Flash evaluates each answer against correct answers + rubric
3. System updates `assignment_submission`: grade, per-question feedback, graded_by="AI"
4. Child notified: "تم تصحيح واجبك — ٨٥/١٠٠"
5. Child sees results with per-question feedback
6. Points auto-awarded based on grade

**Alt Flow — Father Override:**
1. Father reviews AI grade → disagrees → taps "تعديل الدرجة"
2. Father changes grade/feedback → graded_by changes to father's ID
3. Child notified of updated grade

**Postconditions:** Assignment graded; feedback available; points awarded
**Exceptions:**
- AI unavailable → status stays `submitted`; falls back to manual grading
- Grading takes >10s → show "جاري التصحيح..." shimmer

---

## UC-EDU-05: Take Quiz

| Field | Value |
|-------|-------|
| **Actor(s)** | Child (take), Father/Mother (create + review) |
| **Preconditions** | Quiz exists for child's subject |
| **Trigger** | Child opens quiz |
| **Services** | S-EDU-017, S-EDU-019, S-EDU-020 |
| **Screen(s)** | SCR-EDU-06, SCR-EDU-07 |

**Main Flow (Take):**
1. Child opens SCR-EDU-06 → quiz intro: title, time limit, question count, passing score
2. Child taps "ابدأ" → timer starts
3. System shows questions one at a time (MCQ / true-false / short-answer)
4. Child navigates between questions → answers each
5. Child taps "إرسال" (or timer expires) → system creates `quiz_attempt`
6. System calculates score → shows SCR-EDU-07 (results): score circle, per-question breakdown
7. Points awarded if passed

**Postconditions:** Quiz attempt logged; score calculated; visible to parents

---

## UC-EDU-06: Gamification — Points, Badges, Redemption

| Field | Value |
|-------|-------|
| **Actor(s)** | Child (earn/redeem), Father/Mother (view) |
| **Preconditions** | Child has activity in education |
| **Trigger** | Child completes educational activities |
| **Services** | S-EDU-024, S-EDU-028, S-EDU-029 |
| **Screen(s)** | SCR-EDU-08 |

**Main Flow (Earn):**
1. Child completes lesson → +10 نقطة
2. Child submits assignment with grade ≥80 → +25 نقطة
3. Child passes quiz → +50 نقطة
4. Child completes Focus session → +15 نقطة
5. System creates `reward_transaction` → updates visible balance

**Main Flow (Badge):**
1. System checks badge requirements (e.g., "أكمل 10 دروس" / "7 أيام متتالية")
2. Badge earned → creates `user_badge` → notification: "🏆 حصلت على شارة المثابرة!"

**Main Flow (Redeem):**
1. Child opens SCR-EDU-08 → points balance shown
2. Child taps "استبدال" → sees options (e.g., +30 min screen time, unlock game, virtual avatar item)
3. Child selects → system deducts points → reward applied

**Postconditions:** Points tracked; badges awarded; redemption history logged

---

## UC-EDU-07: Focus Mode

| Field | Value |
|-------|-------|
| **Actor(s)** | Child |
| **Preconditions** | Subject selected |
| **Trigger** | Child activates Focus Mode |
| **Services** | S-EDU-034, S-EDU-035 |
| **Screen(s)** | SCR-EDU-09 |

**Main Flow:**
1. Child opens SCR-EDU-09 → selects subject → sets timer (default 25 min)
2. Child taps "ابدأ" → Focus Mode activates
3. System triggers `focus.activated` event → Safety domain blocks non-educational apps
4. Timer counts down; distraction counter tracks: notification attempts, app switch attempts
5. Timer completes → system calculates focus score (duration × low-distraction multiplier)
6. System creates `focus_session` → awards XP based on score
7. Child sees: "أحسنت! ٢٥ دقيقة تركيز — ٤٥ XP" 🎉

**Alt Flow — End Early:**
1. Child taps "إنهاء" before timer → partial session logged; reduced points

**Postconditions:** Focus session logged; apps re-enabled; XP awarded; parent sees in monitoring

---

## UC-EDU-08: Quran Memorization and Recitation

| Field | Value |
|-------|-------|
| **Actor(s)** | Child (practice), Father/Mother (monitor) |
| **Preconditions** | RECORD_AUDIO granted |
| **Trigger** | Child opens Quran section |
| **Services** | S-EDU-038, S-EDU-039, AI-008 |
| **Screen(s)** | SCR-EDU-10 |

**Main Flow (Memorization):**
1. Child opens SCR-EDU-10 → selects surah → selects ayah range
2. System displays ayahs with tajweed color highlighting
3. Child studies text → taps "حفظت" when ready

**Main Flow (Recitation):**
1. Child taps "تسميع" → system shows target ayahs
2. Child taps record → reads aloud (MediaRecorder)
3. Child stops → audio uploaded to cloud
4. Cloud Function `quranAnalyzer`: Whisper STT → Gemini analysis
5. Result: accuracy %, error list (missing/wrong/tajweed), feedback
6. If accuracy ≥80% → status = "memorized" → points awarded
7. **Audio deleted after analysis** (privacy rule)

**Postconditions:** Memorization progress tracked; recitation analyzed; audio deleted
**Exceptions:**
- Audio too short (<3s) → "التسجيل قصير جدًا"
- Whisper/Gemini unavailable → "تعذر التحليل، حاول لاحقًا"

---

## UC-EDU-09: AI Tutor Session

| Field | Value |
|-------|-------|
| **Actor(s)** | Child, Father, Mother |
| **Preconditions** | Premium subscription (or trial active) |
| **Trigger** | User opens AI Tutor |
| **Services** | S-EDU-046, AI-003 |
| **Screen(s)** | SCR-EDU-11 |

**Main Flow:**
1. User opens SCR-EDU-11 → selects subject context
2. User types question: "كيف أحل معادلة من الدرجة الثانية؟"
3. System sends to AI Orchestrator (Socratic method prompt)
4. AI responds with guiding question, NOT direct answer: "ما هي الصيغة العامة للمعادلة التربيعية؟"
5. Student answers → AI guides further with hints
6. Eventually AI provides worked example if student is stuck
7. Session saved in `ai_tutor_sessions`

**Postconditions:** Tutoring session logged; student learning tracked
**Exceptions:** Trial expired → "اشترك لاستخدام المعلم الذكي"

---

## UC-EDU-10: Adaptive Learning Path

| Field | Value |
|-------|-------|
| **Actor(s)** | Child (follow), System (generate) |
| **Preconditions** | Placement test completed (S-EDU-052) |
| **Trigger** | Child opens adaptive learning section |
| **Services** | S-EDU-047, S-EDU-051, S-EDU-052, S-EDU-058 |
| **Screen(s)** | SCR-EDU-12, SCR-EDU-13, SCR-EDU-14, SCR-EDU-15 |

**Main Flow (Placement):**
1. Child opens SCR-EDU-12 → selects subject → takes placement test
2. System generates questions at varying difficulty levels
3. Based on responses → determines starting level + weak/strong areas
4. System creates `placement_test` + `adaptive_learning_state`

**Main Flow (Adaptive Exercises):**
1. Child opens SCR-EDU-13 → sees visual learning path with current position
2. Child taps "التمرين التالي" → SCR-EDU-14
3. System generates exercise at current difficulty level
4. Child answers → correct: difficulty increases (consecutive_correct++); wrong: decreases
5. System updates `adaptive_learning_state`
6. XP earned for each correct answer

**Main Flow (XP + Levels):**
1. XP accumulates → level up triggers: animation + notification
2. Child sees progress in SCR-EDU-15: current level, XP bar, recent earnings
3. Level benefits unlock (e.g., new avatar items, achievement badges)

**Postconditions:** Adaptive state tracked; difficulty auto-adjusts; XP/levels progress

---
---

# System 4: AI Intelligence — 7 P0

## UC-AI-01: Family AI Assistant

| Field | Value |
|-------|-------|
| **Actor(s)** | Father, Mother, Child |
| **Preconditions** | Premium or trial active; online |
| **Trigger** | User opens AI Assistant |
| **Services** | AI-001 |
| **Screen(s)** | SCR-AI-01 |

**Main Flow:**
1. User opens SCR-AI-01 → sees conversation history (or empty state with suggestion chips)
2. User types question: "ساعدني في تنظيم جدول الأسبوع لخالد"
3. System sends to AI Orchestrator:
   a. Rate limit check (Redis)
   b. RAG context retrieval (Pinecone — family context, child data)
   c. Prompt construction (system prompt + RAG + user message)
   d. Gemini 2.5 Flash call
   e. Safety filter
4. Response displayed in chat bubble (violet color for AI)
5. Session logged in `ai_conversations` + `ai_messages`
6. Cost tracked in `ai_cost_tracking`

**Postconditions:** Response delivered; session logged; cost tracked
**Exceptions:**
- Rate limit hit → "وصلت الحد اليومي للأسئلة"
- AI unavailable → "الذكاء الاصطناعي غير متاح حاليًا — حاول لاحقًا"
- Safety filter triggered → response sanitized or blocked
- Prompt injection attempt → immutable system prompt prevents bypass

---

## UC-AI-02: Sentiment Analysis (Behind Scenes)

| Field | Value |
|-------|-------|
| **Actor(s)** | System (automatic) |
| **Preconditions** | Message sent in family chat |
| **Trigger** | `message.sent` event |
| **Services** | AI-002 |
| **Screen(s)** | SCR-PAR-09 (alert view for parent) |

**Main Flow:**
1. Message sent in any family conversation → event `message.sent` fires
2. Cloud Function `sentimentAnalyzer` receives event via Pub/Sub
3. Message text sent to Gemini (temp=0.3) for classification
4. Result: sentiment (positive/neutral/sad/angry/anxious/excited/bullying_risk), intensity (0-1)
5. System saves `sentiment_log` — sentiment result ONLY, NO message text
6. If bullying_risk=true OR 3 consecutive negative in 24h → alert triggered

**Alert Flow:**
1. System creates `content_alert` → sends FCM to Father (and Mother if permitted)
2. Parent sees alert in SCR-PAR-09: category, severity, recommendation
3. Parent reviews → dismisses or acts (block app, talk to child)

**Postconditions:** Sentiment logged (no raw text); alert triggered if risky
**Exceptions:**
- AI unavailable → queued; processed when online; message NOT blocked
- False positive → parent dismisses; logged for tuning

---

## UC-AI-03: AI Private Tutor

| Field | Value |
|-------|-------|
| **Actor(s)** | Child, Father, Mother |
| **Preconditions** | Premium or trial; subject selected |
| **Trigger** | User opens tutor for specific subject |
| **Services** | AI-003 |
| **Screen(s)** | SCR-AI-02 |

**Main Flow:**
1. User opens SCR-AI-02 → selects subject (e.g. الرياضيات)
2. User asks question about a specific topic
3. AI Orchestrator responds with **Socratic method**: guided questions, hints, step-by-step
4. AI never gives direct answer first — always guides student to discover
5. If student stuck after 3 attempts → AI provides worked example
6. Session saved in `ai_tutor_sessions` with subject context

**Postconditions:** Tutoring interaction logged; student learning guided
**Exceptions:** Child-appropriate filter active — AI won't discuss off-topic subjects

---

## UC-AI-04: Auto Assignment Grading

| Field | Value |
|-------|-------|
| **Actor(s)** | System (triggered by submission) |
| **Preconditions** | Assignment submitted; has correct answers/rubric |
| **Trigger** | `assignment.submitted` event |
| **Services** | AI-004 |
| **Screen(s)** | SCR-EDU-05 |

**Main Flow:**
1. Submission received → Pub/Sub triggers `aiGrader`
2. Gemini evaluates each answer (temp=0.2, high determinism)
3. Per-question: correct/incorrect, points, specific feedback in Arabic
4. General feedback + suggested improvement areas
5. System updates submission: grade, feedback, graded_by="AI", graded_at
6. Notification to child: "تم تصحيح واجبك"
7. Notification to parent: "تم تصحيح واجب خالد — ٨٥/١٠٠"

**Postconditions:** Grade + feedback stored; notifications sent; points awarded
**Exceptions:**
- AI fails → submission stays `pending`; falls back to manual grading by parent
- Target: grading completes within 10 seconds

---

## UC-AI-05: Educational Recommendations

| Field | Value |
|-------|-------|
| **Actor(s)** | System (generate), Child/Father (consume) |
| **Preconditions** | Learning history exists |
| **Trigger** | Periodic (after lesson completion) or on-demand |
| **Services** | AI-007, AI-020 |
| **Screen(s)** | SCR-AI-03, SCR-AI-05 |

**Main Flow:**
1. Child completes lesson or quiz → event triggers recommendation engine
2. System aggregates: learning progress, skill gaps, placement results, adaptive state
3. Gemini + Pinecone similarity search generates recommendations
4. Each recommendation: content reference + reason ("سيساعدك في تقوية القسمة")
5. Recommendations appear in SCR-AI-05 as cards
6. User can: accept (→ navigate to content), dismiss, save for later
7. System tracks recommendation status in `ai_recommendations`

**Postconditions:** Personalized recommendations generated; interaction tracked

---

## UC-AI-06: Quran Recitation Analysis

| Field | Value |
|-------|-------|
| **Actor(s)** | Child (recite), System (analyze) |
| **Preconditions** | Audio uploaded; surah/ayah target specified |
| **Trigger** | Child submits recitation recording |
| **Services** | AI-008 |
| **Screen(s)** | SCR-AI-04 |

**Main Flow:**
1. Child records recitation in SCR-EDU-10 → audio uploaded
2. Cloud Function `quranAnalyzer`:
   a. Whisper STT → transcribes Arabic recitation
   b. Gemini compares transcription vs. target surah text
   c. Identifies: missing ayahs, wrong words, tajweed errors
3. Result sent to SCR-AI-04: accuracy %, error list with specific feedback
4. Example error: "مدّ حرف المد في 'الكهفِ' غير كافٍ"
5. If accuracy ≥80% → memorization marked as "محفوظ"
6. **Audio permanently deleted after analysis**

**Postconditions:** Accuracy scored; errors detailed; progress updated; audio deleted
**Exceptions:**
- Background noise too high → "جودة الصوت منخفضة — حاول في مكان هادئ"
- Whisper fails → "تعذر التحليل" — retry option

---
---

# System 5: Administration (S-ADM) — 20 P0

## UC-ADM-01: Father Creates Family (Onboarding)

| Field | Value |
|-------|-------|
| **Actor(s)** | Father |
| **Preconditions** | User registered (email/password); not already in a family |
| **Trigger** | User completes registration |
| **Services** | S-ADM-001, S-ADM-006 |
| **Screen(s)** | SCR-SHR-04 |

**Main Flow:**
1. After registration → system detects user has no family
2. System shows SCR-SHR-04 (Create Family onboarding)
3. Father enters: family name, country (SA default), language preference
4. System creates `family` record with owner=user
5. System creates `family_member` (role=admin)
6. System starts 14-day trial (S-ADM-038)
7. Father is guided to invite members (UC-ADM-02)

**Postconditions:** Family created; father is admin; trial started; ready to invite

---

## UC-ADM-02: Invite Family Members

| Field | Value |
|-------|-------|
| **Actor(s)** | Father only |
| **Preconditions** | Family exists; member count < 6 |
| **Trigger** | Father opens member management |
| **Services** | S-ADM-002, S-ADM-003, S-ADM-004 |
| **Screen(s)** | SCR-ADM-02 |

**Main Flow:**
1. Father opens SCR-ADM-02 → sees current members + "دعوة عضو جديد"
2. Father taps invite → enters: email, role (أم/ابن), permissions (for mother)
3. System creates `invitation` → generates Dynamic Link
4. System sends invite link (or father shares manually via WhatsApp/SMS)
5. Invitee opens link → installs app (if needed) → registers → sees invite
6. Invitee taps "قبول" → system adds to `family_members` → role applied
7. Father notified: "أم خالد انضمت للعائلة"

**Alt Flow — Decline:**
1. Invitee taps "رفض" → invitation status=declined; father notified

**Postconditions:** Member added to family with correct role and permissions
**Exceptions:**
- Family full (6 members) → "وصلت الحد الأقصى — ٦ أعضاء"
- Children full (4) → "وصلت الحد الأقصى — ٤ أطفال"
- Email already in another family → "هذا البريد مسجل في عائلة أخرى"

---

## UC-ADM-03: Link Child Device

| Field | Value |
|-------|-------|
| **Actor(s)** | Father (initiate), Child (complete) |
| **Preconditions** | Child member exists in family; child device available |
| **Trigger** | Father opens device management |
| **Services** | S-ADM-009, S-ADM-010, S-ADM-013 |
| **Screen(s)** | SCR-ADM-03 |

**Main Flow:**
1. Father opens SCR-ADM-03 → taps "ربط جهاز جديد"
2. System generates pairing code (6-digit, valid 15 minutes)
3. On child's device: child installs app → registers → enters pairing code
4. System verifies code → links device to child member
5. System triggers permission cascade on child device:
   - Accessibility Service → explain → grant
   - Usage Stats → explain → grant
   - Location (fine + background) → explain → grant
   - Overlay → explain → grant
   - Notifications → explain → grant
   - Device Admin → explain → grant
   - VPN (for Kill Switch) → explain → grant
6. Each permission: explanation screen → system request → granted/denied
7. All granted → device status = "ACTIVE" → monitoring starts
8. Father sees device in SCR-ADM-03 with status and last sync

**Postconditions:** Child device linked; permissions granted; monitoring active
**Exceptions:**
- Permission denied → device LINKED but DEGRADED; father sees ⚠️ with "صلاحيات ناقصة"
- Pairing code expired → "انتهت صلاحية الرمز — أنشئ رمزًا جديدًا"
- Device already linked to another child → "هذا الجهاز مربوط بطفل آخر"

---

## UC-ADM-04: Subscribe to Premium

| Field | Value |
|-------|-------|
| **Actor(s)** | Father only |
| **Preconditions** | Family exists; trial expired or active |
| **Trigger** | Father opens Premium screen or hits paywall |
| **Services** | S-ADM-014, S-ADM-016, S-ADM-038 |
| **Screen(s)** | SCR-ADM-04, SCR-ADM-11 |

**Main Flow:**
1. Father opens SCR-ADM-04 (or reaches paywall on premium feature)
2. System shows: current status (trial day X / expired / active), feature comparison (free vs premium)
3. Father taps "اشترك الآن — ٤٩ ر.س / شهر"
4. System launches Google Play Billing flow
5. User completes payment → billing token received
6. System calls `subscriptionManager` → activates subscription
7. All premium features unlock immediately
8. Father sees: "تم الاشتراك بنجاح! ✅"

**Trial Flow:**
1. Day 0: trial auto-starts on registration (all features active)
2. Day 11: FCM reminder "٣ أيام متبقية في الفترة التجريبية"
3. Day 14: trial expires → premium features gated → paywall shown

**Postconditions:** Subscription active; features unlocked; billing cycle started
**Exceptions:**
- Payment fails → "فشل الدفع — حاول مرة أخرى"
- Cancel: effective at period end; full access during remaining period

---

## UC-ADM-05: Configure Notifications

| Field | Value |
|-------|-------|
| **Actor(s)** | Father, Mother, Child |
| **Preconditions** | POST_NOTIFICATIONS granted |
| **Trigger** | User opens notification settings |
| **Services** | S-ADM-020, S-ADM-022, S-ADM-023 |
| **Screen(s)** | SCR-ADM-05 |

**Main Flow:**
1. User opens SCR-ADM-05 → sees notification categories:
   - رسائل جديدة (messages) ✅
   - تنبيهات أمان (safety alerts) ✅ — cannot disable for father
   - تعليم (education updates) ✅
   - تذكيرات (reminders) ✅
   - SOS 🔒 — always on, cannot be disabled by anyone
2. User toggles categories on/off per preference
3. User sets quiet hours (e.g., ١١ م — ٦ ص) — non-critical notifications suppressed
4. System saves `notification_preferences`

**Postconditions:** Notification preferences saved; quiet hours active
**Exceptions:** SOS notifications always delivered regardless of settings

---

## UC-ADM-06: Manage Settings and Language

| Field | Value |
|-------|-------|
| **Actor(s)** | All roles |
| **Preconditions** | User authenticated |
| **Trigger** | User opens settings |
| **Services** | S-ADM-026, S-ADM-027 |
| **Screen(s)** | SCR-ADM-06, SCR-SHR-06 |

**Main Flow:**
1. User opens SCR-ADM-06 → sees: family settings (father only), user settings (all), language, privacy
2. Language toggle: العربية / English → system switches direction (RTL/LTR), reloads UI
3. Father-only settings: calendar mode (Hijri primary/Gregorian primary), timezone, week start day
4. All users: theme, font size, auto-translate preference

**Postconditions:** Settings saved to `family_settings` / `user_settings`; UI updated

---

## UC-ADM-07: Configure Child Privacy

| Field | Value |
|-------|-------|
| **Actor(s)** | Father only |
| **Preconditions** | Children exist in family |
| **Trigger** | Father opens child privacy settings |
| **Services** | S-ADM-028 |
| **Screen(s)** | SCR-ADM-07 |

**Main Flow:**
1. Father opens SCR-ADM-07 → sees privacy settings per child:
   - حفظ نصوص الرسائل: ❌ (off — only sentiment stored)
   - مستوى شفافية الابن: منخفض (child sees simplified version of what parents see)
   - مدة الاحتفاظ بالبيانات: 90 يوم (default)
2. Father adjusts settings → saves
3. System updates `privacy_settings`

**Postconditions:** Privacy boundaries configured; system enforces
**Exceptions:** Mother cannot access this screen (father-exclusive)

---

## UC-ADM-08: Export and Delete Data

| Field | Value |
|-------|-------|
| **Actor(s)** | Father, Mother |
| **Preconditions** | Family exists |
| **Trigger** | User opens data management |
| **Services** | S-ADM-029 |
| **Screen(s)** | SCR-ADM-08 |

**Main Flow (Export):**
1. User opens SCR-ADM-08 → taps "تصدير البيانات"
2. Selects scope: family data / my data only
3. System creates async export job → FCM when ready (up to 24h)
4. User downloads JSON+ZIP file (valid 24 hours)

**Main Flow (Delete):**
1. User taps "حذف حسابي" → confirmation: "سيتم حذف كل بياناتك بعد ٣٠ يومًا"
2. User types "حذف" to confirm
3. System starts 30-day grace period → data marked for deletion
4. After 30 days: hard delete from all stores (Cloud SQL, Firestore, Storage, Pinecone)
5. Father deleting → family dissolution warning: other members notified

**Postconditions:** Data exported/scheduled for deletion; GDPR/PDPL compliant

---

## UC-ADM-09: Today Dashboard

| Field | Value |
|-------|-------|
| **Actor(s)** | Father, Mother |
| **Preconditions** | At least one child linked |
| **Trigger** | Parent opens app (home screen) |
| **Services** | S-ADM-033 |
| **Screen(s)** | SCR-ADM-09 |

**Main Flow:**
1. Parent opens app → SCR-ADM-09 (Today Dashboard) is home screen
2. Dashboard shows:
   - **Child profile switcher** at top (if multiple children)
   - **Live chips**: location (with geofence name), battery %, online/offline, screen time remaining
   - **Needs attention** cards: pending extra-time requests, unreviewed content alerts, ungraded assignments
   - **Instant actions**: اتصال (call), حدد موقع (locate), قفل (lock), SOS
   - **Today's schedule**: school times, assignment due dates, calendar events
3. Parent taps any card → navigates to relevant detail screen

**Postconditions:** Parent has complete real-time view of family state in one screen

---

## UC-ADM-10: School Schedule (Hijri)

| Field | Value |
|-------|-------|
| **Actor(s)** | Father |
| **Preconditions** | Child exists |
| **Trigger** | Father configures school schedule |
| **Services** | S-ADM-035 |
| **Screen(s)** | SCR-ADM-10 |

**Main Flow:**
1. Father opens SCR-ADM-10 → Hijri week grid
2. Father sets per day: school start time, school end time, breaks
3. Father assigns subjects to periods (optional)
4. System creates `school_time_schedule` records
5. Schedule feeds into School Time mode (S-PAR-052) and Calendar

**Postconditions:** School schedule configured; feeds into School Time enforcement

---

## UC-ADM-11: Trial Management

| Field | Value |
|-------|-------|
| **Actor(s)** | Father |
| **Preconditions** | Family in trial period |
| **Trigger** | Father opens trial status |
| **Services** | S-ADM-038 |
| **Screen(s)** | SCR-ADM-11 |

**Main Flow:**
1. Trial auto-starts on family creation (14 days, all features)
2. Father can check trial status in SCR-ADM-11:
   - Days remaining: ١١ يوم
   - Features active: all ✅
   - Usage stats: AI calls used, children monitored, focus sessions
3. Day 11: FCM reminder → "٣ أيام متبقية — اشترك لمتابعة الحماية والتعليم الذكي"
4. Day 14: trial expires → premium features gated → paywall shown on those features
5. Free features continue: chat, SOS, calendar, basic screen time, basic location

**Postconditions:** Trial tracked; reminders sent; graceful degradation to free tier

---
---

# Cross-System Use Cases

## UC-CROSS-01: Geofence → Chat → Notification → Dashboard

| Field | Value |
|-------|-------|
| **Actor(s)** | System (trigger), Father/Mother (consume) |
| **Services** | S-PAR-014, S-PAR-032, S-COM-036 (system msg), S-ADM-020, S-ADM-033 |

**Flow:**
1. Child enters/exits geofence → `geofence.entered`/`geofence.exited` event
2. System creates `geofence_event` record
3. System sends system message in family chat: "خالد وصل إلى المدرسة"
4. System sends FCM to father: "خالد وصل إلى المدرسة"
5. Today Dashboard updates child's location chip with geofence name

---

## UC-CROSS-02: Assignment → AI Grade → Notification → Dashboard

| Field | Value |
|-------|-------|
| **Actor(s)** | Child (submit), System (grade), Father (review) |
| **Services** | S-EDU-011, AI-004, S-EDU-013, S-ADM-020, S-ADM-033 |

**Flow:**
1. Child submits assignment → `assignment.submitted` event
2. AI grades → `assignment.graded` event
3. System sends notification to child: "تم تصحيح واجبك — ٨٥/١٠٠"
4. System sends notification to father: "تم تصحيح واجب خالد في الرياضيات"
5. Today Dashboard shows: "واجب خالد: ٨٥/١٠٠ — الرياضيات" in needs-attention (if low grade)

---

## UC-CROSS-03: Focus Mode → App Blocking → Screen Time → Dashboard

| Field | Value |
|-------|-------|
| **Actor(s)** | Child (activate), System (enforce), Father (monitor) |
| **Services** | S-EDU-034, S-PAR-015, S-PAR-001, S-PAR-034, S-ADM-033 |

**Flow:**
1. Child activates Focus Mode → `focus.activated` event
2. Safety domain blocks non-educational apps via AccessibilityService
3. Screen time accounting pauses during Focus (educational time doesn't count against limit)
4. Monitoring Hub shows child in Focus Mode with subject + remaining time
5. Today Dashboard shows: "🎯 خالد — تركيز — الرياضيات"
6. Focus ends → apps re-enabled → screen time resumes → XP awarded

---

## UC-CROSS-04: Screen Time Limit → Lock → Request → Approve → Unlock

| Field | Value |
|-------|-------|
| **Actor(s)** | Child, Father |
| **Services** | S-PAR-001, S-PAR-005, S-PAR-009, S-ADM-020 |

**Flow:**
1. Child reaches daily screen time limit → 5-minute grace warning
2. Grace expires → device locked (SCR-PAR-03)
3. Child taps "طلب وقت إضافي" → enters reason + amount
4. Father receives FCM → reviews request
5. Father approves → child device unlocks → extra time added
6. OR Father denies → child sees "لم تتم الموافقة"

---

## UC-CROSS-05: Subscription Expired → Feature Gating → Paywall

| Field | Value |
|-------|-------|
| **Actor(s)** | Father |
| **Services** | S-ADM-038, S-ADM-016, S-ADM-014 |

**Flow:**
1. Trial expires (day 14) or subscription lapses
2. System gates premium features:
   - AI screens show "اشترك لاستخدام الذكاء الاصطناعي"
   - Advanced monitoring (29 categories, Kill Switch) → paywall
   - Adaptive learning → paywall
3. Free features continue uninterrupted
4. Father opens any gated feature → SCR-ADM-04 paywall
5. Father subscribes → all features unlock immediately

---

*End of Use Cases. 91 P0 services covered across 5 systems + 5 cross-system flows.*

</content>
</invoke>