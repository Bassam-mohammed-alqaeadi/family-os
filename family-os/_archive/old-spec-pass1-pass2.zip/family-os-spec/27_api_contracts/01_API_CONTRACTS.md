---
title: "API Contracts — Cloud Functions & Endpoints"
tags: [api, contracts, backend, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification (Pass 2)
---

# API Contracts — Cloud Functions & Endpoints

> Every Cloud Function endpoint documented with input, output, auth, and error contracts.

---

## 1. API Architecture

```
Flutter App
    ↓ HTTPS (TLS 1.3)
Cloud Functions (Node.js)
    ↓
┌─────────────┬──────────────┬──────────────┐
│ Cloud SQL   │ Firestore    │ Redis        │
│ (PostgreSQL)│ (real-time)  │ (cache)      │
└─────────────┴──────────────┴──────────────┘
    ↓                                    ↓
┌──────────┐                    ┌──────────┐
│ Pinecone │                    │ Firebase │
│ (vector) │                    │ Storage  │
└──────────┘                    └──────────┘
```

**All endpoints:**
- Base URL: `https://<region>-<project>.cloudfunctions.net/<functionName>`
- Auth: Firebase ID token in `Authorization: Bearer <token>` header
- Content-Type: `application/json`
- Response format: `{ "status": "ok"|"error", "data": {...}, "error": {...} }`
- Rate limit: 100 req/min per user (except SOS: 10/hour)
- Idempotency: `X-Request-Id` header on all mutations

---

## 2. Authentication & Family

### 2.1 messageSender

| Field | Value |
|-------|-------|
| Method | POST |
| Path | `/messageSender` |
| Auth | Firebase ID token |
| Rate | 30/min |

**Request:**
```json
{
  "conversation_id": "uuid",
  "body": "نص الرسالة",
  "message_type": "text"|"voice"|"image"|"file"|"system",
  "reply_to_id": "uuid|null",
  "attachment_url": "gs://...|null",
  "idempotency_key": "uuid"
}
```

**Response (200):**
```json
{
  "status": "ok",
  "data": {
    "message_id": "uuid",
    "sent_at": "2026-09-13T10:00:00Z",
    "sent_at_hijri": "١٤٤٧/٣/١٥"
  }
}
```

**Errors:**
| Code | Error | Cause |
|------|-------|-------|
| 401 | `unauthorized` | Invalid/expired token |
| 403 | `not_member` | User not in conversation's family |
| 403 | `chat_locked` | Conversation locked by father |
| 429 | `rate_limited` | >30 messages/min |

### 2.2 createFamily

| Field | Value |
|-------|-------|
| Method | POST |
| Auth | Firebase ID token (must not already be in a family) |

**Request:**
```json
{
  "family_name": "عائلة الخالد",
  "country_code": "SA",
  "locale": "ar_SA",
  "hijri_enabled": true
}
```

**Response (200):**
```json
{
  "status": "ok",
  "data": {
    "family_id": "uuid",
    "trial_started": true,
    "trial_expires_at": "2026-09-27T10:00:00Z"
  }
}
```

### 2.3 inviteMember

| Field | Value |
|-------|-------|
| Method | POST |
| Auth | Father only |

**Request:**
```json
{
  "email": "umm.khalid@example.com",
  "role": "limited_admin",
  "permissions": {
    "view_content_alerts": true,
    "create_assignments": true,
    "grade_assignments": true,
    "view_all_children": true
  }
}
```

**Response (200):**
```json
{
  "status": "ok",
  "data": {
    "invitation_id": "uuid",
    "invite_link": "https://familyapp.page.link/invite?code=...",
    "expires_at": "2026-09-20T10:00:00Z"
  }
}
```

---

## 3. AI Endpoints

### 3.1 aiOrchestrator

| Field | Value |
|-------|-------|
| Method | POST |
| Auth | Firebase ID token |
| Rate | Free: 30/day, Premium: unlimited |

**Request:**
```json
{
  "feature": "assistant"|"tutor"|"grading"|"recommendation"|"translation"|"sentiment"|"recitation",
  "input": {
    "message": "ساعدني في تنظيم جدول اليوم",
    "context": { "conversation_id": "uuid" }
  },
  "user_id": "uuid"
}
```

**Response (200):**
```json
{
  "status": "ok",
  "data": {
    "response": "بالتأكيد! إليك اقتراح لتنظيم...",
    "metadata": {
      "model": "gemini-2.5-flash",
      "input_tokens": 150,
      "output_tokens": 200,
      "cost_usd": 0.00007,
      "safety_filtered": false
    }
  }
}
```

**Errors:**
| Code | Error | Cause |
|------|-------|-------|
| 429 | `rate_limited` | Daily limit exceeded |
| 429 | `ai_cost_exceeded` | Family AI cost cap exceeded |
| 503 | `ai_unavailable` | Gemini API down |
| 403 | `feature_locked` | Trial expired, feature is premium |

### 3.2 voiceTranscriber

| Field | Value |
|-------|-------|
| Method | POST |
| Auth | Firebase ID token |

**Request:**
```json
{
  "audio_url": "gs://bucket/voice/uuid.m4a",
  "language": "ar"
}
```

**Response (200):**
```json
{
  "status": "ok",
  "data": {
    "transcribed_text": "مرحبا كيف حالك",
    "confidence": 0.95,
    "duration_ms": 15000
  }
}
```

### 3.3 quranAnalyzer

| Field | Value |
|-------|-------|
| Method | POST |
| Auth | Firebase ID token |

**Request:**
```json
{
  "audio_url": "gs://bucket/quran/uuid.m4a",
  "surah_number": 1,
  "from_ayah": 1,
  "to_ayah": 7
}
```

**Response (200):**
```json
{
  "status": "ok",
  "data": {
    "accuracy_percent": 87,
    "errors": [
      { "ayah": 3, "type": "missing", "detail": "آية ٣ غير مكتملة" },
      { "ayah": 5, "type": "tajweed", "detail": "مدّ حرف المد في 'الصراط' غير كافٍ" }
    ],
    "feedback": "أحسنت! تلاوة جيدة. راجع الآية ٣ ومدّ حروف المد في الآية ٥.",
    "passed": true,
    "audio_deleted": true
  }
}
```

---

## 4. Safety Endpoints

### 4.1 locationUpdater

| Field | Value |
|-------|-------|
| Method | POST |
| Auth | Firebase ID token (child device) |
| Rate | 1/30sec (balanced mode) |

**Request:**
```json
{
  "lat": 24.7136,
  "lng": 46.6753,
  "accuracy": 10,
  "speed": 0,
  "battery": 85,
  "timestamp": "2026-09-13T10:00:00Z"
}
```

**Response (200):**
```json
{
  "status": "ok",
  "data": {
    "geofence_events": [
      { "geofence_id": "uuid", "event": "entered", "name": "المنزل" }
    ]
  }
}
```

### 4.2 killSwitchHandler

| Field | Value |
|-------|-------|
| Method | POST |
| Auth | Father only |

**Request:**
```json
{
  "child_user_id": "uuid",
  "action": "activate"|"deactivate",
  "duration_minutes": 60 | null
}
```

**Response (200):**
```json
{
  "status": "ok",
  "data": {
    "active": true,
    "activated_at": "2026-09-13T10:00:00Z",
    "deactivates_at": "2026-09-13T11:00:00Z"
  }
}
```

### 4.3 emergencyHandler (SOS)

| Field | Value |
|-------|-------|
| Method | POST |
| Auth | Firebase ID token (child) |
| Rate | 10/hour |
| Priority | HIGHEST — bypasses all queues |

**Request:**
```json
{
  "type": "sos"|"crash",
  "lat": 24.7136,
  "lng": 46.6753,
  "accuracy": 10,
  "battery": 85,
  "triggered_at": "2026-09-13T10:00:00Z"
}
```

**Response (200):**
```json
{
  "status": "ok",
  "data": {
    "emergency_id": "uuid",
    "notified_parents": ["father_uid", "mother_uid"],
    "auto_call_initiated": true
  }
}
```

---

## 5. Education Endpoints

### 5.1 aiGrader

| Field | Value |
|-------|-------|
| Method | POST |
| Auth | Firebase ID token |
| Trigger | Pub/Sub (after assignment submission) |

**Request:**
```json
{
  "submission_id": "uuid",
  "assignment_id": "uuid",
  "answers": [
    { "question_id": "uuid", "answer": "باريس" },
    { "question_id": "uuid", "answer": "٤٥" }
  ]
}
```

**Response (200):**
```json
{
  "status": "ok",
  "data": {
    "grade": 85,
    "total_points": 100,
    "per_question": [
      { "question_id": "uuid", "correct": true, "points": 50, "feedback": "إجابة صحيحة!" },
      { "question_id": "uuid", "correct": false, "points": 35, "feedback": "الإجابة الصحيحة هي ٤٥. تذكر: ٩ × ٥ = ٤٥" }
    ],
    "general_feedback": "أداء جيد! راجع جدول الضرب في ٩.",
    "graded_by": "AI",
    "graded_at": "2026-09-13T10:00:05Z"
  }
}
```

### 5.2 submitAssignment

| Field | Value |
|-------|-------|
| Method | POST |
| Auth | Firebase ID token (child) |

**Request:**
```json
{
  "assignment_id": "uuid",
  "answers": [
    { "question_id": "uuid", "answer": "باريس" },
    { "question_id": "uuid", "answer": "٤٥" }
  ],
  "attachment_url": "gs://...|null",
  "idempotency_key": "uuid"
}
```

**Response (200):**
```json
{
  "status": "ok",
  "data": {
    "submission_id": "uuid",
    "status": "submitted",
    "grading_status": "pending_ai",
    "submitted_at": "2026-09-13T10:00:00Z"
  }
}
```

---

## 6. Administration Endpoints

### 6.1 subscriptionManager

| Field | Value |
|-------|-------|
| Method | POST |
| Auth | Father only |

**Request (activate):**
```json
{
  "action": "activate"|"cancel"|"check_status",
  "play_billing_token": "...|null",
  "plan": "premium"
}
```

**Response (200):**
```json
{
  "status": "ok",
  "data": {
    "subscription_status": "active",
    "plan": "premium",
    "current_period_end": "2026-10-13T10:00:00Z",
    "auto_renew": true
  }
}
```

### 6.2 todayDashboard

| Field | Value |
|-------|-------|
| Method | GET |
| Auth | Firebase ID token (father/mother) |

**Response (200):**
```json
{
  "status": "ok",
  "data": {
    "children": [
      {
        "user_id": "uuid",
        "display_name": "خالد",
        "avatar_url": "gs://...",
        "online": true,
        "battery": 85,
        "location": {
          "lat": 24.7136, "lng": 46.6753,
          "freshness": "2 min ago",
          "geofence_name": "المنزل"
        },
        "screen_time": {
          "used_today": 120,
          "limit_today": 180,
          "remaining": 60
        },
        "education": {
          "xp": 1250,
          "level": 5,
          "assignments_pending": 2
        },
        "safety": {
          "alerts_unread": 0,
          "killswitch_active": false,
          "focus_active": false,
          "in_school": false
        }
      }
    ],
    "needs_attention": [
      { "type": "extra_time_request", "child": "خالد", "amount": 30 },
      { "type": "content_alert", "child": "فهد", "severity": "medium" }
    ],
    "today_schedule": [
      { "time": "14:00", "event": "حصة رياضيات — خالد", "type": "school" },
      { "time": "18:00", "event": "واجب علوم — خالد", "type": "assignment" }
    ]
  }
}
```

### 6.3 exportData

| Field | Value |
|-------|-------|
| Method | POST |
| Auth | Father or Mother |

**Request:**
```json
{
  "scope": "family"|"user",
  "user_id": "uuid|null"
}
```

**Response (202):**
```json
{
  "status": "ok",
  "data": {
    "export_id": "uuid",
    "estimated_ready_at": "2026-09-13T10:24:00Z",
    "format": "json+zip"
  }
}
```

> Export is async. FCM notification sent when ready. Download link valid 24 hours.

---

## 7. Error Code Reference

| Code | Error Type | Meaning | User-Facing Message |
|------|-----------|---------|-------------------|
| 400 | `bad_request` | Invalid input | "بيانات غير صحيحة" |
| 401 | `unauthorized` | Not authenticated | "يجب تسجيل الدخول" |
| 403 | `forbidden` | Not authorized | "لا تملك صلاحية لهذا الإجراء" |
| 403 | `not_member` | Not in family | "لست عضوًا في هذه العائلة" |
| 403 | `father_only` | Requires father role | "هذا الإجراء متاح للأب فقط" |
| 403 | `chat_locked` | Conversation locked | "هذه المحادثة مقفلة" |
| 403 | `feature_locked` | Premium feature, trial expired | "اشترك للوصول لهذه الميزة" |
| 404 | `not_found` | Resource doesn't exist | "غير موجود" |
| 409 | `conflict` | Sync conflict | "تعارض في البيانات" |
| 429 | `rate_limited` | Too many requests | "طلبات كثيرة، حاول لاحقًا" |
| 429 | `ai_cost_exceeded` | AI cost cap | "حد الذكاء الاصطناعي اليومي" |
| 500 | `internal_error` | Server error | "خطأ في الخادم، حاول لاحقًا" |
| 503 | `ai_unavailable` | AI service down | "الذكاء الاصطناعي غير متاح حاليًا" |
| 503 | `sync_in_progress` | Sync running | "جاري المزامنة..." |

---

## 8. Firestore Real-time Listeners

| Listener | Document Path | Subscribed By | Purpose |
|----------|--------------|---------------|---------|
| Family presence | `families/{id}/presence/{uid}` | All family members | Online/offline status |
| Live location | `families/{id}/locations/{uid}` | Father, Mother | Real-time GPS tracking |
| Typing indicator | `families/{id}/typing/{conv}:{uid}` | Conversation members | Typing status |
| Shopping list | `families/{id}/shopping_list/{item}` | All family members | Real-time shopping list |
| SOS active | `families/{id}/emergencies/{eid}` | Father, Mother | Live SOS tracking |
| Call signaling | `calls/{id}/signaling/{eid}` | Call participants | WebRTC signaling |

---

## 9. Webhook / Scheduled Functions

| Function | Schedule | Purpose |
|----------|----------|---------|
| `trialReminder` | Daily 09:00 UTC | Check trials expiring in 3 days → FCM |
| `trialExpiry` | Daily 09:00 UTC | Check expired trials → gate features |
| `weeklyReport` | Sunday 08:00 AST | Generate + send weekly family report |
| `bedtimeEnforcer` | Every minute | Check bedtime schedules → trigger lock |
| `schoolTimeEnforcer` | Every minute | Check school schedules → trigger mode |
| `geofenceMonitor` | Event-driven | Process geofence transitions → notifications |
| `costTracker` | Daily 00:00 UTC | Aggregate AI costs per family |
