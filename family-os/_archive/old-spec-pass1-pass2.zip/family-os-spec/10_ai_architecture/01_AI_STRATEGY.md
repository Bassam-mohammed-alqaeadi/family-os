---
title: "AI Strategy & Architecture"
tags: [ai, architecture, strategy, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification
---

# AI Strategy & Architecture

> AI is the differentiating backbone — not a chatbot. It makes the platform smart: translates, grades, analyzes sentiment, recommends, memorizes Quran, acts as tutor. All in Arabic.

---

## 1. AI Capability Classification

| Type | Capabilities | Purpose |
|------|-------------|---------|
| **Assistive AI** | AI-001 (Assistant) | Help users with questions, reminders, summaries |
| **Predictive AI** | AI-020 (Recommendations), AI-022 (Pattern analysis P1) | Predict what the user needs next |
| **Detection AI** | AI-002 (Sentiment), AI-009 (Sensitive content P1) | Detect risks and patterns |
| **Recommendation AI** | AI-007 (Edu recommendations), AI-020 | Recommend content, actions, behaviors |
| **Family Insights** | AI-006 (Behavior analysis P1), AI-011 (Summarization P1) | Aggregate insights for parents |
| **Safety Intelligence** | AI-002, AI-009 | Keep children safe through intelligent monitoring |
| **Automation** | AI Orchestrator | Rate limit, RAG, safety filter, logging — all automated |
| **Natural Language Interface** | AI-001, AI-003, AI-015 (Voice P1) | Conversational interface in Arabic |

---

## 2. AI Model Stack

| Capability | Model | Provider | Cost |
|-----------|-------|----------|------|
| AI Assistant + Tutor + Grading | Gemini 2.5 Flash | Google | $0.07/M input, $0.29/M output |
| Sentiment analysis | Gemini 2.5 Flash | Google | Same |
| Quran recitation STT | Whisper | OpenAI | $0.006/min |
| Quran recitation analysis | Gemini 2.5 Flash | Google | Same |
| Translation | Gemini 2.5 Flash | Google | Same (cached in Redis) |
| Content classification | Gemini 2.5 Flash | Google | Same |
| Embeddings | text-embedding-004 | Google | $0.006/M tokens |
| Vector store | Pinecone | Pinecone | Usage-based |
| Cache | Redis | — | Low cost |

**Estimated AI cost per premium user: $2–4/month** — covered by subscription.

---

## 3. AI Orchestrator (Infrastructure)

Every AI call flows through the AI Orchestrator:

```
User Request
    ↓
[1] Rate Limit Check (Redis) — plan-based limits
    ↓
[2] RAG Context Retrieval (Pinecone) — if applicable
    ↓
[3] Prompt Construction (system prompt + RAG context + user message)
    ↓
[4] Gemini API Call (or Whisper for audio)
    ↓
[5] Safety Filter (Gemini safety settings + custom)
    ↓
[6] Response to User
    ↓
[7] Log: ai_usage_logs + ai_cost_tracking
```

---

## 4. P0 AI Capabilities (Detailed)

### AI-001: Family AI Assistant

| Attribute | Value |
|-----------|-------|
| Input | User message (text) + family context (RAG) |
| Model | Gemini 2.5 Flash, temp=0.7 |
| Output | Conversational response in user's language |
| Confidence | Not applicable (conversational) |
| Failure | "عذرًا، لم أتمكن من الرد. حاول مرة أخرى." |
| Privacy | Conversation stored 90 days; no other family data exposed |
| Offline | Unavailable — requires online |
| Human override | N/A (advisory only) |
| Explainability | Responses are self-explanatory |
| Audit | ai_conversations + ai_messages + ai_usage_logs |

### AI-002: Sentiment Analysis

| Attribute | Value |
|-----------|-------|
| Input | Message text (transient — NOT stored in AI logs) |
| Model | Gemini 2.5 Flash, temp=0.3 |
| Output | sentiment (positive/neutral/sad/angry/anxious/excited/bullying_risk), intensity (0-1) |
| Confidence | Intensity score 0–1 |
| Failure | Log as "neutral"; do not block message |
| Privacy | **NO message text stored in sentiment_logs** — only result |
| Offline | Queued; processed when online |
| Human override | Father can dismiss alert |
| Explainability | Category + recommendation shown to parent |
| Audit | sentiment_logs + FCM alert if bullying_risk=true |
| Alert rule | 3 consecutive negative sentiments in 24h → parent alert |

### AI-003: AI Private Tutor

| Attribute | Value |
|-----------|-------|
| Input | Student question + subject context + last 10 messages |
| Model | Gemini 2.5 Flash, temp=0.6, Socratic method |
| Output | Guided explanation (NOT direct answer) + challenge question |
| Confidence | N/A |
| Failure | "لم أتمكن من الشرح. حاول بصياغة مختلفة." |
| Privacy | Session stored 90 days |
| Offline | Unavailable |
| Human override | Student can skip; parent can review sessions |
| Explainability | Socratic — explanation is the output |
| Audit | ai_tutor_sessions |

### AI-004: Auto Assignment Grading

| Attribute | Value |
|-----------|-------|
| Input | Assignment submission (answers) + correct answers + rubric |
| Model | Gemini 2.5 Flash, temp=0.2 |
| Output | Grade (0-100), per-question feedback, suggested improvement |
| Confidence | Grade + feedback quality |
| Failure | Fallback to manual grading (father); log error |
| Privacy | Submission content processed; not stored in AI logs |
| Offline | Queued |
| Human override | Father can override grade (S-EDU-014) |
| Explainability | Per-question feedback provided |
| Audit | assignment_submissions (grade + feedback + graded_by="AI") |
| Target | <10 seconds grading time |

### AI-007/020: Educational Recommendations

| Attribute | Value |
|-----------|-------|
| Input | User's learning progress + skill gaps + placement test + adaptive state |
| Model | Gemini 2.5 Flash + Pinecone similarity search |
| Output | Recommended lesson/exercise/video + reason ("will help with division") |
| Confidence | Reason explanation provided |
| Failure | No recommendation shown; logged |
| Privacy | Learning data used; no message content |
| Offline | Unavailable |
| Human override | Student can dismiss; father can apply/dismiss |
| Explainability | Each recommendation includes a reason |
| Audit | ai_recommendations (status tracked: generated→shown→accepted/dismissed/expired) |

### AI-008: Quran Recitation Analysis

| Attribute | Value |
|-----------|-------|
| Input | Audio recording (M4A) + target surah text |
| Model | Whisper (STT) → Gemini (analysis) |
| Output | accuracy_percent, errors (missing/wrong/extra/tajweed), feedback |
| Confidence | accuracy_percent (0–100) |
| Failure | "تعذّر التحليل. حاول مرة أخرى." Audio deleted regardless |
| Privacy | **Audio deleted after analysis** — never stored permanently |
| Offline | Unavailable (requires Whisper + Gemini) |
| Human override | Student can retry; parent sees progress only |
| Explainability | Specific errors listed (e.g., "مدّ حرف المد في 'الكهفِ' غير كافٍ") |
| Audit | quran_memorization (progress, status) |
| Pass threshold | accuracy ≥80% → memorized |

---

## 5. AI Safety Principles

| Principle | Implementation |
|-----------|---------------|
| AI serves, not decides | AI never makes autonomous safety decisions (e.g., cannot block apps, lock device, activate Kill Switch) |
| Human override always | Every AI recommendation can be dismissed/overridden by human |
| No raw child text in AI logs | Sentiment logs store result only, not input text |
| Audio deleted after processing | Quran recitation audio deleted after analysis |
| Cost transparency | ai_cost_tracking per family per day |
| Rate limiting | Plan-based limits prevent abuse and control cost |
| Child-appropriate | AI responses filtered for child-appropriate content |
| No sensitive content retrieval | RAG excludes sensitive content (similarity threshold >0.75) |

---

## 6. AI Cost Management

| Metric | Target |
|--------|--------|
| Cost per premium user/month | < $4 |
| Cost per free user/month | < $0.50 |
| Gemini calls per user/day (avg) | < 20 |
| Whisper calls per user/day (avg) | < 2 |
| Cache hit rate (translation) | > 60% |
| RAG retrieval accuracy | > 0.75 similarity threshold |

### Cost Control Mechanisms

1. Rate limits per plan (free/family/premium)
2. Redis caching for translations (1hr TTL)
3. Batch sentiment analysis (process every Nth message, not all)
4. Adaptive learning: local computation for level transitions; Gemini only for content generation
5. Fallback to Gemini Flash-Lite if cost rises
