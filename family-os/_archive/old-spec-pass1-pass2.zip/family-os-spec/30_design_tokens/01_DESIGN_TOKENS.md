---
title: "Design Tokens — Complete Reference"
tags: [design, tokens, system, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification (Pass 2)
---

# Design Tokens — Complete Reference

> The single source of truth for all design system values. Every token is named, valued, and documented with usage rules.

---

## 1. Color Tokens

### 1.1 Primary (Jade)

| Token | Hex | Usage |
|-------|-----|-------|
| `--jade-900` | `#0D4A3F` | Dark backgrounds, covers, splash |
| `--jade-700` | `#1B6B5A` | Primary buttons, active nav, headers |
| `--jade-600` | `#2A9D8F` | Links, secondary buttons, toggle on |
| `--jade-500` | `#3DB89E` | Hover states, confirmation accents |
| `--jade-100` | `#D4F0EC` | Pale card backgrounds, selected chips |
| `--jade-50` | `#EEF8F6` | Transparent overlays, subtle backgrounds |

### 1.2 Accent (Coral)

| Token | Hex | Usage |
|-------|-----|-------|
| `--coral-700` | `#C25230` | Coral text on light backgrounds |
| `--coral-600` | `#E76F51` | Distinguished actions, mother's accent |
| `--coral-500` | `#F0916F` | Coral hover, secondary accent |

### 1.3 AI (Violet)

| Token | Hex | Usage |
|-------|-----|-------|
| `--violet-700` | `#5B21B6` | AI text on light backgrounds |
| `--violet-600` | `#7C3AED` | AI buttons, AI feature indicators, AI chat bubbles |

### 1.4 Semantic

| Token | Hex | Usage |
|-------|-----|-------|
| `--success` | `#10B981` | Success states, completed tasks, online indicators |
| `--danger` | `#EF4444` | SOS, errors, destructive actions, delete |
| `--warning` | `#F59E0B` | Warnings, trial expiry warnings, pending approvals |
| `--info` | `#3B82F6` | Informational badges (didactic only — NOT for primary actions) |

### 1.5 Ink (Neutrals)

| Token | Hex | Usage |
|-------|-----|-------|
| `--ink-900` | `#0F172A` | Primary text, headings |
| `--ink-700` | `#1E293B` | Secondary text, body |
| `--ink-500` | `#64748B` | Tertiary text, captions, timestamps |
| `--ink-300` | `#CBD5E1` | Disabled text, borders, dividers |
| `--ink-100` | `#F1F5F9` | Subtle backgrounds, disabled backgrounds |
| `--ink-50` | `#F8FAFC` | **Screen background (MANDATORY)** |

### 1.6 Surface

| Token | Hex | Usage |
|-------|-----|-------|
| `--paper` | `#FFFFFF` | Card backgrounds, bottom nav, status bar |
| `--overlay` | `rgba(0,0,0,0.4)` | Modal/scrim backgrounds |

---

## 2. Typography Tokens

### 2.1 Font Families

| Token | Family | Usage |
|-------|--------|-------|
| `--font-display` | `'Cairo', sans-serif` | Headings, titles, large numbers |
| `--font-body` | `'IBM Plex Arabic', sans-serif` | Body text, descriptions, labels |
| `--font-numbers` | `'Tajawal', sans-serif` | Numbers, stats, timestamps, counters |

### 2.2 Font Sizes

| Token | Size | Line Height | Usage |
|-------|------|-------------|-------|
| `--text-xs` | 12px | 16px | Captions, timestamps, badges |
| `--text-sm` | 14px | 20px | Secondary text, field labels |
| `--text-base` | 16px | 24px | Body text (default) |
| `--text-lg` | 18px | 26px | Card titles, list items |
| `--text-xl` | 20px | 28px | Section headers |
| `--text-2xl` | 24px | 32px | Screen titles |
| `--text-3xl` | 30px | 38px | Hero numbers, dashboard stats |
| `--text-4xl` | 36px | 44px | Splash title, onboarding headlines |

### 2.3 Font Weights

| Token | Weight | Usage |
|-------|--------|-------|
| `--fw-normal` | 400 | Body text |
| `--fw-medium` | 500 | Labels, secondary emphasis |
| `--fw-semibold` | 600 | Buttons, card titles |
| `--fw-bold` | 700 | Screen titles, section headers |
| `--fw-extrabold` | 800 | Hero numbers, splash |
| `--fw-black` | 900 | Display only (rare) |

---

## 3. Spacing Tokens

| Token | Value | Usage |
|-------|-------|-------|
| `--sp-1` | 4px | Tight gaps within components |
| `--sp-2` | 8px | Component internal padding, icon gaps |
| `--sp-3` | 12px | Small card padding, list item gaps |
| `--sp-4` | 16px | Card padding, standard gap (DEFAULT) |
| `--sp-5` | 24px | Section gaps, large card padding |
| `--sp-6` | 32px | Screen edge padding, large section gaps |
| `--sp-7` | 48px | Major section separation |
| `--sp-8` | 64px | Page-level vertical rhythm |

---

## 4. Geometry Tokens

### 4.1 Corner Radius

| Token | Value | Usage |
|-------|-------|-------|
| `--radius-sm` | 8px | Small badges, chips, tags |
| `--radius-md` | 14px | Cards, buttons, input fields (DEFAULT) |
| `--radius-lg` | 20px | Large cards, bottom sheets |
| `--radius-xl` | 28px | Covers, hero images, splash |
| `--radius-full` | 9999px | Circular avatars, badges, FAB |

### 4.2 Borders

| Token | Value | Usage |
|-------|-------|-------|
| `--border-light` | 1px solid `--ink-100` | Card borders (when no shadow) |
| `--border-default` | 1px solid `--ink-300` | Input field borders |
| `--border-focus` | 2px solid `--jade-600` | Focused input fields |

---

## 5. Shadow Tokens

| Token | Value | Usage |
|-------|-------|-------|
| `--sh-1` | `0 1px 3px rgba(0,0,0,.06)` | Flat cards, list items |
| `--sh-2` | `0 2px 8px rgba(0,0,0,.08)` | Standard cards (DEFAULT) |
| `--sh-3` | `0 8px 24px rgba(0,0,0,.12)` | Dialogs, bottom sheets |
| `--sh-4` | `0 16px 48px rgba(0,0,0,.16)` | Covers, full-screen overlays |

> **Rule:** A card uses EITHER `--sh-2` OR `--border-light` — NEVER both (anti-slop rule #3).

---

## 6. Motion Tokens

| Token | Duration | Easing | Usage |
|-------|----------|--------|-------|
| `--motion-fade-up` | 600ms | `cubic-bezier(0.16, 1, 0.3, 1)` | Cards appearing |
| `--motion-slide` | 400ms | `cubic-bezier(0.16, 1, 0.3, 1)` | RTL navigation transitions |
| `--motion-scale` | 300ms | `cubic-bezier(0.16, 1, 0.3, 1)` | Dialogs, sheets |
| `--motion-pulse` | 2000ms ∞ | `ease-in-out` | SOS button, live indicators |
| `--motion-shimmer` | 1500ms ∞ | `linear` | Loading placeholders |
| `--motion-stagger` | 100–200ms | — | Staggered card entrance |

> **Limits:** No motion > 800ms for general elements. No parallax. No bounce (except SOS).

---

## 7. Component Tokens

### 7.1 Buttons

| Variant | Background | Text | Border | Height |
|---------|-----------|------|--------|--------|
| Primary | `--jade-700` | white | none | 48px |
| Coral | `--coral-600` | white | none | 48px |
| Violet (AI) | `--violet-600` | white | none | 48px |
| Outline | transparent | `--jade-700` | `--border-default` | 48px |
| Ghost | transparent | `--ink-700` | none | 48px |
| Danger | `--danger` | white | none | 48px |
| Small | same | same | same | 36px |
| Large | same | same | same | 56px |

### 7.2 Input Fields

| Property | Value |
|----------|-------|
| Height | 52px |
| Border (default) | `--border-default` |
| Border (focus) | `--border-focus` + subtle ring |
| Background | `--paper` |
| Label | Visible, above field, `--text-sm`, `--ink-500` |
| Error | `--danger` border + error text below |
| Corner radius | `--radius-md` (14px) |

### 7.2 Cards

| Property | Value |
|----------|-------|
| Background | `--paper` |
| Corner radius | `--radius-md` (14px) |
| Shadow OR border | `--sh-2` OR `--border-light` (never both) |
| Padding | `--sp-4` (16px) default |
| Gap between cards | `--sp-4` (16px) |

### 7.3 Bottom Navigation

| Property | Value |
|----------|-------|
| Height | 64px |
| Background | `--paper` |
| Active color | `--jade-700` |
| Inactive color | `--ink-500` |
| Icon size | 24px |
| Label | `--text-xs`, `--fw-medium` |

### 7.4 FAB (SOS)

| Property | Value |
|----------|-------|
| Size | 64px |
| Background | `--danger` |
| Icon | SOS text or phone icon |
| Position | Bottom-start, 16px from edges |
| Animation | `--motion-pulse` (always pulsing) |
| Trigger | Hold 3 seconds |
| Visibility | Child role only, on every screen |

### 7.5 Chat Bubbles

| Property | Outgoing | Incoming |
|----------|----------|----------|
| Background | `--jade-500` | `--paper` + `--border-light` |
| Text color | white | `--ink-900` |
| Corner radius | 14px (notch on sender side) | 14px (notch on receiver side) |
| Max width | 75% of screen | 75% of screen |
| Timestamp | `--text-xs`, `--ink-500` | `--text-xs`, `--ink-500` |
| AI bubble | `--violet-600` bg, white text | — |

---

## 8. Icon Tokens

| Property | Value |
|----------|-------|
| Icon set | Phosphor Icons (Regular) |
| Default size | 24px |
| Small size | 20px |
| Large size | 32px |
| Stroke width | 1.5 |
| Color | Inherit from parent text color |
| In buttons | Match button text color |

> **Rule:** NO emoji in production UI (except inside chat message bubbles). Use SVG icons only.

---

## 9. State Tokens

### 9.1 Loading (Shimmer)

| Property | Value |
|----------|-------|
| Base color | `--ink-100` |
| Highlight color | `--ink-50` |
| Animation | `--motion-shimmer` (1500ms infinite) |
| Shape | Match the component being loaded |

### 9.2 Empty State

| Element | Specification |
|---------|--------------|
| Illustration | Simple SVG, 120×120px, `--ink-300` stroke |
| Title | `--text-lg`, `--fw-semibold`, `--ink-700` |
| Description | `--text-sm`, `--ink-500`, max 2 lines |
| Action button | Primary or outline, contextual |

### 9.3 Error State

| Element | Specification |
|---------|--------------|
| Icon | Warning SVG, `--danger` color, 48px |
| Title | `--text-lg`, `--fw-semibold`, `--ink-900` |
| Message | `--text-sm`, `--ink-500`, with specific error detail |
| Retry button | Primary, "إعادة المحاولة" |

### 9.4 Permission Denied

| Element | Specification |
|---------|--------------|
| Icon | Lock/shield SVG, `--warning` color, 48px |
| Title | `--text-lg`, `--fw-semibold`, `--ink-900` |
| Explanation | `--text-sm`, `--ink-500`, specific to the permission |
| Action | "فتح الإعدادات" (Open Settings) button |

### 9.5 Locked (Child)

| Element | Specification |
|---------|--------------|
| Overlay | Semi-transparent `--jade-900` (40% opacity) |
| Icon | Lock SVG, white, 48px |
| Message | White text, explaining why feature is locked |
| Action | "طلب صلاحية" (Request access) if applicable |

### 9.6 Trial Expired

| Element | Specification |
|---------|--------------|
| Banner | `--warning` background, full width, 48px height |
| Icon | Clock/crown SVG |
| Message | "انتهت الفترة التجريبية — اشترك للمتابعة" |
| Action | "اشترك الآن" button → SCR-ADM-04 |

---

## 10. Localization Tokens

| Token | Value | Notes |
|-------|-------|-------|
| `--locale-default` | `ar_SA` | Arabic (Saudi Arabia) |
| `--locale-secondary` | `en_US` | English (US) |
| `--direction-default` | `rtl` | Right-to-left |
| `--direction-alt` | `ltr` | Left-to-right (English) |
| `--calendar-default` | `hijri` | Umm al-Qura calendar |
| `--calendar-secondary` | `gregorian` | Standard |
| `--currency` | `SAR` | Saudi Riyal |
| `--timezone-default` | `Asia/Riyadh` | UTC+3 |
