# Requirements Coverage Audit Matrix — World-Class Family OS

> **Document ID:** 01_REQUIREMENTS_COVERAGE_MATRIX
> **Scope:** 91 P0 requirements across 5 systems (S-COM, S-PAR, S-EDU, AI, S-ADM)
> **Purpose:** Full traceability — every P0 requirement traced to its Service, Domain, Capability, Priority, Screen(s), Workflow(s), Data Entity(ies), Event(s), Permission, Test Scenario, and Coverage Status.
> **Language note:** Service names preserved in Arabic (product language). Structural labels in English for audit readability.
> **Roles:** Father (admin — ALL permissions) · Mother (limited_admin — Father screens minus 8 exclusive) · Child (child — restricted IA, SOS FAB on every screen)

---

## Legend

| Symbol | Meaning |
|---|---|
| ✅ Covered | Requirement has a defined screen, workflow, data entity, event, permission, and test scenario |
| 🟡 Partial | Requirement is addressed but one or more traceability dimensions are incomplete or underspecified |
| 🔴 Gap | Requirement is missing a critical traceability dimension (screen, data, workflow, or test) with no workaround |

**Coverage dimensions checked (per row):** Screen · Workflow · Data Entity · Event · Permission · Test Scenario

---

## System Index

| System | P0 Count | Section |
|---|---|---|
| S-COM — Communications | 20 | [§1](#1-s-com--communications-20-p0) |
| S-PAR — Monitoring | 20 | [§2](#2-s-par--monitoring-20-p0) |
| S-EDU — Education & Growth | 24 | [§3](#3-s-edu--education--growth-24-p0) |
| AI — Artificial Intelligence | 7 | [§4](#4-ai--artificial-intelligence-7-p0) |
| S-ADM — Administration & Commerce | 20 | [§5](#5-s-adm--administration--commerce-20-p0) |
| **Total** | **91** | |

---

## Coverage Summary (preliminary)

| Status | Count | % |
|---|---|---|
| ✅ Covered | 84 | 92.3% |
| 🟡 Partial | 6 | 6.6% |
| 🔴 Gap | 1 | 1.1% |

> Detailed gap analysis: see companion file `02_COVERAGE_GAPS_AND_RISKS.md`.

---

## 1. S-COM — Communications (20 P0)

**Domain:** Communications — conversations, messages, attachments, events, tasks, shopping, emergencies
**Default permission model:** All family members can chat; administrative actions (calendar event delete, SOS resolution) restricted.

| Req ID | Service Name (AR) | Domain | Capability | Priority | Screen(s) | Workflow(s) | Data Entity(ies) | Event(s) | Permission | Test Scenario | Status |
|---|---|---|---|---|---|---|---|---|---|---|---|
| S-COM-001 | محادثة عائلية جماعية | Communications | Group messaging — family-wide | P0 | Family Chat Screen | Open Family Chat → type message → send → all members receive → read receipts populate | conversations, conversation_members, messages, message_reads | message.sent, message.read | All family members (father, mother, child) | Verify a message sent by father is delivered to all family members and read receipts appear for each within 2s | ✅ Covered |
| S-COM-002 | محادثة فردية 1:1 | Communications | Direct private messaging | P0 | Direct Chat Screen | Select member → open 1:1 conversation → send message → only recipient sees it | conversations, conversation_members, messages, message_reads | message.sent, message.read | All family members | Verify a 1:1 message is visible only to the two participants and not surfaced in the family group | ✅ Covered |
| S-COM-003 | مجموعة فرعية | Communications | Sub-group creation & messaging | P0 | Group Chat Screen (sub-group) | Father/mother creates sub-group → selects subset of members → members chat privately | conversations, conversation_members, messages | message.sent | Father, Mother (create); selected members (participate) | Verify a sub-group with 2 of 4 family members keeps messages invisible to non-members | ✅ Covered |
| S-COM-004 | رد على رسالة | Communications | Threaded reply to message | P0 | Chat Screen (reply thread) | Long-press message → tap reply → compose reply → reply appears quoted above original | messages, message_reactions | message.sent | All family members | Verify a reply correctly quotes the parent message and links the thread | ✅ Covered |
| S-COM-006 | مكالمة صوت P2P | Communications | Peer-to-peer voice call | P0 | Voice Call Screen | Tap call icon on a 1:1 chat → ring recipient → connect → talk → hang up | conversations, messages (call metadata) | — (no `call.*` event defined) | All family members | Verify a P2P voice call connects between two devices and call metadata is logged | 🟡 Partial |
| S-COM-010 | وسائط | Communications | Media sharing (photo/video) | P0 | Media Viewer / Chat Screen (attachment picker) | Tap attachment → select photo/video → compress → upload → recipient previews inline | message_attachments, messages | message.sent | All family members | Verify a 5 MB photo is sent, displayed inline, and downloadable by recipient | ✅ Covered |
| S-COM-011 | تأكيد قراءة | Communications | Read receipt tracking | P0 | Chat Screen (read indicators) | Recipient opens message → `message_reads` row created → sender sees double-checkmark | message_reads, messages | message.read | All family members | Verify read receipt appears on sender device within 2s of recipient opening the message | ✅ Covered |
| S-COM-025 | إرسال ملف | Communications | File attachment sharing | P0 | Chat Screen (file picker) | Tap paperclip → select file → upload → recipient downloads | message_attachments, messages | message.sent | All family members | Verify a PDF document uploads, displays a file card, and downloads intact on recipient device | ✅ Covered |
| S-COM-029 | إرسال صوت | Communications | Voice message recording & send | P0 | Chat Screen (voice recorder) | Hold mic button → record audio → release → upload → recipient plays inline | message_attachments, voice_transcriptions, messages | voice.transcribed, message.sent | All family members | Verify a 10-second voice message records, sends, and plays back on recipient device | ✅ Covered |
| S-COM-030 | إضافة حدث تقويمي | Communications | Family calendar event creation | P0 | Family Calendar Screen (add event) | Open calendar → tap add → set title/date/time/reminder → save → event appears for all members | family_events | event.created | Father, Mother | Verify a new event appears on all family members' calendars and reminder fires at configured time | ✅ Covered |
| S-COM-031 | تعديل/حذف حدث | Communications | Calendar event edit & delete | P0 | Family Calendar Screen (event detail) | Open event → edit fields → save, or → delete → confirm → event removed for all | family_events | event.created (updated) | Father, Mother (edit/delete); Child (view only) | Verify an edit propagates to all members and a delete removes it from every calendar | ✅ Covered |
| S-COM-032 | تذكيرات/مهام | Communications | Family reminders & tasks | P0 | Tasks Screen | Create task → assign to member → set due date → assignee completes → marked done | family_tasks | task.created, task.completed | Father, Mother (create/assign); all (complete own) | Verify a task assigned to child appears on their Today board and completes when checked | ✅ Covered |
| S-COM-033 | قائمة تسوق مشتركة | Communications | Shared shopping list | P0 | Shopping List Screen | Add item → all members see it → any member checks off → item marked purchased | shopping_list_items | task.completed (generic) | All family members | Verify an item added by mother appears on father's and child's list and checks off in real time | ✅ Covered |
| S-COM-035 | بث موقع لحظي | Communications | Live location broadcast | P0 | Live Location Screen / Map | User taps share location → GPS stream begins → family sees moving pin → stop sharing | locations | location.broadcast | All family members (opt-in) | Verify a live location pin updates on family map within 5s and stops when user ends share | ✅ Covered |
| S-COM-036 | استطلاعات | Communications | Polls & family voting | P0 | Poll Screen (in-chat) | Create poll → add options → send → members vote → results tally live | — (no `polls` / `poll_votes` table defined) | — (no `poll.*` event defined) | Father, Mother (create); all (vote) | Verify a poll with 3 options tallies votes correctly and shows percentages to all members | 🔴 Gap |
| S-COM-039 | SOS + كشف حوادث | Communications | SOS alert & accident detection | P0 | SOS FAB (every child screen) / Emergency Dashboard (parent) | Child taps SOS FAB → emergency_events row created → all parents notified with location → parents acknowledge → resolved | emergency_events, locations | sos.activated, sos.resolved | Child (trigger); Father, Mother (resolve) | Verify SOS from child device alerts all parents within 3s with live GPS and resolves on parent acknowledge | ✅ Covered |
| S-COM-041 | رسالة صوتية + تفريغ | Communications | Voice message with transcription | P0 | Chat Screen (voice message + transcript toggle) | Voice message sent → AI transcribes → recipient toggles transcript → reads text | voice_transcriptions, message_attachments, messages | voice.transcribed, message.sent | All family members | Verify a voice message produces an accurate Arabic transcript and toggles on/off on recipient device | ✅ Covered |
| S-COM-044 | ترجمة لحظية | Communications | Real-time message translation | P0 | Chat Screen (translation toggle) | Incoming message in foreign language → toggle translate → AR text replaces/overlays → toggle off to restore original | message_translations, messages | message.translated | All family members | Verify an English message is translated to Arabic on toggle and original restored on toggle off | ✅ Covered |
| S-COM-048 | ردود تفاعلية سريعة | Communications | Quick emoji reactions | P0 | Chat Screen (reaction picker) | Long-press message → pick emoji → reaction recorded → all members see it on message | message_reactions, messages | message.sent (reaction) | All family members | Verify a 👍 reaction appears on the message for all members and updates if changed | ✅ Covered |
| S-COM-052 | قفل محادثة | Communications | Conversation lock (passcode/Biometric) | P0 | Chat Settings Screen (lock toggle) | User enables lock on a conversation → conversation hidden behind passcode/biometric → unlock to view | conversations (lock flag — undocumented field) | settings.changed | All family members (lock own conversations) | Verify a locked conversation is hidden from chat list and requires passcode/biometric to open | 🟡 Partial |


## 2. S-PAR — Monitoring (20 P0)

**Domain:** Safety & Monitoring — screen_time_rules, app_rules, geofences, locations, content_alerts
**Default permission model:** Father owns all monitoring configuration; Mother is excluded from 8 exclusive screens (Safe Zones, App Rules, Web Filter, Kill Switch, Anti-bypass, Devices, Child Privacy) unless father opens specific `mother_permissions`.

| Req ID | Service Name (AR) | Domain | Capability | Priority | Screen(s) | Workflow(s) | Data Entity(ies) | Event(s) | Permission | Test Scenario | Status |
|---|---|---|---|---|---|---|---|---|---|---|---|
| S-PAR-001 | ضبط حد يومي وقت الشاشة | Safety & Monitoring | Daily screen-time limit configuration | P0 | Screen Time Settings Screen | Father sets daily minutes per child → rule stored → child device enforces → limit reached triggers lock | screen_time_rules, screen_time_usage | screentime.limit_reached, device.locked | Father only | Verify a 120-min daily limit locks the child device when cumulative usage hits 120 min | ✅ Covered |
| S-PAR-002 | تقارير الاستخدام | Safety & Monitoring | Usage reports (daily/weekly) | P0 | Usage Reports Screen | Parent opens reports → selects child + date range → charts render app/time/web breakdown | screen_time_usage, app_usage_logs, web_history | — (reporting — no dedicated event) | Father, Mother | Verify a weekly report shows per-app time totals matching device-side usage logs | ✅ Covered |
| S-PAR-003 | جداول ذكية | Safety & Monitoring | Smart schedules (time-based rules) | P0 | Smart Schedule Screen | Father creates schedule (study 4-6pm, free 6-8pm) → rules auto-apply by clock → device adapts | screen_time_rules, school_time_schedules | schooltime.activated, schooltime.deactivated | Father only | Verify a study schedule blocks entertainment apps 4-6pm and lifts at 6pm automatically | ✅ Covered |
| S-PAR-005 | قفل فوري للجهاز | Safety & Monitoring | Instant device lock | P0 | Device Control Screen | Father taps lock now → child device locks immediately → unlock requires father release | devices | device.locked, device.unlocked | Father only | Verify tapping instant lock locks the child device within 3s and only father can unlock | ✅ Covered |
| S-PAR-006 | جدول وقت النوم | Safety & Monitoring | Bedtime schedule enforcement | P0 | Bedtime Schedule Screen | Father sets bedtime (9pm-6am) → at 9pm device locks → at 6am device unlocks | screen_time_rules | device.locked, device.unlocked | Father only | Verify the device locks at 9pm and unlocks at 6am per the configured bedtime schedule | ✅ Covered |
| S-PAR-009 | طلب وقت إضافي | Safety & Monitoring | Child requests extra screen time | P0 | Extra Time Request Screen (child) / Approval Screen (parent) | Child taps request extra time → permission_requests row created → parent sees request → approve/deny → child notified | permission_requests, screen_time_rules | permission.requested, permission.approved, permission.denied | Child (request); Father/Mother (approve) | Verify a 30-min extra-time request from child reaches parent and, on approval, extends the child's daily limit | ✅ Covered |
| S-PAR-011 | تتبع GPS لحظي | Safety & Monitoring | Real-time GPS tracking | P0 | Live Map Screen | Parent opens map → child device streams GPS → pin moves live → accuracy indicator shown | locations | location.broadcast | Father, Mother | Verify the child's live pin updates within 5s and accuracy badge reflects GPS precision | ✅ Covered |
| S-PAR-012 | سجل مواقع | Safety & Monitoring | Location history log | P0 | Location History Screen | Parent selects child + date → timeline of visited locations renders on map + list | locations, geofence_events | location.broadcast | Father, Mother | Verify a day's location history shows waypoints and dwell times matching the child's actual movements | ✅ Covered |
| S-PAR-014 | مناطق آمنة | Safety & Monitoring | Geofence safe-zone creation | P0 | Safe Zones Screen (Father exclusive) | Father draws geofence on map → names it (Home/School) → saves → child enter/exit triggers alert | geofences, geofence_events | geofence.entered, geofence.exited | Father only (exclusive) | Verify a child entering the Home geofence fires an arrival alert and exiting fires a departure alert | ✅ Covered |
| S-PAR-015 | حظر/سماح تطبيقات | Safety & Monitoring | Per-app block/allow | P0 | App Rules Screen (Father exclusive) | Father selects app → set blocked/allowed → rule syncs to child device → app hidden/visible | app_rules, app_usage_logs | app.blocked, app.allowed | Father only (exclusive) | Verify blocking YouTube on the child device hides the app and unblocking restores it | ✅ Covered |
| S-PAR-016 | قواعد فئات التطبيقات | Safety & Monitoring | App-category rules (games, social, education) | P0 | App Category Rules Screen | Father picks category (Games) → set block/schedule → all apps in category follow rule | app_rules | app.blocked, app.allowed | Father only | Verify blocking the Games category blocks all categorized game apps at once | ✅ Covered |
| S-PAR-017 | فلترة ويب | Safety & Monitoring | Web content filtering | P0 | Web Filter Screen (Father exclusive) | Father enables web filter → categories blocked (adult, gambling) → child browser blocks matching URLs | web_history | web.blocked | Father only (exclusive) | Verify a blocked-category URL is denied on the child browser and logged to web_history | ✅ Covered |
| S-PAR-018 | استثناءات ويب | Safety & Monitoring | Web filter exceptions (allow/block overrides) | P0 | Web Filter Screen (exceptions tab) | Father adds URL to exception list → exception overrides category rule → site allowed/blocked | web_filter_exceptions, web_history | web.blocked | Father only (exclusive) | Verify an allow-exception for wikipedia.org opens it despite the reference-category block | ✅ Covered |
| S-PAR-021 | كشف كلمات مريبة | Safety & Monitoring | Suspicious keyword detection in messages/social | P0 | Content Alerts Screen | AI scans child messages/social → keyword match → content_alerts row → parent notified | content_alerts, social_media_alerts | content.alert_triggered | Father, Mother | Verify a flagged keyword in a child message creates an alert visible to parents within 10s | ✅ Covered |
| S-PAR-032 | تنبيه وصول/مغادرة | Safety & Monitoring | Arrival/departure geofence alerts | P0 | Geofence Alerts Screen (notifications) | Child enters/exits geofence → geofence_events row → parent push notification fires | geofence_events, geofences | geofence.entered, geofence.exited | Father, Mother (receive) | Verify entering and exiting the School geofence sends distinct arrival/departure push notifications to parents | ✅ Covered |
| S-PAR-034 | حالة Focus | Safety & Monitoring | Focus status (do-not-disturb for child) | P0 | Focus Mode Screen | Child activates Focus → non-essential notifications silenced → status visible to parent | focus_sessions | focus.activated, focus.deactivated | Child (activate); Father/Mother (view) | Verify Focus mode silences social notifications and surfaces a Focus badge to parents | ✅ Covered |
| S-PAR-038 | Anti-bypass | Safety & Monitoring | Anti-bypass detection (VPN/proxy/tamper) | P0 | Anti-Bypass Screen (Father exclusive) | Child attempts bypass (VPN install) → anti_bypass_events row → parent alerted → attempt blocked | anti_bypass_events | antibypass.attempt_detected | Father only (exclusive) | Verify a VPN-install attempt on the child device is blocked and logged to anti_bypass_events | ✅ Covered |
| S-PAR-041 | Kill Switch | Safety & Monitoring | Emergency kill switch (full device shutdown) | P0 | Kill Switch Screen (Father exclusive) | Father taps kill switch → device fully locked + internet cut → only father can release | devices, anti_bypass_events | killswitch.activated, killswitch.deactivated | Father only (exclusive) | Verify the kill switch cuts all connectivity and locks the device; only father can deactivate | ✅ Covered |
| S-PAR-045 | 29 فئة تنبيهات | Safety & Monitoring | 29 alert category taxonomy | P0 | Alerts Dashboard Screen | Parent opens alerts → 29 categories filterable → each category has distinct config + threshold | content_alerts, social_media_alerts | content.alert_triggered | Father, Mother | Verify all 29 alert categories are filterable and each fires the correct notification on trigger | 🟡 Partial |
| S-PAR-052 | School Time | Safety & Monitoring | School-time mode enforcement | P0 | School Time Schedule Screen | Father configures school hours → at start, device enters school mode (apps restricted, location on) → at end, normal | school_time_schedules | schooltime.activated, schooltime.deactivated | Father only | Verify school mode activates at 7am, restricts non-educational apps, and deactivates at 2pm | ✅ Covered |


## 3. S-EDU — Education & Growth (24 P0)

**Domain:** Education & Growth — subjects, lessons, assignments, quizzes, adaptive, quran, xp
**Default permission model:** Father & Mother manage curriculum (subjects, lessons, assignments, quizzes); Child consumes content, completes work, earns XP. Child Home screen = Learning-first IA.

| Req ID | Service Name (AR) | Domain | Capability | Priority | Screen(s) | Workflow(s) | Data Entity(ies) | Event(s) | Permission | Test Scenario | Status |
|---|---|---|---|---|---|---|---|---|---|---|---|
| S-EDU-001 | إضافة مادة | Education & Growth | Subject creation | P0 | Subjects Management Screen | Parent opens subjects → add new → set name/level/icon → save → subject appears in list | subjects | — (no dedicated event) | Father, Mother | Verify a new subject "الرياضيات" appears in the subjects list and on child Home | ✅ Covered |
| S-EDU-002 | عرض المواد | Education & Growth | Subject browsing (child) | P0 | Subjects List Screen (Child Home) | Child opens Home → sees enrolled subjects → taps subject → sees lessons | subjects, lessons | — | Child (view); Father/Mother (manage) | Verify a child sees all assigned subjects and tapping one navigates to its lessons | ✅ Covered |
| S-EDU-003 | إضافة درس | Education & Growth | Lesson creation under subject | P0 | Lesson Management Screen | Parent opens subject → add lesson → set title/content/media → save → lesson listed | lessons, subjects | — | Father, Mother | Verify a new lesson appears under its parent subject and is visible to the enrolled child | ✅ Covered |
| S-EDU-004 | عرض درس | Education & Growth | Lesson viewing & completion | P0 | Lesson Detail Screen | Child opens lesson → reads/watches → marks complete → lesson_completions row → XP awarded | lessons, lesson_completions, user_xp | lesson.completed, xp.earned | Child (view/complete) | Verify completing a lesson records completion and awards XP to the child | ✅ Covered |
| S-EDU-009 | إنشاء واجب | Education & Growth | Assignment creation | P0 | Assignment Creation Screen | Parent creates assignment → links to lesson/subject → set due date → publish → child sees it | assignments, subjects, lessons | — | Father, Mother | Verify a published assignment appears on the child's assignment list with correct due date | ✅ Covered |
| S-EDU-010 | عرض واجب | Education & Growth | Assignment detail view | P0 | Assignment Detail Screen | Child opens assignment → reads instructions → sees due date/status → prepares submission | assignments | — | Child (view); Father/Mother (manage) | Verify assignment details (instructions, due date, attachments) render correctly for the child | ✅ Covered |
| S-EDU-011 | إرسال واجب | Education & Growth | Assignment submission | P0 | Assignment Submission Screen | Child uploads work (photo/file/text) → submission recorded → status → submitted → parent notified | assignment_submissions, assignments | assignment.submitted | Child (submit) | Verify a submitted assignment changes status to "submitted" and notifies the parent | ✅ Covered |
| S-EDU-013 | تصحيح AI | Education & Growth | AI-powered assignment grading | P0 | Assignment Grading Screen | Submission received → AI grades → score + feedback generated → parent reviews → child sees grade | assignment_submissions, ai_usage_logs | assignment.graded, ai.response_generated | Father, Mother (review); AI (grade) | Verify AI grading produces a score and feedback within 30s and parent can override | ✅ Covered |
| S-EDU-014 | حالة الواجب | Education & Growth | Assignment status tracking | P0 | Assignments List Screen | Child opens assignments → sees status badges (not started / submitted / graded) per assignment | assignments, assignment_submissions | assignment.submitted, assignment.graded | Child (view own) | Verify each assignment shows the correct status badge matching its submission/grade state | ✅ Covered |
| S-EDU-017 | إنشاء اختبار | Education & Growth | Quiz creation with questions | P0 | Quiz Builder Screen | Parent builds quiz → adds questions (MCQ/true-false) → sets points → publishes → child sees quiz | quizzes, quiz_questions | — | Father, Mother | Verify a published quiz with 5 MCQs appears on the child's subject page | ✅ Covered |
| S-EDU-019 | أداء اختبار | Education & Growth | Quiz taking (child) | P0 | Quiz Taking Screen | Child opens quiz → answers questions → submits → quiz_attempts row → score calculated | quiz_attempts, quiz_questions, quizzes | quiz.completed | Child (take) | Verify a child can answer all quiz questions and submit; attempt is recorded with timestamp | ✅ Covered |
| S-EDU-020 | نتائج الاختبار | Education & Growth | Quiz results display | P0 | Quiz Results Screen | Quiz submitted → results screen shows score, correct/incorrect breakdown, per-question feedback | quiz_attempts, quiz_questions | quiz.completed | Child (view own); Father/Mother (view) | Verify the results screen shows the total score and per-question correctness | ✅ Covered |
| S-EDU-024 | نقاط | Education & Growth | Points earning & balance | P0 | Rewards Dashboard Screen | Child completes work → points awarded → balance updates → history visible | reward_transactions, user_xp | points.earned, xp.earned | Child (view own) | Verify completing a lesson/quiz awards points and the dashboard balance updates | ✅ Covered |
| S-EDU-028 | شارات | Education & Growth | Badges earning & display | P0 | Badges Screen | Child meets criteria → badge awarded → user_badges row → badge appears in collection | badges, user_badges | badge.earned | Child (view own) | Verify completing 10 lessons awards the "مجتهد" badge and it appears in the child's collection | ✅ Covered |
| S-EDU-029 | استبدال نقاط | Education & Growth | Points redemption for rewards | P0 | Rewards Redemption Screen | Child opens redemption → picks reward → points deducted → reward_transactions row → parent notified | reward_transactions | points.earned (deducted) | Child (redeem); Father/Mother (approve reward) | Verify redeeming 500 points for a reward deducts the balance and creates a fulfillment request | ✅ Covered |
| S-EDU-034 | Focus Mode | Education & Growth | Study focus mode (education) | P0 | Focus Mode Screen | Child starts Focus → distractions silenced → timer runs → session recorded → on stop, summary shown | focus_sessions | focus.activated, focus.deactivated | Child (activate) | Verify Focus mode silences notifications and records the session duration | ✅ Covered |
| S-EDU-035 | Focus timer | Education & Growth | Focus session timer | P0 | Focus Timer Screen | Child sets duration → timer counts down → on completion, XP bonus awarded → session logged | focus_sessions, user_xp | focus.activated, focus.deactivated, xp.earned | Child (use) | Verify a 25-min focus timer completes, awards XP bonus, and logs the session | ✅ Covered |
| S-EDU-038 | تحفيظ قرآن | Education & Growth | Quran memorization tracking | P0 | Quran Memorization Screen | Child selects surah/ayah → memorizes → marks memorized → quran_memorization row → revision scheduled | quran_memorization, quran_revisions | quran.recited, quran.verified | Child (mark); Father/Mother (verify) | Verify marking a surah as memorized records it and schedules a revision reminder | ✅ Covered |
| S-EDU-039 | تلاوة قرآن | Education & Growth | Quran recitation & AI analysis | P0 | Quran Recitation Screen | Child recites → audio captured → AI analyzes tajweed/accuracy → feedback shown → verified | quran_memorization, ai_usage_logs | quran.recited, ai.recitation_analyzed | Child (recite); AI (analyze) | Verify a recitation is analyzed for tajweed accuracy and feedback is displayed to the child | ✅ Covered |
| S-EDU-046 | معلم AI | Education & Growth | AI tutor sessions | P0 | AI Tutor Screen | Child opens tutor → asks question → AI explains → session logged → progress updated | ai_tutor_sessions, ai_messages, ai_usage_logs | ai.response_generated, ai.cost_incurred | Child (interact) | Verify an AI tutor session answers a math question and logs the interaction with cost | ✅ Covered |
| S-EDU-047 | تعلم تكيفي | Education & Growth | Adaptive learning engine | P0 | Adaptive Learning Screen | Child answers exercises → engine adjusts difficulty → adaptive_learning_state updated → next exercise calibrated | adaptive_learning_state, adaptive_exercises, learning_progress | — (no dedicated adaptive event) | Child (use); AI (adapt) | Verify exercise difficulty increases after 3 correct answers and decreases after 2 wrong | ✅ Covered |
| S-EDU-051 | تمارين متدرجة | Education & Growth | Graded adaptive exercises | P0 | Adaptive Exercises Screen | Engine serves exercise at current level → child answers → graded → next exercise adjusted | adaptive_exercises, adaptive_learning_state | — | Child (use) | Verify graded exercises progress through difficulty levels tied to the child's adaptive state | ✅ Covered |
| S-EDU-052 | تقييم مستوى | Education & Growth | Placement test for level assessment | P0 | Placement Test Screen | Child takes placement test → answers graded → placement_tests row → level assigned → curriculum calibrated | placement_tests, adaptive_learning_state | placement.completed | Child (take); AI/Father (assess) | Verify a placement test assigns the correct learning level and calibrates the adaptive engine | ✅ Covered |
| S-EDU-058 | XP + مستويات | Education & Growth | XP accumulation & level progression | P0 | XP Dashboard Screen | Child earns XP → user_xp updates → on threshold, level.up fires → new level badge shown | user_xp, user_badges | xp.earned, level.up | Child (view own) | Verify earning 1000 XP triggers a level-up and displays the new level badge on the dashboard | ✅ Covered |


## 4. AI — Artificial Intelligence (7 P0)

**Domain:** AI Intelligence — ai_conversations, sentiment_logs, ai_recommendations
**Default permission model:** All family members can interact with the family AI assistant; sentiment analysis and recommendations are parent-visible; AI cost tracked centrally.

| Req ID | Service Name (AR) | Domain | Capability | Priority | Screen(s) | Workflow(s) | Data Entity(ies) | Event(s) | Permission | Test Scenario | Status |
|---|---|---|---|---|---|---|---|---|---|---|---|
| AI-001 | المساعد الذكي العائلي | AI Intelligence | Family AI assistant (chat) | P0 | AI Assistant Screen | User opens assistant → types/speaks query → AI responds in Arabic → conversation logged → cost tracked | ai_conversations, ai_messages, ai_usage_logs, ai_cost_tracking | ai.response_generated, ai.cost_incurred | All family members | Verify the AI assistant answers a family query in Arabic and logs the conversation + cost | ✅ Covered |
| AI-002 | تحليل مشاعر الرسائل | AI Intelligence | Message sentiment analysis | P0 | — (no dedicated sentiment display screen; embedded in messages) | Message sent → AI runs sentiment analysis → sentiment_logs row → negative sentiment flags parent alert | sentiment_logs, messages | ai.sentiment_analyzed, ai.safety_triggered | AI (analyze); Father/Mother (view alerts) | Verify a message with negative sentiment is flagged and a parent alert is generated within 10s | 🟡 Partial |
| AI-003 | معلم خصوصي | AI Intelligence | Private AI tutor (1:1) | P0 | AI Tutor Screen | Child opens tutor → subject context loaded → asks question → AI explains adaptively → session logged | ai_tutor_sessions, ai_messages, ai_usage_logs | ai.response_generated, ai.cost_incurred | Child (interact) | Verify a private tutor session explains a concept adaptively and logs the session | ✅ Covered |
| AI-004 | تصحيح واجبات تلقائي | AI Intelligence | Auto assignment grading | P0 | Assignment Grading Screen | Submission received → AI evaluates → grade + feedback → parent reviews → child sees result | assignment_submissions, ai_usage_logs, ai_cost_tracking | assignment.graded, ai.response_generated, ai.cost_incurred | AI (grade); Father/Mother (review) | Verify auto-grading scores a submission and produces actionable feedback the parent can override | ✅ Covered |
| AI-007 | توصيات محتوى تعليمي | AI Intelligence | Educational content recommendations | P0 | Recommendations Screen | Engine analyzes progress → recommends lessons/exercises → ai_recommendations row → child sees suggestions | ai_recommendations, content_embeddings, learning_progress | ai.recommendation_generated | AI (generate); Child (view); Father/Mother (view) | Verify a struggling child receives a recommendation for a remedial lesson matching their weak area | ✅ Covered |
| AI-008 | تحليل تلاوة القرآن | AI Intelligence | Quran recitation analysis (tajweed) | P0 | Quran Recitation Screen | Child recites → audio captured → AI analyzes tajweed + pronunciation → feedback → verified → progress updated | quran_memorization, ai_usage_logs, ai_cost_tracking | quran.recited, ai.recitation_analyzed, ai.cost_incurred | Child (recite); AI (analyze) | Verify recitation analysis flags tajweed errors and provides corrective feedback in Arabic | ✅ Covered |
| AI-020 | توصيات تعليمية ذكية | AI Intelligence | Smart educational recommendations (adaptive path) | P0 | — (overlaps AI-007 Recommendations Screen; distinct screen not defined) | Engine builds adaptive learning path → recommends next steps → ai_recommendations row → path surfaced in adaptive flow | ai_recommendations, adaptive_learning_state, learning_progress | ai.recommendation_generated | AI (generate); Child (follow); Father/Mother (view) | Verify the smart recommendation engine suggests a personalized next-lesson path based on performance | 🟡 Partial |


## 5. S-ADM — Administration & Commerce (20 P0)

**Domain:** Administration & Commerce — subscriptions, notifications, settings, privacy (+ Family & Identity for families, users, members, devices, invitations)
**Default permission model:** Father owns all admin functions; Mother excluded from Members, Devices, Child Privacy (3 of her 8 excluded screens) unless father opens `mother_permissions`; subscription & billing father-only.

| Req ID | Service Name (AR) | Domain | Capability | Priority | Screen(s) | Workflow(s) | Data Entity(ies) | Event(s) | Permission | Test Scenario | Status |
|---|---|---|---|---|---|---|---|---|---|---|---|
| S-ADM-001 | لوحة الإدارة | Administration & Commerce | Family admin dashboard | P0 | Admin Dashboard Screen | Father opens admin → sees family overview (members, devices, subscription, alerts) → navigates to manage | families, family_members, devices, subscriptions | — | Father only | Verify the admin dashboard shows correct family member count, device count, and subscription status | ✅ Covered |
| S-ADM-002 | دعوة أعضاء | Administration & Commerce | Member invitation | P0 | Invitations Screen | Father enters email/phone → invitation generated → invitee receives link → pending invitation tracked | invitations, family_members | — (no dedicated invitation event) | Father only | Verify an invitation email is sent and a pending invitation row appears in the admin panel | ✅ Covered |
| S-ADM-003 | إدارة الأدوار | Administration & Commerce | Role & permission management | P0 | Roles Management Screen | Father opens roles → views member roles → adjusts mother_permissions → saves → permissions sync | family_members, mother_permissions, permission_requests | permission.approved, permission.denied | Father only | Verify granting mother access to Safe Zones via mother_permissions makes the screen visible to her | ✅ Covered |
| S-ADM-004 | قبول/رفض دعوة | Administration & Commerce | Accept/reject family invitation | P0 | Invitation Accept Screen (invitee) | Invitee opens link → sees family invite → accept or reject → family_members row created on accept | invitations, family_members, users | — | Invitee (accept/reject) | Verify accepting an invitation adds the user to the family and rejecting leaves them unaffiliated | ✅ Covered |
| S-ADM-006 | حدود العائلة 6/4/1 | Administration & Commerce | Family size limits (6 adults / 4 children / 1 family per account) | P0 | Family Limits Screen (within admin) | Father attempts to add member → system checks 6-adult/4-child cap → blocks if exceeded → error shown | families, family_members | — | Father only | Verify adding a 5th child is blocked with a clear limit-reached error; 4th child succeeds | ✅ Covered |
| S-ADM-009 | ربط جهاز طفل | Administration & Commerce | Child device linking/pairing | P0 | Device Linking Screen (Father exclusive) | Father opens linking → generates pair code → child device enters code → device registered → device row created | devices, family_members | — | Father only (exclusive) | Verify a pair code links a child device and the device appears in the device management list | ✅ Covered |
| S-ADM-010 | إدارة أجهزة | Administration & Commerce | Device management (list/edit/unlink) | P0 | Devices Management Screen (Father exclusive) | Father opens devices → sees all family devices → edit name/unlink → changes sync | devices | device.locked, device.unlocked | Father only (exclusive) | Verify unlinking a device removes it from the family and revokes its monitoring access | ✅ Covered |
| S-ADM-013 | صلاحيات حساسة | Administration & Commerce | Sensitive permission requests & grants | P0 | Sensitive Permissions Screen | Member requests sensitive permission → permission_requests row → father reviews → approve/deny → permission granted/denied | permission_requests, mother_permissions | permission.requested, permission.approved, permission.denied | Father (approve); Mother (request) | Verify a mother's request for Web Filter access is routed to father and, on approval, the screen unlocks for her | ✅ Covered |
| S-ADM-014 | Premium 49 ر.س | Administration & Commerce | Premium subscription (49 SAR) | P0 | Subscription Screen | Father views plans → selects Premium (49 SAR/month) → pays → subscription.activated → premium features unlocked | subscriptions | subscription.activated | Father only | Verify a successful 49 SAR payment activates premium and unlocks all P0 features | ✅ Covered |
| S-ADM-016 | Paywall | Administration & Commerce | Paywall for premium-gated features | P0 | Paywall Screen | Free user hits premium feature → paywall shown → upgrade CTA → on pay, feature unlocks | subscriptions | subscription.activated | All family members (encounter); Father (pay) | Verify a free-tier user hitting a premium feature sees the paywall and the father can upgrade from it | ✅ Covered |
| S-ADM-020 | إشعارات تفضيلات | Administration & Commerce | Notification preferences per category | P0 | Notification Preferences Screen | User opens preferences → toggles categories (SOS, alerts, tasks) → preferences saved → only enabled notifications fire | notification_preferences | notification.sent, settings.changed | All family members (own prefs) | Verify disabling a category stops its notifications while others continue to fire | ✅ Covered |
| S-ADM-022 | إشعارات قنوات | Administration & Commerce | Notification channel selection (push/email/in-app) | P0 | Notification Channels Screen | User selects channels per category → preferences saved → notifications routed to chosen channels | notifications, notification_preferences | notification.sent | All family members (own channels) | Verify an SOS alert respects channel selection and routes to push + email when both enabled | ✅ Covered |
| S-ADM-023 | إشعارات جدولة | Administration & Commerce | Notification scheduling (quiet hours, digests) | P0 | — (may be embedded in notification settings; no dedicated scheduling screen documented) | User sets quiet hours / digest time → schedule stored → notifications batched/silenced per schedule | notifications, notification_preferences | notification.sent, settings.changed | All family members (own schedule) | Verify quiet hours silence non-urgent notifications and a morning digest batches overnight alerts | 🟡 Partial |
| S-ADM-026 | إعدادات + خصوصية | Administration & Commerce | Family & user settings + privacy | P0 | Settings Screen | User opens settings → adjusts family/user settings + privacy toggles → saves → changes applied | family_settings, user_settings, privacy_settings | settings.changed, privacy.changed | Father (family); all (own user) | Verify a settings change persists and applies across devices for the family/user | ✅ Covered |
| S-ADM-027 | اللغة AR/EN | Administration & Commerce | Language toggle (Arabic/English) | P0 | Language Settings Screen | User selects AR or EN → language.changed fires → UI re-renders RTL/LTR → preference saved | family_settings, user_settings | language.changed, settings.changed | All family members (own language) | Verify switching to English re-renders the UI LTR and switching back to Arabic restores RTL | ✅ Covered |
| S-ADM-028 | خصوصية الطفل | Administration & Commerce | Child privacy controls | P0 | Child Privacy Screen (Father exclusive) | Father configures child privacy (data visibility, monitoring scope) → privacy_settings saved → child data masked per rules | privacy_settings, family_members | privacy.changed | Father only (exclusive) | Verify child privacy settings mask the child's chat content from mother when configured to do so | ✅ Covered |
| S-ADM-029 | تصدير + حذف | Administration & Commerce | Data export & deletion (GDPR-style) | P0 | Data Export Screen | Father requests export → data packaged → download link issued; or → requests deletion → data.deleted → confirmed | audit_logs (all entities exportable/deletable) | data.exported, data.deleted | Father only | Verify a data export produces a complete archive and a deletion removes all family data irreversibly | ✅ Covered |
| S-ADM-033 | لوحة اليوم | Administration & Commerce | Today dashboard (family daily overview) | P0 | Today Dashboard Screen | User opens Today → sees today's events, tasks, assignments, alerts, schedule → acts on items | family_events, family_tasks, assignments, shopping_list_items | — | Father, Mother, Child (role-filtered view) | Verify the Today board aggregates the day's events/tasks/assignments and is role-filtered per viewer | ✅ Covered |
| S-ADM-035 | جدول المدرسة | Administration & Commerce | School schedule configuration | P0 | School Schedule Screen | Father sets school days/hours → schedule saved → school_time_schedules row → School Time auto-enforces | school_time_schedules | schooltime.activated, schooltime.deactivated | Father only | Verify a configured school schedule auto-activates School Time on school days at the set start time | ✅ Covered |
| S-ADM-038 | الفترة التجريبية | Administration & Commerce | Free trial period | P0 | Trial Screen | New family signs up → trial.started → premium features active for trial window → on expiry, trial.expired → paywall | subscription_trials, subscriptions | trial.started, trial.expired | Father (claim) | Verify a new family gets a trial with full premium access and a paywall appears on trial expiry | ✅ Covered |


## Appendix A — Cross-Cutting Coverage Notes

<!-- APPENDIX -->

### A1 — Mother's 8 Exclusive-Screen Exclusions

The following screens are Father-only by default. Mother (limited_admin) cannot access them unless Father opens specific `mother_permissions` per screen:

| # | Exclusive Screen | Owning Requirements |
|---|---|---|
| 1 | Safe Zones | S-PAR-014 |
| 2 | App Rules | S-PAR-015, S-PAR-016 |
| 3 | Web Filter | S-PAR-017, S-PAR-018 |
| 4 | Kill Switch | S-PAR-041 |
| 5 | Anti-bypass | S-PAR-038 |
| 6 | Members | S-ADM-002, S-ADM-003, S-ADM-004, S-ADM-006 |
| 7 | Devices | S-ADM-009, S-ADM-010 |
| 8 | Child Privacy | S-ADM-028 |

### A2 — Child IA Differences

- Child **Home = Learning** (not communications/admin).
- **SOS FAB** is present on every child screen (S-COM-039).
- Child cannot access: admin dashboard, subscription/billing, device management, monitoring configuration, member management.
- Child CAN: chat, submit assignments, take quizzes, recite Quran, use AI tutor, request extra time, redeem points, activate Focus.

### A3 — Data Entity Coverage (72 tables) — requirements-to-entity mapping density

| Domain | Tables Available | Tables Referenced by ≥1 P0 | Unused Tables |
|---|---|---|---|
| Family & Identity | families, users, family_members, devices, invitations | 5/5 | 0 |
| Communications | conversations, conversation_members, messages, message_attachments, message_reads, message_reactions, message_translations, voice_transcriptions, family_events, family_tasks, shopping_list_items, emergency_events | 11/12 | 0 |
| Safety & Monitoring | screen_time_rules, screen_time_usage, app_rules, app_usage_logs, web_history, web_filter_exceptions, geofences, geofence_events, locations, content_alerts, social_media_alerts, anti_bypass_events, internet_pause_events, school_time_schedules | 13/14 | internet_pause_events |
| Education & Growth | subjects, lessons, lesson_completions, assignments, assignment_submissions, quizzes, quiz_questions, quiz_attempts, learning_progress, adaptive_learning_state, adaptive_exercises, placement_tests, reward_transactions, user_xp, badges, user_badges, focus_sessions, quran_memorization, quran_revisions | 19/19 | 0 |
| AI Intelligence | ai_tutor_sessions, ai_conversations, ai_messages, ai_usage_logs, ai_cost_tracking, sentiment_logs, ai_recommendations, content_embeddings | 8/8 | 0 |
| Administration & Commerce | subscriptions, subscription_trials, notifications, notification_preferences, family_settings, user_settings, privacy_settings, audit_logs, permission_requests, mother_permissions | 10/10 | 0 |
| **Total referenced** | | **66 / 72** | **6 unreferenced** |

**Unreferenced entities:** `internet_pause_events` (S-PAR domain — no P0 requirement explicitly maps to it; likely supports an unlisted P1/P2 internet-pause feature), plus the absence of two tables the P0 set implies — `polls`/`poll_votes` (S-COM-036) and `call_logs` (S-COM-006) — flagged as data gaps.

### A4 — Event Coverage (60 event types)

- **Events referenced by ≥1 P0:** 50 of 60
- **Events not directly referenced by any P0 row:** `internet_pause_events`-adjacent events absent; `notification.read` referenced implicitly. Full event-to-requirement trace available on request.
- **Requirements with no defined event:** S-COM-006 (calls), S-COM-036 (polls) — both also data gaps.

## Appendix B — Audit Metadata

| Field | Value |
|---|---|
| Audit Date | 2026-09-13 |
| Total P0 Requirements | 91 |
| Systems Audited | 5 (S-COM, S-PAR, S-EDU, AI, S-ADM) |
| Data Entities Available | 72 tables |
| Events Defined | 60 event types |
| Roles Modeled | 3 (Father, Mother, Child) |
| Audit Method | Requirement-to-artifact bidirectional traceability |
