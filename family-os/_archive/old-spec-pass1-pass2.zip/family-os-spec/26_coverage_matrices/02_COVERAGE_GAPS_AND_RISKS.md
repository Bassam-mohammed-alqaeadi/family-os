# Coverage Gaps & Risk Assessment — World-Class Family OS

> **Document ID:** 02_COVERAGE_GAPS_AND_RISKS
> **Companion to:** `01_REQUIREMENTS_COVERAGE_MATRIX.md`
> **Scope:** Gap analysis and risk assessment for the 91 P0 requirements across 5 systems
> **Audit Date:** 2026-09-13

---

## Table of Contents

1. [Methodology](#1-methodology)
2. [Gap Inventory by Category](#2-gap-inventory-by-category)
   - 2.1 Requirements with NO Screen Coverage
   - 2.2 Requirements with NO Data Entity
   - 2.3 Requirements with NO Workflow
   - 2.4 Requirements with NO Test Scenario
   - 2.5 Partially Covered Requirements
3. [Risk Assessment Matrix](#3-risk-assessment-matrix)
4. [Summary Statistics](#4-summary-statistics)
5. [Recommendations & Remediation Roadmap](#5-recommendations--remediation-roadmap)

---

<!-- METHODOLOGY -->

## 1. Methodology

### 1.1 Audit Approach

This gap analysis applies **bidirectional requirement-to-artifact traceability** to the 91 P0 requirements defined across the five systems of the World-Class Family OS:

| System | P0 Count | Domain |
|---|---|---|
| S-COM — Communications | 20 | Communications |
| S-PAR — Monitoring | 20 | Safety & Monitoring |
| S-EDU — Education & Growth | 24 | Education & Growth |
| AI — Artificial Intelligence | 7 | AI Intelligence |
| S-ADM — Administration & Commerce | 20 | Administration & Commerce + Family & Identity |
| **Total** | **91** | |

### 1.2 Coverage Dimensions

Each requirement was traced against **six dimensions** derived from the product's design surface:

| Dimension | Question Asked | Source of Truth |
|---|---|---|
| **Screen** | Is there a UI screen where the user interacts with this capability? | Screen inventory (inferred from IA + role model) |
| **Workflow** | Is there a defined end-to-end user flow (trigger → action → outcome)? | Workflow definitions in the spec |
| **Data Entity** | Is there a database table that persists the requirement's state? | 72-table data entity catalog |
| **Event** | Is there a domain event that fires on the requirement's key actions? | 60-event catalog |
| **Permission** | Is the access control defined per role (Father / Mother / Child)? | 3-role permission model |
| **Test Scenario** | Is there a verifiable test that validates the requirement? | Test scenario per row in the matrix |

### 1.3 Status Classification Rules

| Status | Rule |
|---|---|
| ✅ **Covered** | All six dimensions have at least one mapped artifact |
| 🟡 **Partial** | 1–2 dimensions are missing, underspecified, or overlap ambiguously with another requirement, but a workable implementation path exists |
| 🔴 **Gap** | A critical dimension (Screen, Data, or Workflow) is entirely absent with no workaround in the current spec |

### 1.4 Risk Scoring

Risk level for each gap is assessed on three factors:

| Factor | Weight | Description |
|---|---|---|
| **User Impact** | High | Does the gap block a core user journey or safety-critical function? |
| **Implementation Effort** | Medium | How much spec + engineering work is needed to close the gap? |
| **Spec Maturity** | Medium | Is the requirement well-defined enough to implement, or does it need design work? |

Combined into a single risk tier:

| Risk Level | Criteria |
|---|---|
| 🔴 **High** | Safety-critical or revenue-blocking; no workaround; requires immediate spec + design work |
| 🟠 **Medium** | Core feature degraded; workaround exists but is fragile; should be resolved before P0 sign-off |
| 🟡 **Low** | Nice-to-have or edge case; can be deferred to P1 without blocking launch |

### 1.5 Sources Cross-Checked

- 91 P0 requirement definitions (per system)
- 72 data entity tables (catalog)
- 60 domain events (catalog)
- 3-role permission model (Father / Mother / Child with 8 mother-excluded screens)
- Domain taxonomy (8 domains, 2 cross-cutting)

<!-- GAPS_NO_SCREEN -->

### 2.1 Requirements with NO Screen Coverage

A "no screen" gap means the requirement has no dedicated UI surface where a user interacts with the capability. Some of these are background AI services whose *results* surface on other screens, but no screen explicitly displays the capability's own output.

| # | Req ID | Service Name (AR) | Why No Screen | Current Surfacing |
|---|---|---|---|---|
| 1 | AI-002 | تحليل مشاعر الرسائل | Sentiment analysis runs as a background AI pipeline on messages; no dedicated screen displays sentiment trends, scores, or history to parents | Negative-sentiment results surface as parent alerts on the Content Alerts Screen, but there is no sentiment dashboard, no per-conversation sentiment view, and no historical sentiment trend visualization |
| 2 | AI-020 | توصيات تعليمية ذكية | Overlaps with AI-007 (توصيات محتوى تعليمي) which already owns the Recommendations Screen; AI-020 is a *smart path* engine whose output would need a distinct adaptive-path surface | Currently expected to surface within the adaptive learning flow, but no dedicated "learning path" screen is defined to distinguish it from AI-007's content recommendations |
| 3 | S-ADM-023 | إشعارات جدولة | Notification scheduling (quiet hours, digests) has no dedicated scheduling screen; assumed to be embedded within Notification Settings | Functions may be reachable as sub-toggles inside Notification Preferences / Channels screens, but no explicit scheduling UI (time picker, digest preview, quiet-hours calendar) is documented |

**Observation:** All three "no screen" gaps are 🟡 Partial rather than 🔴 Gap — each has an implicit surfacing path on an existing screen, but none has a dedicated, spec'd UI for its core capability. This creates ambiguity for design and QA.

<!-- GAPS_NO_DATA -->

### 2.2 Requirements with NO Data Entity

A "no data entity" gap means no table in the 72-entity catalog persists the requirement's state, history, or configuration. This is the most consequential gap type — without persistence, the feature cannot function in a multi-device, cross-session family platform.

| # | Req ID | Service Name (AR) | Missing Entity | Impact |
|---|---|---|---|---|
| 1 | S-COM-036 | استطلاعات | `polls` and `poll_votes` tables | Polls cannot persist question, options, votes, or results; the feature is unimplementable without these tables |
| 2 | S-COM-006 | مكالمة صوت P2P | `call_logs` (or `calls`) table | Voice call metadata (initiator, recipient, duration, status, timestamp) has no persistence; call history, missed-call tracking, and billing cannot function |
| 3 | S-COM-052 | قفل محادثة | No documented `conversation_locks` table or lock field on `conversations` | The lock state has nowhere to persist; unlock method (passcode/biometric token reference) is unspecified |

**Note on S-COM-052:** A lock flag *could* be added as a column on the existing `conversations` table, making this lower-effort than the other two. However, as currently specified, no such field is documented — hence the partial classification.

<!-- GAPS_NO_WORKFLOW -->

### 2.3 Requirements with NO Workflow

**Result: 0 requirements lack a defined workflow.**

Every one of the 91 P0 requirements has at least a baseline trigger → action → outcome flow documented in the coverage matrix. This is the strongest coverage dimension.

**Caveat — thin workflows:** While no requirement has *zero* workflow, a small number have workflows that are underspecified (single-step or missing error/edge-case paths). These are tracked under §2.5 Partial Coverage rather than here. Notably:

- S-PAR-045 (29 alert categories) — workflow exists per-category but the 29 distinct category configurations are not individually specced.
- S-EDU-047 / S-EDU-051 (adaptive learning + graded exercises) — the adaptation decision logic is referenced but not step-defined.


### 2.4 Requirements with NO Test Scenario

**Result: 0 requirements lack a test scenario.**

Every P0 requirement has at least one verifiable test scenario documented in the coverage matrix (File 1, column "Test Scenario"). Test scenarios specify the actor, the action, and the expected observable outcome.

**Caveat — test depth:** The documented test scenarios cover the **happy path** for each requirement. The following requirements need additional edge-case / negative-path tests that are not yet specced:

| Req ID | Service Name (AR) | Missing Test Coverage |
|---|---|---|
| S-COM-036 | استطلاعات | All tests blocked by data gap (no `polls` table) — no test can run until entity is added |
| S-COM-006 | مكالمة صوت P2P | No test for call failure, network drop, or missed-call recovery (data gap compounds this) |
| S-PAR-045 | 29 فئة تنبيهات | Individual category tests needed for all 29 categories; current test covers the dashboard generically |
| S-PAR-038 | Anti-bypass | No test for specific bypass vectors (VPN, proxy, sideload, time-change, uninstall evasion) |
| S-PAR-041 | Kill Switch | No test for partial-network-failure kill switch release or child-side recovery |
| S-ADM-029 | تصدير + حذف | No test for export completeness (all 72 entities) or deletion irreversibility audit |

### 2.5 Partially Covered Requirements

A requirement is "Partially Covered" when it has a workable implementation path but one or more traceability dimensions are incomplete, underspecified, or ambiguously overlap with another requirement. These are not full gaps — the feature can ship — but they need spec tightening before P0 sign-off.

| # | Req ID | Service Name (AR) | Missing / Weak Dimension | Detail | Recommended Action |
|---|---|---|---|---|---|
| 1 | S-COM-006 | مكالمة صوت P2P | Data Entity + Event | No `call_logs` table; no `call.*` event in the 60-event catalog. Call metadata unpersisted. | Add `call_logs` entity + `call.initiated`, `call.connected`, `call.ended`, `call.missed` events |
| 2 | S-COM-036 | استطلاعات | Data Entity + Event | No `polls` / `poll_votes` table; no `poll.*` event. Feature is unimplementable as specced. | Add `polls` + `poll_votes` entities + `poll.created`, `poll.voted`, `poll.closed` events |
| 3 | S-COM-052 | قفل محادثة | Data Entity | No documented lock field on `conversations` or dedicated `conversation_locks` table. Unlock method unspecified. | Add `is_locked` + `lock_method` columns to `conversations`, or a `conversation_locks` table; specify biometric/passcode flow |
| 4 | S-PAR-045 | 29 فئة تنبيهات | Workflow + Test | 29 alert categories exist as a taxonomy but individual category configurations, thresholds, and per-category tests are not specced. | Produce a 29-row category config sub-spec; define threshold defaults and a test per category |
| 5 | AI-002 | تحليل مشاعر الرسائل | Screen | No dedicated sentiment display screen; results only surface as alerts. No sentiment history/trend view. | Add a Sentiment Insights screen (parent-facing) showing per-child sentiment trends and flagged conversations |
| 6 | AI-020 | توصيات تعليمية ذكية | Screen | Overlaps AI-007; no distinct "adaptive learning path" screen to differentiate smart-path recommendations from content recommendations. | Either merge AI-020 into AI-007 with a "path" vs "content" tab, or add a dedicated Learning Path screen |
| 7 | S-ADM-023 | إشعارات جدولة | Screen | No dedicated scheduling UI; quiet hours and digest configuration assumed embedded in notification settings but not specced. | Add a Notification Scheduling screen with quiet-hours time picker, digest-time selector, and preview |
| 8 | S-EDU-047 | تعلم تكيفي | Event + Workflow depth | No dedicated `adaptive.*` event; adaptation decision logic referenced but not step-defined. | Add `adaptive.state_updated`, `adaptive.difficulty_changed` events; spec the adaptation algorithm trigger conditions |
| 9 | S-EDU-051 | تمارين متدرجة | Event | No dedicated exercise event; grading tracked via adaptive state only. | Add `exercise.completed`, `exercise.graded` events |
| 10 | S-PAR-002 | تقارير الاستخدام | Event | Reporting is a read aggregation with no dedicated event; report generation/regeneration not evented. | Add `report.generated` event for audit and cache-invalidation |
| 11 | S-EDU-001 | إضافة مادة | Event | No `subject.created` event; subject lifecycle not evented (same for S-EDU-003 lesson, S-EDU-009 assignment, S-EDU-017 quiz creation). | Add `subject.created`, `lesson.created`, `assignment.created`, `quiz.created` events for lifecycle tracking |

**Summary of partial dimensions (across all 11 items in the table above):**

| Weak Dimension | Count |
|---|---|
| Data Entity missing | 3 |
| Screen missing/ambiguous | 3 |
| Event missing | 5 |
| Workflow depth insufficient | 2 |
| Test depth insufficient | 2 |

> Of the 11 items above, **6** are marked 🟡 Partial in the coverage matrix (missing a critical dimension: screen or data entity). The remaining **5** (S-EDU-047, S-EDU-051, S-PAR-002, S-EDU-001, and the S-EDU-003/009/017 lifecycle group) are ✅ Covered in the matrix but have a weak *event* dimension only — they are listed here for completeness and tracked as Low-risk remediation.

---

## 3. Risk Assessment Matrix

Each gap and partial-coverage item is scored for risk. Risk reflects the potential impact on the user experience, safety, or launch readiness if the gap is not closed before P0 sign-off.

| Gap ID | Requirement | Gap Type | Risk Level | Recommendation |
|---|---|---|---|---|
| GAP-01 | S-COM-036 — استطلاعات | No Data Entity (polls) + No Event | 🔴 High | Block P0 sign-off. Add `polls` + `poll_votes` tables and `poll.created/voted/closed` events before implementation. A family polling feature with no persistence is unshippable. |
| GAP-02 | S-COM-006 — مكالمة صوت P2P | No Data Entity (call_logs) + No Event | 🟠 Medium | Add `call_logs` table and `call.*` events. Voice calls can technically function via WebRTC without persistence, but missed-call tracking, history, and billing require the entity. Resolve before P0 sign-off. |
| GAP-03 | S-COM-052 — قفل محادثة | No Data Entity (lock state) | 🟠 Medium | Add `is_locked` + `lock_method` to `conversations` table (low effort). Without it, conversation lock state resets on reinstall/device change. Resolve before P0 sign-off. |
| GAP-04 | S-PAR-045 — 29 فئة تنبيهات | Partial Workflow + Test depth | 🟠 Medium | The 29-category taxonomy needs individual configs and tests. A generic dashboard test does not validate category-specific thresholds. Produce a 29-row sub-spec before P0 sign-off. |
| GAP-05 | AI-002 — تحليل مشاعر الرسائل | No Screen | 🟡 Low | Sentiment analysis runs as a background pipeline; alerts already surface on the Content Alerts Screen. A dedicated Sentiment Insights screen is a P1 enhancement, not a P0 blocker. Defer. |
| GAP-06 | AI-020 — توصيات تعليمية ذكية | No Screen (overlaps AI-007) | 🟡 Low | Clarify the relationship between AI-007 and AI-020. If they are the same capability, merge and reduce P0 count to 90. If distinct, add a Learning Path tab. Low effort either way. |
| GAP-07 | S-ADM-023 — إشعارات جدولة | No dedicated Screen | 🟡 Low | Quiet hours and digest scheduling can live inside Notification Settings as sub-toggles. A dedicated screen is preferable but not P0-blocking. Resolve in design review. |
| GAP-08 | S-EDU-047 — تعلم تكيفي | No Event + Workflow depth | 🟠 Medium | Adaptive learning is a core education P0. Without `adaptive.*` events, the adaptation engine cannot be audited or debugged. Add events and spec the adaptation trigger logic before sign-off. |
| GAP-09 | S-EDU-051 — تمارين متدرجة | No Event | 🟡 Low | Add `exercise.completed/graded` events. Low effort; exercises function without events but lose auditability. Can bundle with GAP-08. |
| GAP-10 | S-PAR-002 — تقارير الاستخدام | No Event | 🟡 Low | Add `report.generated` event for cache-invalidation and audit. Reports function without it; defer if needed. |
| GAP-11 | S-EDU-001/003/009/017 — Content lifecycle | No lifecycle Events | 🟡 Low | Add `subject.created`, `lesson.created`, `assignment.created`, `quiz.created` events. Content creation works without events but loses lifecycle traceability. Bundle into one event-addition sprint. |
| GAP-12 | S-PAR-038 — Anti-bypass | Test depth | 🟠 Medium | Safety-critical feature. Without vector-specific tests (VPN, proxy, sideload, time-change), bypass detection cannot be validated. Add per-vector test cases before P0 sign-off. |
| GAP-13 | S-PAR-041 — Kill Switch | Test depth | 🔴 High | Safety-critical. A kill switch that cannot be reliably tested for failure recovery is a launch risk. Add network-failure and child-side-recovery test scenarios immediately. |
| GAP-14 | S-ADM-029 — تصدير + حذف | Test depth | 🟠 Medium | Data export completeness and deletion irreversibility are compliance-critical (GDPR-style). Without tests proving all 72 entities export and delete correctly, the feature carries legal risk. Add completeness tests. |

---

## 4. Summary Statistics

### 4.1 Overall Coverage

| Metric | Count | % |
|---|---|---|
| Total P0 Requirements | 91 | 100% |
| ✅ Fully Covered | 84 | 92.3% |
| 🟡 Partially Covered | 6 | 6.6% |
| 🔴 Gap (unimplementable as specced) | 1 | 1.1% |

> **Note:** The §2.5 Partial Coverage table lists 11 items because it includes 5 requirements (S-EDU-047, S-EDU-051, S-PAR-002, S-EDU-001, and the lifecycle group S-EDU-003/009/017) that are ✅ Covered in the matrix but have a weak *event* dimension only. The 6 requirements marked 🟡 Partial in the matrix are those with a missing critical dimension (screen or data entity), not just a missing event.

### 4.2 Gaps by Category

| Gap Category | Count | Requirements |
|---|---|---|
| No Screen Coverage | 3 | AI-002, AI-020, S-ADM-023 |
| No Data Entity | 3 | S-COM-036, S-COM-006, S-COM-052 |
| No Workflow | 0 | — |
| No Test Scenario | 0 | — |
| Partial Coverage (matrix-level, missing screen or data) | 6 | S-COM-006, S-COM-052, S-PAR-045, AI-002, AI-020, S-ADM-023 |
| Test Depth Insufficient (happy-path only) | 6 | S-COM-036, S-COM-006, S-PAR-045, S-PAR-038, S-PAR-041, S-ADM-029 |

### 4.3 Gaps by Risk Level

| Risk Level | Count | Gap IDs |
|---|---|---|
| 🔴 High | 2 | GAP-01, GAP-13 |
| 🟠 Medium | 6 | GAP-02, GAP-03, GAP-04, GAP-08, GAP-12, GAP-14 |
| 🟡 Low | 6 | GAP-05, GAP-06, GAP-07, GAP-09, GAP-10, GAP-11 |

> Total risk items: 14 (6 partial-coverage requirements + 1 true gap + 7 test-depth/event-weak items from §2.5, with some overlap). The 2 High-risk items are: S-COM-036 (unimplementable without data entity) and S-PAR-041 Kill Switch (safety-critical, untested failure recovery).

### 4.4 Coverage by System

| System | P0 Count | ✅ Covered | 🟡 Partial | 🔴 Gap | Coverage Rate |
|---|---|---|---|---|---|
| S-COM — Communications | 20 | 17 | 2 | 1 | 85% |
| S-PAR — Monitoring | 20 | 19 | 1 | 0 | 95% |
| S-EDU — Education & Growth | 24 | 24 | 0 | 0 | 100% |
| AI — Artificial Intelligence | 7 | 5 | 2 | 0 | 71% |
| S-ADM — Administration & Commerce | 20 | 19 | 1 | 0 | 95% |
| **Total** | **91** | **84** | **6** | **1** | **92%** |

**Key takeaway:** AI Intelligence has the lowest coverage rate (71%) — both its partial items (AI-002 sentiment analysis, AI-020 smart recommendations) lack a dedicated screen. S-COM carries the only true gap (S-COM-036 polls — no data entity). S-EDU is fully covered at 100% (its two event-weak items are covered in the matrix). S-PAR and S-ADM are strong at 95%.

### 4.5 Coverage by Dimension

| Dimension | Covered | Partial / Missing | Coverage Rate |
|---|---|---|---|
| Screen | 88 | 3 missing | 96.7% |
| Workflow | 91 | 0 missing (2 thin) | 100% |
| Data Entity | 88 | 3 missing | 96.7% |
| Event | 83 | 8 missing* | 91.2% |
| Permission | 91 | 0 missing | 100% |
| Test Scenario | 91 | 0 missing (6 shallow) | 100% |

*Event coverage is the weakest dimension — 8 requirements have no dedicated event in the 60-event catalog. Most are content-lifecycle events (subject/lesson/assignment/quiz creation) and adaptive-learning events.

---

## 5. Recommendations & Remediation Roadmap

### 5.1 Immediate Actions (before P0 sign-off — 🔴 High risk)

| Priority | Action | Gap IDs | Effort |
|---|---|---|---|
| 1 | **Add `polls` + `poll_votes` data entities and `poll.created/voted/closed` events** — unblocks S-COM-036 | GAP-01 | Small (schema + API) |
| 2 | **Add Kill Switch failure-recovery and child-side-recovery test scenarios** — safety-critical | GAP-13 | Medium (test design) |
| 3 | **Add Anti-bypass per-vector test cases** (VPN, proxy, sideload, time-change, uninstall evasion) | GAP-12 | Medium (test design) |

### 5.2 Pre-Launch Actions (before public release — 🟠 Medium risk)

| Priority | Action | Gap IDs | Effort |
|---|---|---|---|
| 4 | Add `call_logs` entity + `call.*` events for S-COM-006 | GAP-02 | Small |
| 5 | Add `is_locked` + `lock_method` to `conversations` for S-COM-052 | GAP-03 | Small |
| 6 | Produce 29-row alert category config sub-spec for S-PAR-045 | GAP-04 | Medium |
| 7 | Add `adaptive.state_updated/difficulty_changed` events + spec adaptation logic for S-EDU-047 | GAP-08 | Medium |
| 8 | Add data export completeness + deletion irreversibility tests for S-ADM-029 | GAP-14 | Medium |

### 5.3 Post-Launch / P1 Enhancements (🟡 Low risk)

| Priority | Action | Gap IDs | Effort |
|---|---|---|---|
| 9 | Add Sentiment Insights screen for AI-002 | GAP-05 | Medium |
| 10 | Clarify AI-020 vs AI-007 relationship (merge or add Learning Path tab) | GAP-06 | Small |
| 11 | Add Notification Scheduling screen for S-ADM-023 | GAP-07 | Small |
| 12 | Add `exercise.completed/graded` events for S-EDU-051 | GAP-09 | Small |
| 13 | Add `report.generated` event for S-PAR-002 | GAP-10 | Small |
| 14 | Add content-lifecycle events (`subject/lesson/assignment/quiz.created`) | GAP-11 | Small |

### 5.4 Spec Health Recommendations

1. **Event catalog expansion** — the 60-event catalog is the weakest traceability surface (91.2% coverage). A focused event-addition sprint covering content lifecycle, adaptive learning, calls, polls, and reporting would raise event coverage to ~99%.
2. **Test depth standard** — adopt a mandatory "happy path + 2 edge cases + 1 negative path" test standard per P0 requirement. The current happy-path-only coverage hides failure modes in safety-critical features (Kill Switch, Anti-bypass, SOS).
3. **AI-007 / AI-020 de-duplication** — two P0 requirements map to the same Recommendations Screen with ambiguous differentiation. Resolve in a design review: either merge (reducing P0 count to 90) or define a distinct surface for each.
4. **Unused entity audit** — `internet_pause_events` exists in the 72-table catalog but no P0 requirement maps to it. Confirm whether it supports an unlisted P1/P2 feature or should be removed from the schema.
5. **Mother-permission traceability** — the 8 mother-excluded screens are documented, but the `mother_permissions` grant/revoke workflow (S-ADM-013) needs per-screen test scenarios verifying that a granted permission actually unlocks the screen for the mother role.

---

*End of document. Companion file: `01_REQUIREMENTS_COVERAGE_MATRIX.md`*
