---
title: "Unified Domain Architecture"
tags: [domain, architecture, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification
---

# Unified Domain Architecture

> The platform is organized into **Domains**, not feature lists. Each Domain has clear boundaries, responsibilities, and contracts with other Domains.

---

## 1. Domain Decomposition

The original 5 systems map to 7 Domains. Two cross-cutting Domains (Family Context + Security & Trust) were extracted because they serve all other Domains.

| # | Domain | Original System | ID Prefix | Services P0 | Services Total |
|---|--------|----------------|-----------|-------------|----------------|
| ١ | **Family & Identity** | Administration (core) | `S-ADM` | 8 | 15 |
| ٢ | **Communications** | التواصل | `S-COM` | 20 | 52 |
| ٣ | **Safety & Monitoring** | المراقبة | `S-PAR` | 20 | 54 |
| ٤ | **Education & Growth** | التعليم | `S-EDU` | 24 | 60 |
| ٥ | **AI Intelligence** | الذكاء الاصطناعي | `AI` | 7 | 22 |
| ٦ | **Administration & Commerce** | Administration (commerce) | `S-ADM` | 12 | 26 |
| ٧ | **Family Context** (cross-cutting) | New | `FC` | — | — |
| ٨ | **Security & Trust** (cross-cutting) | New | `ST` | — | — |

> **Why split Administration?** The original `S-ADM` mixed identity/role management (who you are) with commerce/billing (what you pay). These have different change rates, security profiles, and team ownerships. Splitting them clarifies contracts.

---

## 2. Domain: Family & Identity

| Attribute | Value |
|-----------|-------|
| **Purpose** | Manage the family entity, its members, their roles, and their identity |
| **Responsibilities** | Family creation, member invitation, role assignment, device registration, profile management |
| **Actors** | Father (owner), Mother (limited), Child (subject) |
| **Key Entities** | `Family`, `FamilyMember`, `User`, `Device`, `Invitation`, `Role`, `Permission` |
| **Key Services (P0)** | S-ADM-001/002/003/004/006/009/010/013 |
| **Events Produced** | `family.created`, `member.invited`, `member.joined`, `member.role_changed`, `device.registered`, `device.linked` |
| **Events Consumed** | `subscription.activated` (enables member limits), `subscription.expired` (restricts features) |
| **Dependencies** | Administration & Commerce (subscription gates), Security & Trust (auth) |
| **Offline Behavior** | Family data cached locally in Drift; invitations queued; role changes sync when online |
| **AI Opportunities** | None directly — AI consumes family context |
| **Security** | Father cannot be removed or demoted; child cannot self-remove; all mutations audited |
| **Policies** | Max 6 members, 4 children, 1 device per child; father-only operations enforced at RLS + app level |

---

## 3. Domain: Communications

| Attribute | Value |
|-----------|-------|
| **Purpose** | Provide safe, family-focused communication channels |
| **Responsibilities** | Chat (family/1:1/sub-group), voice messages + transcription, translation, media, calendar (Hijri), tasks, shopping lists, SOS, live location broadcast |
| **Actors** | All roles (father, mother, child) with different capabilities |
| **Key Entities** | `Conversation`, `Message`, `MessageAttachment`, `MessageRead`, `MessageReaction`, `MessageTranslation`, `VoiceTranscription`, `FamilyEvent`, `FamilyTask`, `ShoppingListItem`, `EmergencyEvent`, `Location` |
| **Key Services (P0)** | S-COM-001/002/003/004/006/010/011/025/029/030/031/032/033/035/036/039/041/044/048/052 |
| **Events Produced** | `message.sent`, `message.read`, `voice.transcribed`, `message.translated`, `event.created`, `task.created`, `task.completed`, `sos.activated`, `sos.resolved`, `location.broadcast` |
| **Events Consumed** | `geofence.entered` (→ system message), `geofence.exited` (→ system message), `alert.triggered` (→ notification), `assignment.graded` (→ system message) |
| **Dependencies** | AI (sentiment, translation, transcription), Safety (geofence events → system messages), Education (assignment events → system messages) |
| **Offline Behavior** | Messages queued in Drift; sent on reconnect; voice recorded locally, uploaded when online; calendar/tasks fully offline-syncable |
| **AI Opportunities** | AI-002 sentiment analysis (behind scenes), AI-007/S-COM-044 translation, S-COM-041 Whisper transcription |
| **Security** | Chat lock (father-only); child cannot disable location broadcast; message encryption in transit (TLS 1.3) |
| **Policies** | Family chat is mandatory for all members; child cannot create sub-groups; father-only chat lock; Hijri calendar mandatory |

---

## 4. Domain: Safety & Monitoring

| Attribute | Value |
|-----------|-------|
| **Purpose** | Protect children digitally — screen time, content, location, apps, anti-bypass |
| **Responsibilities** | Screen time limits + reports, device lock, app blocking, web filtering, GPS tracking, geofences, content alerts (29 categories), Kill Switch, Anti-bypass, School Time, Focus Mode execution |
| **Actors** | Father (configures all), Mother (view + limited config), Child (subject — cannot disable) |
| **Key Entities** | `ScreenTimeRule`, `ScreenTimeUsage`, `AppRule`, `AppUsageLog`, `WebHistory`, `WebFilterException`, `Geofence`, `GeofenceEvent`, `Location`, `SocialMediaAlert`, `ContentAlert`, `AntiBypassEvent`, `InternetPauseEvent`, `SchoolTimeSchedule`, `PermissionRequest` |
| **Key Services (P0)** | S-PAR-001/002/003/005/006/009/011/012/014/015/016/017/018/021/032/034/038/041/045/052 |
| **Events Produced** | `screentime.limit_reached`, `device.locked`, `device.unlocked`, `app.blocked`, `app.allowed`, `web.blocked`, `geofence.entered`, `geofence.exited`, `content.alert_triggered`, `killswitch.activated`, `killswitch.deactivated`, `antibypass.attempt_detected`, `schooltime.activated`, `schooltime.deactivated`, `permission.requested`, `permission.approved`, `permission.denied` |
| **Events Consumed** | `family.member_joined` (→ start monitoring), `subscription.activated` (→ enable advanced), `focus.activated` (→ block apps per education request) |
| **Dependencies** | Family & Identity (member roles), AI (content classification), Communications (SOS + geofence system messages), Education (Focus Mode triggers app blocking) |
| **Offline Behavior** | All rules cached locally; enforcement continues offline; usage logs cached + synced; geofence events queued; alerts processed locally for known patterns |
| **AI Opportunities** | AI-002 content classification (29 categories), dialect/slang detection (P1), sensitive image detection (P2) |
| **Security** | Child cannot disable location/app monitoring; Anti-bypass prevents uninstallation; Kill Switch uses VPN + Accessibility; all sensitive operations father-only |
| **Policies** | Father-only: zones, app rules, web filter, Kill Switch, Anti-bypass; Mother: view + School Time (if opened); transparency low for child |

---

## 5. Domain: Education & Growth

| Attribute | Value |
|-----------|-------|
| **Purpose** | Support children's learning with Arabic curriculum, Quran, adaptive learning, gamification |
| **Responsibilities** | Subjects, lessons, assignments, quizzes, AI grading, points/badges, Focus Mode, Quran memorization + recitation, adaptive learning path, placement test, XP/levels |
| **Actors** | Child (performs), Father/Mother (assign + monitor) |
| **Key Entities** | `Subject`, `Lesson`, `LessonCompletion`, `Assignment`, `AssignmentSubmission`, `Quiz`, `QuizQuestion`, `QuizAttempt`, `LearningProgress`, `RewardTransaction`, `FocusSession`, `QuranMemorization`, `QuranRevision`, `AdaptiveLearningState`, `AdaptiveExercise`, `PlacementTest`, `UserXP`, `AITutorSession` |
| **Key Services (P0)** | S-EDU-001/002/003/004/009/010/011/013/014/017/019/020/024/028/029/034/035/038/039/046/047/051/052/058 |
| **Events Produced** | `lesson.completed`, `assignment.submitted`, `assignment.graded`, `quiz.completed`, `points.earned`, `badge.earned`, `focus.activated`, `focus.deactivated`, `quran.recited`, `quran.verified`, `placement.completed`, `level.up`, `xp.earned` |
| **Events Consumed** | `screentime.limit_reached` (→ pause learning), `device.locked` (→ pause), `schooltime.activated` (→ only educational apps) |
| **Dependencies** | AI (tutor AI-003, grading AI-004, recitation AI-008, recommendations AI-020), Safety (Focus Mode triggers app blocking via S-PAR app_rules), Communications (assignment events → system messages) |
| **Offline Behavior** | Lessons + quizzes fully offline; assignments cached, submitted when online; Quran recitation recorded locally, uploaded when online; points/badges computed locally, synced |
| **AI Opportunities** | AI-003 tutor, AI-004 grading, AI-008 recitation analysis, AI-020 smart recommendations, adaptive learning path generation |
| **Security** | Child sees own data only; parents see all children's progress; AI grading results visible to child; no raw message text exposed |
| **Policies** | Parents create content; child performs; points auto-granted; Focus Mode links to Safety app_rules; Hijri dates for assignment due dates |

---

## 6. Domain: AI Intelligence

| Attribute | Value |
|-----------|-------|
| **Purpose** | Provide intelligent assistance across all Domains — assistant, tutor, sentiment, grading, recommendations, recitation analysis |
| **Responsibilities** | AI Orchestrator (rate limit + RAG + safety + logging), family assistant chat, sentiment analysis, private tutor, auto-grading, educational recommendations, Quran recitation analysis |
| **Actors** | All roles (different capabilities) |
| **Key Entities** | `AIConversation`, `AIMessage`, `AIUsageLog`, `SentimentLog`, `AITutorSession`, `AIRecommendation`, `AICostTracking` |
| **Key Capabilities (P0)** | AI-001/002/003/004/007/008/020 |
| **Events Produced** | `ai.response_generated`, `ai.sentiment_analyzed`, `ai.recommendation_generated`, `ai.recitation_analyzed`, `ai.cost_incurred`, `ai.safety_triggered` |
| **Events Consumed** | `message.sent` (→ sentiment analysis), `assignment.submitted` (→ auto-grading), `quran.recited` (→ recitation analysis), `lesson.completed` (→ recommendations) |
| **Dependencies** | Communications (messages), Education (submissions, recitations), Safety (content for classification), Family Context (family state for RAG) |
| **Offline Behavior** | AI capabilities require online (Gemini Cloud Function). Offline mode: assistant unavailable, sentiment queued, grading queued, recitation queued |
| **AI Opportunities** | This IS the AI domain. All capabilities documented with input, output, confidence, failure behavior, privacy, human override, explainability, auditability |
| **Security** | No raw children's messages stored in AI logs (only sentiment result); AI never makes autonomous safety decisions; all AI outputs logged for audit; cost tracking per family |
| **Policies** | AI serves, not decides; sensitive safety decisions require human approval; AI cost capped per family; AI content filtered for child-appropriateness |

---

## 7. Domain: Administration & Commerce

| Attribute | Value |
|-----------|-------|
| **Purpose** | Manage subscription, billing, notifications, settings, privacy, data export/deletion, Today Dashboard, school schedule, trial period |
| **Responsibilities** | Premium subscription (49 SAR/month), 14-day trial, Paywall, notification preferences + center, family/user settings, language (AR/EN), privacy settings, child privacy, data export + deletion (GDPR/PDPL), Today Dashboard, school schedule (Hijri), trial management |
| **Actors** | Father (all), Mother (settings + notifications + export), Child (own settings + notifications) |
| **Key Entities** | `Subscription`, `SubscriptionTrial`, `Notification`, `NotificationPreference`, `FamilySetting`, `UserSetting`, `PrivacySetting`, `MotherPermission`, `SchoolTimeSchedule`, `TodayDashboard` |
| **Key Services (P0)** | S-ADM-014/016/020/022/023/026/027/028/029/033/035/038 |
| **Events Produced** | `subscription.activated`, `subscription.canceled`, `subscription.expired`, `trial.started`, `trial.expired`, `notification.sent`, `notification.read`, `settings.changed`, `language.changed`, `privacy.changed`, `data.exported`, `data.deleted` |
| **Events Consumed** | `sos.activated` (→ push urgent notification), `alert.triggered` (→ push alert notification), `assignment.graded` (→ notification), `geofence.entered/exited` (→ notification) |
| **Dependencies** | Family & Identity (members), Google Play Billing (payment), FCM (push), all Domains (consume their events for notifications + Today Dashboard) |
| **Offline Behavior** | Settings cached locally; notifications queued in Drift; subscription status cached; trial countdown local; export/deletion requires online |
| **AI Opportunities** | Today Dashboard aggregates AI insights; smart notification prioritization (P1) |
| **Security** | Billing father-only; privacy settings father-only for child; data deletion requires 30-day grace period; mother_permissions managed by father only |
| **Policies** | One Premium plan (49 SAR); 14-day trial auto-starts; free tier (**broad** — see `12_business` §3.1): comms + calls + SOS + calendar/tasks + **basic screen time (daily total + top 5 apps)** + **live location + 24 h history** + 1 safe zone; paywall gates: advanced monitoring, Kill Switch, 29 categories, AI, adaptive education |

---

## 8. Cross-Cutting Domain: Family Context

| Attribute | Value |
|-----------|-------|
| **Purpose** | Provide a unified, real-time view of the entire family state that all Domains can consume |
| **Responsibilities** | Aggregate family identity, members, roles, devices, locations, policies, tasks, events, alerts, safety status, schedules, budget, emergencies, decisions into a single context object |
| **Consumers** | All Domains — they read Family Context to make decisions |
| **Producers** | All Domains — they write events that update Family Context |

### Unified Family Context Model

```
FamilyContext {
  family: { id, name, locale, hijri_enabled, subscription_status }
  members: [{
    id, role, display_name, avatar,
    device: { id, model, os_version, last_seen, battery, online },
    location: { lat, lng, accuracy, freshness, geofence_status },
    screen_time: { used_today, limit_today, remaining, focus_active },
    education: { xp, level, assignments_pending, last_lesson },
    safety: { alerts_unread, last_alert_type, killswitch_active },
    status: { in_school, in_focus, sleeping, emergency }
  }]
  policies: { screentime_rules, app_rules, web_filter, geofences, school_time }
  events: [recent_events]  // last 50
  alerts: [active_alerts]
  emergencies: [active_emergencies]
  schedules: { school_schedule, bedtime, quiet_hours }
}
```

**Implementation:** Family Context is a computed projection from all Domain data, cached in Drift and refreshed via Firestore real-time listeners. It is NOT a separate database — it is a materialized view.

---

## 9. Cross-Cutting Domain: Security & Trust

| Attribute | Value |
|-----------|-------|
| **Purpose** | Provide authentication, authorization, encryption, audit, privacy, and compliance across all Domains |
| **Responsibilities** | Firebase Auth (email/password + biometric), RBAC + `mother_permissions`, RLS in PostgreSQL, Firestore Security Rules, TLS 1.3 transit encryption, AES-256 storage encryption, E2E for calls (LiveKit), audit log, tamper resistance (Anti-bypass), rate limiting, data retention, data deletion, export, privacy boundaries, emergency access |

### Security vs Privacy vs Safety vs Compliance

| Concept | Definition | Example |
|---------|-----------|---------|
| **Safety** | Protecting the child from external harm | Content alerts, geofences, Kill Switch |
| **Security** | Protecting the system from unauthorized access | Auth, encryption, RLS, anti-bypass |
| **Privacy** | Protecting the child's personal data from over-exposure | Father sees sentiment result, not raw messages |
| **Compliance** | Meeting legal requirements | GDPR/PDPL data export + deletion, COPPA child data |
| **Trust** | The family's confidence that the platform acts in their interest | Transparency, human override, audit log |

---

## 10. Domain Dependency Map

```
Family & Identity ←──→ Administration & Commerce
       ↑                        ↑
       │                        │
Communications ←──── AI ←──── Education
       ↑                        ↑
       │                        │
Safety & Monitoring ───────────┘
       ↑
       │
  Family Context (all read/write)
       ↑
       │
  Security & Trust (all consume)
```

**Key contracts:**
- Education → Safety: Focus Mode triggers `app_rules` blocking (S-EDU-034 → S-PAR)
- AI → Communications: Sentiment analysis after each message (AI-002 → S-COM)
- AI → Education: Grading, tutor, recitation, recommendations (AI-003/004/008/020 → S-EDU)
- Safety → Communications: Geofence events → system messages (S-PAR → S-COM-036)
- Administration → All: Subscription status gates feature availability
- Family Context → All: Real-time family state projection
