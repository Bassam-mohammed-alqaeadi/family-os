---
title: "UX Architecture & Design System"
tags: [ux, design, architecture, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification
---

# UX Architecture & Design System

---

## 1. Experience Architecture

### 1.1 Information Architecture

```
App
├── Shared (SCR-SHR-*)
│   ├── Splash → Login → Recovery
│   ├── Create Family (father) / Join (mother/child)
│   ├── Profile
│   └── Language Settings
├── Father/Mother Shell
│   ├── Bottom Nav: Today · Communicate · Monitor · Learn · More
│   ├── Today (SCR-ADM-09) — Home
│   │   ├── Needs-me first (alerts, time requests, install approvals)
│   │   ├── Live chips (location freshness, battery, online status)
│   │   ├── Child profile switcher
│   │   └── Instant actions (ring, locate, kill, SOS)
│   ├── Communicate (SCR-COM-01)
│   │   ├── Chat list → Conversation → Voice/Translate/Lock
│   │   ├── Calendar (Hijri+Gregorian)
│   │   ├── Tasks/Shopping
│   │   ├── Quick Location → Map
│   │   └── SOS (receive mode)
│   ├── Monitor (SCR-PAR-01) — Father only / P for Mother
│   │   ├── Screen Time
│   │   ├── Map + GPS
│   │   ├── Safe Zones (father)
│   │   ├── App Rules (father)
│   │   ├── Web Filter (father)
│   │   ├── Content Alerts (29 categories)
│   │   ├── School Time
│   │   ├── Kill Switch (father)
│   │   └── Anti-bypass (father)
│   ├── Learn (SCR-EDU-02)
│   │   ├── Subjects → Lessons → Assignments → Quizzes
│   │   ├── Points + Badges
│   │   ├── Focus Mode
│   │   ├── Quran
│   │   ├── AI Tutor
│   │   └ Placement → Adaptive Path → Exercises → XP
│   └── More (SCR-ADM-06)
│       ├── Admin Hub (father) → Members, Devices, Paywall, Privacy, Trial
│       ├── Notifications
│       ├── Settings
│       └── Export/Delete
└── Child Shell
    ├── Bottom Nav: Learn · Communicate · My Time · AI · More
    ├── Learn (SCR-EDU-01) — Home
    │   ├── Remaining time chip, XP chip, streak
    │   ├── Transparency card ("what parents see")
    │   ├── Subjects → Lessons → Assignments → Quizzes
    │   ├── Focus Mode
    │   ├── Quran recitation
    │   └ Placement → Adaptive → XP Dashboard
    ├── Communicate (SCR-COM-01)
    │   ├── Family chat + 1:1
    │   ├── Voice messages
    │   └── SOS (launch — FAB hold 3s)
    ├── My Time (SCR-PAR-02) — partial (remaining only)
    │   └── Request extra time (SCR-PAR-04)
    ├── AI (SCR-AI-01)
    │   ├── Assistant
    │   ├── Tutor
    │   ├── Recommendations
    │   └── Recitation analysis
    └── More (SCR-ADM-06) — limited
        ├── Profile, Language, Notifications
        └── No members/billing/privacy management
```

### 1.2 Navigation Rules

| Rule | Implementation |
|------|---------------|
| Role-based routing | GoRouter redirects based on `user.role` |
| Mother hard-hide | 13 screens removed from navigation + routes blocked |
| Child restrictions | 25+ screens removed from navigation + routes blocked |
| Permission denial | `UX-PERM-DENIED` dialog within flow (not a new screen) |
| SOS FAB | Floating button on every child screen; hold 3s → `SCR-COM-07` |

---

## 2. Design System

### 2.1 Color Palette

| Token | Hex | Usage |
|-------|-----|-------|
| `--jade-900` | `#0D4A3F` | Dark backgrounds, covers |
| `--jade-700` | `#1B6B5A` | Primary |
| `--jade-600` | `#2A9D8F` | Buttons, links |
| `--jade-500` | `#3DB89E` | Hover, confirmation |
| `--jade-100` | `#D4F0EC` | Pale backgrounds |
| `--jade-50` | `#EEF8F6` | Transparent backgrounds |
| `--coral-700` | `#C25230` | Text on light |
| `--coral-600` | `#E76F51` | Accent secondary |
| `--coral-500` | `#F0916F` | Distinguished actions |
| `--violet-700` | `#5B21B6` | AI text |
| `--violet-600` | `#7C3AED` | AI Primary |
| `--success` | `#10B981` | Success states |
| `--danger` | `#EF4444` | Error, SOS, danger |
| `--warning` | `#F59E0B` | Warning |
| `--info` | `#3B82F6` | Informational (diactic only) |
| `--ink-900`→`--ink-50` | Various | Text, borders, backgrounds |
| `--paper` | `#FFFFFF` | Card background |
| Screen background | `--ink-50` `#F8FAFC` | Always |

### 2.2 Role Differentiation

| Role | How it differs | Color |
|------|---------------|-------|
| Father | Full permissions + exclusive screens | Jade as Primary |
| Mother | Same structure + mother_permissions filter | Same identity; Coral for distinguished actions |
| Child | Different IA (Home = Learning), SOS FAB, low transparency | Jade base; Violet for Education/AI paths |

> **No separate skin/theme per role.** One brand identity, differentiated by IA and permissions.

### 2.3 Typography

| Role | Font | Notes |
|------|------|-------|
| Display/Headings | Cairo | No long paragraphs |
| Body text | IBM Plex Arabic | |
| Numbers | Tajawal | |
| Minimum size | 12px | |

### 2.4 Spacing & Geometry

- Spacing scale: 4 / 8 / 12 / 16 / 24 / 32 / 48 / 64
- Card gap: 16 · Section gap: 24 · Large section: 32
- Corner radius: Cards/buttons/fields 14px · Covers 28px · Badges full
- Shadows: sh-1 flat · sh-2 card · sh-3 dialog · sh-4 cover

### 2.5 Components

| Component | Specification |
|-----------|--------------|
| Buttons | Primary (Jade) · Coral · Violet (AI) · Outline · Ghost · Danger · 3 sizes |
| Fields | Visible label · focus with Jade-600 + subtle ring |
| Cards | Soft shadow OR uniform border — NO colored side-border + rounded corners together |
| Icons | Phosphor Regular 24px stroke 1.5 — NO emoji in UI (except chat bubbles) |
| Bottom nav | Per role from IA |
| FAB SOS | Danger + pulse animation only |
| Charts | fl_chart |
| Maps | Google Maps SDK |

### 2.6 Mandatory UI States

Every screen must implement: `empty` · `loading (shimmer)` · `success` · `error` · `denied-permission` (if applicable) · `locked` (child) · `trial-expired` (premium features)

### 2.7 Motion

| Type | Duration | When |
|------|----------|------|
| fade-in-up | 600ms | Cards |
| slide-in-right | 400ms | RTL navigation |
| scale-in | 300ms | Dialogs |
| pulse | 2000ms ∞ | SOS / live |
| shimmer | 1500ms ∞ | Loading |

> No parallax · No motion >800ms for general elements · Stagger 100–200ms

### 2.8 Anti-Slop Rules (10 Mandatory)

1. No gradient on text
2. No emoji in production UI (except inside chat bubbles)
3. No colored side-border cards
4. Screen background = Ink-50 only
5. No Inter/Roboto/Arial fonts
6. No decorative stats without purpose
7. Simple SVG / Phosphor icons only
8. Real content density
9. Complete states for every screen
10. Spacing that breathes

---

## 3. Screen Catalog (62 MVP)

### Count by System

| System | Count |
|--------|-------|
| Communications | 11 |
| Monitoring | 12 |
| Education | 15 |
| AI | 5 |
| Administration | 11 |
| Shared | 6 |
| Mandatory UI flows (+2) | 2 |
| **Total** | **62** |

### Full catalog: see `05_user_experience/02_SCREEN_CATALOG.md`

---

## 4. Localization

| Aspect | Value |
|--------|-------|
| Languages (MVP) | Arabic (primary) + English |
| Direction | RTL (Arabic) · LTR (English) — dynamic switch |
| i18n files | ARB format |
| Calendar | Hijri (mandatory) + Gregorian (secondary) |
| Future languages (P1) | Urdu + Hindi |
| Fonts | IBM Plex Arabic / Cairo / Tajawal — support both scripts |

---

## 5. Accessibility

| Requirement | Implementation |
|-------------|---------------|
| Min text size | 12px |
| Font scaling | small/medium/large/extra_large |
| High contrast | Theme support (P1) |
| Screen reader | Semantic labels on all interactive elements |
| Touch targets | Minimum 44×44dp |
| Color contrast | WCAG AA minimum |
