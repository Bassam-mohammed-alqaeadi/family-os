---
title: "Screen Catalog (62 MVP)"
tags: [screens, catalog, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification
---

# Screen Catalog (62 MVP)

> Canonical source for Screen IDs. Frozen by Constitution. No additions without updating Constitution + this file.

---

## Shared (SCR-SHR-*) — 6

| ID | Screen | Roles | Services |
|----|--------|-------|----------|
| SCR-SHR-01 | Splash | All | — |
| SCR-SHR-02 | Login (email/password) | All | S-ADM-001 |
| SCR-SHR-03 | Account recovery (email) | All | S-ADM-001 |
| SCR-SHR-04 | Create family (onboarding) | Father | S-ADM-002–006 |
| SCR-SHR-05 | Profile | All | S-ADM-026 |
| SCR-SHR-06 | Language settings (AR/EN) | All | S-ADM-027 |
| ~~SCR-SHR-07~~ | ~~Child transparency~~ | — | CANCELLED |

## Communications (SCR-COM-*) — 11

| ID | Screen | Roles | Services |
|----|--------|-------|----------|
| SCR-COM-01 | Chat list | All | S-COM-001/002/003 |
| SCR-COM-02 | Conversation detail | All | S-COM-004/006/010/011/025/029/048 |
| SCR-COM-03 | Family calendar (Hijri) | Father, Mother | S-COM-030/031 |
| SCR-COM-04 | Tasks/shopping | All | S-COM-032/033 |
| SCR-COM-05 | Calendar event | Father, Mother | S-COM-030 |
| SCR-COM-06 | Quick location | All | S-COM-035/036 |
| SCR-COM-07 | SOS (launch/receive) | Child launch; Parent receive | S-COM-039 + S-PAR-032 |
| SCR-COM-08 | Message settings | Father, Mother | P0 message settings |
| SCR-COM-09 | Translation settings | All | S-COM-044 |
| SCR-COM-10 | Voice + transcription | All | S-COM-006/041 |
| SCR-COM-11 | Lock conversation | Father only | S-COM-052 |

## Monitoring (SCR-PAR-*) — 12

| ID | Screen | Roles | Services |
|----|--------|-------|----------|
| SCR-PAR-01 | Monitoring hub | Father; Mother P | S-PAR-001/034 |
| SCR-PAR-02 | Screen time | Father full; Child partial | S-PAR-001/002/003/006 |
| SCR-PAR-03 | Device lock (child) | Child | S-PAR-005 |
| SCR-PAR-04 | Extra time request | Child | S-PAR-009 |
| SCR-PAR-05 | Map + GPS | Father, Mother | S-PAR-011/012 + S-COM-035 |
| SCR-PAR-06 | Safe zones | Father only | S-PAR-014 |
| SCR-PAR-07 | App rules | Father only | S-PAR-015/016 |
| SCR-PAR-08 | Web filter | Father only | S-PAR-017/018 |
| SCR-PAR-09 | Content alerts (29) | Father, Mother P | S-PAR-021/045 + AI-002 |
| SCR-PAR-10 | School Time | Father; Mother P | S-PAR-052 |
| SCR-PAR-11 | Kill Switch | Father only | S-PAR-041 |
| SCR-PAR-12 | Anti-bypass | Father only | S-PAR-038 |

## Education (SCR-EDU-*) — 15

| ID | Screen | Roles | Services |
|----|--------|-------|----------|
| SCR-EDU-01 | Learning home (Child Home) | All | S-EDU-002 |
| SCR-EDU-02 | Subjects | All | S-EDU-001/002 |
| SCR-EDU-03 | Lessons | Child | S-EDU-003/004 |
| SCR-EDU-04 | Interactive lesson | Child | S-EDU-004 |
| SCR-EDU-05 | Assignment + submit | Child | S-EDU-009–014 + AI-004 |
| SCR-EDU-06 | Quiz | Child | S-EDU-017/019/020 |
| SCR-EDU-07 | Quiz results | All | S-EDU-020 |
| SCR-EDU-08 | Points + badges | All | S-EDU-024/028/029 |
| SCR-EDU-09 | Focus Mode | Child | S-EDU-034/035 |
| SCR-EDU-10 | Quran recitation | Child | S-EDU-038/039 + AI-008 |
| SCR-EDU-11 | AI Tutor | All | S-EDU-046 + AI-003 |
| SCR-EDU-12 | Placement test | Child | S-EDU-052 |
| SCR-EDU-13 | Adaptive path | Child | S-EDU-047 |
| SCR-EDU-14 | Adaptive exercise | Child | S-EDU-047/051 |
| SCR-EDU-15 | Level + XP | All | S-EDU-058 |

## AI (SCR-AI-*) — 5

| ID | Screen | Roles | Services |
|----|--------|-------|----------|
| SCR-AI-01 | AI Assistant | All | AI-001 |
| SCR-AI-02 | Private tutor | All | AI-003 |
| SCR-AI-03 | AI recommendations | Father, Child | AI-007 |
| SCR-AI-04 | Recitation analysis | Child | AI-008 |
| SCR-AI-05 | Smart edu recommendations | All | AI-020 |

## Administration (SCR-ADM-*) — 11

| ID | Screen | Roles | Services |
|----|--------|-------|----------|
| SCR-ADM-01 | Admin hub | Father only | S-ADM-001 |
| SCR-ADM-02 | Members | Father only | S-ADM-002/003/004/006 |
| SCR-ADM-03 | Devices + permissions | Father only | S-ADM-009/010/013 |
| SCR-ADM-04 | Premium + Paywall | Father only | S-ADM-014/016 |
| SCR-ADM-05 | Notifications | All | S-ADM-020/022/023 |
| SCR-ADM-06 | Settings + language + privacy | All | S-ADM-026/027 |
| SCR-ADM-07 | Child privacy | Father only | S-ADM-028 |
| SCR-ADM-08 | Export + delete | Father, Mother | S-ADM-029 |
| SCR-ADM-09 | Today Dashboard (Parent Home) | Father, Mother | S-ADM-033 |
| SCR-ADM-10 | School schedule (Hijri) | Father | S-ADM-035 |
| SCR-ADM-11 | Trial (14 days) | Father | S-ADM-038 |

## Mandatory UI Flows (+2)

| ID | Description |
|----|-------------|
| UX-SOS-RECV | SOS receive mode on SCR-COM-07 (different layout) |
| UX-PERM-DENIED | Permission denial dialog (Accessibility/Location/Notifications/Overlay/UsageStats) |

## Summary

| System | Count |
|--------|-------|
| Shared | 6 |
| Communications | 11 |
| Monitoring | 12 |
| Education | 15 |
| AI | 5 |
| Administration | 11 |
| UI Flows | 2 |
| **Total** | **62** |
