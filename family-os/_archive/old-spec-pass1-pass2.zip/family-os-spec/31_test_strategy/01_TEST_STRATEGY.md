---
title: "Test Strategy & Quality Assurance Plan"
tags: [testing, qa, strategy, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification (Pass 2)
---

# Test Strategy & Quality Assurance Plan

> Comprehensive testing strategy covering unit, integration, E2E, device, security, compliance, and user acceptance testing.

---

## 1. Testing Pyramid

```
                    ┌─────────┐
                    │   E2E   │  ~5% — Critical user journeys
                    │  Tests  │
                  / └─────────┘ \
                /                 \
              /                     \
            /     ┌─────────┐         \
           /      │Integrat.│  ~25%    \
          /       │  Tests  │           \
         /        └─────────┘             \
        /                                   \
       /         ┌─────────┐                  \
      /           │  Unit   │  ~70%             \
     /            │  Tests  │                     \
    /             └─────────┘                      \
   /________________________________\
```

---

## 2. Unit Testing

### 2.1 Framework
- **Flutter:** `flutter_test` package
- **Backend:** `jest` for Cloud Functions (Node.js)
- **Coverage target:** 80% line coverage, 70% branch coverage

### 2.2 Critical Unit Test Areas

| Area | What to Test | Count Est. |
|------|-------------|------------|
| Auth | Token refresh, session expiry, biometric fallback | ~20 |
| RBAC | Role permissions per screen/action, mother_permissions overlay | ~50 |
| Drift DB | CRUD operations, migration scripts, conflict resolution | ~100 |
| Cloud SQL | RLS policies, query correctness, constraint validation | ~80 |
| Firestore | Security rules, real-time listener updates | ~40 |
| Message handling | Send, queue, retry, read receipts, reactions | ~30 |
| Screen time | Usage calculation, limit enforcement, bedtime triggers | ~25 |
| GPS/Geofence | Location parsing, geofence enter/exit detection | ~20 |
| App blocking | Package name matching, category rules, Accessibility events | ~25 |
| Content alerts | 29 category classification, severity scoring, dedup | ~30 |
| Education | Assignment grading, quiz scoring, points calculation | ~35 |
| Adaptive learning | Level transitions, exercise generation, placement scoring | ~20 |
| Quran | Recitation accuracy calculation, tajweed error detection | ~15 |
| AI Orchestrator | Rate limiting, RAG retrieval, safety filter, cost tracking | ~25 |
| Subscription | Trial countdown, billing state, feature gating | ~20 |
| Sync | Queue operations, conflict resolution, idempotency | ~30 |
| **Total** | | **~565** |

---

## 3. Integration Testing

### 3.1 Framework
- **Flutter:** `integration_test` package + `mockito` for mocking
- **Backend:** `jest` + `firebase-functions-test`
- **Database:** Test containers with PostgreSQL + Firestore emulator

### 3.2 Critical Integration Test Flows

| Flow | Systems | What to Verify |
|------|---------|----------------|
| Auth → Family creation → Member invite | Auth + Family + Invitations | End-to-end onboarding |
| Message send → Sentiment analysis → Alert | Comms + AI + Safety | AI-002 behind-scenes pipeline |
| Assignment submit → AI grading → Notification | Education + AI + Admin | Full grading pipeline |
| Geofence enter → System message → Push notification | Safety + Comms + Admin | Cross-system event flow |
| Screen time limit → Device lock → Extra time request | Safety + Family | Enforcement + recovery |
| SOS → Location broadcast → Parent notification → Resolve | Comms + Safety + Admin | Critical safety flow |
| Focus Mode → App blocking → Timer → XP award | Education + Safety | Cross-domain dependency |
| Trial expire → Feature gate → Paywall → Subscribe | Admin + Commerce | Revenue flow |
| Device link → Permission grant → Monitoring start | Family + Safety | Device enrollment |
| Quran recite → Upload → Whisper → Gemini → Result | Education + AI | Audio processing pipeline |

---

## 4. End-to-End (E2E) Testing

### 4.1 Framework
- **Flutter:** `integration_test` with real Firebase emulators
- **Device:** Android Emulator (API 29, 33, 34) + real devices

### 4.2 Critical E2E User Journeys

| Journey | Steps | Pass Criteria |
|---------|-------|---------------|
| Father onboarding | Install → Register → Create family → Invite mother → Invite child → Link child device → Grant permissions → Configure screen time → First dashboard | All steps complete, data synced, dashboard populated |
| Child daily learning | Open app → Learning home → Start lesson → Complete → Take quiz → Submit → AI grades → Earn XP → Level up → Start Focus Mode | All steps complete, XP awarded, level updated |
| SOS emergency | Child triggers SOS → Parent receives FCM → Parent opens SOS → View child location → Call child → Resolve | SOS delivered <5s, parent notified <30s, resolution logged |
| Offline → Online sync | Go offline → Send messages → Complete assignments → Go online → Sync | All data synced, no conflicts, no data loss |
| Subscription flow | Trial day 14 → Open app → Paywall shown → Subscribe → Premium active | Feature gate triggers, payment processes, features unlock |
| Cross-system alert | Child receives bullying message → AI-002 detects → Parent alert → Parent reviews → Parent acts | Alert delivered, parent can review, action logged |

---

## 5. Device Testing Matrix

| Device | API Level | Screen | Priority | Notes |
|--------|-----------|--------|----------|-------|
| Samsung Galaxy S23 | 34 | 1080×2340 | Critical | Most common flagship |
| Samsung Galaxy A54 | 34 | 1080×2400 | Critical | Most common mid-range |
| Samsung Galaxy A14 | 33 | 720×1600 | High | Budget device |
| Xiaomi Redmi Note 12 | 33 | 1080×2400 | High | Popular budget |
| Google Pixel 7 | 34 | 1080×2400 | Medium | Clean Android |
| Samsung Galaxy Tab A9 | 33 | 1340×800 | Medium | Tablet layout |
| Oppo Reno 8 | 33 | 1080×2412 | Medium | Popular in Gulf |
| Huawei Nova 11 | 33 | 1080×2388 | Low | No GMS — check HMS |

### Key Device Test Areas:
- RTL layout correctness on all screen sizes
- Accessibility Service reliability across OEM skins
- VPN (Kill Switch) compatibility across OEM modifications
- Battery drain monitoring (foreground + background)
- Notification delivery (FCM) across OEM power management
- Location accuracy in balanced power mode

---

## 6. Security Testing

### 6.1 Static Analysis

| Tool | Target | What it finds |
|------|--------|---------------|
| `dart_code_metrics` | Flutter code | Code quality, complexity, unused code |
| `snyk` | Dependencies | Known vulnerabilities |
| `Semgrep` | Flutter + Node.js | Security anti-patterns |
| `firebase-security-rules-test` | Firestore rules | Permission bypass attempts |

### 6.2 Dynamic Security Testing

| Test | Method | Pass Criteria |
|------|--------|---------------|
| RLS bypass attempt | Direct SQL with non-family user | All queries blocked |
| Firestore rules bypass | Direct Firestore access with wrong UID | All reads/writes blocked |
| Token tampering | Modify JWT payload | Auth rejected |
| API rate limit | Send 200 requests in 10 seconds | Rate limit triggers at threshold |
| SOS rate limit | Trigger 15 SOS in 1 hour | Blocked after 10th |
| Anti-bypass: uninstall attempt | Try to uninstall app on child device | Device Admin prevents uninstall |
| Anti-bypass: force stop | Try to force-stop app | Foreground service persists |
| Anti-bypass: date change | Change device date/time | Accessibility detects + alerts father |
| Anti-bypass: VPN usage | Install third-party VPN | Kill Switch VPN takes priority |
| Storage encryption | Inspect Drift database file | SQLCipher encrypted, not readable |

### 6.3 Penetration Testing (Pre-Launch)

| Area | Scope |
|------|-------|
| Authentication | Firebase Auth bypass, session hijacking, password reset abuse |
| Authorization | RLS bypass, mother_permissions circumvention, child privilege escalation |
| Data exposure | Message interception, location data leak, sentiment data leak |
| AI abuse | Prompt injection, jailbreak attempts, cost bombing |
| SOS abuse | False SOS flooding, SOS interception |
| Child safety | Can child disable monitoring? Can child see alerts? Can child fake location? |

---

## 7. Compliance Testing

| Regulation | Test | Pass Criteria |
|------------|------|---------------|
| COPPA | Verify no raw child text in AI logs | sentiment_logs table has NO message_text column |
| COPPA | Verify parent consent flow | Cannot create child account without father's family |
| PDPL | Data export completeness | Export ZIP contains all user data in JSON |
| PDPL | Data deletion completeness | After 30-day grace, all user data hard-deleted |
| PDPL | Arabic language availability | All user-facing text available in Arabic |
| GDPR | Right to portability | JSON export is machine-readable |
| GDPR | Right to be forgotten | Deletion removes from all stores + backups |
| Google Play | Accessibility justification | Promo video + documentation submitted |
| Google Play | SMS/call log declaration | Only CALL_PHONE for SOS, no SMS read |

---

## 8. Performance Testing

| Metric | Test Method | Target |
|--------|------------|--------|
| App cold start | Launch on mid-range device | < 2 seconds |
| App warm start | Launch from background | < 500ms |
| Message send (optimistic) | Tap send button | < 200ms UI feedback |
| Message delivery | Send → receive on other device | < 2 seconds |
| AI grading | Submit assignment → grade returned | < 10 seconds |
| Translation | Send message → translation available | < 2 seconds |
| Voice transcription (30s) | Send voice → text available | < 3 seconds |
| SOS delivery | Child trigger → parent FCM | < 5 seconds |
| Screen time check | App launch → enforcement check | < 100ms |
| Geofence detection | Enter zone → notification | < 30 seconds |
| Battery (foreground) | 1 hour active monitoring | < 4% drain |
| Battery (background) | 1 hour background | < 1.5% drain |
| Battery (location) | 1 hour balanced GPS | < 2% drain |
| Local DB size | 30 days of usage | < 50MB |
| App size (initial) | Fresh install | < 50MB |

---

## 9. UX Testing

### 9.1 Shneiderman Checklist (Per Screen)

Every screen validated against:
1. **Visibility of system status** — loading indicators, sync status, online/offline
2. **Match between system and real world** — Arabic language, Hijri dates, cultural appropriateness
3. **User control and freedom** — cancel, undo, back navigation
4. **Consistency and standards** — design system compliance, RTL alignment
5. **Error prevention** — confirmation dialogs for destructive actions, input validation
6. **Recognition rather than recall** — visible options, persistent labels
7. **Flexibility and efficiency** — shortcuts, quick actions, FAB
8. **Aesthetic and minimalist design** — no decorative clutter, purposeful elements
9. **Help users recognize/recover from errors** — specific error messages, recovery paths
10. **Help and documentation** — tooltips, onboarding, help screens

### 9.2 Accessibility Testing

| Test | Tool | Pass Criteria |
|------|------|---------------|
| Screen reader | TalkBack | All interactive elements have semantic labels |
| Color contrast | Accessibility Scanner | WCAG AA minimum (4.5:1 for normal text) |
| Touch targets | Manual measurement | Minimum 44×44dp |
| Font scaling | Settings → Large font | UI adapts without overflow |
| High contrast | Settings → High contrast | Theme support (P1) |
| RTL correctness | Visual inspection | All layouts mirror correctly in RTL |

### 9.3 User Acceptance Testing

| Phase | Participants | Duration | Focus |
|-------|-------------|----------|-------|
| Alpha | 5 families (internal) | 2 weeks | Core flows, crashes, data sync |
| Beta | 50 families (invited) | 4 weeks | Real-world usage, battery, network |
| Open Beta | 500 families | 2 weeks | Scale, edge cases, feedback |
| Pre-launch | 1000 families | 1 week | Final validation, store readiness |

---

## 10. Test Automation CI/CD

```
Code Push → GitHub Actions
    ↓
[1] Lint (dart analyze + eslint)
[2] Unit Tests (flutter test + jest)
[3] Static Security (Semgrep + snyk)
[4] Build (flutter build apk --debug)
[5] Integration Tests (integration_test + emulators)
[6] Coverage Report (80% line, 70% branch)
    ↓
PR Review → Merge → Staging
    ↓
[7] E2E Tests (staging environment)
[8] Security Scan (staging)
[9] Performance Test (staging)
    ↓
Release Candidate → Production
```

---

## 11. Quality Gates

| Gate | Criteria | Blocking? |
|------|----------|-----------|
| Code review | 2 approvals, no unresolved comments | ✅ |
| Unit tests | 80% line, 70% branch, 0 failures | ✅ |
| Integration tests | 0 failures on critical flows | ✅ |
| E2E tests | 0 failures on critical journeys | ✅ |
| Security scan | 0 critical/high vulnerabilities | ✅ |
| Performance | All NFR targets met | ✅ |
| Accessibility | WCAG AA, TalkBack, 44dp targets | ✅ |
| Design system | 0 anti-slop violations | ✅ |
| RTL validation | All screens pass RTL check | ✅ |
| Crash-free | > 99.5% in beta | ✅ |
