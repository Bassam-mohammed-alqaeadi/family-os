---
title: "System Architecture & Offline-First"
tags: [architecture, offline, system, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification
---

# System Architecture & Offline-First

---

## 1. Technical Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Flutter Application (Dart)                 │
│  UI + Navigation + State + Business Logic                    │
│  MVVM + Riverpod 2.x + GoRouter                              │
├─────────────────────────────────────────────────────────────┤
│  Local DB (Drift/SQLite) │ fl_chart │ Lottie │ LiveKit      │
├─────────────────────────────────────────────────────────────┤
│              Native Android Bridges (Kotlin/Java)             │
│  UsageStatsManager │ AccessibilityService │ FusedLocation    │
│  GeofencingClient │ VPN (Kill Switch) │ MediaRecorder        │
│  WorkManager │ Foreground Service │ DevicePolicyManager      │
├─────────────────────────────────────────────────────────────┤
│                    Backend (Cloud)                            │
│  Firebase Auth │ Cloud Firestore │ Cloud Functions (Node.js) │
│  Cloud SQL (PostgreSQL+RLS) │ Redis │ Pinecone │ FCM         │
│  Gemini 2.5 Flash │ Whisper │ Google Play Billing            │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. Native Bridges (14 P0)

| Service | Android API | Bridge Type | System |
|---------|-------------|-------------|--------|
| Screen time | UsageStatsManager | Channel | Monitoring |
| App blocking + content | AccessibilityService | Channel | Monitoring |
| Device lock | Accessibility + Overlay / DPM | Channel | Monitoring |
| GPS | FusedLocationProvider | Plugin | Monitoring + Comms |
| Geofences | GeofencingClient | Plugin | Monitoring |
| Kill Switch | Local VPN + Accessibility | Channel | Monitoring |
| Anti-bypass | VPN + Accessibility + DPM | Channel | Monitoring |
| School Time | WorkManager + Accessibility | Channel | Monitoring |
| Quran recording | MediaRecorder | Channel | Education |
| Billing | Play Billing | Plugin | Admin |
| Invitations | Dynamic Links | Plugin | Admin |
| Background service | WorkManager / FGS | Plugin/Channel | Multi |
| Incidents | SensorManager | Channel | Comms |
| Images (P2) | TFLite | Plugin | Monitoring |

> Every sensitive permission: **denial path** with explanation + "Open Settings" button.

---

## 3. Offline-First Architecture

### 3.1 Principle

> Every Domain operates in three modes: **Online**, **Offline**, **Degraded**. Offline is not a fallback — it is an architecture.

### 3.2 Mode Matrix

| Domain | Online | Offline | Degraded |
|--------|--------|---------|----------|
| Communications | Full: messages, calls, translation | Messages queued, voice recorded locally, calendar/tasks fully functional | Calls unavailable, translation queued, AI unavailable |
| Monitoring | Full: real-time tracking, AI classification | Rules enforced locally, usage logs cached, geofence events queued | AI classification queued, remote lock unavailable (local enforcement continues) |
| Education | Full: AI grading, tutor, adaptive | Lessons/quizzes fully offline, assignments cached, points local | AI grading queued, tutor unavailable, adaptive limited to local state |
| AI | Full | Unavailable (requires Gemini) | All AI queued for when online |
| Admin | Full | Settings local, notifications queued, subscription cached | Export/delete require online, billing requires online |

### 3.3 Sync Architecture

```
Local Operation (Drift)
    ↓
Sync Queue (Drift: pending_operations table)
    ↓
On reconnect: 
    [1] Flush queue → Cloud Functions
    [2] Conflict resolution (last-writer-wins for most; merge for messages)
    [3] Pull latest from Cloud SQL → update Drift cache
    [4] Firestore real-time listeners resume
```

### 3.4 Conflict Resolution

| Data Type | Strategy |
|-----------|----------|
| Messages | Append-only (no conflict) |
| Calendar events | Last-writer-wins |
| Tasks | Last-writer-wins |
| Screen time rules | Last-writer-wins (father's device authoritative) |
| Usage logs | Merge (each device logs independently) |
| Points/XP | Server-authoritative (recalculate on sync) |
| Quiz attempts | No conflict (single submit) |
| Settings | Last-writer-wins |
| Location | No conflict (overwrite) |

### 3.5 Retry Strategy

- Exponential backoff: 1s → 2s → 4s → 8s → 16s → 32s → 60s (max)
- Max 3 retries for non-critical; infinite for SOS
- Idempotency key on every operation to prevent duplicates
- SOS: urgent priority — bypasses queue, sends immediately on any connectivity

### 3.6 Event Ordering

- Events timestamped at creation (client time + server time on receipt)
- Server reconciles using vector clocks for same-family events
- SOS events always priority-processed regardless of queue order

---

## 4. Backend Architecture

### 4.1 Cloud Functions (Node.js)

| Function | Purpose | Trigger |
|----------|---------|---------|
| `messageSender` | Send message + FCM | HTTP POST |
| `sentimentAnalyzer` | AI-002 sentiment | Pub/Sub (after message) |
| `contentScanner` | AI content classification | HTTP POST (from Accessibility) |
| `aiOrchestrator` | Rate limit + RAG + Gemini + safety | HTTP POST |
| `aiGrader` | Auto-grading | Pub/Sub (after submission) |
| `quranAnalyzer` | Whisper + Gemini recitation | HTTP POST |
| `translator` | Gemini translate + Redis cache | HTTP POST |
| `voiceTranscriber` | Whisper STT | HTTP POST |
| `locationUpdater` | Save location + geofence check | HTTP POST |
| `emergencyHandler` | SOS + FCM + auto-call | HTTP POST |
| `killSwitchHandler` | Internet pause/resume | HTTP POST |
| `subscriptionManager` | Trial + billing + features | HTTP + Scheduled |
| `trialReminder` | Day 11 + Day 14 FCM | Scheduled (cron daily) |
| `todayDashboard` | Aggregate dashboard data | HTTP GET |
| `weeklyReport` | Sunday report | Scheduled (cron weekly) |

### 4.2 Data Partitioning

| Data | Partition Strategy |
|------|-------------------|
| Messages | By family_id, then by month |
| Usage logs | By user_id, then by month |
| Location history | By user_id, then by month; BigQuery after 30 days |
| Audit logs | By family_id, then by month |
| AI usage logs | By family_id, then by month |

---

## 5. Non-Functional Requirements (NFR)

| Category | Metric | Target |
|----------|--------|--------|
| **Performance** | App load time | < 2s |
| | API response (P95) | < 500ms |
| | Message send (optimistic) | < 200ms |
| | Message delivery | < 2s |
| | Call start | < 3s |
| | AI grading | < 10s |
| | Translation | < 2s |
| | Voice transcription (30s msg) | < 3s |
| | SOS response (child→parent) | < 5s |
| **Scalability** | Families | 100K at launch → 5.5M by 2028 |
| | Concurrent users | 100K → 2M |
| | Database | RLS + read replicas + partitioning |
| **Reliability** | Uptime | 99.5% |
| | Crash-free sessions | > 99.5% |
| | Firestore sync success | > 99.5% |
| | Offline sync success | > 99% |
| **Security** | Auth | Firebase Auth + biometric |
| | Encryption | TLS 1.3 + AES-256 |
| | RLS | All family-scoped tables |
| | Audit | All sensitive actions |
| **Privacy** | COPPA | Compliant (no raw text, parent consent) |
| | PDPL | Compliant (consent, access, deletion) |
| | GDPR | Ready (export, deletion, portability) |
| **Battery** | Foreground monitoring | ~4%/hour |
| | Background monitoring | ~1.5%/hour |
| | Location (balanced) | ~2%/hour |
| **Storage** | App size | < 50MB initial |
| | Local DB | < 100MB per device |
| | Media | Firebase Storage (cloud) |
| **Observability** | Crash reporting | Firebase Crashlytics |
| | Performance | Firebase Performance Monitoring |
| | AI cost tracking | Per family per day |
| **Localization** | Arabic + English | RTL/LTR dynamic |
| | Hijri calendar | Mandatory |
| **Compatibility** | Android | 10+ (API 29+) |
| | iOS | Deferred (P1+) |
