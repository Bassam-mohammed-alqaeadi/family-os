---
title: "Permission Matrix — Role × Screen × Action × Android Permission"
tags: [permissions, security, rbac, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification (Pass 2)
---

# Permission Matrix

> The complete authority on who can access what, do what, and what Android permissions each action requires.

---

## 1. Role Permission Overview

| Screen/Action | Father (admin) | Mother (limited_admin) | Child (child) |
|---------------|:---:|:---:|:---:|
| **Shared** | | | |
| SCR-SHR-01 Splash | ✅ | ✅ | ✅ |
| SCR-SHR-02 Login | ✅ | ✅ | ✅ |
| SCR-SHR-03 Account recovery | ✅ | ✅ | ✅ |
| SCR-SHR-04 Create family | ✅ | ❌ | ❌ |
| SCR-SHR-05 Profile | ✅ (all fields) | ✅ (own fields) | ✅ (limited fields) |
| SCR-SHR-06 Language | ✅ | ✅ | ✅ |
| **Communications** | | | |
| SCR-COM-01 Chat list | ✅ | ✅ | ✅ |
| SCR-COM-02 Conversation | ✅ | ✅ | ✅ |
| SCR-COM-03 Calendar | ✅ | ✅ | ❌ (view only via home) |
| SCR-COM-04 Tasks/shopping | ✅ | ✅ | ✅ (tasks assigned) |
| SCR-COM-05 Event edit | ✅ | ✅ | ❌ |
| SCR-COM-06 Quick location | ✅ | ✅ | ✅ (share own) |
| SCR-COM-07 SOS | ✅ (receive) | ✅ (receive) | ✅ (launch) |
| SCR-COM-08 Message settings | ✅ | ✅ | ❌ |
| SCR-COM-09 Translation | ✅ | ✅ | ✅ |
| SCR-COM-10 Voice msg | ✅ | ✅ | ✅ |
| SCR-COM-11 Chat lock | ✅ | ❌ | ❌ |
| Create sub-group | ✅ | ❌ | ❌ |
| **Monitoring** | | | |
| SCR-PAR-01 Monitoring hub | ✅ | ✅ (limited) | ❌ |
| SCR-PAR-02 Screen time | ✅ (full) | ✅ (view) | ✅ (remaining only) |
| SCR-PAR-03 Device lock | ✅ (trigger) | ❌ | ✅ (locked view) |
| SCR-PAR-04 Extra time request | ✅ (approve) | ✅ (approve if granted) | ✅ (request) |
| SCR-PAR-05 Map + GPS | ✅ | ✅ | ❌ |
| SCR-PAR-06 Safe zones | ✅ | ❌ | ❌ |
| SCR-PAR-07 App rules | ✅ | ❌ | ❌ |
| SCR-PAR-08 Web filter | ✅ | ❌ | ❌ |
| SCR-PAR-09 Content alerts | ✅ | ✅ (if granted) | ❌ |
| SCR-PAR-10 School Time | ✅ | ✅ (if granted) | ❌ |
| SCR-PAR-11 Kill Switch | ✅ | ❌ | ❌ |
| SCR-PAR-12 Anti-bypass | ✅ | ❌ | ❌ |
| **Education** | | | |
| SCR-EDU-01 Learning home | ✅ (monitor) | ✅ (monitor) | ✅ (learn) |
| SCR-EDU-02 Subjects | ✅ (manage) | ✅ (manage) | ✅ (view) |
| SCR-EDU-03 Lessons | ✅ (manage) | ✅ (manage) | ✅ (view) |
| SCR-EDU-04 Interactive lesson | ✅ (preview) | ✅ (preview) | ✅ (learn) |
| SCR-EDU-05 Assignment submit | ✅ (create/grade) | ✅ (create/grade) | ✅ (submit) |
| SCR-EDU-06 Quiz | ✅ (create) | ✅ (create) | ✅ (take) |
| SCR-EDU-07 Quiz results | ✅ (all children) | ✅ (all children) | ✅ (own) |
| SCR-EDU-08 Points + badges | ✅ (all) | ✅ (all) | ✅ (own) |
| SCR-EDU-09 Focus Mode | ❌ | ❌ | ✅ |
| SCR-EDU-10 Quran | ✅ (monitor) | ✅ (monitor) | ✅ (practice) |
| SCR-EDU-11 AI Tutor | ✅ | ✅ | ✅ |
| SCR-EDU-12 Placement test | ✅ (assign) | ✅ (assign) | ✅ (take) |
| SCR-EDU-13 Adaptive path | ✅ (view) | ✅ (view) | ✅ (follow) |
| SCR-EDU-14 Adaptive exercise | ❌ | ❌ | ✅ |
| SCR-EDU-15 Level + XP | ✅ (all) | ✅ (all) | ✅ (own) |
| **AI** | | | |
| SCR-AI-01 AI Assistant | ✅ | ✅ | ✅ |
| SCR-AI-02 AI Tutor | ✅ | ✅ | ✅ |
| SCR-AI-03 AI recommendations | ✅ | ❌ | ✅ |
| SCR-AI-04 Recitation analysis | ❌ | ❌ | ✅ |
| SCR-AI-05 Smart recommendations | ✅ | ✅ | ✅ |
| **Administration** | | | |
| SCR-ADM-01 Admin hub | ✅ | ❌ | ❌ |
| SCR-ADM-02 Members | ✅ | ❌ | ❌ |
| SCR-ADM-03 Devices | ✅ | ❌ | ❌ |
| SCR-ADM-04 Premium + Paywall | ✅ | ❌ | ❌ |
| SCR-ADM-05 Notifications | ✅ (all) | ✅ (own) | ✅ (own) |
| SCR-ADM-06 Settings | ✅ (all) | ✅ (own) | ✅ (own) |
| SCR-ADM-07 Child privacy | ✅ | ❌ | ❌ |
| SCR-ADM-08 Export + delete | ✅ | ✅ | ❌ |
| SCR-ADM-09 Today Dashboard | ✅ | ✅ | ❌ |
| SCR-ADM-10 School schedule | ✅ | ❌ | ❌ |
| SCR-ADM-11 Trial | ✅ | ❌ | ❌ |

---

## 2. Father-Exclusive Screens (8)

These screens are HARD-HIDDEN from Mother (not configurable):

| # | Screen | Reason |
|---|--------|--------|
| 1 | SCR-PAR-06 Safe Zones | Geofence management = full surveillance config |
| 2 | SCR-PAR-07 App Rules | App blocking = device control |
| 3 | SCR-PAR-08 Web Filter | Web filtering = content control |
| 4 | SCR-PAR-11 Kill Switch | Internet pause = ultimate control |
| 5 | SCR-PAR-12 Anti-bypass | Tamper protection = system security |
| 6 | SCR-ADM-02 Members | Family membership management |
| 7 | SCR-ADM-03 Devices | Device registration + permissions |
| 8 | SCR-ADM-07 Child Privacy | Privacy boundary configuration |

---

## 3. Mother Permissions (Configurable by Father)

The father can open specific permissions to the mother via `mother_permissions`:

| Permission Key | Default | Effect when granted |
|----------------|---------|---------------------|
| `view_content_alerts` | ✅ Granted | Mother sees content alert feed (SCR-PAR-09) |
| `view_safe_zones` | ❌ Denied | Mother can view (not edit) safe zones |
| `manage_school_time` | ❌ Denied | Mother can configure School Time (SCR-PAR-10) |
| `approve_extra_time` | ❌ Denied | Mother can approve child's extra time requests |
| `create_assignments` | ✅ Granted | Mother can create assignments and quizzes |
| `grade_assignments` | ✅ Granted | Mother can grade assignments (manual override) |
| `view_all_children` | ✅ Granted | Mother sees all children's data |
| `export_data` | ✅ Granted | Mother can export family data |
| `manage_notifications` | ✅ Granted | Mother can manage notification preferences |
| `edit_calendar` | ✅ Granted | Mother can create/edit calendar events |
| `manage_tasks` | ✅ Granted | Mother can create/assign tasks |

---

## 4. Android Permissions Matrix

| Android Permission | Required By | Denial Impact | Denial Recovery |
|--------------------|-------------|---------------|-----------------|
| `ACCESSIBILITY_SERVICE` | App blocking, Web filter, Content alerts, Anti-bypass, Device lock, School Time | Monitoring non-functional | Dialog → explain → "Open Settings" |
| `USAGE_STATS` | Screen time tracking | Screen time limits non-functional | Dialog → explain → "Open Settings" |
| `ACCESS_FINE_LOCATION` | GPS tracking, Geofences, SOS location | Location features non-functional | Dialog → explain → request again |
| `ACCESS_BACKGROUND_LOCATION` | Background location tracking | Live location breaks when app backgrounded | Dialog → explain "always allow" |
| `SYSTEM_ALERT_WINDOW` | Device lock overlay | Instant lock non-functional | Dialog → explain → "Open Settings" |
| `RECORD_AUDIO` | Voice messages, Quran recitation | Voice features non-functional | Dialog → explain → request again |
| `FOREGROUND_SERVICE` | Background monitoring service | Monitoring stops when app backgrounded | Required at install |
| `RECEIVE_BOOT_COMPLETED` | Auto-start on boot | Anti-bypass weakened | Required at install |
| `POST_NOTIFICATIONS` | Push notifications | Notifications non-functional | Dialog → explain → request again |
| `BIND_DEVICE_ADMIN` | Anti-bypass, Device lock (DPM) | Uninstall prevention broken | Required during onboarding |
| `VPN_SERVICE` | Kill Switch (local VPN) | Kill Switch non-functional | Dialog → explain → request |
| `READ_MEDIA_IMAGES` | Media sharing (images) | Cannot send images | Dialog → request |
| `READ_MEDIA_VIDEO` | Media sharing (video) | Cannot send video | Dialog → request |
| `CALL_PHONE` | SOS auto-call | Cannot auto-call parent | Dialog → request |
| `SCHEDULE_EXACT_ALARM` | Bedtime schedule, School Time | Scheduled enforcement delayed | Dialog → request |

---

## 5. Enforcement Layers

| Layer | Technology | What it enforces |
|-------|-----------|------------------|
| **App (UI)** | Riverpod providers + GoRouter redirects | Screen visibility, button visibility, action availability |
| **App (Logic)** | Repository/service layer checks | Business rule enforcement before API call |
| **API** | Cloud Functions auth context | Role + family membership validation on every call |
| **Database** | PostgreSQL RLS policies | Row-level isolation by family_id + user_id |
| **Firestore** | Security Rules | Document-level isolation by family_id |
| **Storage** | Firebase Storage Rules | File access by family membership |

---

## 6. Permission Denial Recovery Flow

```
Permission Required
    ↓
Check if granted
    ↓
[Granted] → Proceed
    ↓ [Not Granted]
Show explanation dialog:
  "هذه الميزة تحتاج صلاحية [X] لأن [Y]. بدونها، [Z] لن يعمل."
  Buttons: [منح الصلاحية] [فتح الإعدادات] [ليس الآن]
    ↓
[منح الصلاحية] → System permission dialog → [Granted] → Proceed / [Denied] → Show fallback
[فتح الإعدادات] → Open Android Settings → User grants manually → Return → Re-check
[ليس الآن] → Feature disabled, show banner on relevant screen
    ↓
[Permanently Denied] → Only "فتح الإعدادات" button (system won't show dialog again)
```

---

## 7. Trial-Expired Feature Gating

| Feature | Free Tier | Premium Required |
|---------|:---:|:---:|
| Family chat | ✅ | — |
| 1:1 chat | ✅ | — |
| SOS | ✅ | — |
| Family calendar | ✅ | — |
| Basic tasks/shopping | ✅ | — |
| Screen time basic | ✅ | — |
| Location view | ✅ | — |
| Advanced monitoring (29 categories) | ❌ | ✅ |
| Kill Switch | ❌ | ✅ |
| Anti-bypass | ❌ | ✅ |
| School Time | ❌ | ✅ |
| AI Assistant | ❌ | ✅ |
| AI Tutor | ❌ | ✅ |
| AI auto-grading | ❌ | ✅ |
| AI recitation analysis | ❌ | ✅ |
| Adaptive learning | ❌ | ✅ |
| Placement test | ❌ | ✅ |
| XP + levels | ❌ | ✅ |
| Smart recommendations | ❌ | ✅ |
| Translation | ❌ | ✅ |
| Voice transcription | ❌ | ✅ |

> When trial expires, premium features show a **trial-expired state** with a "اشترك الآن" (Subscribe Now) button linking to SCR-ADM-04.
