---
title: "Contradictions, Duplicates & Resolutions"
tags: [requirements, contradictions, audit, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification
---

# Contradictions, Duplicates & Resolutions

> All contradictions discovered during analysis, with resolution and rationale.

---

## 1. Critical Contradictions (6)

### C-01: P0 Service Count — 55 vs 71 vs 91

| Source | Count |
|--------|-------|
| Original analysis | ~55 |
| Enhanced analysis | ~71 |
| Enhanced planning | 91 |
| Product Constitution | 91 (frozen) |

**Resolution:** **91 P0 services** — frozen by owner in Constitution. The 91 includes 20 new P0 services added from competitive analysis (S-COM-041/044/048/052, S-PAR-038/041/045/052, S-EDU-047/051/052/058, AI-020, S-ADM-033/035/038) plus 4 services promoted from P1 to P0 (S-PAR-003/012/016/018).

**Rationale:** Enhanced planning integrates original analysis + competitive analysis + AI capabilities. It is the most complete and was frozen by owner.

---

### C-02: Authentication — Phone OTP vs Email/Password

| Source | Method |
|--------|--------|
| Original analysis + scenarios | Phone number + OTP |
| Product Constitution (frozen) | Firebase Auth Email/Password + biometric optional |
| UI Scope Freeze (frozen) | Email + password; phone ≠ login |

**Resolution:** **Email/Password** — frozen by Constitution. Phone number is for communication only, not authentication.

**Rationale:** Owner decision. Email is more reliable for family accounts (children may not have phones). Screens `SCR-SHR-02` / `SCR-SHR-03` updated for email flow.

**Impact:** All scenarios referencing phone OTP are deprecated for MVP. Login flow uses email + password + optional biometric.

---

### C-03: AI-007 Definition — Translation vs Behavior Analysis

| Source | AI-007 Definition |
|--------|-------------------|
| P0 planning file (2-4) | Real-time translation |
| Backlog file (enhanced) | Behavior analysis + recommendations |
| Service-to-Screen matrix | Maps to SCR-AI-03 "توصيات AI" |
| Traceability P0 | Maps to SCR-AI-03 |

**Resolution:** **AI-007 = توصيات محتوى تعليمي (Educational content recommendations)** — per the frozen Service-to-Screen matrix and Screen ID Catalog. Translation is S-COM-044 (a Communications service using Gemini).

**Rationale:** The Screen ID Catalog (frozen) maps AI-007 to `SCR-AI-03` "توصيات AI", not a translation screen. Translation has its own service S-COM-044 → `SCR-COM-09`. The backlog file's definition was a mislabel.

---

### C-04: Local Database — Isar vs Drift

| Source | Local DB |
|--------|----------|
| Full design document | "Isar/Drift" (ambiguous) |
| Product Constitution (frozen) | **Drift (SQLite)** — not Isar |
| UI Scope Freeze (frozen) | Drift (SQLite) |

**Resolution:** **Drift (SQLite)** — frozen by Constitution. Isar is excluded.

**Rationale:** Drift provides better SQLite compatibility, migration support, and query capabilities for offline-first architecture. Owner decision.

---

### C-05: Kill Switch Mechanism — VPN vs AccessibilityService

| Source | Mechanism |
|--------|-----------|
| Enhanced analysis | VPN to stop internet |
| Original analysis | AccessibilityService for monitoring |
| Conflicts file resolution | Both |

**Resolution:** **Both VPN + AccessibilityService** — VPN stops internet traffic; AccessibilityService prevents bypass of the lock. Documented in `activity-kill-switch` and `activity-anti-bypass`.

**Rationale:** VPN alone can be bypassed by killing the app; AccessibilityService prevents uninstallation and force-stop. Together they form a robust anti-bypass layer.

---

### C-06: Jetpack Compose — Referenced but Forbidden

| Source | Position |
|--------|----------|
| Some analysis files | References Jetpack Compose |
| Product Constitution (frozen) | "No Jetpack Compose as UI" |

**Resolution:** **Flutter is the product UI. Jetpack Compose is forbidden as UI.** Kotlin/Java only for native bridges (AccessibilityService, FusedLocationProvider, etc.).

**Rationale:** Owner decision. Single UI layer reduces complexity and ensures cross-platform future (iOS).

---

## 2. Duplicates (3)

### D-01: SOS Across Two Systems

| Service | System | Role |
|---------|--------|------|
| S-COM-039 | Communications | SOS button + family notification |
| S-PAR-032 | Monitoring | Live location broadcast for emergency |

**Resolution:** **Two separate services, one screen** (`SCR-COM-07`). S-COM-039 owns the SOS trigger and notification; S-PAR-032 owns the live location stream during the emergency. Not a duplicate — intentional integration.

---

### D-02: School Time Across Two Systems

| Service | System | Role |
|---------|--------|------|
| S-PAR-052 | Monitoring | Executes app blocking during school hours |
| S-ADM-035 | Administration | Configures the school schedule (Hijri) |

**Resolution:** **Intentional integration** — Admin configures, Monitoring executes. Shared table: `school_time_schedules`. Screens: `SCR-PAR-10` (toggle) + `SCR-ADM-10` (schedule editor).

---

### D-03: AI Tutor Across Two Systems

| Service | System | Role |
|---------|--------|------|
| S-EDU-046 | Education | User journey + screen |
| AI-003 | AI | Engine + capability |

**Resolution:** **Intentional integration** — Education owns the user-facing experience (`SCR-EDU-11` / `SCR-AI-02`); AI owns the Gemini-powered engine behind the scenes.

---

## 3. Terminology Normalization

| Original Term | Normalized Term | Reason |
|---------------|-----------------|--------|
| نظام التواصل | Communications (`S-COM`) | Consistent with service IDs |
| نظام المراقبة | Parental Monitoring (`S-PAR`) | "Monitoring" not "Control" — aligns with Safety Over Surveillance principle |
| نظام التعليم | Education (`S-EDU`) | |
| نظام الذكاء الاصطناعي | AI (`AI`) | |
| نظام الإدارة | Administration (`S-ADM`) | |
| وقت الشاشة | Screen Time | |
| مناطق آمنة | Safe Zones (Geofences) | |
| قفل الجهاز | Device Lock | |
| وضع المدرسة | School Time | |
| وضع التركيز | Focus Mode | |
| المساعد الذكي | AI Assistant | |
| المعلم الخصوصي | AI Tutor | |
| لوحة اليوم | Today Dashboard | |
| الصلاحيات الحسّاسة | Sensitive Permissions | |
| الأدوار | Roles | |
| الأب | Father (`admin`) | |
| الأم | Mother (`limited_admin`) | |
| الابن | Child (`child`) | |

---

## 4. Deprecated Items

| Item | Status | Reason |
|------|--------|--------|
| Phone OTP authentication | Deprecated | Replaced by Email/Password |
| Isar as local DB | Deprecated | Replaced by Drift |
| Jetpack Compose as UI | Deprecated | Flutter is sole UI |
| `SCR-SHR-07` (child transparency high) | Cancelled | Owner decision — low transparency only |
| Old P0 count (55) | Deprecated | Replaced by 91 |
| Screen viewer (MVP) | Deferred to P2 | No MVP screen |
| SMS reading (MVP) | Deferred to P1 | No MVP screen |
| Call log (MVP) | Deferred to P1 | No MVP screen |
| One-way audio (MVP) | Deferred to P2 | No MVP screen |

---

## 5. Architecture Conflicts Found & Fixed

| # | Conflict | Fix |
|---|----------|-----|
| AC-01 | No Offline-First architecture designed | Added Offline Architecture spec (`06_system_architecture/03_OFFLINE_ARCHITECTURE.md`) |
| AC-02 | No Unified Event Model | Added Event Model (`07_behavioral_architecture/02_EVENT_MODEL.md`) |
| AC-03 | No API contracts | Added Integration Model (`11_integrations/01_INTEGRATION_MODEL.md`) |
| AC-04 | No Observability/Operations | Added Operations spec (`14_operations/01_OBSERVABILITY_AND_OPS.md`) |
