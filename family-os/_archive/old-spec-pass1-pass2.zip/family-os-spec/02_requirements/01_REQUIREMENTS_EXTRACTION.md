---
title: "Requirements Extraction — All Systems"
tags: [requirements, extraction, complete, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification
---

# Requirements Extraction — All Systems

> Extracted from 998 source files. Every requirement is classified and traced.

---

## 1. Requirements Classification System

| Status | Meaning |
|--------|---------|
| **Accepted** | Requirement confirmed and included in spec |
| **Duplicate** | Same requirement under different names — merged |
| **Contradictory** | Conflicts with another requirement — resolved (see contradictions file) |
| **Deprecated** | Superseded by a newer decision |
| **Assumption** | Inferred from context — needs human confirmation |
| **Open Decision** | Cannot be resolved from files — needs human input |
| **Missing** | Gap discovered during analysis |
| **Future Opportunity** | Not P0 but strategically valuable |
| **Rejected** | Explicitly excluded with reason |

---

## 2. System 1: Communications (S-COM) — 20 P0 Services

| ID | Service | P | Status | Notes |
|----|---------|---|--------|-------|
| S-COM-001 | محادثة عائلية جماعية | P0 | Accepted |强制性 family chat |
| S-COM-002 | محادثة فردية 1:1 | P0 | Accepted | |
| S-COM-003 | مجموعة فرعية | P0 | Accepted | Father-only creation |
| S-COM-004 | رد على رسالة | P0 | Accepted | |
| S-COM-006 | مكالمة صوت P2P | P0 | Accepted | LiveKit |
| S-COM-010 | وسائط (صور/فيديو/ملفات) | P0 | Accepted | Firebase Storage |
| S-COM-011 | تأكيد قراءة | P0 | Accepted | |
| S-COM-025 | إرسال ملف | P0 | Accepted | |
| S-COM-029 | إرسال صوت | P0 | Accepted | |
| S-COM-030 | إضافة حدث تقويمي | P0 | Accepted | Hijri mandatory |
| S-COM-031 | تعديل/حذف حدث | P0 | Accepted | |
| S-COM-032 | تذكيرات/مهام | P0 | Accepted | |
| S-COM-033 | قائمة تسوق مشتركة | P0 | Accepted | |
| S-COM-035 | بث موقع لحظي | P0 | Accepted | IA in monitoring |
| S-COM-036 | استطلاعات | P0 | Accepted | |
| S-COM-039 | SOS + كشف حوادث | P0 | Accepted | One screen SCR-COM-07 |
| S-COM-041🆕 | رسالة صوتية + تفريغ | P0 | Accepted | Whisper STT |
| S-COM-044🆕 | ترجمة لحظية | P0 | Accepted | Gemini translate |
| S-COM-048🆕 | ردود تفاعلية سريعة | P0 | Accepted | |
| S-COM-052🆕 | قفل محادثة | P0 | Accepted | Father only |

### P1–P3 Communications (Backlog)

| ID | Service | P | Status |
|----|---------|---|--------|
| S-COM-007 | مكالمة فيديو P2P | P1 | Accepted |
| S-COM-042 | جدولة رسائل | P1 | Accepted |
| S-COM-043 | مجلدات محادثات | P2 | Accepted |
| S-COM-045 | مكالمة جماعية | P2 | Accepted |
| S-COM-047 | مخطط وجبات + تسوق | P1 | Accepted — out of MVP UI |
| S-COM-049 | حالات/قصص عائلية | P1 | Accepted |
| S-COM-050 | رسائل مؤقتة | P1 | Accepted |
| S-COM-051 | ChoreAI | P1 | Accepted |
| S-COM-053 | ملصقات + خلفيات | P3 | Future Opportunity |

---

## 3. System 2: Monitoring (S-PAR) — 20 P0 Services

| ID | Service | P | Status | Notes |
|----|---------|---|--------|-------|
| S-PAR-001 | ضبط حد يومي وقت الشاشة | P0 | Accepted | UsageStatsManager |
| S-PAR-002 | تقارير الاستخدام | P0 | Accepted | |
| S-PAR-003 | جداول ذكية | P0 | Accepted | |
| S-PAR-005 | قفل فوري للجهاز | P0 | Accepted | Accessibility/Overlay |
| S-PAR-006 | جدول وقت النوم | P0 | Accepted | |
| S-PAR-009 | طلب وقت إضافي | P0 | Accepted | Child initiates |
| S-PAR-011 | تتبع GPS لحظي | P0 | Accepted | FusedLocationProvider |
| S-PAR-012 | سجل مواقع | P0 | Accepted | |
| S-PAR-014 | مناطق آمنة (Geofence) | P0 | Accepted | Father only |
| S-PAR-015 | حظر/سماح تطبيقات | P0 | Accepted | Accessibility |
| S-PAR-016 | قواعد فئات التطبيقات | P0 | Accepted | |
| S-PAR-017 | فلترة ويب | P0 | Accepted | Father only |
| S-PAR-018 | استثناءات ويب | P0 | Accepted | |
| S-PAR-021 | كشف كلمات مريبة (٢٩ فئة) | P0 | Accepted | AI-002 behind scenes |
| S-PAR-032 | تنبيه وصول/مغادرة | P0 | Accepted | Geofence event |
| S-PAR-034 | حالة Focus في المراقبة | P0 | Accepted | Display only |
| S-PAR-038🆕 | Anti-bypass | P0 | Accepted | VPN + Accessibility |
| S-PAR-041🆕 | Kill Switch | P0 | Accepted | Local VPN |
| S-PAR-045🆕 | ٢٩ فئة تنبيهات | P0 | Accepted | |
| S-PAR-052🆕 | School Time | P0 | Accepted | Hijri schedule |

### P1–P3 Monitoring (Backlog)

| ID | Service | P | Status |
|----|---------|---|--------|
| S-PAR-004 | مكافأة وقت إضافي | P1 | Accepted |
| S-PAR-007/008 | اتجاهات + تحليلات | P1 | Accepted |
| S-PAR-013 | أماكن متكررة | P1 | Accepted |
| S-PAR-019 | تصفح خفي | P1 | Accepted |
| S-PAR-024/025 | تيك توك + يوتيوب | P1 | Accepted |
| S-PAR-026/027 | مراقبة مكالمات + SMS | P1 | Accepted — no MVP screen |
| S-PAR-028 | عارض شاشة | P2 | Accepted — no MVP screen |
| S-PAR-029 | صور عن بُعد | P2 | Accepted |
| S-PAR-030 | صوت باتجاه واحد | P2 | Accepted — no MVP screen |
| S-PAR-031 | كشف صور حساسة | P2 | Accepted |
| S-PAR-037 | فلترة راوتر | P2 | Accepted |
| S-PAR-040 | Contact Watchlist | P1 | Accepted |
| S-PAR-043 | Camera lock | P2 | Accepted |
| S-PAR-044 | Sexting prevention | P1 | Accepted |
| S-PAR-046 | YouTube محسّن | P1 | Accepted |
| S-PAR-047 | Analytics متقدمة | P1 | Accepted |
| S-PAR-048 | Benchmark أقران | P3 | Future Opportunity |
| S-PAR-050 | تقرير قيادة | P1 | Accepted |
| S-PAR-051 | Gaming alerts | P1 | Accepted |
| S-PAR-053 | App approval | P1 | Accepted |
| S-PAR-054 | كشف عامية AI | P1 | Accepted |

---

## 4. System 3: Education (S-EDU) — 24 P0 Services

| ID | Service | P | Status | Notes |
|----|---------|---|--------|-------|
| S-EDU-001 | إضافة مادة | P0 | Accepted | |
| S-EDU-002 | عرض المواد | P0 | Accepted | |
| S-EDU-003 | إضافة درس | P0 | Accepted | |
| S-EDU-004 | عرض درس | P0 | Accepted | |
| S-EDU-009 | إنشاء واجب | P0 | Accepted | Hijri due date |
| S-EDU-010 | عرض واجب | P0 | Accepted | |
| S-EDU-011 | إرسال واجب | P0 | Accepted | |
| S-EDU-013 | تصحيح AI | P0 | Accepted | AI-004 |
| S-EDU-014 | حالة الواجب | P0 | Accepted | |
| S-EDU-017 | إنشاء اختبار | P0 | Accepted | |
| S-EDU-019 | أداء اختبار | P0 | Accepted | |
| S-EDU-020 | نتائج الاختبار | P0 | Accepted | |
| S-EDU-024 | نقاط | P0 | Accepted | Auto-grant |
| S-EDU-028 | شارات | P0 | Accepted | |
| S-EDU-029 | استبدال نقاط | P0 | Accepted | |
| S-EDU-034 | Focus Mode | P0 | Accepted | S-EDU-034 |
| S-EDU-035 | Focus timer | P0 | Accepted | |
| S-EDU-038 | تحفيظ قرآن | P0 | Accepted | MediaRecorder |
| S-EDU-039 | تلاوة قرآن | P0 | Accepted | |
| S-EDU-046 | معلم AI | P0 | Accepted | AI-003 |
| S-EDU-047🆕 | تعلم تكيفي | P0 | Accepted | |
| S-EDU-051🆕 | تمارين متدرجة | P0 | Accepted | |
| S-EDU-052🆕 | تقييم مستوى | P0 | Accepted | Placement test |
| S-EDU-058🆕 | XP + مستويات | P0 | Accepted | |

### P1–P3 Education (Backlog)

| ID | Service | P | Status |
|----|---------|---|--------|
| S-EDU-048 | أقسام تنافسية | P2 | Future |
| S-EDU-049 | مسارات بصرية | P1 | Accepted |
| S-EDU-053 | توصيات مهارات | P1 | Accepted |
| S-EDU-054 | قصص تفاعلية | P2 | Accepted |
| S-EDU-055 | كتابة إبداعية | P1 | Accepted |
| S-EDU-057 | تحديات يومية | P1 | Accepted |
| S-EDU-059 | Skill Gap reports | P1 | Accepted |
| S-EDU-060 | مكتبة فيديو | P1 | Accepted |

---

## 5. System 4: AI — 7 P0 Capabilities

| ID | Capability | P | Status | Notes |
|----|-----------|---|--------|-------|
| AI-001 | المساعد الذكي العائلي | P0 | Accepted | Gemini 2.5 Flash + RAG |
| AI-002 | تحليل مشاعر الرسائل | P0 | Accepted | Behind scenes → PAR-09 |
| AI-003 | معلم خصوصي | P0 | Accepted | AI tutor |
| AI-004 | تصحيح واجبات تلقائي | P0 | Accepted | → EDU-05 |
| AI-007 | توصيات محتوى تعليمي | P0 | Accepted | |
| AI-008 | تحليل تلاوة القرآن | P0 | Accepted | Whisper + Gemini |
| AI-020🆕 | توصيات تعليمية ذكية | P0 | Accepted | |

### P1–P3 AI (Backlog)

| ID | Capability | P | Status |
|----|-----------|---|--------|
| AI-005 | تحليل صور | P1 | Accepted |
| AI-006 | محادثة صوتية | P1 | Accepted |
| AI-009 | تحليل أنماط نوم/نشاط | P1 | Accepted |
| AI-010 | تلخيص محادثات غائبة | P1 | Accepted |
| AI-011 | تحليل سلوك + توصيات | P1 | Accepted |

---

## 6. System 5: Administration (S-ADM) — 20 P0 Services

| ID | Service | P | Status | Notes |
|----|---------|---|--------|-------|
| S-ADM-001 | لوحة الإدارة | P0 | Accepted | Father hub |
| S-ADM-002 | دعوة أعضاء | P0 | Accepted | Dynamic Links, father only |
| S-ADM-003 | إدارة الأدوار | P0 | Accepted | Father only |
| S-ADM-004 | قبول/رفض دعوة | P0 | Accepted | |
| S-ADM-006 | حدود العائلة (٦/٤/١) | P0 | Accepted | |
| S-ADM-009 | ربط جهاز طفل | P0 | Accepted | Father only |
| S-ADM-010 | إدارة أجهزة | P0 | Accepted | |
| S-ADM-013 | صلاحيات حسّاسة | P0 | Accepted | |
| S-ADM-014 | Premium ٤٩ ر.س | P0 | Accepted | Play Billing |
| S-ADM-016 | Paywall | P0 | Accepted | |
| S-ADM-020 | إشعارات — تفضيلات | P0 | Accepted | |
| S-ADM-022 | إشعارات — قنوات | P0 | Accepted | |
| S-ADM-023 | إشعارات — جدولة | P0 | Accepted | |
| S-ADM-026 | إعدادات + خصوصية | P0 | Accepted | |
| S-ADM-027 | اللغة AR/EN | P0 | Accepted | RTL/LTR |
| S-ADM-028 | خصوصية الطفل | P0 | Accepted | Father only |
| S-ADM-029 | تصدير + حذف | P0 | Accepted | GDPR/PDPL |
| S-ADM-033🆕 | لوحة اليوم | P0 | Accepted | Home for parents |
| S-ADM-035🆕 | جدول المدرسة (هجري) | P0 | Accepted | Feeds School Time |
| S-ADM-038🆕 | الفترة التجريبية ١٤ يوم | P0 | Accepted | |

---

## 7. Inferred Requirements (Added by Analysis)

### Essential (must have for system integrity)

| ID | Requirement | Justification | Status |
|----|-------------|---------------|--------|
| INF-001 | Offline sync conflict resolution | Offline-First requires this | Essential |
| INF-002 | Event bus / Unified Family Event Model | Cross-system reactivity | Essential |
| INF-003 | Permission denial recovery flow | UX contract requires it | Essential |
| INF-004 | Audit log for all sensitive actions | Security + compliance | Essential |
| INF-005 | Session management + token refresh | Auth lifecycle | Essential |
| INF-006 | Device registration + trust | Multi-device support foundation | Essential |
| INF-007 | Family state snapshot | Unified Family Context | Essential |
| INF-008 | Notification delivery guarantees | Safety alerts must arrive | Essential |

### Strongly Recommended

| ID | Requirement | Justification | Status |
|----|-------------|---------------|--------|
| INF-009 | Observability / crash reporting | Production reliability | Strongly Recommended |
| INF-010 | Feature flags | Safe rollout | Strongly Recommended |
| INF-011 | A/B testing framework | Conversion optimization | Strongly Recommended |
| INF-012 | Push notification analytics | Engagement tracking | Strongly Recommended |

### Strategic

| ID | Requirement | Justification | Status |
|----|-------------|---------------|--------|
| INF-013 | School integration API | B2B expansion path | Strategic |
| INF-014 | Web parent dashboard | Extended access | Strategic |
| INF-015 | Multi-language expansion framework | i18n beyond AR+EN | Strategic |
