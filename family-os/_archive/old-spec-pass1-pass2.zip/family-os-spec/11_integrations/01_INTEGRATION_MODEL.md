---
title: "Integrations & API Contracts"
tags: [integrations, api, contracts, binding]
created: 2026-09-13
phase: Unified World-Class Family Platform Specification
---

# Integrations & API Contracts

---

## 1. External Integrations

| Integration | Purpose | Required Data | Failure Behavior | Cost | Replaceable |
|-------------|---------|---------------|-----------------|------|-------------|
| Firebase Auth | Authentication | Email, password | App unusable | Free tier → paid | No (core) |
| Cloud Firestore | Real-time sync | All live data | Degrade to offline | Free tier → paid | No (core) |
| Cloud SQL (PostgreSQL) | System of record | All structured data | Degrade to offline | Paid | No (core) |
| Cloud Functions | Backend logic | All API calls | API unavailable | Free tier → paid | No (core) |
| FCM | Push notifications | Notification payload | Notification not delivered | Free | Yes (alternative: SMS) |
| Firebase Storage | Media storage | Files, images, audio | Media unavailable | Free tier → paid | Yes (S3) |
| Google Maps SDK | Maps + location | Lat/lng, markers | Map unavailable | $200/mo free credit | Yes (Mapbox) |
| LiveKit | WebRTC calls | Signaling, ICE | Calls unavailable | Self-hosted or cloud | Yes (Janus) |
| Gemini 2.5 Flash | AI capabilities | Text prompts | AI unavailable | $0.07–0.29/M tokens | Yes (Claude, GPT) |
| Whisper (STT) | Voice transcription | Audio | Transcription unavailable | $0.006/min | Yes (Gemini STT) |
| Pinecone | Vector store (RAG) | Embeddings | RAG unavailable | Free tier → paid | Yes (Weaviate) |
| Redis | Cache + rate limit | Key-value | Cache miss (slower) | Low | Yes (Memurai) |
| Google Play Billing | Subscriptions | Purchase tokens | Billing unavailable | 15% commission | No (Android only) |
| Firebase Dynamic Links | Invitations | Invite links | Invitations fail | Free | Yes (deep links) |

---

## 2. API Architecture

### 2.1 Communication Pattern

| Pattern | Technology | Use Case |
|---------|-----------|----------|
| REST API | Dio → Cloud Functions | All CRUD operations |
| Real-time | Firestore listeners | Messages, location, presence, typing |
| Push | FCM | Notifications |
| WebRTC | LiveKit | Voice/video calls |

### 2.2 API Design Principles

- RESTful resource-oriented design
- JSON request/response
- JWT auth via Firebase Auth
- RLS enforced at database level
- Rate limiting at Cloud Function level
- Idempotency keys for mutations
- Pagination via cursor for lists
- Error format: `{error: {code, message, details}}`

### 2.3 Key API Endpoints (P0)

#### Communications
```
POST   /api/conversations
GET    /api/conversations
POST   /api/messages
POST   /api/messages/{id}/read
POST   /api/messages/{id}/react
POST   /api/transcribe
POST   /api/translate
POST   /api/emergency/sos
POST   /api/emergency/{id}/resolve
POST   /api/location/update
GET    /api/calendar/events
POST   /api/calendar/events
GET    /api/tasks
POST   /api/tasks
```

#### Monitoring
```
GET    /api/screen-time/rules/{user_id}
POST   /api/screen-time/rules
POST   /api/devices/{id}/lock
POST   /api/devices/{id}/unlock
POST   /api/permission-requests
POST   /api/permission-requests/{id}/approve
POST   /api/permission-requests/{id}/deny
GET    /api/geofences
POST   /api/geofences
POST   /api/content-scan
POST   /api/internet/pause
POST   /api/internet/resume
GET    /api/school-time/schedule
POST   /api/school-time/schedule
```

#### Education
```
GET    /api/subjects
POST   /api/subjects
GET    /api/assignments
POST   /api/assignments
POST   /api/assignments/{id}/submit
GET    /api/quizzes
POST   /api/quizzes/{id}/attempt
POST   /api/placement/start
POST   /api/placement/{id}/answer
POST   /api/focus/start
POST   /api/focus/end
POST   /api/ai/quran/analyze
```

#### AI
```
POST   /api/ai/assistant
POST   /api/ai/tutor
POST   /api/ai/recommendations
```

#### Administration
```
POST   /api/families
POST   /api/invitations
POST   /api/invitations/{id}/accept
POST   /api/subscriptions
POST   /api/subscriptions/cancel
GET    /api/today-dashboard
GET    /api/notifications
POST   /api/notifications/{id}/read
POST   /api/settings
POST   /api/privacy
POST   /api/data/export
POST   /api/data/delete
POST   /api/mother-permissions
```

---

## 3. Internal Integration Contracts

### 3.1 Education → Safety (Focus Mode)

```
Education: focus.activated event
    ↓ payload: { user_id, blocked_categories: [entertainment, social, games] }
Safety: receives event → applies app_rules blocking
    ↓
Education: focus.deactivated event
    ↓
Safety: receives event → removes app_rules blocking
```

### 3.2 AI → Communications (Sentiment)

```
Comms: message.sent event
    ↓ payload: { message_id, body (transient) }
AI: receives event → Gemini sentiment analysis
    ↓ payload: { message_id, sentiment, intensity, bullying_risk }
Comms: if bullying_risk → FCM to parent
    ↓
Safety: if bullying_risk → content_alerts entry
```

### 3.3 Safety → Communications (Geofence)

```
Safety: geofence.entered/exited event
    ↓ payload: { user_id, geofence_name, event_type }
Comms: receives event → system message in family chat
    ↓
Admin: receives event → notification
```

### 3.4 Admin → All (Subscription)

```
Admin: subscription.activated/expired event
    ↓ payload: { family_id, plan_tier }
All domains: receive event → enable/disable features per plan
```
